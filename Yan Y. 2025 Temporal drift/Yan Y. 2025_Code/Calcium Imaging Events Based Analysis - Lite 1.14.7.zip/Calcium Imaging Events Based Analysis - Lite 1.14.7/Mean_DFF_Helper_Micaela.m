% Start with this
meandffvalue_allmice = [];
Opts.General.Suite2p_Format = 1;

% Load the file from one mouse, then run these 2 lines.
% Repeat for every mouse
tmp = double([wake, NREM, REM]);

meandffvalue_allmice = [meandffvalue_allmice; tmp];
