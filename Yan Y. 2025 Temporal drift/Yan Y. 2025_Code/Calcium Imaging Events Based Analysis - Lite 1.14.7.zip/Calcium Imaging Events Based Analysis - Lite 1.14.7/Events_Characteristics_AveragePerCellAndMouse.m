
n_mice = numel(Mouse_Names);
EventsTogether = [];
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    [CuttentMouse_Events] = separate_events_per_mouse (Events_AllSessions, MouseName);
    
    for i_session = 1:nanmax([CuttentMouse_Events.Session])
        CurrentSession_Index = [CuttentMouse_Events.Session];
        CurrentSession_Events = CuttentMouse_Events(CurrentSession_Index == i_session);
        
        Current_TraceNumber = [CurrentSession_Events.TraceNumber];
        n_cells = nanmax(Current_TraceNumber);
        
        for i_cell = 1:n_cells
            CurrentCell_Index = [CurrentSession_Events.TraceNumber];
            CurrentCell_Events = CurrentSession_Events(CurrentCell_Index == i_cell);
            
            Events_Awake = separate_events_per_state (CurrentCell_Events, 1);
            Events_NREM = separate_events_per_state (CurrentCell_Events, 2);
            Events_REM = separate_events_per_state (CurrentCell_Events, 4);
            
            % Integral
            Events.Awake(i_cell).Integral_Avg = nanmean([Events_Awake.Integral]);
            Events.NREM(i_cell).Integral_Avg = nanmean([Events_NREM.Integral]);
            Events.REM(i_cell).Integral_Avg = nanmean([Events_REM.Integral]);
            
            % Amplitude
            Events.Awake(i_cell).Amplitude_Avg = nanmean([Events_Awake.Amp_Baseline]);
            Events.NREM(i_cell).Amplitude_Avg = nanmean([Events_NREM.Amp_Baseline]);
            Events.REM(i_cell).Amplitude_Avg = nanmean([Events_REM.Amp_Baseline]);
            
            % Integral
            Events.Awake(i_cell).Integral_StE = nanstd([Events_Awake.Integral])./sqrt(n_cells);
            Events.NREM(i_cell).Integral_StE = nanstd([Events_NREM.Integral])./sqrt(n_cells);
            Events.REM(i_cell).Integral_StE = nanstd([Events_REM.Integral])./sqrt(n_cells);
            
            % Amplitude
            Events.Awake(i_cell).Amplitude_StE = nanstd([Events_Awake.Amp_Baseline])./sqrt(n_cells);
            Events.NREM(i_cell).Amplitude_StE = nanstd([Events_NREM.Amp_Baseline])./sqrt(n_cells);
            Events.REM(i_cell).Amplitude_StE = nanstd([Events_REM.Amp_Baseline])./sqrt(n_cells);
        end
        
        EventsTogether = [EventsTogether; Events];
        
        Events_Session{i_session} = Events;
        clear Events
    end
    Events_CellAverages_perMouse_perSession{i_mouse} = Events_Session;
    clear Events_Session
end
