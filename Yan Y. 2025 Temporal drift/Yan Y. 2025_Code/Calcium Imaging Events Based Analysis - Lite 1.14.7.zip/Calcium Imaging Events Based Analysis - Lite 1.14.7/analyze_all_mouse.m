% Analyze all mice.
% For most options (directories included) check in the set_options function

warning('off', 'MATLAB:chckxy:IgnoreNaN'); % Ignore spline interpolation warning messages.

% Add Default Directories
Dir_Main = pwd;
addpath(genpath(Dir_Main));
addpath(genpath('Z:\Lab_resources\calcium_imaging_toolbox'));

% Add Data Directories.
fprintf('Please Specify the Data Folder.\n\n')
Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');
% fprintf('Please Specify the EEG Data Folder.\n\n')
% Dir_EEGData = uigetdir(Dir_Main, 'Choose EEG Data Folder');


% Options
Opts = set_options (Dir_Main, Dir_Data);
FLAG_Split_MiniscopeData = 0; % Split Christina Data in different folders+files
FLAG_Christina_TEST = 0;
Test_Signal_Length = 1000;
Set_Hypnogram_NaN = 1;
Set_Hypnogram_3to4 = 1;
FLAG_Cut_Hypnogram_0s = 1;
Resample_Hypno = 1;

Opts.General.Suite2p_Format = 1;


% Get Mice Names (from folder structure)
cd(Dir_Data); tmp_list = dir; cd(Dir_Main);
tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
Mouse_Folders = tmp_list;
clear tmp*

Mouse_Names = cell(numel(Mouse_Folders), 1);
Mouse_Sessions = zeros(numel(Mouse_Folders), 1);
i_mouse_name = 1;
for i_mouse = 1:numel(Mouse_Folders)
    Mouse_Names{i_mouse_name} = Mouse_Folders(i_mouse).name;
    tmp_folder = sprintf('%s\\%s', Dir_Data, Mouse_Names{i_mouse_name});
    cd(tmp_folder); tmp_list = dir; cd(Dir_Main);
    tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
    if ~isempty(tmp_list)
        Mouse_Sessions(i_mouse) = numel(tmp_list);
        i_mouse_name = i_mouse_name + 1;
    else
        error('Mouse "%s" contains no sessions.\n\n', Mouse_Names{i_mouse_name});
    end
end
n_mice = numel(Mouse_Names);
n_sessions = nansum(Mouse_Sessions);

% Split Miniscope data if needed, and get new Mouse Names + Sessions
if FLAG_Split_MiniscopeData == 1
    fprintf('\nSplitting Concatenated Miniscope Sessions into separate folders+files...\n...\n');
    for i_mouse = 1:n_mice
        MouseName = Mouse_Names{i_mouse};
        CurrentMouseFolder = sprintf('%s\\%s', Opts.Dir_Data, MouseName);
        cd(CurrentMouseFolder)
        SubFoldersList = dir;
        cd(Opts.Dir_Main)
        
        SubFoldersList(1:2) = []; % Remove "." and ".." elements
        SubFilesList = SubFoldersList;
        SubFoldersList([SubFoldersList.isdir] == 0) = []; % Remove non-folder elements
        SubFilesList([SubFilesList.isdir] == 1) = []; % Remove folder elements
        n_files = numel(SubFilesList);
        n_sessionfolders = numel(SubFoldersList);
        if n_files > 0 % If more than 1 file is detected in the main folder
            error('The mouse folder %s must not contain any files. Put the file for splitting in the subfolder "session_1"\n', MouseName)
        end
        if n_sessionfolders > 1 % If more than 1 folders are detected
            fprintf('More than one session folders for mouse %s.\n', MouseName)
            fprintf('Data was considered as already split.\n')
            continue
        end

        i_session = 1;
        [CalciumTraces, Hypnogram, ~, ~, ~, SessionStarts] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
        n_sessions = numel(SessionStarts - 1);
        SplitConcatMiniscopeData (CalciumTraces, Hypnogram, SessionStarts, n_sessions, MouseName, Opts);
    end
    clear CalciumTraces; clear Hypnogram; clear SessionStarts;
    clear SubFoldersList; clear n_sessionfolders; clear CurrentMouseFolder
    % Get again the sessions structure
    Mouse_Names = cell(numel(Mouse_Folders), 1);
    Mouse_Sessions = zeros(numel(Mouse_Folders), 1);
    i_mouse_name = 1;
    for i_mouse = 1:numel(Mouse_Folders)
        Mouse_Names{i_mouse_name} = Mouse_Folders(i_mouse).name;
        tmp_folder = sprintf('%s\\%s', Dir_Data, Mouse_Names{i_mouse_name});
        cd(tmp_folder); tmp_list = dir; cd(Dir_Main);
        tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
        if ~isempty(tmp_list)
            Mouse_Sessions(i_mouse) = numel(tmp_list);
            i_mouse_name = i_mouse_name + 1;
        else
            error('Mouse "%s" contains no sessions.\n\n', Mouse_Names{i_mouse_name});
        end
    end
    n_mice = numel(Mouse_Names);
    n_sessions = nansum(Mouse_Sessions);
end



%% Analyze All Mice.
Removed_Candidate_Events = NaN(1, n_mice);
CalciumTraces_Clean_AllSessions = cell(1, n_sessions);
MouseCellsRecorded = NaN(1, n_mice);
Hypnogram_AllSessions = struct;

% Initializing waitbar.
prog_bar = waitbar(0, 'Cylon virus detected!', 'Name', 'Detecting events...',...
    'CreateCancelBtn',...
    'setappdata(gcbf,''canceling'',1)');

% 1st mouse separated to define "Events_AllMice" struct
i_mouse_ses = 1;
for i_mouse = 1:1
    % Get Mouse Name
    MouseName = Mouse_Names{i_mouse};
    Opts.SingleTraceAnalysis.MouseName = MouseName;
    n_current_sessions = Mouse_Sessions(i_mouse);
    fprintf('\n~~~~~~ Getting Calcium Events for Mouse "%s" ~~~~~~\n\n', MouseName);
    for i_session = 1:1
        % Update waitbar
        waitbar(0/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', 0, n_sessions));
        if getappdata(prog_bar, 'canceling')
            delete(prog_bar);
            warning('Operation cancelled by user.');
            return
        end
        % Load Calcium Data & EEG Classification (Hypnogram)
        if strcmpi (Opts.General.CellType, 'Pyr')
            CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session);
            Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session);
        elseif strcmpi (Opts.General.CellType, 'Astro')
            [CalciumTraces, Hypnogram, EEG1, EMG, TTL, SessionStarts] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
        end
        if FLAG_Christina_TEST == 1 % Just to test the analysis, to remove after testing
            Hypnogram(Hypnogram == 0) = 1;
        end
        if Set_Hypnogram_NaN == 1
            Hypnogram(isnan(Hypnogram)) = []; % <--------------------------------------------
        end
        if Set_Hypnogram_3to4 == 1
            Hypnogram(Hypnogram == 3) = 4;
        end
        if Resample_Hypno == 1
            [tmp_dim1, tmp_dim2] = size(CalciumTraces);
            nnn = numel(Hypnogram)/tmp_dim1;
            yyy = downsample(Hypnogram, 100);
            Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
        end
        if FLAG_Cut_Hypnogram_0s == 1
            if numel(Hypnogram(Hypnogram == 0))
                warning('The Hypnogram had some 0 values, the corresponding frames have been cut form the analysis.')
                CalciumTraces(Hypnogram == 0, :) = [];
            end
        end
        
        % Get the EEG classification time.
        calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
        
        % Analyze!
        fprintf('\n    Analyzing Session #%d\n', i_session);
        [Events_AllSessions, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, 1}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
        Removed_Candidate_Events(1) = n_removed;
        HypnoState(1).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
        HypnoState(1).MouseName = MouseName;
        HypnoState(1).Session = i_session;
            
        % Add Mouse Tag & Cell Tag
        for i_tmp = 1:numel(Events_AllSessions)
            Events_AllSessions(i_tmp).MouseTag = MouseName;
            Events_AllSessions(i_tmp).Session = i_session;
            Events_AllSessions(i_tmp).Composite.MouseTag = MouseName;
            Events_AllSessions(i_tmp).Composite.Session = i_session;
        end
    end
    Hypnogram_AllSessions(1).Hypnogram = Hypnogram;
    Hypnogram_AllSessions(1).StateChanges = StateChanges;
    Hypnogram_AllSessions(1).calTime = calTime;
    Hypnogram_AllSessions(1).StateDuration_Array = StateLength;
    Hypnogram_AllSessions(1).MouseName = MouseName;
    Hypnogram_AllSessions(1).Session = 1;
    
    if n_current_sessions > 1
        for i_session = 2:n_current_sessions
            % Update waitbar
            waitbar(i_mouse_ses/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', i_mouse_ses, n_sessions));
            if getappdata(prog_bar, 'canceling')
                delete(prog_bar);
                warning('Operation cancelled by user.');
                return
            end
            i_mouse_ses = i_mouse_ses + 1;
            % Load Calcium Data & EEG Classification (Hypnogram)
            if strcmpi (Opts.General.CellType, 'Pyr')
                CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session);
                Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session);
            elseif strcmpi (Opts.General.CellType, 'Astro')
                [CalciumTraces, Hypnogram, EEG1, EMG, TTL] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
            end
            if FLAG_Christina_TEST == 1 % Just to test the analysis, to remove after testing
                Hypnogram(Hypnogram == 0) = 1;
            end
            
            if Set_Hypnogram_NaN == 1
                Hypnogram(isnan(Hypnogram)) = []; % <--------------------------------------------
            end
            if Set_Hypnogram_3to4 == 1
                Hypnogram(Hypnogram == 3) = 4;
            end

            if Resample_Hypno == 1
                [tmp_dim1, tmp_dim2] = size(CalciumTraces);
                nnn = numel(Hypnogram)/tmp_dim1;
                yyy = downsample(Hypnogram, 100);
                Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
            end
            if FLAG_Cut_Hypnogram_0s == 1
                if numel(Hypnogram(Hypnogram == 0))
                    warning('The Hypnogram had some 0 values, the corresponding frames have been cut form the analysis.')
                    CalciumTraces(Hypnogram == 0, :) = [];
                end
            end
            
            % Get the EEG classification time.
            calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
            
            % Analyze!
            fprintf('\n    Analyzing Session #%d\n\n', i_session);
            [Events_MouseAllTraces, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, i_mouse_ses}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
            Removed_Candidate_Events(1) = n_removed;
            HypnoState(i_mouse_ses).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
            HypnoState(i_mouse_ses).MouseName = MouseName;
            HypnoState(i_mouse_ses).Session = i_session;
            
            % Add Mouse Tag & Cell Tag
            for i_tmp = 1:numel(Events_MouseAllTraces)
                Events_MouseAllTraces(i_tmp).MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Session = i_session;
                Events_MouseAllTraces(i_tmp).Composite.MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Composite.Session = i_session;
            end
            Events_AllSessions = [Events_AllSessions, Events_MouseAllTraces];

            Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
            Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
            Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
            Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
            Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
            Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
            
            fprintf('\n    Completed Analysis for Session %d\n\n', i_session);
        end
    end
    [~, MouseCellsRecorded(i_mouse)] = size(CalciumTraces);
    fprintf('\n--- Completed Analysis for Mouse "%s" ---\n\n', MouseName);
end 

% All other mice
if n_mice > 1
    for i_mouse = 2:n_mice
        % Get Mouse Name
        MouseName = Mouse_Names{i_mouse};
        Opts.SingleTraceAnalysis.MouseName = MouseName;
        n_current_sessions = Mouse_Sessions(i_mouse);
        fprintf('\n~~~~~~ Getting Calcium Events for Mouse "%s" ~~~~~~\n\n', MouseName);
        for i_session = 1:n_current_sessions
            % Update waitbar
            waitbar(i_mouse_ses/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', i_mouse_ses, n_sessions));
            if getappdata(prog_bar, 'canceling')
                delete(prog_bar);
                warning('Operation cancelled by user.');
                return
            end
        
            i_mouse_ses = i_mouse_ses + 1;
            Opts.SingleTraceAnalysis.CurrentSession = i_session;
            % Load Calcium Data & EEG Classification (Hypnogram)
            if strcmpi (Opts.General.CellType, 'Pyr')
                CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session);
                Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session);
            elseif strcmpi (Opts.General.CellType, 'Astro')
                [CalciumTraces, Hypnogram, EEG1, EMG, TTL] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
            end
            if FLAG_Christina_TEST == 1 % Just to test the analysis, to remove after testing
                % Correct Hypnogram state '0' to state '1'
                Hypnogram(Hypnogram == 0) = 1;
            end
            if Set_Hypnogram_NaN == 1
                Hypnogram(isnan(Hypnogram)) = []; % <--------------------------------------------
            end
            if Set_Hypnogram_3to4 == 1
                Hypnogram(Hypnogram == 3) = 4;
            end
            if Resample_Hypno == 1
                [tmp_dim1, tmp_dim2] = size(CalciumTraces);
                nnn = numel(Hypnogram)/tmp_dim1;
                yyy = downsample(Hypnogram, 100);
                Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
            end
            
            if FLAG_Cut_Hypnogram_0s == 1
                if numel(Hypnogram(Hypnogram == 0))
                    warning('The Hypnogram had some 0 values, the corresponding frames have been cut form the analysis.')
                    CalciumTraces(Hypnogram == 0, :) = [];
                end
            end
            
            % Get the EEG classification time.
            calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
            
            % Analyze!
            fprintf('\n    Analyzing Session #%d\n\n', i_session);
            [Events_MouseAllTraces, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, i_mouse_ses}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
            
            HypnoState(i_mouse_ses).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
            HypnoState(i_mouse_ses).MouseName = MouseName;
            HypnoState(i_mouse_ses).Session = i_session;
            Removed_Candidate_Events(i_mouse_ses) = n_removed;
            
            % Add Mouse Tag
            for i_tmp = 1:numel(Events_MouseAllTraces)
                Events_MouseAllTraces(i_tmp).MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Session = i_session;
                Events_MouseAllTraces(i_tmp).Composite.MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Composite.Session = i_session;
            end
            fprintf('\n    Completed Analysis for Session %d\n\n', i_session);
            
            % Get results together
            Events_AllSessions = [Events_AllSessions, Events_MouseAllTraces];
            
            Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
            Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
            Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
            Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
            Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
            Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
        end
        [~, MouseCellsRecorded(i_mouse)] = size(CalciumTraces);
        fprintf('\n--- Completed Analysis for Mouse "%s" ---\n\n', MouseName);
    end
end
n_sessions = numel(Hypnogram_AllSessions);
delete(prog_bar);
clear CalciumTraces


for i_tmp = 1:numel(Events_AllSessions)
    Events_AllSessions(i_tmp).CellTag = sprintf('%s_%d_%d', Events_AllSessions(i_tmp).MouseTag, Events_AllSessions(i_tmp).Session, Events_AllSessions(i_tmp).TraceNumber);
    Events_AllSessions(i_tmp).Composite.CellTag = Events_AllSessions(i_tmp).CellTag;
end
% Check which recordings have a specific state.
SessionHasState = SessionsCheckStates (Hypnogram_AllSessions, Opts);
Opts.n_mice = n_mice;
Opts.n_sessions = n_sessions;
Opts.Mouse_Sessions = Mouse_Sessions;
Opts.Mouse_N_Cells = MouseCellsRecorded;
Opts.SessionHasState = SessionHasState;

% Add info about duration of each state.
for i_session = 1:n_sessions
    n_states = numel(Hypnogram_AllSessions(i_session).StateChanges);
    for i_state = 1:n_states
        tmp_state_start = Hypnogram_AllSessions(i_session).StateChanges(i_state);
        if i_state ~= n_states
            tmp_state_end = Hypnogram_AllSessions(i_session).StateChanges(i_state+1) - 1;
        else
            tmp_state_end = numel(Hypnogram_AllSessions(i_session).Hypnogram);
        end
        Hypnogram_AllSessions(i_session).StateDuration(i_state) = tmp_state_end - tmp_state_start + 1;
        Current_State = Hypnogram_AllSessions(i_session).Hypnogram(Hypnogram_AllSessions(i_session).StateChanges(i_state));
        Hypnogram_AllSessions(i_session).StateType(i_state) = Current_State;
    end
end

clear tmp*
clear i_*

% Print Results Summary.
fprintf('Events detected = %d.\n', numel(Events_AllSessions));
fprintf('Events filtered = %d.\n', nansum(Removed_Candidate_Events));



%% Extra Analysis

% Events stats per state.
[Events_Data, MouseMeans] = Init_Plot_EventsPerState(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);

% Sync Analysis
[Sync_Stats, n_states_per_session] = sync_point_analysis (Events_AllSessions, Hypnogram_AllSessions, Opts);

% Analysis per State
State_Info_perSession = SingleState_Analysis_per_mouse(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
SingleState_Analysis_Plots(State_Info_perSession, Mouse_Names, Opts);

% Analysis of Continuous variables (Whole State Traces Correlation +
% Entropy; Sliding Window Correlation + Entropy)
[Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, Mouse_Analysis_CorrOrdered, MeanOfStates_CorrOrdered, CalciumTraces_Noisy_AllSessions, Stats_MeanOfStatesDifferences_PerSession, Stats_MeanOfStatesDifferences_PerMouse] = Continuous_Raw_Analysis (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);

% Analysis of binarized variables along sliding windows.
ContinuousResults = SyncPoint_Analysis_Continuous (Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);

% Phase State Analysis

% Separated Events Type Analysis
[EventsSinglets, EventsComposite, EventsSubComposite] = SeparateEventType (Events_AllSessions);
[MeanEvent_Singlets, MeanEvent_Composites, N_Events] = mean_event_per_state (EventsSinglets, EventsComposite, Opts);
plot_pie_v2(EventsSinglets, EventsComposite, HypnoState, pwd);
Opts.FLAG_Tonic = 1; % Singlet events
Hist_Results_Singlets = plot_histograms_v2(EventsSinglets, HypnoState, Opts);
Opts.FLAG_Tonic = 0; % Composite events
Hist_Results_Composites = plot_histograms_v2(EventsComposite, HypnoState, Opts);

Opts.FLAG_Tonic = 0; % Composite events
Hist_Results_Composites = plot_histograms_v2(Events_AllSessions, HypnoState, Opts);

f1_options.bins_width = 0.5;

% Max DFF Analysis
analyze_mattia_data
% Plot bar
plot_bar(Events_AllSessions, Mouse_Names, HypnoState, Hypnogram_AllSessions, pwd);


event_frequency_per_state(Events_AllSessions, Hypnogram, StateLength, Opts)

% Get the events frequency per single cell, per state, for every mouse and
% session together
EventsFrequency_allMice = mean_per_cell (Events_AllSessions, Mouse_Names, Opts);

% Cluster Data According to their state of major activity.
Opts.ClusteringVariable = 'Events_Rate'; % 'Events_Rate', 'N_Events', or 'Integral_Sum'
[CellsPerState_Results, CellTag_perMouse, CellTagNum_perMouse] = clustering_cells_activitybased (Events_AllSessions, Mouse_Names, Opts);
plot_clustering(CellTagNum_perMouse, Opts)


% Divide each trace per mouse, according to cell Tag

% Plot each trace average per state

% Divide the events per mouse, according to cell Tag

% Plot events shapes per state

% Plot events integrals etc..per state



%% Plots
if Opts.General.FLAG_Plots == 1
    % Plot Pie Chart of events frequency.
    % Plot Histograms
    Hist_Results = plot_histograms(Events_AllSessions, HypnoState, Opts.Dir_Figures);

    % Plot lags to previous State Change
    Sync2StateChange (Events_AllSessions, Mouse_Names, Opts)
    % Plot advance time to next State Change
    Sync2NextState (Events_AllSessions, Opts)
end