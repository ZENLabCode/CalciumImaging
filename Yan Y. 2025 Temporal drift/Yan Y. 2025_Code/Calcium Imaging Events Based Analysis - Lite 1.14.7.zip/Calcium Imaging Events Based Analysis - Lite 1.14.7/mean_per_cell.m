function EventsFrequency_allMice = mean_per_cell (Events_AllSessions, Mouse_Names, Opts)

n_mice = numel(Mouse_Names);
EventsFrequency_allMice = [];
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    [Events_Current_Mouse] = separate_events_per_mouse (Events_AllSessions, MouseName);
    EventsFrequency_perMouse = [];
    
    % Separate per session
    events_sessions = [Events_Current_Mouse.Session];
    n_sessions = nanmax(events_sessions);
    for i_session = 1:n_sessions
        [Events_Current_Session] = Events_Current_Mouse(events_sessions == i_session);
        
        % Separate per cell
        events_cellIDs = [Events_Current_Session.TraceNumber];
        n_cells = nanmax(events_cellIDs);
        for i_cell = 1:n_cells
            events_per_cell = Events_Current_Session(events_cellIDs == i_cell);
            
            % Separate per state
            for i_state = 1:4
                if i_state == 3
                    continue
                end
                Events_perState = separate_events_per_state (events_per_cell, i_state);
                StatesDuration = unique([Events_perState.StateLength]);
                StatesDuration = nansum(StatesDuration);
                State_Length = StatesDuration./Opts.General.FrameRate; % [s]
                tmp1_EventsFrequency = numel(Events_perState)./State_Length;
                if i_state == 1
                    EventsFrequency(i_cell).Awake = tmp1_EventsFrequency;
                end
                if i_state == 2
                    EventsFrequency(i_cell).NREM = tmp1_EventsFrequency;
                end
                if i_state == 4
                    EventsFrequency(i_cell).REM = tmp1_EventsFrequency;
                end                
            end
        end
        EventsFrequency_perSession = EventsFrequency;
        if n_sessions > 1
            EventsFrequency_perMouse = [EventsFrequency_perMouse, EventsFrequency];
        else
            EventsFrequency_perMouse = EventsFrequency_perSession;
        end
        clear EventsFrequency
    end
    EventsFrequency_allMice = [EventsFrequency_allMice, EventsFrequency_perMouse];
end