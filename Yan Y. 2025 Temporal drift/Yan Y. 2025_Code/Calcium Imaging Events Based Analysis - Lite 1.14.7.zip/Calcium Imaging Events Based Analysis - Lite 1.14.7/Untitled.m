
All_Total_FR_PerState_7 = [];

for i = 1:numel(CellsPerState_Results_7)
    All_Total_FR_PerState_7 = [CellsPerState_Results_7(i).Total_FR_Stable; All_Total_FR_PerState_7];
end
All_Total_FR_PerState_7(:, 3) = [];


All_Total_FR_PerState_10 = [];

for i = 1:numel(CellsPerState_Results_10)
    All_Total_FR_PerState_10 = [CellsPerState_Results_10(i).Total_FR_Stable; All_Total_FR_PerState_10];
end
All_Total_FR_PerState_10(:, 3) = [];


All_Total_FR_PerState_13 = [];

for i = 1:numel(CellsPerState_Results_13)
    All_Total_FR_PerState_13 = [CellsPerState_Results_13(i).Total_FR_Stable; All_Total_FR_PerState_13];
end
All_Total_FR_PerState_13(:, 3) = [];



% Take a sample
SampleSize = 50;
All_Total_FR_PerState_7_Sample = All_Total_FR_PerState_7(1:SampleSize, :);
All_Total_FR_PerState_10_Sample = All_Total_FR_PerState_10(1:SampleSize, :);
All_Total_FR_PerState_13_Sample = All_Total_FR_PerState_13(1:SampleSize, :);



figure;
FontSizeTitles = 18;
AxisFontSize = 14;

subplot(1, 3, 1)
imagesc(All_Total_FR_PerState_7_Sample)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Baseline (LightPhase)', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');

colorbar

subplot(1, 3, 2)
imagesc(All_Total_FR_PerState_10_Sample)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Sleep Deprivation Day (LightPhase)', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');

colorbar

subplot(1, 3, 3)
imagesc(All_Total_FR_PerState_13_Sample)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Day After SD (LightPhase)', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');


colorbar

h_suptitle = suptitle('Firing Rate per state');
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';
