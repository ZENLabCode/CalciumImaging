Trace_Shift = 40;
[~, n_traces] = size(dataArrayEnv);
Trace_LineWidth = 1;
TraceShiftMin = 4;
CURRENT_TRACE = 29;

figure(); set(gcf,'position', get(0,'screensize'));
% Subplot 1
% subplot(2, 1, 1)
hold on; grid on; box on;
yyaxis left

i_trace = 4;
tmp_Trace = dataArrayEnv(:, i_trace) + (0)*Trace_Shift;
plot(tmp_Trace, 'k-', 'LineWidth', Trace_LineWidth)

i_trace = 18;
tmp_Trace = dataArrayEnv(:, i_trace) + (1)*Trace_Shift;
plot(tmp_Trace, 'k-', 'LineWidth', Trace_LineWidth)

i_trace = 13;
tmp_Trace = dataArrayEnv(:, i_trace) + (2)*Trace_Shift;
plot(tmp_Trace, 'k-', 'LineWidth', Trace_LineWidth)

i_trace = 26;
tmp_Trace = dataArrayEnv(:, i_trace) + (3)*Trace_Shift;
plot(tmp_Trace, 'k-', 'LineWidth', Trace_LineWidth)

% for i_trace = CURRENT_TRACE:CURRENT_TRACE
%     tmp_Trace = dataArrayEnv(:, i_trace) + (i_trace-1)*Trace_Shift;
%         tmp_Trace = dataArrayEnv(:, i_trace);
% 
%     plot(tmp_Trace, 'k-', 'LineWidth', Trace_LineWidth)
% end
axis tight
ylim([-inf, inf]);
Y_Left_Lim = ylim;
[Y_Left_Lim] = get(gca, 'ylim');
% set(gca, 'YTick',[]);
xlim([0, inf]);
ylabel('\DeltaF/F')
xlabel('Frames')


% Subplot 1
Trace_Shift = Trace_Shift*60;

hold on;
yyaxis right

i_trace = 4;
tmp_Trace = tracesRaw(:, i_trace) + (0)*Trace_Shift;
plot(tmp_Trace, 'r-', 'LineWidth', Trace_LineWidth)

i_trace = 18;
tmp_Trace = tracesRaw(:, i_trace) + (1)*Trace_Shift;
plot(tmp_Trace, 'r-', 'LineWidth', Trace_LineWidth)

i_trace = 13;
tmp_Trace = tracesRaw(:, i_trace) + (2)*Trace_Shift;
plot(tmp_Trace, 'r-', 'LineWidth', Trace_LineWidth)

i_trace = 26;
tmp_Trace = tracesRaw(:, i_trace) + (3)*Trace_Shift;
plot(tmp_Trace, 'r-', 'LineWidth', Trace_LineWidth)

% for i_trace = CURRENT_TRACE:CURRENT_TRACE
%     tmp_Trace = tracesRaw(:, i_trace) + (i_trace-1)*Trace_Shift;
%     tmp_Trace = tracesRaw(:, i_trace);
%     plot(tmp_Trace, 'r-', 'LineWidth', Trace_LineWidth)
% end
axis tight
Y_Right_Lim = ylim;
% [Y_Right_Max, Y_Right_Min] = get(gca, 'ylim');
% set(gca, 'YTick',[]);
xlim([0, inf]);
ylim([-inf, inf]);
Y_Right_Lim = ylim;
set(gca, 'FontSize', 12);
ylabel('Raw Fluorescence')
ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'r';

set(gca, 'FontSize', 14);
ax.YAxis(1).Limits = [-35, 350];
% ax.YAxis(2).Limits = [-10, 20000];

% Traces candidate: 12, 13, 18, 26, 29