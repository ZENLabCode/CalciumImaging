function DFF_single_trace_analysis


trace = DFFnotnormalized(:, 1);

number_datapoints = numel(trace);

% % Get negative peaks.
% neg_peaks = get_negative_peaks(trace, Hypnogram, FLAG_display);

% Estimate Baseline.
trace_mean = nanmean(trace);
trace_median = nanmedian(trace);
trace_std = nanstd(trace);

% Estimate Noise (ends up with a minimum amplitude & prominence value for the peaks).

% Get signal peaks.
MinPeak_Dist = 3;
MinPeak_Heigth = 15000; % Should be = baseline + noise.
MinPeak_Prom = 2500;
MinPeak_Width = 2;
MaxPeak_Width = 50;
[peaks_amplitude, peaks_location, peaks_width, peaks_prominence] = findpeaks(trace, 'MinPeakHeight', MinPeak_Heigth, 'MinPeakProminence', MinPeak_Prom,'MinPeakDistance', MinPeak_Dist, 'MinPeakWidth', MinPeak_Width, 'MaxPeakWidth', MaxPeak_Width, 'Annotate', 'extents');
findpeaks(trace, 'MinPeakHeight', MinPeak_Heigth, 'MinPeakProminence', MinPeak_Prom,'MinPeakDistance', MinPeak_Dist,'MinPeakWidth' ,MinPeak_Width, 'Annotate', 'extents');

line([0, number_datapoints], [trace_median, trace_median], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)

trace_smooth = smooth(trace);
trace_smooth_median = nanmedian(trace_smooth);
trace_smooth_std = nanstd(trace_median);
trace_deriv = diff(trace_smooth);
trace_deriv = [NaN; trace_deriv];
trace_deriv2 = diff(trace_deriv);
trace_deriv2 = [NaN; trace_deriv2];
figure(); hold on;
plot(trace_smooth); plot(trace_deriv); plot(trace_deriv2); grid on; box on;
line([0, number_datapoints], [trace_smooth_median, trace_smooth_median], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)

% Get the start and end of each event.

% Get the start of an event thanks to the 2nd derivative (2nd derivative peak position - 1)

% Get the end of an event thanks to the 1st derivative (when 1st
% derivative gets near 0 +- std of 1st derivative.

% Estimate events properties.



