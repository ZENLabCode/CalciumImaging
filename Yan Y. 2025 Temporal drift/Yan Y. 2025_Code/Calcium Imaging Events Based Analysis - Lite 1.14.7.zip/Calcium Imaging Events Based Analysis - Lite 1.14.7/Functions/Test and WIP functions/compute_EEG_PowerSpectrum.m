function compute_EEG_PowerSpectrum (Hypnogram)
% This function computes the time Power Spectra of the EEG signal the user
% selects.

% Constants.
EEG_SamplRate = 200; % Sampling rate of the EEG [Hz]
TimeResSpectrogram = 1; % 1.5;
CaTraceLength = numel(Hypnogram);

% Options.
n_smoothing_rounds = 2; % For the Power Spectrum.

% Select EEG Data File.
[EEG_FileName, EEG_FilePath] = uigetfile('.mat', 'Select EEG Raw File', pwd);
fprintf('File "%s" Loaded.\n\n', EEG_FileName);

% Load EEG Raw Data.
tmp_data_struct = load([EEG_FilePath, EEG_FileName]);

% Convert into standard name.
tmp_var_1 = struct2cell(tmp_data_struct);
tmp_var_2 = tmp_var_1{1, 1};
DataCell = tmp_var_2;
[dim1, dim2] = size(DataCell);
if dim2 == 9
    DataCell = DataCell(:, 2:5);
elseif dim2 == 4
    
else
    error('Check dimension of the data cell.')
end
DataMatrix = cell2mat(DataCell);

% Get EEG Traces.
EEG_prefrontal = DataMatrix(:, 1);
EEG_parietal = DataMatrix(:, 2);

TTL = DataMatrix(:, 4);

% Power Spectra.
FreqLims = [0.01, 100];
pspectrum(EEG_prefrontal, EEG_SamplRate, 'spectrogram', 'TimeResolution', TimeResSpectrogram, 'FrequencyLimits', FreqLims);
[sp_power, sp_freq, sp_time_points] = pspectrum(EEG_prefrontal, EEG_SamplRate, 'spectrogram', 'TimeResolution', TimeResSpectrogram, 'FrequencyLimits', FreqLims);

% Resample to the correct number of frames.
resampled_time_array = 1:1:CaTraceLength;
[n_freqs, n_tmp_frames] = size(sp_power);
sp_power_resamp = NaN(n_freqs, CaTraceLength);
for i_freq = 1:n_freqs
    sp_power_resamp(i_freq, :) = resample(sp_power(i_freq, :), CaTraceLength, n_tmp_frames);
end

% Compute power spectrum of different frequency bands.
sp_power = sp_power_resamp;

FreqLims = [0.5, 4];
tmp1 = (sp_freq > FreqLims(1));
tmp2 = (sp_freq <= FreqLims(2));
tmp3 = (tmp1 + tmp2) == 2;
tmp4 = sp_power(find(tmp3), :);
FreqPower.FreqPower_1 = nanmean(tmp4, 1);
FreqPower.FreqLims_1 = FreqLims;
for i_smothing = 1:n_smoothing_rounds
    FreqPower.FreqPower_1 = smooth(FreqPower.FreqPower_1);
end

FreqLims = [4, 9];
tmp1 = (sp_freq > FreqLims(1));
tmp2 = (sp_freq <= FreqLims(2));
tmp3 = (tmp1 + tmp2) == 2;
tmp4 = sp_power(find(tmp3), :);
FreqPower.FreqPower_2 = nanmean(tmp4, 1);
FreqPower.FreqLims_2 = FreqLims;
for i_smothing = 1:n_smoothing_rounds
    FreqPower.FreqPower_2 = smooth(FreqPower.FreqPower_2);
end

FreqLims = [10, 30];
tmp1 = (sp_freq > FreqLims(1));
tmp2 = (sp_freq <= FreqLims(2));
tmp3 = (tmp1 + tmp2) == 2;
tmp4 = sp_power(find(tmp3), :);
FreqPower.FreqPower_3 = nanmean(tmp4, 1);
FreqPower.FreqLims_3 = FreqLims;
for i_smothing = 1:n_smoothing_rounds
    FreqPower.FreqPower_3 = smooth(FreqPower.FreqPower_3);
end

FreqLims = [50, 90];
tmp1 = (sp_freq > FreqLims(1));
tmp2 = (sp_freq <= FreqLims(2));
tmp3 = (tmp1 + tmp2) == 2;
tmp4 = sp_power(find(tmp3), :);
FreqPower.FreqPower_4 = nanmean(tmp4, 1);
FreqPower.FreqLims_4 = FreqLims;
for i_smothing = 1:n_smoothing_rounds
    FreqPower.FreqPower_4 = smooth(FreqPower.FreqPower_4);
end

FreqPower.Smoothing_Rounds = n_smoothing_rounds;

% Plot
figure; hold on;
yyaxis left
plot(FreqPower.FreqPower_1, '-b'); 
plot(FreqPower.FreqPower_2, '-r')
plot(FreqPower.FreqPower_3, '-g')
plot(FreqPower.FreqPower_4, '-y')
tmp_Ylim = ylim;
axis([0, inf, 0, tmp_Ylim(2)]);
% Overlap Hypnogram.
yyaxis right
plot(Hypnogram, '-k', 'LineWidth', 2)
str_legend_1 = sprintf('%0g < Freq < %d', FreqPower.FreqLims_1(1), FreqPower.FreqLims_1(2));
str_legend_2 = sprintf('%d < Freq < %d', FreqPower.FreqLims_2(1), FreqPower.FreqLims_2(2));
str_legend_3 = sprintf('%d < Freq < %d', FreqPower.FreqLims_3(1), FreqPower.FreqLims_3(2));
str_legend_4 = sprintf('%d < Freq < %d', FreqPower.FreqLims_4(1), FreqPower.FreqLims_4(2));
legend({str_legend_1, str_legend_2, str_legend_3, str_legend_4, 'Hypnogram'})
grid on; box on;
tmp_Ylim = ylim;
axis([0, inf, 0, tmp_Ylim(2) + 1]);
% Set side axis to black
ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';
title('Frequency Power during recordings.')
xlabel('Time [Frames]')
yyaxis right; ylabel('State')
yyaxis left; ylabel('Frequency Power')

% Just a test
% FRange = [3.5, 4.5];
% FPower_3_5_to_4_5 = bandpower(EEG_prefrontal, EEG_SamplRate, FRange);

keyboard
