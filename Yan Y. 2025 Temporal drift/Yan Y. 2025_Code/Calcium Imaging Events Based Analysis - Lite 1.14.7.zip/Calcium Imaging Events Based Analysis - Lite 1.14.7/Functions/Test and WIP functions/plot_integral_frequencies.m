plot_integrals_frequencies ()
% WIP


% Plot Mean Frequency per state
FontSizeTitles = 18;
LabelsFontSize = 16;
AxisFontSize = 14;
Plot_LineWidth = 1.5;

figure('units','normalized','outerposition',[0 0 1 1]);

hold on;
errorbar(tmp_int_freq_Awake_Avg, tmp_int_freq_Awake_StE, 'linewidth', Plot_LineWidth);
errorbar(tmp_int_freq_NREM_Avg, tmp_int_freq_NREM_StE, 'linewidth', Plot_LineWidth);
errorbar(tmp_int_freq_REM_Avg, tmp_int_freq_REM_StE, 'linewidth', Plot_LineWidth);
axis square;
box on; grid on;
legend ({'Awake', 'NREM', 'REM'})
ax = gca;
ax.FontSize = AxisFontSize;
title('Average integral per cell', 'FontSize', FontSizeTitles)
xlabel('Cell ID', 'FontSize', LabelsFontSize)
ylabel('Total integral per state, normalized by state length', 'FontSize', LabelsFontSize)

keyboard
% Integrals_Freq_Matrix_perMouse{i_mouse} =