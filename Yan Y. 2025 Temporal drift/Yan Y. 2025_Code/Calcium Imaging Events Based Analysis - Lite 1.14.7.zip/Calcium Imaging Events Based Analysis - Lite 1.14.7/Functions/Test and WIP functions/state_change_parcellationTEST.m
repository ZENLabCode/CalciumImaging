function state_change_parcellationTEST (State_Info_perSession, Mouse_Names, Opts)

keyboard
n_sessions = Opts.n_sessions;


for i_session = 1:n_sessions
    
    tmp = [State_Info_perSession.Session] == i_session;
    CurrentStates = State_Info_perSession(tmp);
    % Isolate each separate mouse session
    for i_mouse = 1:n_mice 
        current_mouse = Mouse_Names{i_mouse};
        RemoveTag = [];
        i_removed = 1;
        for i_state = 1:numel(CurrentStates)
            if strcmpi(CurrentStates(i_state).MouseTag, current_mouse) == 0
                RemoveTag(i_removed) = i_state;
                i_removed = i_removed + 1;
            end
        end
        CurrentStates(RemoveTag) = [];
        
        Current_Parcellation
        
        
    end
end
