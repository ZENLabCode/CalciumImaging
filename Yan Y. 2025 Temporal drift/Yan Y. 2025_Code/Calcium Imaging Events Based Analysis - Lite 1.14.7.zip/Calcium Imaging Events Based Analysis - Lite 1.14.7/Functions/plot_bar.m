function EventsFreq_Results = plot_bar(Events, Mouse_Names, HypnoState, Hypnogram_AllSessions, MouseCellsRecorded, Opts)
% This function plots the barplot of the events distributions across the
% states. The average and error are per mouse.

n_rows = 1;
n_columns = 3;

n_mice = numel(Mouse_Names);

% Remove session 2s
tmp = [Events.Session];
Events(tmp == 2) = [];
    
    
% Get the total duration of sleep states.
for i_session = 1:numel(HypnoState)
    Duration_ToT_Awake_perSession(i_session) = HypnoState(i_session).Duration.Awake;
    Duration_ToT_NREM_perSession(i_session) = HypnoState(i_session).Duration.NoNREM;
    Duration_ToT_REM_perSession(i_session) = HypnoState(i_session).Duration.REM;
end

i_mouse = 0;
for i_session = 1:numel(HypnoState)
    if Hypnogram_AllSessions(i_session).Session == 1
        i_mouse = i_mouse + 1;
        Duration_ToT_Awake_perMouse(i_mouse) = Duration_ToT_Awake_perSession(i_session);
        Duration_ToT_NREM_perMouse(i_mouse) = Duration_ToT_NREM_perSession(i_session);
        Duration_ToT_REM_perMouse(i_mouse) = Duration_ToT_REM_perSession(i_session);
    elseif Hypnogram_AllSessions(i_session).Session == 2
        Duration_ToT_Awake_perMouse(i_mouse) = sum([Duration_ToT_Awake_perSession(i_session), Duration_ToT_Awake_perSession(i_session - 1)]);
        Duration_ToT_NREM_perMouse(i_mouse) = sum([Duration_ToT_NREM_perSession(i_session), Duration_ToT_NREM_perSession(i_session - 1)]);
        Duration_ToT_REM_perMouse(i_mouse) = sum([Duration_ToT_REM_perSession(i_session), Duration_ToT_REM_perSession(i_session - 1)]);
    end
end

Duration_ToT_Awake = sum(Duration_ToT_Awake_perSession);
Duration_ToT_NREM = sum(Duration_ToT_NREM_perSession);
Duration_ToT_REM = sum(Duration_ToT_REM_perSession);

Duration_Avg_perMouse_Awake = nanmean(Duration_ToT_Awake_perMouse);
Duration_Avg_perMouse_NREM = nanmean(Duration_ToT_NREM_perMouse);
Duration_Avg_perMouse_REM = nanmean(Duration_ToT_REM_perMouse);

Duration_StE_perMouse_Awake = nanstd(Duration_ToT_Awake_perMouse)./sqrt(n_mice);
Duration_StE_perMouse_NREM = nanstd(Duration_ToT_NREM_perMouse)./sqrt(n_mice);
Duration_StE_perMouse_REM = nanstd(Duration_ToT_REM_perMouse)./sqrt(n_mice);


% Get the number of events per sleep state.
StateTags = [Events.StateTag];
n_Events_Awake_Avg = numel(StateTags(StateTags == 1));
n_Events_NREM_Avg = numel(StateTags(StateTags == 2));
n_Events_REM_Avg = numel(StateTags(StateTags == 4));


for i_mouse = 1:n_mice
    current_mouse_name = Mouse_Names{i_mouse};
    for i_event = 1:numel(Events)
        if strcmpi(Events(i_event).MouseTag, current_mouse_name)
            Events(i_event).MouseNum = i_mouse;
        end
    end
end

MouseNum = [Events.MouseNum];

n_Events_Awake_perMouse = NaN(1, n_mice);
n_Events_NREM_perMouse = NaN(1, n_mice);
n_Events_REM_perMouse = NaN(1, n_mice);
for i_mouse = 1:n_mice
    Events_Current_Mouse = Events(MouseNum == i_mouse);
    StateTags = [Events_Current_Mouse.StateTag];
    n_cells = MouseCellsRecorded(i_mouse);
    n_Events_Awake_perMouse(i_mouse) = numel(StateTags(StateTags == 1));
    n_Events_NREM_perMouse(i_mouse) = numel(StateTags(StateTags == 2));
    n_Events_REM_perMouse(i_mouse) = numel(StateTags(StateTags == 4));
    
    events_freq_Awake_perMouse(i_mouse) = n_Events_Awake_perMouse(i_mouse)./n_cells;
    events_freq_NREM_perMouse(i_mouse) = n_Events_NREM_perMouse(i_mouse)./n_cells;
    events_freq_REM_perMouse(i_mouse) = n_Events_REM_perMouse(i_mouse)./n_cells;
    
    events_freq_Awake_perMouse(i_mouse) = events_freq_Awake_perMouse(i_mouse)./Duration_ToT_Awake_perMouse(i_mouse);
    events_freq_NREM_perMouse(i_mouse) = events_freq_NREM_perMouse(i_mouse)./Duration_ToT_NREM_perMouse(i_mouse);
    events_freq_REM_perMouse(i_mouse) = events_freq_REM_perMouse(i_mouse)./Duration_ToT_REM_perMouse(i_mouse);
end

% In case there is no REM recorded, set a NaN instead than Inf
events_freq_REM_perMouse(isinf(events_freq_REM_perMouse)) = NaN;


n_Events_Awake_Avg = nanmean(n_Events_Awake_perMouse);
n_Events_NREM_Avg = nanmean(n_Events_NREM_perMouse);
n_Events_REM_Avg = nanmean(n_Events_REM_perMouse);

n_Events_Awake_StE = nanstd(n_Events_Awake_perMouse)./sqrt(n_mice);
n_Events_NREM_StE = nanstd(n_Events_NREM_perMouse)./sqrt(n_mice);
n_Events_REM_StE = nanstd(n_Events_REM_perMouse)./sqrt(n_mice);
    
events_freq_Awake_Avg = nanmean(events_freq_Awake_perMouse);
events_freq_NREM_Avg = nanmean(events_freq_NREM_perMouse);
events_freq_REM_Avg = nanmean(events_freq_REM_perMouse);

events_freq_Awake_StE = nanstd(events_freq_Awake_perMouse)./sqrt(n_mice);
events_freq_NREM_StE = nanstd(events_freq_NREM_perMouse)./sqrt(n_mice);
events_freq_REM_StE = nanstd(events_freq_REM_perMouse)./sqrt(n_mice);


% Set up output
EventsFreq_Results.events_freq_Awake_perMouse = events_freq_Awake_perMouse;
EventsFreq_Results.events_freq_NREM_perMouse = events_freq_NREM_perMouse;
EventsFreq_Results.events_freq_REM_perMouse = events_freq_REM_perMouse;

EventsFreq_Results.events_freq_Awake_Avg = events_freq_Awake_Avg;
EventsFreq_Results.events_freq_NREM_Avg = events_freq_NREM_Avg;
EventsFreq_Results.events_freq_REM_Avg = events_freq_REM_Avg;

EventsFreq_Results.events_freq_Awake_StE = events_freq_Awake_StE;
EventsFreq_Results.events_freq_NREM_StE = events_freq_NREM_StE;
EventsFreq_Results.events_freq_REM_StE = events_freq_REM_StE;


XLocation = [1, 2, 3];

figure('units','normalized','outerposition',[0 0 1 1]);


% SUBPLOT 1
subplot(n_rows, n_columns, 1)
Y = [Duration_Avg_perMouse_Awake, Duration_Avg_perMouse_NREM, Duration_Avg_perMouse_REM];
errlow = [Duration_StE_perMouse_Awake, Duration_StE_perMouse_NREM, Duration_StE_perMouse_REM];
errhigh = [Duration_StE_perMouse_Awake, Duration_StE_perMouse_NREM, Duration_StE_perMouse_REM];
h_bar = bar(XLocation, Y);
xticklabels({'Awake','NREM','REM'})

hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off


ylabel('Total States duration [s]')
grid on; box on; axis square;

tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};

title_str = sprintf('Composition of recordings \n(States cumulative duration)');
title(title_str)

% SUBPLOT 2
subplot(n_rows, n_columns, 2)
Y = [n_Events_Awake_Avg, n_Events_NREM_Avg, n_Events_REM_Avg];
errlow = [n_Events_Awake_StE, n_Events_NREM_StE, n_Events_REM_StE];
errhigh = [n_Events_Awake_StE, n_Events_NREM_StE, n_Events_REM_StE];
h_bar = bar(XLocation, Y);
xticklabels({'Awake','NREM','REM'})

hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off

ylabel('Number of events')
grid on; box on; axis square;

tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};

title_str = sprintf('Ca2+ Events in Sleep States\n');
title(title_str)

% SUBPLOT 3
subplot(n_rows, n_columns, 3)
Y = [events_freq_Awake_Avg, events_freq_NREM_Avg, events_freq_REM_Avg];
errlow = [events_freq_Awake_StE, events_freq_NREM_StE, events_freq_REM_StE];
errhigh = [events_freq_Awake_StE, events_freq_NREM_StE, events_freq_REM_StE];
h_bar = bar(XLocation, Y);

xticklabels({'Awake','NREM','REM'})

hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off

ylabel('Frequency of Events [Hz]')
grid on; box on; axis square;

tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};

title_str = sprintf('Frequency of Ca2+ Events\nin Sleep States');
title(title_str);

if Opts.SaveFiguresAutomatically == 1
    if ~isfield (Opts, 'CellType')
        Opts.CellType = 'Unknown Cell Type';
    end
    FileName = sprintf('%s - Events per State - Bar Plot', Opts.CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end