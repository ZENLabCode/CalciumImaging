CalciumTraces = S20;

CalciumTraces(:, 2:2:end) = [];
CalciumTraces(:, 1:2:end) = [];



tmp = Hypnogram;
tmp(isnan(tmp)) = [];
tmp1 = resample(tmp, 10, 1000);
tmp1 = double(int32(tmp1));

tmp_num = abs(numel(CalciumTraces(:, 1)) - numel(tmp1));

tmp2 = tmp1(1:end-tmp_num);

Hypnogram = tmp2;
