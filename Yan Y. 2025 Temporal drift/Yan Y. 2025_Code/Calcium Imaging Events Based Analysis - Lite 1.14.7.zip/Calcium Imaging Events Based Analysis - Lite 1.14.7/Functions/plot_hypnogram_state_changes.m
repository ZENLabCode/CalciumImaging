function plot_hypnogram_state_changes(Hypnogram_AllMice, calTime)

% This function plots the hypnograms together with the identified state
% changes, for all the mice.

n_mice = numel(Hypnogram_AllMice);
figure();

for i_mouse = 1:n_mice
    subplot(n_mice, 1, i_mouse);
    bar(Hypnogram_AllMice(i_mouse).Hypnogram);
    hold on; box on; grid on;
    tmp = 4.*(ones(1, numel(Hypnogram_AllMice(i_mouse).StateChanges)));
    bar(Hypnogram_AllMice(i_mouse).StateChanges, tmp, 'r', 'LineWidth', 0.5);
end
h = suptitle('Hypnograms');
h.FontSize = 20;
h.FontWeight = 'bold';
xlabel('Frames')