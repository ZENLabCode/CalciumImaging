function [Mouse_Names, Mouse_Sessions, Mouse_Folders] = get_mouse_names (Dir_Data, Dir_Main)

% Get Mice Names (from folder structure)
cd(Dir_Data); tmp_list = dir; cd(Dir_Main);
tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
tmp1 = tmp_list;

Mouse_Names = cell(numel(tmp1), 1);
Mouse_Sessions = zeros(numel(tmp1), 1);

Mouse_Names = cell(numel(tmp1), 1);
Mouse_Sessions = zeros(numel(tmp1), 1);
Mouse_Folders = cell(numel(tmp1), 1);
i_mouse_name = 1;
for i_mouse = 1:numel(tmp1)
    Mouse_Names{i_mouse_name} = tmp1(i_mouse).name;
    Mouse_Folders{i_mouse_name} = tmp1(i_mouse).folder;
    tmp_folder = sprintf('%s\\%s', Dir_Data, Mouse_Names{i_mouse_name});
    cd(tmp_folder); tmp_list = dir; cd(Dir_Main);
    tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
    if ~isempty(tmp_list)
        Mouse_Sessions(i_mouse) = numel(tmp_list);
        i_mouse_name = i_mouse_name + 1;
    else
        error('Mouse "%s" contains no sessions.\n\n', Mouse_Names{i_mouse_name});
    end
end