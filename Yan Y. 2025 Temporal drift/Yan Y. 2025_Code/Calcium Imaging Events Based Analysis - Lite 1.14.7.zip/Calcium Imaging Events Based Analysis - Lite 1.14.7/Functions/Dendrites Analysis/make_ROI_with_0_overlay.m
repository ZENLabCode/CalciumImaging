function ROI_with_0_overlay = make_ROI_with_0_overlay (selected_ROI, selected_ROI_overlay)
% This function will take an ROI, an overlay, and give as output a single
% image that is the ROI, with the overlay on top of it, but with every
% border put = 0.
% In other words, it construct an overlay on top of the ROI image, to allow 
% the user to select a smaller region in the ROI. If the overlay is 
% a square grid (as given by default from the toolbox), it will overlay 
% a grid on the ROI.
% INPUT:
% - "selected_ROI": the ROI logical image.
% - "selected_ROI_overlay": the overlay image, with same dimentions as the 
%   ROI.
% OUTPUT:
% - "ROI_with_0_overlay": the ROI image (2D matrix of double) with the 
%    overlay on top. 
[Height, Width] = size(selected_ROI);

% Identify overlay_tag.
flag_break = 0;
for i_pixel = 1:Height
    if flag_break == 1
        break
    end
    for j_pixel = 1:Width
        if flag_break == 1
            break
        end
        if (selected_ROI_overlay(i_pixel, j_pixel) ~= 0)
            overlay_tag = selected_ROI_overlay(i_pixel, j_pixel);
            flag_break = 1;
        end
    end
end

% Put overlay (with value 0) on top of ROI.
ROI_with_0_overlay = selected_ROI;
for i_pixel = 1:Height
    for j_pixel = 1:Width
        if (selected_ROI_overlay(i_pixel, j_pixel) == overlay_tag)
            ROI_with_0_overlay(i_pixel, j_pixel) = 0;
        end
    end
end
