function ROI_Surface = Fill_ROI_Gaps (ROI_Surface)


Neighbourhood_Element_Radius = 18;
FLAG_CentralityRankedPlot = 1;
min_weight_fixed = 0.05;
max_weight_fixed = 5;
CellBorderLineWidth = 1.5;
CellNodeBorderLineWidth = 3;
FLAG_ROI_input = '.mat';



% Connect existing gaps.
SE_Neigh = strel('disk', Neighbourhood_Element_Radius); % Creates structuring neighbourhood element
ROI_Surface = imclose(ROI_Surface, SE_Neigh); % Closes gaps
ROI_Surface = imfill(ROI_Surface, 'holes');