function find_closest_signal(Current_Peaks_Position, Current_Neighbour_Peaks_Position, Opts)
% Finds if every signal did traval between the two regions and returns



if FLAG_ControlPlot == 1
    figure;
    stem(Current_Peaks_Position)
    hold on; grid on
    stem(Current_Neighbour_Peaks_Position)
    xlabel('Event #')
    ylabel('Frame')
end



for i_Event_1 = 1:numel(Current_Peaks_Position)
    current_event_peak_1 = Current_Peaks_Position(i_Event_1);
    
    for i_Event_2 = 1:numel(Current_Neighbour_Peaks_Position)
        current_event_peak_2 = Current_Neighbour_Peaks_Position(i_Event_2);
        peaks_distance = abs(current_event_peak_1 - current_event_peak_2);
        
        if peaks_distance <= Opts.DendriteAnalysis.max_frames_between_events
        
        else
            
        end
        
    end
    
end