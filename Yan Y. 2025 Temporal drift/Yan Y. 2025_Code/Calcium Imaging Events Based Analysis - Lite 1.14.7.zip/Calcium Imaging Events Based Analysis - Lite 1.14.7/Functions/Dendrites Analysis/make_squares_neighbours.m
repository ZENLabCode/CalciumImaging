function make_squares_neighbours (Dendrites)

% In Dendrites are kept all the Dendrites. For each Dendrite, there is a
% collection of ROIs. 
% This function takes each of these ROIs, takes their pixel coordinates,
% and builds other ROIs at their shorter sides.

