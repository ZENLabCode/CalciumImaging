function [region_output, overlay_labels, overlay_boundaries, selected_region_tag] = select_region_from_pixel(selected_ROI_overlay, selected_ROI, pixel_input)
% Takes 2 pixels as input, and return the region which includes the
% selected pixel as output.

[Height, Width] = size(selected_ROI);

% Put overlay (with value 0) on top of ROI.
ROI_with_overlay = make_ROI_with_0_overlay (selected_ROI, selected_ROI_overlay);

% Get the label of each single region in the overlayed ROI.
[overlay_boundaries, overlay_labels, overlay_number_of_regions] = bwboundaries(ROI_with_overlay, 8, 'noholes');

% Get the selected region tag.
selected_region_tag = overlay_labels(pixel_input(1,1), pixel_input(1,2));

% Get all the pixels with the same tag (the entire region!)
selected_region_area = 0;
region_output = cell(0);
for i_pixel = 1:Height
    for j_pixel = 1:Width
        if (overlay_labels(i_pixel, j_pixel) == selected_region_tag)
            selected_region_area = selected_region_area + 1;
            region_output{1, selected_region_area} = [i_pixel, j_pixel];
        end
    end
end

end

