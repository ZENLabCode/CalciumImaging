function dendritic_analysis ()



%% Initialize
Dir_Main = pwd;
addpath(genpath(Dir_Main));

% Get Data Folder
fprintf('Please Specify the Data Folder.\n\n')
Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');
addpath(genpath(Dir_Data));

% Options
Opts = set_options (Dir_Main, Dir_Data);
Opts.FLAG_Cell_PreSet = 'Pyramidal';
Opts = Options_Preset_Pyramidal (Opts);
Opts.General.FolderNameDelimiter = '\';
Opts.General.Suite2p_Format = 0; % Suite2p format? 0 = no (default)

Opts_Dendrites.Adjacency_Length = 2; % How many subROI to consider adjacent to the selected one
Opts_Dendrites.Neighbourhood_Length = 5; % Lenght of the rectangles to set at the neighbourhood of each dendrite subROI
Opts.Dendrites.ContemporaryInterval = 3; % Consider 2 events contemporary if in the interval X +- Opts.Dendrites.ContemporaryInterval
Opts.General.FrameRate = 3;
Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;

% Get mice names & info
[Mouse_Names, Mouse_Sessions, Mouse_Folders] = get_mouse_names (Dir_Data, Dir_Main);
n_mice = numel(Mouse_Names);
n_sessions = nansum(Mouse_Sessions);

% Load Dendrite ROIs
[Dendrites_perMouse, Dendrites_Bord_1_perMouse, Dendrites_Bord_2_perMouse] = load_dendrites_ROIs_allMice(Dir_Data, Mouse_Names, Mouse_Folders, Mouse_Sessions, Opts_Dendrites);

% Load each time series
Dendrites_perMouse_TS = get_TS_allMice (Dendrites_perMouse, Mouse_Names, Mouse_Folders, Mouse_Sessions, Dir_Main);
Dendrites_perMouse_TS_up = get_TS_allMice (Dendrites_Bord_1_perMouse, Mouse_Names, Mouse_Folders, Mouse_Sessions, Dir_Main); % Sub-ROIs above the ones on the dendrite (external to it)
Dendrites_perMouse_TS_down = get_TS_allMice (Dendrites_Bord_2_perMouse, Mouse_Names, Mouse_Folders, Mouse_Sessions, Dir_Main); % Sub-ROIs below the ones on the dendrite  (external to it)

% Manual artifacts removal
Dendrites_perMouse_TS = manual_artifact_correction_dendrites_analysis (Dendrites_perMouse_TS);
Dendrites_perMouse_TS_up = manual_artifact_correction_dendrites_analysis (Dendrites_perMouse_TS_up);
Dendrites_perMouse_TS_down = manual_artifact_correction_dendrites_analysis (Dendrites_perMouse_TS_down);


%% Gather Events - Dendrite
Events_Dendrite_perMouse = cell(1, n_mice);
Events_DendriteAVG_perMouse = cell(1, n_mice);
i_mouse_ses = 1;
for i_mouse = 1:n_mice
    CurrentMouse_DendritesTS = Dendrites_perMouse_TS{i_mouse}; % Change with Dendrites_perMouse_TS_up or Dendrites_perMouse_TS_down
    MouseName = Mouse_Names{i_mouse};
    n_sessions = numel(CurrentMouse_DendritesTS);
    Events_Dendrite_perSession = cell(1, n_sessions);
    Events_DendriteAVG_perSession = cell(1, n_sessions);
    for i_session = 1:n_sessions
        Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
        calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
        CurrentSession_DendritesTS = CurrentMouse_DendritesTS{i_session};
        n_dendrites = numel(CurrentSession_DendritesTS);
        [~, time_length] = size(CurrentSession_DendritesTS{1, 1});
        
        Dendrites_Average_TS = NaN(n_dendrites, time_length);
        Events_Dendrite = cell(1, n_dendrites);
        Events_DendriteAVG = cell(1, n_dendrites);
        DendritesAVGTraces_Clean = cell(1, n_dendrites);
        for i_dendrite = 1:n_dendrites
            CurrentDendriteTS = CurrentSession_DendritesTS{i_dendrite};
            Dendrite_Average_TS = nanmean(CurrentDendriteTS, 1);
            Dendrites_Average_TS(i_dendrite, :) = Dendrite_Average_TS;
            % Analyze each single subROI
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_Dendrite{i_dendrite}, ~, ~, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (CurrentDendriteTS', Hypnogram, calTime, Opts);
            
            % Analyze the mean dendrites signals to remove motion artifacts
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_DendriteAVG{i_dendrite}, StateChanges, StateLength, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (Dendrite_Average_TS', Hypnogram, calTime, Opts);
        end
        Events_Dendrite_perSession{i_session} = Events_Dendrite;
        Events_DendriteAVG_perSession{i_session} = Events_DendriteAVG;
        Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
        Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
        Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
        Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
        Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
        Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
        i_mouse_ses = i_mouse_ses + 1;
    end
    Events_Dendrite_perMouse{i_mouse} = Events_Dendrite_perSession;
    Events_DendriteAVG_perMouse{i_mouse} = Events_DendriteAVG_perSession;
    clear CurrentMouse_DendritesTS;
end
clear Events_Dendrite_perSession;
clear Events_Dendrite;

% Save automatically
AutomaticSave_FileName = datestr(datetime, 'yyyy-mm-dd');
AutomaticSave_FileName_tmp = ['Events_Dendrites_', AutomaticSave_FileName];
AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
% Check for unique name
DUMMY = 1;
counter_FileName = 1;
while DUMMY == 1
    
    if exist(AutomaticSave_FileName_tmp_2, 'file') ~= 0
        tmp_nametag = sprintf('_%d', counter_FileName);
        AutomaticSave_FileName = [AutomaticSave_FileName_tmp, tmp_nametag];
        AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
    else
        DUMMY = 0;
    end
    counter_FileName = counter_FileName + 1;
end
AutomaticSave_FileName = [AutomaticSave_FileName, '.mat'];
fprintf('The Analysis results are being saved in %s.\n\n', AutomaticSave_FileName)

save(AutomaticSave_FileName, 'Events_Dendrite_perMouse', 'Events_DendriteAVG_perMouse', '-v7.3');


%% Gather Events - Dendrite Up
Events_Dendrite_perMouse = cell(1, n_mice);
Events_DendriteAVG_perMouse = cell(1, n_mice);
i_mouse_ses = 1;
for i_mouse = 1:n_mice
    CurrentMouse_DendritesTS = Dendrites_perMouse_TS_up{i_mouse}; % Change with Dendrites_perMouse_TS_up or Dendrites_perMouse_TS_down
    MouseName = Mouse_Names{i_mouse};
    n_sessions = numel(CurrentMouse_DendritesTS);
    Events_Dendrite_perSession = cell(1, n_sessions);
    Events_DendriteAVG_perSession = cell(1, n_sessions);
    for i_session = 1:n_sessions
        Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
        calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
        CurrentSession_DendritesTS = CurrentMouse_DendritesTS{i_session};
        n_dendrites = numel(CurrentSession_DendritesTS);
        [~, time_length] = size(CurrentSession_DendritesTS{1, 1});
        
        Dendrites_Average_TS = NaN(n_dendrites, time_length);
        Events_Dendrite = cell(1, n_dendrites);
        Events_DendriteAVG = cell(1, n_dendrites);
        DendritesAVGTraces_Clean = cell(1, n_dendrites);
        for i_dendrite = 1:n_dendrites
            CurrentDendriteTS = CurrentSession_DendritesTS{i_dendrite};
            Dendrite_Average_TS = nanmean(CurrentDendriteTS, 1);
            Dendrites_Average_TS(i_dendrite, :) = Dendrite_Average_TS;
            % Analyze each single subROI
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_Dendrite{i_dendrite}, ~, ~, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (CurrentDendriteTS', Hypnogram, calTime, Opts);
            
            % Analyze the mean dendrites signals to remove motion artifacts
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_DendriteAVG{i_dendrite}, StateChanges, StateLength, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (Dendrite_Average_TS', Hypnogram, calTime, Opts);
        end
        Events_Dendrite_perSession{i_session} = Events_Dendrite;
        Events_DendriteAVG_perSession{i_session} = Events_DendriteAVG;
        Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
        Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
        Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
        Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
        Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
        Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
        i_mouse_ses = i_mouse_ses + 1;
    end
    Events_Dendrite_perMouse_Up{i_mouse} = Events_Dendrite_perSession;
    Events_DendriteAVG_perMouse_Up{i_mouse} = Events_DendriteAVG_perSession;
    clear CurrentMouse_DendritesTS;
end
clear Events_Dendrite_perSession;
clear Events_Dendrite;

% Save automatically
AutomaticSave_FileName = datestr(datetime, 'yyyy-mm-dd');
AutomaticSave_FileName_tmp = ['Events_Dendrites_Up_', AutomaticSave_FileName];
AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
% Check for unique name
DUMMY = 1;
counter_FileName = 1;
while DUMMY == 1
    
    if exist(AutomaticSave_FileName_tmp_2, 'file') ~= 0
        tmp_nametag = sprintf('_%d', counter_FileName);
        AutomaticSave_FileName = [AutomaticSave_FileName_tmp, tmp_nametag];
        AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
    else
        DUMMY = 0;
    end
    counter_FileName = counter_FileName + 1;
end
AutomaticSave_FileName = [AutomaticSave_FileName, '.mat'];
fprintf('The Analysis results are being saved in %s.\n\n', AutomaticSave_FileName)

save(AutomaticSave_FileName, 'Events_Dendrite_perMouse_Up', 'Events_DendriteAVG_perMouse_Up', '-v7.3');


%% Gather Events - Dendrite Down
Events_Dendrite_perMouse = cell(1, n_mice);
Events_DendriteAVG_perMouse = cell(1, n_mice);
i_mouse_ses = 1;
for i_mouse = 1:n_mice
    CurrentMouse_DendritesTS = Dendrites_perMouse_TS_down{i_mouse}; % Change with Dendrites_perMouse_TS_up or Dendrites_perMouse_TS_down
    MouseName = Mouse_Names{i_mouse};
    n_sessions = numel(CurrentMouse_DendritesTS);
    Events_Dendrite_perSession = cell(1, n_sessions);
    Events_DendriteAVG_perSession = cell(1, n_sessions);
    for i_session = 1:n_sessions
        Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
        calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
        CurrentSession_DendritesTS = CurrentMouse_DendritesTS{i_session};
        n_dendrites = numel(CurrentSession_DendritesTS);
        [~, time_length] = size(CurrentSession_DendritesTS{1, 1});
        
        Dendrites_Average_TS = NaN(n_dendrites, time_length);
        Events_Dendrite = cell(1, n_dendrites);
        Events_DendriteAVG = cell(1, n_dendrites);
        DendritesAVGTraces_Clean = cell(1, n_dendrites);
        for i_dendrite = 1:n_dendrites
            CurrentDendriteTS = CurrentSession_DendritesTS{i_dendrite};
            Dendrite_Average_TS = nanmean(CurrentDendriteTS, 1);
            Dendrites_Average_TS(i_dendrite, :) = Dendrite_Average_TS;
            % Analyze each single subROI
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_Dendrite{i_dendrite}, ~, ~, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (CurrentDendriteTS', Hypnogram, calTime, Opts);
            
            % Analyze the mean dendrites signals to remove motion artifacts
            Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0;
            [Events_DendriteAVG{i_dendrite}, StateChanges, StateLength, ~, DendritesAVGTraces_Clean{i_dendrite}] = analyze_single_mouse (Dendrite_Average_TS', Hypnogram, calTime, Opts);
        end
        Events_Dendrite_perSession{i_session} = Events_Dendrite;
        Events_DendriteAVG_perSession{i_session} = Events_DendriteAVG;
        Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
        Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
        Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
        Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
        Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
        Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
        i_mouse_ses = i_mouse_ses + 1;
    end
    Events_Dendrite_perMouse_Down{i_mouse} = Events_Dendrite_perSession;
    Events_DendriteAVG_perMouse_Down{i_mouse} = Events_DendriteAVG_perSession;
    clear CurrentMouse_DendritesTS;
end
clear Events_Dendrite_perSession;
clear Events_Dendrite;

% Save automatically
AutomaticSave_FileName = datestr(datetime, 'yyyy-mm-dd');
AutomaticSave_FileName_tmp = ['Events_Dendrites_Down_', AutomaticSave_FileName];
AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
% Check for unique name
DUMMY = 1;
counter_FileName = 1;
while DUMMY == 1
    
    if exist(AutomaticSave_FileName_tmp_2, 'file') ~= 0
        tmp_nametag = sprintf('_%d', counter_FileName);
        AutomaticSave_FileName = [AutomaticSave_FileName_tmp, tmp_nametag];
        AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
    else
        DUMMY = 0;
    end
    counter_FileName = counter_FileName + 1;
end
AutomaticSave_FileName = [AutomaticSave_FileName, '.mat'];
fprintf('The Analysis results are being saved in %s.\n\n', AutomaticSave_FileName)

save(AutomaticSave_FileName, 'Events_Dendrite_perMouse_Down', 'Events_DendriteAVG_perMouse_Down', '-v7.3');




% Part 2 - This requires to load the 3 variables 
% Events_Dendrite_perMouse
% Events_Dendrite_perMouse_Up
% Events_Dendrite_perMouse_down
clear Dendrites_perMouse; clear Dendrites_Bord_1_perMouse; clear Dendrites_Bord_2_perMouse;
clear Dendrites_perMouse_TS;
clear Current*
n_mice = numel(Events_Dendrite_perMouse);

if isfield(Events_Dendrite_perMouse, 'Composite')
    Events_Dendrite_perMouse = events_memory_reduction(Events_Dendrite_perMouse);
end    
if isfield(Events_Dendrite_perMouse_Up, 'Composite')
    Events_Dendrite_perMouse_Up = events_memory_reduction(Events_Dendrite_perMouse_Up);
end    
if isfield(Events_Dendrite_perMouse_Down, 'Composite')
    Events_Dendrite_perMouse_Down = events_memory_reduction(Events_Dendrite_perMouse_Down);
end    
    
Events_Dendrite_perMouse_Final = cell(1, n_mice);
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    fprintf('\n--- Analyzing Mouse %s ---\n\n', MouseName)
    Events_Dendrite_perSession = Events_Dendrite_perMouse{i_mouse};
    Events_Dendrite_perSession_Up = Events_Dendrite_perMouse_Up{i_mouse};
    Events_Dendrite_perSession_Down = Events_Dendrite_perMouse_Down{i_mouse};
    Events_DendriteAVG_perSession = Events_DendriteAVG_perMouse{i_mouse};
    n_sessions = numel(Events_Dendrite_perSession);
    for i_session = 1:n_sessions
        fprintf('- Analyzing Session %d -\n\n', i_session)
        Events_perDendrite = Events_Dendrite_perSession{i_session};
        Events_perDendrite_Up = Events_Dendrite_perSession_Up{i_session};
        Events_perDendrite_Down = Events_Dendrite_perSession_Down{i_session};
        Events_perDendriteAVG = Events_DendriteAVG_perSession{i_session};
        
        % Scroll events, assign them a tag depending on their
        % characteristics.
        % If there is a contemporary global event, mark is as global.
        % If not global, check for conteporary events in its neighbourhood,
        % if present, mark for removal, otherwise, mark as local
        n_dendrites = numel(Events_perDendrite);
        tic
        for i_dendrite = 1:n_dendrites
            fprintf('Analyzing Dendrite %d/%d\n', i_dendrite, n_dendrites)
            Events_Dendrite = Events_perDendrite{i_dendrite};
            Events_Dendrite_Up = Events_perDendrite_Up{i_dendrite};
            Events_Dendrite_Down = Events_perDendrite_Down{i_dendrite};
            Events_DendriteAVG = Events_perDendriteAVG{i_dendrite};
            n_eventsAVG = numel(Events_DendriteAVG);
            
            EventsSubROINumber = [Events_Dendrite.TraceNumber];
            EventsSubROINumber_Up = [Events_Dendrite_Up.TraceNumber];
            EventsSubROINumber_Down = [Events_Dendrite_Down.TraceNumber];

            % Scroll Events and assign each of them tags
            for i_event = 1:numel(Events_Dendrite)
                Events_Dendrite(i_event).EventType = 1; % 2 = 'Global', 1 = Local
                Events_Dendrite(i_event).Remove = 0; % 1 = 'Yes'
                
                %% Check if it makes sense
                if isnan(Events_Dendrite(i_event).PeakLoc)
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                if Events_Dendrite(i_event).PeakLoc <= 0
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                %% Other Integrity checks
                if Events_Dendrite(i_event).Duration_Decay < 1
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                if Events_Dendrite(i_event).Duration_Rise > 1
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                if Events_Dendrite(i_event).Duration < 1.2
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                if Events_Dendrite(i_event).Amp_Baseline < 1.2
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                if Events_Dendrite(i_event).Amp_Baseline < 100
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                if Events_Dendrite(i_event).Integral < 1200
                    Events_Dendrite(i_event).Remove = 1; % Remove this event from the analysis?
                    continue
                end
                
                %% Check if Global
                for i1_event = 1:n_eventsAVG
                    if (Events_Dendrite(i_event).PeakLoc < (Events_DendriteAVG(i1_event).PeakLoc + Opts.Dendrites.ContemporaryInterval)) && (Events_Dendrite(i_event).PeakLoc > (Events_DendriteAVG(i1_event).PeakLoc - Opts.Dendrites.ContemporaryInterval))
                        Events_Dendrite(i_event).EventType = 2; % 2 = 'Global'
                        Events_Dendrite(i_event).Remove = 0; % Remove this event from the analysis?
                        break
                    end
                end
                if Events_Dendrite(i_event).EventType == 2
                    continue
                end
                
                %% Check if coming from another dendrite
                
                % Get the subROI corresponding to the current event.
                CorrentEvent_subROI = Events_Dendrite(i_event).TraceNumber; 
                if isnan(CorrentEvent_subROI)
                    Events_Dendrite(i_event).Remove = 1;
                    continue
                end
                
                
                % Get the events of the corresponding Up and Down
                % Neighborhoods
                tmpUp = find(EventsSubROINumber_Up == CorrentEvent_subROI);
                tmpDown = find(EventsSubROINumber_Down == CorrentEvent_subROI);
                
                % Check that these events are not contemporary
                EventsUp = Events_Dendrite_Up(tmpUp);
                for i1_event = 1:numel(tmpUp)
                    if (Events_Dendrite(i_event).PeakLoc < Events_Dendrite_Up(i1_event).PeakLoc + Opts.Dendrites.ContemporaryInterval) && (Events_Dendrite(i_event).PeakLoc > Events_Dendrite_Up(i1_event).PeakLoc - Opts.Dendrites.ContemporaryInterval)
                        Events_Dendrite(i_event).Remove = 1;
                        break
                    end
                end
                if Events_Dendrite(i_event).Remove == 1
                    continue
                end
                EventsDown = Events_Dendrite_Down(tmpDown);
                for i1_event = 1:numel(tmpDown)
                    if (Events_Dendrite(i_event).PeakLoc < Events_Dendrite_Down(i1_event).PeakLoc + Opts.Dendrites.ContemporaryInterval) && (Events_Dendrite(i_event).PeakLoc > Events_Dendrite_Down(i1_event).PeakLoc - Opts.Dendrites.ContemporaryInterval)
                        Events_Dendrite(i_event).Remove = 1;
                        break
                    end
                end
                if Events_Dendrite(i_event).Remove == 1
                    continue
                end
                
                
            end
            
            % Remove events that are false positives
            try
                Events_Removal = [Events_Dendrite.Remove];
                fprintf('Removing #%d/%d false positives...\n', numel(Events_Removal(Events_Removal == 1)), numel(Events_Removal));
                Events_Dendrite(Events_Removal == 1) = [];
                fprintf('Done.\n');
            catch
                keyboard
            end
            Events_perDendrite{i_dendrite} = Events_Dendrite;
        end
        Events_Dendrite_perSession{i_session} = Events_perDendrite;
        
        % Get time needed for the computation
        computation_time = toc;
        time_comp_hour = floor(computation_time/(60*60));
        time_comp_m = floor( (computation_time - time_comp_hour*(60*60)) /60);
        time_comp_s = floor(rem( (computation_time - time_comp_hour*(60*60)), 60));
        fprintf('Done! Time elapsed: %dh:%dm:%ds.\n', time_comp_hour, time_comp_m, time_comp_s);
    end
    Events_Dendrite_perMouse_Final{i_mouse} = Events_Dendrite_perSession;
end



Events_Dendrite_perMouse_Final_2 = Events_Dendrite_perMouse_Final;
Events_PropagationDistance_perMouse = cell(1, n_mice);
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    fprintf('\n--- Analyzing Mouse %s ---\n\n', MouseName)
    Events_Dendrite_perSession = Events_Dendrite_perMouse_Final{i_mouse};
    Events_DendriteAVG_perSession = Events_DendriteAVG_perMouse{i_mouse};
    n_sessions = numel(Events_Dendrite_perSession);
    Events_PropagationDistance_perSession = cell(1, n_sessions);
    for i_session = 1:n_sessions
        fprintf('- Analyzing Session %d -\n\n', i_session)
        Events_perDendrite = Events_Dendrite_perSession{i_session};
        Events_perDendriteAVG = Events_DendriteAVG_perSession{i_session};
        
        % Scroll events, assign them a tag depending on their
        % characteristics.
        % If there is a contemporary global event, mark is as global.
        % If not global, check for conteporary events in its neighbourhood,
        % if present, mark for removal, otherwise, mark as local
        n_dendrites = numel(Events_perDendrite);
        tic
        Events_PropagationDistance = [];
        for i_dendrite = 1:n_dendrites
            fprintf('Analyzing Dendrite %d/%d\n', i_dendrite, n_dendrites)
            Events_Dendrite = Events_perDendrite{i_dendrite};
            Events_DendriteAVG = Events_perDendriteAVG{i_dendrite};
            n_eventsAVG = numel(Events_DendriteAVG);
            
            EventsSubROINumber = [Events_Dendrite.TraceNumber];
            EventsSubROIPeakLoc = [Events_Dendrite.PeakLoc];
            
            n_subROIs = nanmax(EventsSubROINumber);
            n_events = numel(Events_Dendrite);
           
            % Scroll Events and assign each of them tags
            for i_event = 1:n_events
%                 fprintf('Checking Event %d/%d\n', i_event, n_events);
                Events_Dendrite(i_event).Remove = 1;
                
                CurrentEvent_Peak = Events_Dendrite(i_event).PeakLoc;
                CurrentEvent_subROI = Events_Dendrite(i_event).TraceNumber;
                tag1 = zeros(1, numel(EventsSubROIPeakLoc));
                tag2 = zeros(1, numel(EventsSubROIPeakLoc));
                % Find every event that is contemporary
                tag1(EventsSubROIPeakLoc >= CurrentEvent_Peak - Opts.Dendrites.ContemporaryInterval) = 1;
                tag2(EventsSubROIPeakLoc <= CurrentEvent_Peak + Opts.Dendrites.ContemporaryInterval) = 1;
                tmp = tag2(tag1 == 1);
                events_contemporary_list = find(tmp);
                
                if numel(events_contemporary_list) > 0
                    contemporary_events = Events_Dendrite(events_contemporary_list);
                else
                    Events_Dendrite(i_event).contemporary_events_distance = NaN;
                    Events_Dendrite(i_event).Remove = 1;
                    continue
                end
                n_contemp_events = numel(contemporary_events);
                if  n_contemp_events <= 1
                    Events_Dendrite(i_event).contemporary_events_distance = NaN;
                    Events_Dendrite(i_event).Remove = 1;
                    continue
                end
                
                % Get the contemporary events sub-ROIs
                contemporary_events_subROI_list = [contemporary_events.TraceNumber];
                
                % Check how far an event has propagated
                counter_adjacency = 0;
                current_distance_in_subROIs = NaN;
                contemporary_events_distance = NaN(1, n_contemp_events);
                for i_cont_events = 1:n_contemp_events
                    current_distance_in_subROIs = abs(CurrentEvent_subROI - contemporary_events_subROI_list(i_cont_events));
                    if current_distance_in_subROIs <= Opts_Dendrites.Adjacency_Length
                        counter_adjacency = counter_adjacency + 1; % Keep track of how many adjacent events have been detected to this one
                    end
                    contemporary_events_distance(i_cont_events) = current_distance_in_subROIs;
                end
                % Do not count duplicates
                contemporary_events_distance = unique(contemporary_events_distance);
                contemporary_events_distance(contemporary_events_distance == 0) = [];
                
                % Check that the current event had at least another detection otherwise
                % mark that event for removal
                tmp_n = numel(contemporary_events_distance);
                if counter_adjacency == 0 || tmp_n == 0 % counts the event itself 
                    Events_Dendrite(i_event).Remove = 1;
                else
                    Events_Dendrite(i_event).Remove = 0;
                end
                if tmp_n == 1
                    if contemporary_events_distance > Opts_Dendrites.Adjacency_Length
                        Events_Dendrite(i_event).Remove = 1;
                    end
                end
                Events_Dendrite(i_event).contemporary_events_distance = contemporary_events_distance;
            end
            
            
            % Remove events that are false positives
            try
                Events_Removal = [Events_Dendrite.Remove];
                fprintf('Removing #%d/%d false positives...\n', numel(Events_Removal(Events_Removal == 1)), numel(Events_Removal));
                Events_Dendrite(Events_Removal == 1) = [];
                fprintf('Done.\n');
            catch
                keyboard
            end
            n_events = numel(Events_Dendrite);
            
            % 
            n_current_distances = NaN(1, n_events);
            current_distances_max = NaN(1, n_events);
            for i_event = 1:n_events
                Events_Dendrite(i_event).Spine = 0;
                current_distances = Events_Dendrite(i_event).contemporary_events_distance;
                current_distances_jumps = diff(current_distances);
                n_contemporary_events = numel(current_distances);
                
                % Divide all the event distances into consecutive ones
                event_group = 1;
                EventGroup = NaN(1, n_contemporary_events);
                for i_cont_event = 1:n_contemporary_events-1
                    if current_distances_jumps(i_cont_event) > 3*(Opts_Dendrites.Adjacency_Length)
                        event_group = event_group + 1;
                    end
                    EventGroup(i_cont_event) = event_group;
                end
                EventGroup(n_contemporary_events) = event_group;
                current_distances_consecutive = current_distances(EventGroup == 1);
                
                % 
                if isempty(current_distances_consecutive)
                    current_distances_max(i_event) = 0;
                    n_current_distances(i_event) = 0;
                else
                    current_distances_max(i_event) = nanmax(current_distances_consecutive);
                    n_current_distances(i_event) = numel(current_distances_consecutive);
                end
                Events_Dendrite(i_event).PropagationDistance = current_distances_max(i_event);
                Events_Dendrite(i_event).contemporary_adjacent_events = current_distances_consecutive;
                if Events_Dendrite(i_event).PropagationDistance <= 20
                    Events_Dendrite(i_event).EventType = 1;
                    if Events_Dendrite(i_event).PropagationDistance <= 2
                        Events_Dendrite(i_event).Spine = 1;
                    end
                else
                    Events_Dendrite(i_event).EventType = 2;
                end
            end
            Events_PropagationDistance = [Events_PropagationDistance, [Events_Dendrite.PropagationDistance]];
            Events_perDendrite{i_dendrite} = Events_Dendrite;
        end
        
        Events_PropagationDistance_perSession{i_session} = Events_PropagationDistance;
        Events_Dendrite_perSession{i_session} = Events_perDendrite;
        
        % Get time needed for the computation
        computation_time = toc;
        time_comp_hour = floor(computation_time/(60*60));
        time_comp_m = floor( (computation_time - time_comp_hour*(60*60)) /60);
        time_comp_s = floor(rem( (computation_time - time_comp_hour*(60*60)), 60));
        fprintf('Done! Time elapsed: %dh:%dm:%ds.\n', time_comp_hour, time_comp_m, time_comp_s);
    end
    Events_PropagationDistance_perMouse{i_mouse} = Events_PropagationDistance_perSession;
    Events_Dendrite_perMouse_Final_2{i_mouse} = Events_Dendrite_perSession;
end

for i_mouse = 1:n_mice
    n_sessions = numel(Events_Dendrite_perSession);
    Events_PropagationDistance_perSession = Events_PropagationDistance_perMouse{i_mouse};
%     for i_session = 1:n_sessions
%         Events_PropagationDistance = Events_PropagationDistance_perSession{i_session};
%         histogram(Events_PropagationDistance);
%         keyboard
%     end
end

% Plot
[Events_Stats, Events_Stats_perMouse] = plot_dendrites (Events_Dendrite_perMouse_Final_2, Events_DendriteAVG_perMouse, Hypnogram_AllSessions, Mouse_Names, Opts);

