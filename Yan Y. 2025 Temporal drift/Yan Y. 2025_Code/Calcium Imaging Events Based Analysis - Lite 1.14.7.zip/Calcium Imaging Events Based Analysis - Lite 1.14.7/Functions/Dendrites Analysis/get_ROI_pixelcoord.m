function [region_pixels] = get_ROI_pixelcoord (overlay_labels, selected_region_tag)
% This function gives as output the list of pixels of a region.
% The input selected_region_tag is just the number of the ROI sub region as
% present in the overlay_labels variable.


[dim1, dim2] = size(overlay_labels);

% Get all the pixels with the same tag (the entire region!)
selected_region_area = 0;
region_pixels = cell(0);
for i_pixel = 1:dim1
    for j_pixel = 1:dim2
        if (overlay_labels(i_pixel, j_pixel) == selected_region_tag)
            selected_region_area = selected_region_area + 1;
            region_pixels{1, selected_region_area} = [i_pixel, j_pixel];
        end
    end
end

end
