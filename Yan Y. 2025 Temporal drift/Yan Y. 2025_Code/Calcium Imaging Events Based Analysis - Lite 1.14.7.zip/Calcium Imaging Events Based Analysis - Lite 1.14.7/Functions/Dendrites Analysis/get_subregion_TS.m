function [time_series_region, n_region_pixels, region_pixels] = get_subregion_TS (images_stack, overlay_labels_ROI, n_subregion, Opts)

% Options
min_n_pixels = Opts.DendriteAnalysis.min_n_pixels;

% Get all the pixel coordinates in the sub-region
for i_subregion = 1:n_subregion
    [region_pixels{i_subregion}] = get_ROI_pixelcoord (overlay_labels_ROI, i_subregion);
    
    n_region_pixels{i_subregion} = numel(region_pixels{i_subregion});
    
    if n_region_pixels{i_subregion} < min_n_pixels
        time_series_region{i_subregion} = NaN;
        continue
    end
    
    
    % Get the average time serioes of the sub-region
    time_series_region{i_subregion} = get_region_time_series(images_stack, region_pixels{i_subregion});
end
