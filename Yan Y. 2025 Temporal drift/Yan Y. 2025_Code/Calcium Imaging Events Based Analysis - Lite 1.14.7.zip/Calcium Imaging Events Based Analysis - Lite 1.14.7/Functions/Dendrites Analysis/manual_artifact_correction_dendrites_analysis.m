function Dendrites_perMouse_TS = manual_artifact_correction_dendrites_analysis (Dendrites_perMouse_TS)
% Manually set to NaNs all the segments of movement artifacts or laser stim



% % MA095
% tmp_Dendrites = Dendrites_perMouse_TS{1, 1}{1, 1};
% for i = 1:numel(tmp_Dendrites)
%     tmp = tmp_Dendrites{i};
%     tmp(:, 3828:3886) = NaN(size(tmp(:, 3828:3886)));
%     tmp(:, 4003:4007) = NaN(size(tmp(:, 4003:4007)));
%     tmp(:, 7929:7977) = NaN(size(tmp(:, 7929:7977)));
%     tmp_Dendrites{i} = tmp;
% end
% 
% tmp_Dendrites = Dendrites_perMouse_TS{1, 1}{1, 2};
% for i = 1:numel(tmp_Dendrites)
%     tmp = tmp_Dendrites{i};
%     tmp(:, 6589:6677) = NaN(size(tmp(:, 6589:6677)));
%     tmp(:, 7606:7686) = NaN(size(tmp(:, 7606:7686)));
%     tmp_Dendrites{i} = tmp;
% end
% 
% % MA096
% tmp_Dendrites = Dendrites_perMouse_TS{1, 2}{1, 1};
% for i = 1:numel(tmp_Dendrites)
%     tmp = tmp_Dendrites{i};
%     tmp(:, 3406:3408) = NaN(size(tmp(:, 3406:3408)));
%     tmp(:, 3416:3418) = NaN(size(tmp(:, 3416:3418)));
%     tmp(:, 3638:3674) = NaN(size(tmp(:, 3638:3674)));
%     tmp(:, 3904:3944) = NaN(size(tmp(:, 3904:3944)));
%     tmp(:, 4146:4168) = NaN(size(tmp(:, 4146:4168)));
%     tmp(:, 4766:4768) = NaN(size(tmp(:, 4766:4768)));
%     tmp_Dendrites{i} = tmp;
% end
% 
% % MA111
% tmp_Dendrites = Dendrites_perMouse_TS{1, 4}{1, 1};
% for i = 1:numel(tmp_Dendrites)
%     tmp = tmp_Dendrites{i};
%     tmp(:, 246:283) = NaN(size(tmp(:, 246:283)));
%     tmp(:, 1909:2030) = NaN(size(tmp(:, 1909:2030)));
%     tmp(:, 4504:4568) = NaN(size(tmp(:, 4504:4568)));
%     tmp_Dendrites{i} = tmp;
% end


% VIP 44
tmp_Dendrites = Dendrites_perMouse_TS{1, 1}{1, 1};
for i = 1:numel(tmp_Dendrites)
    tmp = tmp_Dendrites{i};
    tmp(:, 777:955) = NaN(size(tmp(:, 777:955)));
    tmp(:, 1753:1795) = NaN(size(tmp(:, 1753:1795)));
    tmp(:, 2100:2131) = NaN(size(tmp(:, 2100:2131)));
    tmp_Dendrites{i} = tmp;
end

% VIP 45
tmp_Dendrites = Dendrites_perMouse_TS{1, 2}{1, 1};
for i = 1:numel(tmp_Dendrites)
    tmp = tmp_Dendrites{i};
    tmp(:, 946:1028) = NaN(size(tmp(:, 946:1028)));
    tmp(:, 1201:1223) = NaN(size(tmp(:, 1201:1223)));
    tmp_Dendrites{i} = tmp;
end

% VIP 46
tmp_Dendrites = Dendrites_perMouse_TS{1, 3}{1, 1};
for i = 1:numel(tmp_Dendrites)
    tmp = tmp_Dendrites{i};
    tmp(:, 885:948) = NaN(size(tmp(:, 885:948)));
    tmp(:, 1078:1113) = NaN(size(tmp(:, 1078:1113)));
    tmp_Dendrites{i} = tmp;
end

% VIP 49
tmp_Dendrites = Dendrites_perMouse_TS{1, 4}{1, 1};
for i = 1:numel(tmp_Dendrites)
    tmp = tmp_Dendrites{i};
    tmp(:, 978:993) = NaN(size(tmp(:, 978:993)));
    tmp(:, 1279:1302) = NaN(size(tmp(:, 1279:1302)));
    tmp_Dendrites{i} = tmp;
end


% VIP 50
tmp_Dendrites = Dendrites_perMouse_TS{1, 5}{1, 1};
for i = 1:numel(tmp_Dendrites)
    tmp = tmp_Dendrites{i};
    tmp(:, 1024:1055) = NaN(size(tmp(:, 1024:1055)));
    tmp(:, 1237:1262) = NaN(size(tmp(:, 1237:1262)));
    tmp_Dendrites{i} = tmp;
end







