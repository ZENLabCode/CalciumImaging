function [selected_pixel] = select_pixel_in_ROI_overlay(selected_ROI_with_overlay, background_img)
% Ask the user to select a pixel in the displayed image ROI.
% ---------------------------------------------------------------------- %
% This function will pop up a figure window, where the user is required to
% select (with a single left-click of the mouse) a single pixel.
% Once the pixel is selected correctly (inside the ROI), it will return it
% as output.
% The figure displayed might be chosen, a suggested one is the maximum
% projection over the entire images stack.
% 
% ~~~ INPUTS ~~~ %
% - "selected_ROI_overlay" is the segmented ROI overlay which will be
% displayed in the image.
% - "background_img" is the image which will be displayed inside the ROI
% borders and under the segmentation grid. 
% Its purpose it to help the user selecting a meaningful pixel. 
% 
% ~~~ OUTPUTS ~~~ %
% 
% - "selected_pixel" is the pixel selected by the user.
% 
% ---------------------------------------------------------------------- %

[Height, Width] = size(background_img);

%% Construct the image to show.
img_to_display = double(selected_ROI_with_overlay);

% Normalize to 1 the image to display.
background_img_max = max(max(background_img));
background_img = background_img./background_img_max;

for i_pixel = 1:Height
    for j_pixel = 1:Width
        if (selected_ROI_with_overlay(i_pixel, j_pixel) == 1)
            img_to_display(i_pixel, j_pixel) = selected_ROI_with_overlay(i_pixel, j_pixel).*background_img(i_pixel, j_pixel);
        end
    end
end


%% Show the image.
fprintf('Select a (single) pixel with a left mouse click.\n');
displayed_figure_handle = figure(); 
imshow(img_to_display);
set(gcf, 'Position', get(0,'Screensize'));
title('Left Click to select a pixel. Pixel must be inside the ROI!');
xlabel('Width'); ylabel('Height');
[selected_pixel(1,2), selected_pixel(1,1)] = ginput(1);
selected_pixel = uint16(selected_pixel);

if (selected_ROI_with_overlay(selected_pixel(1,1), selected_pixel(1,2)) == 1)
    fprintf('Selected pixel [%d, %d].\n', selected_pixel(1,1), selected_pixel(1,2));
else
    error('Selected pixel is not part of the ROI!');
end

pause (0.25);
close(displayed_figure_handle);

% imshow(img_to_diaplay, 'border', 'Tight'); 

end

