function [time_series_output] = get_region_time_series(images_stack, region_output)
% This function takes the time series corresponding to all pixels in the
% selected region, and computes its average (and max / min / std) time
% series.
% 
% ~~~ INPUT VARIABLES ~~~ %
% 
% - "images_stack", a 3D matrix containing the DFoF film.
% - "images_stack_info", a struct variable containing the infos about 
%   the image_stack. It is automatically produced by the toolbox when
%   loading or modifying the images_stack used.% Declaring variables.
% - "region_output", a 1 x number_of_pixel_in_region cell. Each cell
%   element is the coordinates of a pixel in the selected region. 
% 
% ~~~ OUTPUT VARIABLES ~~~ %
% 
% - "time_series_output", a structure variable containing 4 time series:
%   the average, the standard deviation, max and min time series 
%   of all the pixels in a region.
% 
% ---------------------------------------------------------------------- %


[dim1,dim2,number_of_frames] = size(images_stack);
number_of_pixel_in_region = numel(region_output);

[tmp_d1, tmp_d2] = size(region_output);
if tmp_d1 > tmp_d2
    region_output = region_output';
end

pixel_values = cell(1, number_of_pixel_in_region);
for i_frame = 1:number_of_frames
    for i_pixel = 1:number_of_pixel_in_region
        current_pixel = region_output{1, i_pixel};
        % Check that the coordinates are not 0s
        if current_pixel(1, 1) == 0
            warning('Pixel coordinate was = 0, set it to 1 automatically')
            current_pixel(1, 1) = 1;
        elseif current_pixel(1, 2) == 0
            warning('Pixel coordinate was = 0, set it to 1 automatically')
            current_pixel(1, 2) = 1;
        end
        % Check that the coordinates are > 0
        if current_pixel(1, 1) < 0
            warning('Pixel coordinate was < 0, set it to NaN')
            current_pixel(1, 1) = NaN;
        elseif current_pixel(1, 2) < 0
            warning('Pixel coordinate was < 0, set it to NaN')
            current_pixel(1, 2) = NaN;
        end
        
        % Check that the coordinates are not NaNs
        if isnan(current_pixel(1, 1)) || isnan(current_pixel(1, 2))
            pixel_values_tmp(1, i_pixel) = NaN;
        else
            % Check that the coordinates are inside the borders.
            if current_pixel(1, 1) > dim1 || current_pixel(1, 2) > dim2
                pixel_values_tmp(1, i_pixel) = NaN;
            else
                % Get the actual pixel value
                try
                    pixel_values_tmp(1, i_pixel) = images_stack(current_pixel(1, 1), current_pixel(1, 2), i_frame);
                catch
                    keyboard
                end
            end
        end

    end
    pixel_values_tmp = double(pixel_values_tmp);
    pixel_values{1, i_frame} = pixel_values_tmp;
end

time_series_average = zeros(1, number_of_frames);
time_series_std = zeros(1, number_of_frames);
time_series_max = zeros(1, number_of_frames);
time_series_min = zeros(1, number_of_frames);
for i_frame = 1:number_of_frames
        % Average
        time_series_average(1, i_frame) = nanmean(pixel_values{1, i_frame});
        % Standard deviation
        time_series_std(1, i_frame) = nanstd(pixel_values{1, i_frame});
        % Max
        time_series_max(1, i_frame) = nanmax(pixel_values{1, i_frame});
        % Min
        time_series_min(1, i_frame) = nanmin(pixel_values{1, i_frame});
end

% Output
time_series_output.average = time_series_average;
time_series_output.std = time_series_std;
time_series_output.max = time_series_max;
time_series_output.min = time_series_min;

end

