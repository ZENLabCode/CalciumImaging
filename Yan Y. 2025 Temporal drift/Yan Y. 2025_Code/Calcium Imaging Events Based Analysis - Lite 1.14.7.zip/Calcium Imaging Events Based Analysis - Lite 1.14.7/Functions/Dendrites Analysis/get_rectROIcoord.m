function ROIcoords = get_rectROIcoord (ROIraw)
% This function gets the coordinates of a single rectangular ROI taken by
% ImageJ

RectBounds = ROIraw.vnRectBounds;
x1 = RectBounds(1);
x2 = RectBounds(3);
y1 = RectBounds(2);
y2 = RectBounds(4);

i = 0;
i_points = 1;
while i < numel(x1:x2)
    x = x1 + i;
    j = 0;
    while j < numel(y1:y2)
        y = y1 + j;
        coordinates(i_points, :) = [x, y];
        i_points = i_points + 1;
        j = j + 1;
    end
    i = i + 1;
end
ROIcoords = coordinates;