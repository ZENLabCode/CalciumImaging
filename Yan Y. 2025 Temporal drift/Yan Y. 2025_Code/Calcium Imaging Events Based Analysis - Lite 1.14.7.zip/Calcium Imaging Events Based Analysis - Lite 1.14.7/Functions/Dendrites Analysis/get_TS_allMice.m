function AllMice_TS = get_TS_allMice (Dendrites_perMouse, Mouse_Names, Mouse_Folders, Mouse_Sessions, Dir_Main)
% This function gets the Time Series (TS) of each subROI, of each dendrite,
% of each session, of each mouse.


n_mice = numel(Mouse_Names);
AllMice_TS = cell(1, n_mice);
for i_mouse = 1:n_mice

    MouseName = Mouse_Names{i_mouse};
    MouseFolder = Mouse_Folders{i_mouse};
    MouseDir = [MouseFolder, '\', MouseName];
    MouseDendrites = Dendrites_perMouse{i_mouse};
    fprintf('-----Loading Time Series for Mouse %s-----\n\n', MouseName);

    % Get each session
    n_current_sessions = Mouse_Sessions(i_mouse);
    MouseSession_TS = cell(1, n_current_sessions);
    for i_session = 1:n_current_sessions
        Session_N = sprintf('Session_%d', i_session);
        SessionDir = [MouseDir, '\', Session_N];
        if exist(SessionDir, 'dir') == 0
           error('The folder "%s" does not exist.\nCreate one manually and make sure that inside it has:\n- The images stack needed for the analysis named DFF_Film.tiff\n- The Hypnogram.mat file', SessionDir) 
        end
        
        SessionDendrites = MouseDendrites{i_session};
        fprintf('-Session %d-\n\n', i_session);

        % Load the tif stack
        cd(SessionDir)
        if exist('DFF_Film.tiff', 'file') ~= 0
            [images_stack, images_info] = load_tiff_stack ('DFF_Film.tiff', SessionDir);
        elseif exist('DFF_film.tiff', 'file') ~= 0
            [images_stack, images_info] = load_tiff_stack ('DFF_film.tiff', SessionDir);
        elseif exist('DFF_Film.tif', 'file') ~= 0
            [images_stack, images_info] = load_tiff_stack ('DFF_Film.tif', SessionDir);
        else
            warning('Could not find the DFF_Film.tiff file in "%s": verify the presence of the file and the correct spelling', SessionDir);
            keyboard
        end
        cd(Dir_Main)
        
        file_name_tmp = images_info.Filename;
        images_stack_info = images_info(1);
        images_stack_info.FileName_short = strtok(file_name_tmp, '.');
        images_stack_info.FileName_extention = '.tif';
        images_stack_info.number_of_frames = numel(images_info);
        clear images_info; clear file_name_tmp;

        % Compute the projection
        [img_stack_projection, img_stack_proj_info] = compute_img_stack_projection(images_stack, 'avg');
        [dim1, dim2] = size(img_stack_projection);

        % Get each Dendrite
        n_dendrites = numel(SessionDendrites);
        SessionDendrites_TS = cell(1, n_dendrites);
        time_tot = 0;
        for i_dendrite = 1:n_dendrites
            tic
            fprintf('Getting TS of Dendrite %d/%d, for Mouse %s.S%d\n', i_dendrite, n_dendrites, MouseName, i_session)
            current_Dendrite = SessionDendrites{i_dendrite};
            n_subROIs = numel(current_Dendrite);
            n_frames = images_stack_info.number_of_frames;
            
            % Get the TS of each sub-ROI
            Dendrite_subROIs_TS = NaN(n_subROIs, n_frames);
            for i_subROI = 1:n_subROIs
                subROI_coords = current_Dendrite{i_subROI};
                subROI_coords = num2cell(subROI_coords, 2);
                
                % Get the time series.
                time_series_output = get_region_time_series(images_stack, subROI_coords);
                time_series_output = [time_series_output.average];
                Dendrite_subROIs_TS(i_subROI, :) = time_series_output;
            end
            computation_time = toc;
            time_comp_hour = floor(computation_time/(60*60));
            time_comp_m = floor( (computation_time - time_comp_hour*(60*60)) /60);
            time_comp_s = floor(rem( (computation_time - time_comp_hour*(60*60)), 60));
            fprintf('Done! Time elapsed: %dh:%dm:%ds.\n', time_comp_hour, time_comp_m, time_comp_s);
            time_tot = time_tot + computation_time;

            SessionDendrites_TS{i_dendrite} = Dendrite_subROIs_TS;
        end
            time_comp_hour = floor(time_tot/(60*60));
            time_comp_m = floor( (time_tot - time_comp_hour*(60*60)) /60);
            time_comp_s = floor(rem( (time_tot - time_comp_hour*(60*60)), 60));
            fprintf('\nDone! Total Time elapsed: %dh:%dm:%ds.\n\n', time_comp_hour, time_comp_m, time_comp_s);

        MouseSession_TS{i_session} = SessionDendrites_TS;
    end
    AllMice_TS{i_mouse} = MouseSession_TS;
end