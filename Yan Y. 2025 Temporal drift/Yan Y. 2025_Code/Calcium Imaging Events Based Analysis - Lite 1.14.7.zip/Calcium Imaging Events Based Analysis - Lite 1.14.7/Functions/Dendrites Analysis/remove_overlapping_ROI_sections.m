function ROIs_Output = remove_overlapping_ROI_sections (ROIs_Input)


n_ROIs = numel(ROIs_Input);

ROI_Updated = ROIs_Input;
for i_ROI = 1:n_ROIs
    % Select current ROI
    current_ROI_1 = ROIs_Input{i_ROI};
    current_ROI_updated = current_ROI_1;
    % Scroll every other ROI, if they are overlapping, cancel the overlap
    for j_ROI = 1:n_ROIs
        if j_ROI == i_ROI
            continue
        end
        current_ROI_2 = ROIs_Input{j_ROI};
                
        % Get the pixels of the two ROIs
        [current_ROI_1_Pixels] = get_ROI_pixelcoord (current_ROI_1, 1);
        [current_ROI_2_Pixels] = get_ROI_pixelcoord (current_ROI_2, 1);
        
        % Scroll all pixels of the two ROIs
        for i_pixel = 1:numel(current_ROI_1_Pixels)
            current_pixel_1 = current_ROI_1_Pixels{i_pixel};
            for j_pixel = 1:numel(current_ROI_2_Pixels)
                current_pixel_2 = current_ROI_2_Pixels{j_pixel};
                
                if (current_pixel_1(1, 1) == current_pixel_2(1, 1)) && (current_pixel_1(1, 2) == current_pixel_2(1, 2))
                    current_ROI_updated(current_pixel_1) = 0;
%                     fprintf('Pixel overpapping\n')
                end
            end
        end
        
    end
    ROI_Updated{i_ROI} = current_ROI_updated;
    
end

ROIs_Output = ROI_Updated;