function [Dendrites_perMouse, Dendrites_Bord_1_perMouse, Dendrites_Bord_2_perMouse] = load_dendrites_ROIs_allMice(Dir_Data, Mouse_Names, Mouse_Folders, Mouse_Sessions, Opts_Dendrites)
% This function loads the Dendrites ROIs for every mouse

% Initialize
if exist('Dir_Data', 'var') == 0
    fprintf('Please Specify the Data Folder.')
    Dir_Data = uigetdir('Choose Data Folder');
end
addpath(genpath(Dir_Data));

n_mice = numel(Mouse_Names);

% Scroll each mouse
Dendrites_perMouse = cell(1, n_mice);
Dendrites_Bord_1_perMouse = cell(1, n_mice);
Dendrites_Bord_2_perMouse = cell(1, n_mice);
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    MouseFolder = Mouse_Folders{i_mouse};
    MouseDir = [MouseFolder, '\', MouseName];
    n_current_sessions = Mouse_Sessions(i_mouse);
    
    % Scroll and load sessions.
    Dendrites_perSession = cell(1, n_current_sessions);
    Dendrites_Bord_1_perSession = cell(1, n_current_sessions);
    Dendrites_Bord_2_perSession = cell(1, n_current_sessions);
    for i_session = 1:n_current_sessions
        Session_N = sprintf('Session_%d', i_session);
        SessionDir = [MouseDir, '\', Session_N];
        SessionDendritesDir = [SessionDir, '\', 'Dendrites'];
        
        [Dendrites, Dendrites_Bord_1, Dendrites_Bord_2] = load_dendrites_ROIs_singleMouse(SessionDendritesDir, Opts_Dendrites);
        Dendrites_perSession{i_session} = Dendrites;
        Dendrites_Bord_1_perSession{i_session} = Dendrites_Bord_1;
        Dendrites_Bord_2_perSession{i_session} = Dendrites_Bord_2;
    end
    
    % Save dendrites ROI coords per mouse
    Dendrites_perMouse{i_mouse} = Dendrites_perSession;
    Dendrites_Bord_1_perMouse{i_mouse} = Dendrites_Bord_1_perSession;
    Dendrites_Bord_2_perMouse{i_mouse} = Dendrites_Bord_2_perSession;
end
