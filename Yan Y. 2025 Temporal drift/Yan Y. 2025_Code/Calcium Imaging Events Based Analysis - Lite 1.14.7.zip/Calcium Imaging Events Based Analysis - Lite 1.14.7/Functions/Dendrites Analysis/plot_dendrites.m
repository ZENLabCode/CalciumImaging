function [Events_Stats, Events_Stats_perMouse] = plot_dendrites (Events_allMouse, Events_allMouse_AVG, Hypnogram_AllSessions, Mouse_Names, Opts)




%% Initialize
n_mice = numel(Mouse_Names);

% Get the total duration of sleep states.
for i_session = 1:numel(Hypnogram_AllSessions)
    Hypnogram = Hypnogram_AllSessions(i_session).Hypnogram;
    MouseName = Hypnogram_AllSessions(i_session).MouseName;
    HypnoState(i_session).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
    HypnoState(i_session).MouseName = MouseName;
    HypnoState(i_session).Session = i_session;
end

for i_session = 1:numel(HypnoState)
    Duration_ToT(i_session).Awake = HypnoState(i_session).Duration.Awake;
    Duration_ToT(i_session).NREM = HypnoState(i_session).Duration.NoNREM;
    Duration_ToT(i_session).REM = HypnoState(i_session).Duration.REM;
end

i_mouse_session = 1;
% Remove false positive events & assign Global/Local event tag
for i_mouse = 1:n_mice
    fprintf('\n---Analyzing mouse %s---\n\n', Mouse_Names{i_mouse})
    Events_currentMouse = Events_allMouse{i_mouse};
    Events_currentMouse_AVG = Events_allMouse_AVG{i_mouse};
    n_sessions = numel(Events_currentMouse);
    for i_session = 1:n_sessions
        fprintf('- Analyzing Session %d -\n', i_session)
        Events_currentSession = Events_currentMouse{i_session};
        Events_currentSession_AVG = Events_currentMouse_AVG{i_session};
        n_dendrites = numel(Events_currentSession);
        for i_dendrite = 1:n_dendrites
            fprintf('Analyzing Dendrite %d/%d\n', i_dendrite, n_dendrites)
            Events_currentDendrite = Events_currentSession{i_dendrite};
            Events_currentDendrite_AVG = Events_currentSession_AVG{i_dendrite};
            n_events = numel(Events_currentDendrite);
            
            try
                for i_event = 1:n_events
                    Events_currentDendrite(i_event).EventGroup = NaN;
                    if Events_currentDendrite(i_event).EventType == 2
%                         Events_currentDendrite(i_event).EventGroup = 0;
                    end
                    Events_currentDendrite(i_event).Skip = 0;
                end
            catch
                keyboard
            end
            
            i_EventGroup = 1;
            Events_currentDendrite(1).EventGroup = 1;
            for i_event = 1:n_events - 1
                
                for j_event = 2:n_events
                    if isnan(Events_currentDendrite(i_event).EventGroup)
                        if (Events_currentDendrite(i_event).Start > (Events_currentDendrite(j_event).Start - Opts.Dendrites.ContemporaryInterval)) && (Events_currentDendrite(i_event).Start < (Events_currentDendrite(j_event).Start + Opts.Dendrites.ContemporaryInterval))
                            Events_currentDendrite(j_event).EventGroup = i_event;
                            Events_currentDendrite(j_event).Skip = 1;
                        end
                    end
                end

            end
            
            for i_State = 1:4
                if i_State == 3
                    continue
                end
                Events_Current_State = Events_currentDendrite([Events_currentDendrite.StateTag] == i_State);
                if isempty(Events_currentDendrite_AVG)
                    Events_Current_State_AVG = [];
                else
                    Events_Current_State_AVG = Events_currentDendrite_AVG([Events_currentDendrite_AVG.StateTag] == i_State);
                end
                Events_Type = [Events_Current_State.EventType];
%                 Events_PropagationDistance = [Events_Current_State.PropagationDistance]; % units = #subROI
%                 Events_PropagationDistance = Events_PropagationDistance.*(0.51*2); % units = [um] (micrometers)
                
                Events_Current_State_Global = Events_Current_State(find(Events_Type == 2));
                Events_Current_State_Local = Events_Current_State(find(Events_Type == 1));
                Events_Group_Global = [Events_Current_State_Global.EventGroup];
                Events_Group_Local = [Events_Current_State_Local.EventGroup];
                
                Events_Global = Events_Group_Global(Events_Group_Global ~= 0);
                Events_Local = Events_Group_Local(Events_Group_Local ~= 0);

                [Events_Local_Unique,Events_Local_Unique_ID,ic] = unique(Events_Local);
                [Events_Global_Unique,Events_Global_Unique_ID,ic] = unique(Events_Global);
                
                Events_Current_State_Local_Unique =  Events_Current_State_Local(Events_Local_Unique_ID);
                Events_Current_State_Global_Unique = Events_Current_State_Global(Events_Global_Unique_ID);
                
                Events_Current_State_Unique = [Events_Current_State_Local_Unique, Events_Current_State_Global_Unique];
                
                currentdendrite_Events_PropagationDistance = [Events_Current_State_Unique.PropagationDistance]; % units = #subROI
                currentdendrite_Events_PropagationDistance = currentdendrite_Events_PropagationDistance.*(0.51*2); % units = [um] (micrometers)
                currentdendrite_Events_PropagationDistance(currentdendrite_Events_PropagationDistance == 0) = 1;
                
                currentdendrite_EventsLocal_PropagationDistance = [Events_Current_State_Local_Unique.PropagationDistance]; % units = #subROI
                currentdendrite_EventsLocal_PropagationDistance = currentdendrite_EventsLocal_PropagationDistance.*(0.51*2); % units = [um] (micrometers)
                currentdendrite_EventsLocal_PropagationDistance(currentdendrite_EventsLocal_PropagationDistance == 0) = 1;
                
                currentdendrite_EventsGlobal_PropagationDistance = [Events_Current_State_Global_Unique.PropagationDistance]; % units = #subROI
                currentdendrite_EventsGlobal_PropagationDistance = currentdendrite_EventsGlobal_PropagationDistance.*(0.51*2); % units = [um] (micrometers)
                currentdendrite_EventsGlobal_PropagationDistance(currentdendrite_EventsGlobal_PropagationDistance == 0) = 1;
                
                
                if i_State == 1
                    n_Events_Local(i_dendrite).Awake = numel(Events_Local_Unique);
                    n_Events_Global(i_dendrite).Awake = numel(Events_Global_Unique);
                    Events_Freq_Local(i_dendrite).Awake = n_Events_Local(i_dendrite).Awake./Duration_ToT(i_mouse_session).Awake;
                    Events_Freq_Global(i_dendrite).Awake = n_Events_Global(i_dendrite).Awake./Duration_ToT(i_mouse_session).Awake;
                    Events_PropagationDistance(i_dendrite).Awake = currentdendrite_Events_PropagationDistance;
                    EventsLocal_PropagationDistance(i_dendrite).Awake = currentdendrite_EventsLocal_PropagationDistance;
                    EventsGlobal_PropagationDistance(i_dendrite).Awake = currentdendrite_EventsGlobal_PropagationDistance;
                end
                
                if i_State == 2
                    n_Events_Local(i_dendrite).NREM = numel(Events_Local_Unique);
                    n_Events_Global(i_dendrite).NREM = numel(Events_Global_Unique);
                    Events_Freq_Local(i_dendrite).NREM = n_Events_Local(i_dendrite).NREM./Duration_ToT(i_mouse_session).NREM;
                    Events_Freq_Global(i_dendrite).NREM = n_Events_Global(i_dendrite).NREM./Duration_ToT(i_mouse_session).NREM;
                    Events_PropagationDistance(i_dendrite).NREM = currentdendrite_Events_PropagationDistance;
                    EventsLocal_PropagationDistance(i_dendrite).NREM = currentdendrite_EventsLocal_PropagationDistance;
                    EventsGlobal_PropagationDistance(i_dendrite).NREM = currentdendrite_EventsGlobal_PropagationDistance;
                end
                
                if i_State == 4
                    n_Events_Local(i_dendrite).REM = numel(Events_Local_Unique);
                    n_Events_Global(i_dendrite).REM = numel(Events_Global_Unique);
                    Events_Freq_Local(i_dendrite).REM = n_Events_Local(i_dendrite).REM./Duration_ToT(i_mouse_session).REM;
                    Events_Freq_Global(i_dendrite).REM = n_Events_Global(i_dendrite).REM./Duration_ToT(i_mouse_session).REM;
                    Events_PropagationDistance(i_dendrite).REM = currentdendrite_Events_PropagationDistance;
                    EventsLocal_PropagationDistance(i_dendrite).REM = currentdendrite_EventsLocal_PropagationDistance;
                    EventsGlobal_PropagationDistance(i_dendrite).REM = currentdendrite_EventsGlobal_PropagationDistance;
                end
            end
            
        end
        Events_Stats_perSession(i_session).n_Events_Local = n_Events_Local;
        Events_Stats_perSession(i_session).n_Events_Global = n_Events_Global;
        Events_Stats_perSession(i_session).Events_Freq_Local = Events_Freq_Local;
        Events_Stats_perSession(i_session).Events_Freq_Global = Events_Freq_Global;
        Events_Stats_perSession(i_session).Events_PropagationDistance = Events_PropagationDistance;
        Events_Stats_perSession(i_session).EventsLocal_PropagationDistance = EventsLocal_PropagationDistance;
        Events_Stats_perSession(i_session).EventsGlobal_PropagationDistance = EventsGlobal_PropagationDistance;
        
        clear n_Events_Local; clear n_Events_Global; clear Events_Freq_Local; clear Events_Freq_Global; clear EventsLocal_PropagationDistance; clear EventsGlobal_PropagationDistance; clear Events_PropagationDistance
        i_mouse_session = i_mouse_session + 1;
    end
    Events_Stats_perMouse{i_mouse} = Events_Stats_perSession;
    clear Events_Stats_perSession
end

% keyboard

EventsPropagation_DendriteAvg_all = [];
EventsLocalPropagation_DendriteAvg_all = [];
EventsGlobalPropagation_DendriteAvg_all = [];
EventsPropagation_DendriteStd_all = [];

i_session_tot = 1;
allDendrites_n_Events_Local = [];
allDendrites_n_Events_Global = [];
allDendrites_Events_Freq_Local = [];
allDendrites_Events_Freq_Global = [];
allDendrites_Events_Propagation_Local = [];
allDendrites_Events_Propagation_Global = [];
for i_mouse = 1:n_mice
    fprintf('\n---Analyzing mouse %s---\n\n', Mouse_Names{i_mouse})
    Events_Stats_currentMouse = Events_Stats_perMouse{i_mouse};
    n_sessions = numel(Events_Stats_currentMouse);
    
    % Get the average per session
    tmpEventsPropagation_DendriteAvg = cell(1, n_sessions);
    tmpEventsPropagation_DendriteStd = cell(1, n_sessions);
    for i_session = 1:n_sessions
        fprintf('Analyzing session %d\n', i_session)
        Events_Stats_currentSession = Events_Stats_currentMouse(i_session);

        %         n_dendrites = numel(Events_Stats_currentSession);
        n_Events_Local = Events_Stats_currentSession.n_Events_Local;
        n_Events_Global = Events_Stats_currentSession.n_Events_Global;
        Events_Freq_Local = Events_Stats_currentSession.Events_Freq_Local;
        Events_Freq_Global = Events_Stats_currentSession.Events_Freq_Global;
        Events_Propagation_Local = Events_Stats_currentSession.EventsLocal_PropagationDistance;
        Events_Propagation_Global = Events_Stats_currentSession.EventsGlobal_PropagationDistance;
        
        EventsPropagation = Events_Stats_currentSession.Events_PropagationDistance;
        n_dendrites = numel(EventsPropagation);
        
        % Unite all dendrites
        allDendrites_n_Events_Local = [allDendrites_n_Events_Local, n_Events_Local];
        allDendrites_n_Events_Global = [allDendrites_n_Events_Global, n_Events_Global];
        allDendrites_Events_Freq_Local = [allDendrites_Events_Freq_Local, Events_Freq_Local];
        allDendrites_Events_Freq_Global = [allDendrites_Events_Freq_Global, Events_Freq_Global];
        allDendrites_Events_Propagation_Local = [allDendrites_Events_Propagation_Local, Events_Propagation_Local];
        allDendrites_Events_Propagation_Global = [allDendrites_Events_Propagation_Global, Events_Propagation_Global];
        
        % Mean propagation
        EventsPropagation_DendriteAvg = [];
        EventsPropagation_DendriteStd = [];
        for i_dendrite = 1:n_dendrites
            EventsPropagation_DendriteAvg(i_dendrite).Awake = nanmean([EventsPropagation(i_dendrite).Awake]);
            EventsPropagation_DendriteStd(i_dendrite).Awake = nanstd([EventsPropagation(i_dendrite).Awake]);
            EventsPropagation_DendriteAvg(i_dendrite).NREM = nanmean([EventsPropagation(i_dendrite).NREM]);
            EventsPropagation_DendriteStd(i_dendrite).NREM = nanstd([EventsPropagation(i_dendrite).NREM]);
            EventsPropagation_DendriteAvg(i_dendrite).REM = nanmean([EventsPropagation(i_dendrite).REM]);
            EventsPropagation_DendriteStd(i_dendrite).REM = nanstd([EventsPropagation(i_dendrite).REM]);
        end
        
        tmpEventsPropagation_DendriteAvg{i_session} = EventsPropagation_DendriteAvg;
        tmpEventsPropagation_DendriteStd{i_session} = EventsPropagation_DendriteStd;

        % Mean propagation Local
        EventsLocal_Propagation_DendriteAvg = [];
        EventsGlobalPropagation_DendriteAvg = [];
        for i_dendrite = 1:n_dendrites
            EventsLocal_Propagation_DendriteAvg(i_dendrite).Awake = nanmean([Events_Propagation_Local(i_dendrite).Awake]);
            EventsLocal_Propagation_DendriteAvg(i_dendrite).NREM = nanmean([Events_Propagation_Local(i_dendrite).NREM]);
            EventsLocal_Propagation_DendriteAvg(i_dendrite).REM = nanmean([Events_Propagation_Local(i_dendrite).REM]);
            EventsGlobalPropagation_DendriteAvg(i_dendrite).Awake = nanmean([Events_Propagation_Global(i_dendrite).Awake]);
            EventsGlobalPropagation_DendriteAvg(i_dendrite).NREM = nanmean([Events_Propagation_Global(i_dendrite).NREM]);
            EventsGlobalPropagation_DendriteAvg(i_dendrite).REM = nanmean([Events_Propagation_Global(i_dendrite).REM]);
        end
        tmpEventsLocalPropagation_DendriteAvg{i_session} = EventsLocal_Propagation_DendriteAvg;
        tmpEventsGlobalPropagation_DendriteAvg{i_session} = EventsGlobalPropagation_DendriteAvg;
        
        % Events Propagation
        tmpEvents_Stats(i_session).Propagation_Avg.Awake = nanmean([EventsPropagation.Awake]);
        tmpEvents_Stats(i_session).Propagation_Avg.NREM = nanmean([EventsPropagation.NREM]);
        tmpEvents_Stats(i_session).Propagation_Avg.REM = nanmean([EventsPropagation.REM]);
        tmpEvents_Stats(i_session).Propagation_Std.Awake = nanstd([EventsPropagation.Awake]);
        tmpEvents_Stats(i_session).Propagation_Std.NREM = nanstd([EventsPropagation.NREM]);
        tmpEvents_Stats(i_session).Propagation_Std.REM = nanstd([EventsPropagation.REM]);
        
        % Events Propagation Local
        tmpEvents_Stats(i_session).PropagationLocal_Avg.Awake = nanmean([Events_Propagation_Local.Awake]);
        tmpEvents_Stats(i_session).PropagationLocal_Avg.NREM = nanmean([Events_Propagation_Local.NREM]);
        tmpEvents_Stats(i_session).PropagationLocal_Avg.REM = nanmean([Events_Propagation_Local.REM]);
        tmpEvents_Stats(i_session).PropagationLocal_Std.Awake = nanstd([Events_Propagation_Local.Awake]);
        tmpEvents_Stats(i_session).PropagationLocal_Std.NREM = nanstd([Events_Propagation_Local.NREM]);
        tmpEvents_Stats(i_session).PropagationLocal_Std.REM = nanstd([Events_Propagation_Local.REM]);
        
        % Events Propagation Global
        tmpEvents_Stats(i_session).PropagationGlobal_Avg.Awake = nanmean([Events_Propagation_Global.Awake]);
        tmpEvents_Stats(i_session).PropagationGlobal_Avg.NREM = nanmean([Events_Propagation_Global.NREM]);
        tmpEvents_Stats(i_session).PropagationGlobal_Avg.REM = nanmean([Events_Propagation_Global.REM]);
        tmpEvents_Stats(i_session).PropagationGlobal_Std.Awake = nanstd([Events_Propagation_Global.Awake]);
        tmpEvents_Stats(i_session).PropagationGlobal_Std.NREM = nanstd([Events_Propagation_Global.NREM]);
        tmpEvents_Stats(i_session).PropagationGlobal_Std.REM = nanstd([Events_Propagation_Global.REM]);
        
        % n Events Local
        tmpEvents_Stats(i_session).n_EventsLocal_Avg.Awake = nanmean([n_Events_Local.Awake]);
        tmpEvents_Stats(i_session).n_EventsLocal_Avg.NREM = nanmean([n_Events_Local.NREM]);
        tmpEvents_Stats(i_session).n_EventsLocal_Avg.REM = nanmean([n_Events_Local.REM]);
        tmpEvents_Stats(i_session).n_EventsLocal_Std.Awake = nanstd([n_Events_Local.Awake]);
        tmpEvents_Stats(i_session).n_EventsLocal_Std.NREM = nanstd([n_Events_Local.NREM]);
        tmpEvents_Stats(i_session).n_EventsLocal_Std.REM = nanstd([n_Events_Local.REM]);
        
        % n Events Global
        tmpEvents_Stats(i_session).n_EventsGlobal_Avg.Awake = nanmean([n_Events_Global.Awake]);
        tmpEvents_Stats(i_session).n_EventsGlobal_Avg.NREM = nanmean([n_Events_Global.NREM]);
        tmpEvents_Stats(i_session).n_EventsGlobal_Avg.REM = nanmean([n_Events_Global.REM]);
        tmpEvents_Stats(i_session).n_EventsGlobal_Std.Awake = nanstd([n_Events_Global.Awake]);
        tmpEvents_Stats(i_session).n_EventsGlobal_Std.NREM = nanstd([n_Events_Global.NREM]);
        tmpEvents_Stats(i_session).n_EventsGlobal_Std.REM = nanstd([n_Events_Global.REM]);
        
        % Events Freq Local
        tmpEvents_Stats(i_session).Events_Freq_Local_Avg.Awake = nanmean([Events_Freq_Local.Awake]);
        tmpEvents_Stats(i_session).Events_Freq_Local_Avg.NREM = nanmean([Events_Freq_Local.NREM]);
        tmpEvents_Stats(i_session).Events_Freq_Local_Avg.REM = nanmean([Events_Freq_Local.REM]);
        tmpEvents_Stats(i_session).Events_Freq_Local_Std.Awake = nanstd([Events_Freq_Local.Awake]);
        tmpEvents_Stats(i_session).Events_Freq_Local_Std.NREM = nanstd([Events_Freq_Local.NREM]);
        tmpEvents_Stats(i_session).Events_Freq_Local_Std.REM = nanstd([Events_Freq_Local.REM]);
        
        % Events Freq Global
        tmpEvents_Stats(i_session).Events_Freq_Global_Avg.Awake = nanmean([Events_Freq_Global.Awake]);
        tmpEvents_Stats(i_session).Events_Freq_Global_Avg.NREM = nanmean([Events_Freq_Global.NREM]);
        tmpEvents_Stats(i_session).Events_Freq_Global_Avg.REM = nanmean([Events_Freq_Global.REM]);
        tmpEvents_Stats(i_session).Events_Freq_Global_Std.Awake = nanstd([Events_Freq_Global.Awake]);
        tmpEvents_Stats(i_session).Events_Freq_Global_Std.NREM = nanstd([Events_Freq_Global.NREM]);
        tmpEvents_Stats(i_session).Events_Freq_Global_Std.REM = nanstd([Events_Freq_Global.REM]);
        
    end
    
    % Get the avereage per mouse
    DUMMY = 1;
    while DUMMY == 1
        if n_sessions == 2
            tmp1 = tmpEventsPropagation_DendriteAvg{1};
            tmp2 = tmpEventsPropagation_DendriteAvg{2};
            tmp1Awake = [tmp1.Awake];
            tmp1NREM = [tmp1.NREM];
            tmp1REM = [tmp1.REM];
            tmp2Awake = [tmp2.Awake];
            tmp2NREM = [tmp2.NREM];
            tmp2REM = [tmp2.REM];
            
            try
                tmp3Awake = [tmp1Awake, tmp2Awake];
                tmp3NREM = [tmp1NREM, tmp2NREM];
                tmp3REM = [tmp1REM, tmp2REM];
                
                for i_dendrite = 1:numel(tmp3Awake)
                    EventsPropagation_DendriteAvg(i_dendrite).Awake = tmp3Awake(i_dendrite);
                    EventsPropagation_DendriteAvg(i_dendrite).NREM = tmp3NREM(i_dendrite);
                    EventsPropagation_DendriteAvg(i_dendrite).REM = tmp3REM(i_dendrite);
                end
            catch
                EventsPropagation_DendriteAvg = tmpEventsPropagation_DendriteAvg{i_session};
            end
            % Local only
            clear tmp1; clear tmp2; clear tmp1Awake; clear tmp1NREM; clear tmp1REM; clear tmp2Awake; clear tmp2NREM; clear tmp2REM;
            
            tmp1 = tmpEventsLocalPropagation_DendriteAvg{1};
            tmp2 = tmpEventsLocalPropagation_DendriteAvg{2};
            tmp1Awake = [tmp1.Awake];
            tmp1NREM = [tmp1.NREM];
            tmp1REM = [tmp1.REM];
            tmp2Awake = [tmp2.Awake];
            tmp2NREM = [tmp2.NREM];
            tmp2REM = [tmp2.REM];
            try
                tmp3Awake = [tmp1Awake, tmp2Awake];
                tmp3NREM = [tmp1NREM, tmp2NREM];
                tmp3REM = [tmp1REM, tmp2REM];
                for i_dendrite = 1:numel(tmp3Awake)
                    EventsLocal_Propagation_DendriteAvg(i_dendrite).Awake = tmp3Awake(i_dendrite);
                    EventsLocal_Propagation_DendriteAvg(i_dendrite).NREM = tmp3NREM(i_dendrite);
                    EventsLocal_Propagation_DendriteAvg(i_dendrite).REM = tmp3REM(i_dendrite);
                end
            catch
                EventsLocal_Propagation_DendriteAvg = tmpEventsLocalPropagation_DendriteAvg{i_session};
            end
            % Global only
            clear tmp1; clear tmp2; clear tmp1Awake; clear tmp1NREM; clear tmp1REM; clear tmp2Awake; clear tmp2NREM; clear tmp2REM;
            
            tmp1 = tmpEventsGlobalPropagation_DendriteAvg{1};
            tmp2 = tmpEventsGlobalPropagation_DendriteAvg{2};
            tmp1Awake = [tmp1.Awake];
            tmp1NREM = [tmp1.NREM];
            tmp1REM = [tmp1.REM];
            tmp2Awake = [tmp2.Awake];
            tmp2NREM = [tmp2.NREM];
            tmp2REM = [tmp2.REM];
            try
                tmp3Awake = [tmp1Awake, tmp2Awake];
                tmp3NREM = [tmp1NREM, tmp2NREM];
                tmp3REM = [tmp1REM, tmp2REM];
                for i_dendrite = 1:numel(tmp3Awake)
                    EventsGlobal_Propagation_DendriteAvg(i_dendrite).Awake = tmp3Awake(i_dendrite);
                    EventsGlobal_Propagation_DendriteAvg(i_dendrite).NREM = tmp3NREM(i_dendrite);
                    EventsGlobal_Propagation_DendriteAvg(i_dendrite).REM = tmp3REM(i_dendrite);
                end
            catch
                EventsGlobal_Propagation_DendriteAvg = tmpEventsGlobalPropagation_DendriteAvg{i_session};
            end
            
            % Events Propagation
            Events_Stats.Propagation_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Propagation_Avg.Awake, tmpEvents_Stats(2).Propagation_Avg.Awake]);
            Events_Stats.Propagation_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Propagation_Avg.NREM, tmpEvents_Stats(2).Propagation_Avg.NREM]);
            Events_Stats.Propagation_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).Propagation_Avg.REM, tmpEvents_Stats(2).Propagation_Avg.REM]);
            Events_Stats.Propagation_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Propagation_Std.Awake, tmpEvents_Stats(2).Propagation_Std.Awake]);
            Events_Stats.Propagation_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Propagation_Std.NREM, tmpEvents_Stats(2).Propagation_Std.NREM]);
            Events_Stats.Propagation_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).Propagation_Std.REM, tmpEvents_Stats(2).Propagation_Std.REM]);
            Events_Stats.Propagation_All(i_mouse).Awake = ([tmpEvents_Stats(1).Propagation_Avg.Awake, tmpEvents_Stats(2).Propagation_Avg.Awake]);
            Events_Stats.Propagation_All(i_mouse).NREM = ([tmpEvents_Stats(1).Propagation_Avg.NREM, tmpEvents_Stats(2).Propagation_Avg.NREM]);
            Events_Stats.Propagation_All(i_mouse).REM = ([tmpEvents_Stats(1).Propagation_Avg.REM, tmpEvents_Stats(2).Propagation_Avg.REM]);

            % Events Propagation Local
            Events_Stats.PropagationLocal_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).PropagationLocal_Avg.Awake, tmpEvents_Stats(2).PropagationLocal_Avg.Awake]);
            Events_Stats.PropagationLocal_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).PropagationLocal_Avg.NREM, tmpEvents_Stats(2).PropagationLocal_Avg.NREM]);
            Events_Stats.PropagationLocal_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).PropagationLocal_Avg.REM, tmpEvents_Stats(2).PropagationLocal_Avg.REM]);
            Events_Stats.PropagationLocal_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).PropagationLocal_Std.Awake, tmpEvents_Stats(2).PropagationLocal_Std.Awake]);
            Events_Stats.PropagationLocal_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).PropagationLocal_Std.NREM, tmpEvents_Stats(2).PropagationLocal_Std.NREM]);
            Events_Stats.PropagationLocal_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).PropagationLocal_Std.REM, tmpEvents_Stats(2).PropagationLocal_Std.REM]);
            
            % Events Propagation Global
            Events_Stats.PropagationGlobal_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).PropagationGlobal_Avg.Awake, tmpEvents_Stats(2).PropagationGlobal_Avg.Awake]);
            Events_Stats.PropagationGlobal_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).PropagationGlobal_Avg.NREM, tmpEvents_Stats(2).PropagationGlobal_Avg.NREM]);
            Events_Stats.PropagationGlobal_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).PropagationGlobal_Avg.REM, tmpEvents_Stats(2).PropagationGlobal_Avg.REM]);
            Events_Stats.PropagationGlobal_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).PropagationGlobal_Std.Awake, tmpEvents_Stats(2).PropagationGlobal_Std.Awake]);
            Events_Stats.PropagationGlobal_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).PropagationGlobal_Std.NREM, tmpEvents_Stats(2).PropagationGlobal_Std.NREM]);
            Events_Stats.PropagationGlobal_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).PropagationGlobal_Std.REM, tmpEvents_Stats(2).PropagationGlobal_Std.REM]);
            
            % n Events Local
            Events_Stats.n_EventsLocal_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).n_EventsLocal_Avg.Awake, tmpEvents_Stats(2).n_EventsLocal_Avg.Awake]);
            Events_Stats.n_EventsLocal_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).n_EventsLocal_Avg.NREM, tmpEvents_Stats(2).n_EventsLocal_Avg.NREM]);
            Events_Stats.n_EventsLocal_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).n_EventsLocal_Avg.REM, tmpEvents_Stats(2).n_EventsLocal_Avg.REM]);
            Events_Stats.n_EventsLocal_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).n_EventsLocal_Std.Awake, tmpEvents_Stats(2).n_EventsLocal_Std.Awake]);
            Events_Stats.n_EventsLocal_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).n_EventsLocal_Std.NREM, tmpEvents_Stats(2).n_EventsLocal_Std.NREM]);
            Events_Stats.n_EventsLocal_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).n_EventsLocal_Std.REM, tmpEvents_Stats(2).n_EventsLocal_Std.REM]);
            
            % n Events Global
            Events_Stats.n_EventsGlobal_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Avg.Awake, tmpEvents_Stats(2).n_EventsGlobal_Avg.Awake]);
            Events_Stats.n_EventsGlobal_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Avg.NREM, tmpEvents_Stats(2).n_EventsGlobal_Avg.NREM]);
            Events_Stats.n_EventsGlobal_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Avg.REM, tmpEvents_Stats(2).n_EventsGlobal_Avg.REM]);
            Events_Stats.n_EventsGlobal_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Std.Awake, tmpEvents_Stats(2).n_EventsGlobal_Std.Awake]);
            Events_Stats.n_EventsGlobal_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Std.NREM, tmpEvents_Stats(2).n_EventsGlobal_Std.NREM]);
            Events_Stats.n_EventsGlobal_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).n_EventsGlobal_Std.REM, tmpEvents_Stats(2).n_EventsGlobal_Std.REM]);
            
            % Events Freq Local
            Events_Stats.Events_Freq_Local_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Avg.Awake, tmpEvents_Stats(2).Events_Freq_Local_Avg.Awake]);
            Events_Stats.Events_Freq_Local_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Avg.NREM, tmpEvents_Stats(2).Events_Freq_Local_Avg.NREM]);
            Events_Stats.Events_Freq_Local_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Avg.REM, tmpEvents_Stats(2).Events_Freq_Local_Avg.REM]);
            Events_Stats.Events_Freq_Local_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Std.Awake, tmpEvents_Stats(2).Events_Freq_Local_Std.Awake]);
            Events_Stats.Events_Freq_Local_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Std.NREM, tmpEvents_Stats(2).Events_Freq_Local_Std.NREM]);
            Events_Stats.Events_Freq_Local_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).Events_Freq_Local_Std.REM, tmpEvents_Stats(2).Events_Freq_Local_Std.REM]);
            
            % Events Freq Global
            Events_Stats.Events_Freq_Global_Avg(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Avg.Awake, tmpEvents_Stats(2).Events_Freq_Global_Avg.Awake]);
            Events_Stats.Events_Freq_Global_Avg(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Avg.NREM, tmpEvents_Stats(2).Events_Freq_Global_Avg.NREM]);
            Events_Stats.Events_Freq_Global_Avg(i_mouse).REM = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Avg.REM, tmpEvents_Stats(2).Events_Freq_Global_Avg.REM]);
            Events_Stats.Events_Freq_Global_Std(i_mouse).Awake = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Std.Awake, tmpEvents_Stats(2).Events_Freq_Global_Std.Awake]);
            Events_Stats.Events_Freq_Global_Std(i_mouse).NREM = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Std.NREM, tmpEvents_Stats(2).Events_Freq_Global_Std.NREM]);
            Events_Stats.Events_Freq_Global_Std(i_mouse).REM = nanmean([tmpEvents_Stats(1).Events_Freq_Global_Std.REM, tmpEvents_Stats(2).Events_Freq_Global_Std.REM]);
            

        elseif n_sessions == 1
            
            EventsPropagation_DendriteAvg = tmpEventsPropagation_DendriteAvg{i_session};
            EventsLocal_Propagation_DendriteAvg = tmpEventsLocalPropagation_DendriteAvg{i_session};
            EventsGlobal_Propagation_DendriteAvg = tmpEventsGlobalPropagation_DendriteAvg{i_session};
            
            % Propagation
            Events_Stats.Propagation_Avg(i_mouse).Awake = tmpEvents_Stats(1).Propagation_Avg.Awake;
            Events_Stats.Propagation_Avg(i_mouse).NREM = tmpEvents_Stats(1).Propagation_Avg.NREM;
            Events_Stats.Propagation_Avg(i_mouse).REM = tmpEvents_Stats(1).Propagation_Avg.REM;
            Events_Stats.Propagation_Std(i_mouse).Awake = tmpEvents_Stats(1).Propagation_Std.Awake;
            Events_Stats.Propagation_Std(i_mouse).NREM = tmpEvents_Stats(1).Propagation_Std.NREM;
            Events_Stats.Propagation_Std(i_mouse).REM = tmpEvents_Stats(1).Propagation_Std.REM;
            Events_Stats.Propagation_All(i_mouse).Awake = [tmpEvents_Stats(1).Propagation_Avg.Awake];
            Events_Stats.Propagation_All(i_mouse).NREM = [tmpEvents_Stats(1).Propagation_Avg.NREM];
            Events_Stats.Propagation_All(i_mouse).REM = [tmpEvents_Stats(1).Propagation_Avg.REM];
            
            % Propagation Local
            Events_Stats.PropagationLocal_Avg(i_mouse).Awake = tmpEvents_Stats(1).PropagationLocal_Avg.Awake;
            Events_Stats.PropagationLocal_Avg(i_mouse).NREM = tmpEvents_Stats(1).PropagationLocal_Avg.NREM;
            Events_Stats.PropagationLocal_Avg(i_mouse).REM = tmpEvents_Stats(1).PropagationLocal_Avg.REM;
            Events_Stats.PropagationLocal_Std(i_mouse).Awake = tmpEvents_Stats(1).PropagationLocal_Std.Awake;
            Events_Stats.PropagationLocal_Std(i_mouse).NREM = tmpEvents_Stats(1).PropagationLocal_Std.NREM;
            Events_Stats.PropagationLocal_Std(i_mouse).REM = tmpEvents_Stats(1).PropagationLocal_Std.REM;
            
            % Propagation Global
            Events_Stats.PropagationGlobal_Avg(i_mouse).Awake = tmpEvents_Stats(1).PropagationGlobal_Avg.Awake;
            Events_Stats.PropagationGlobal_Avg(i_mouse).NREM = tmpEvents_Stats(1).PropagationGlobal_Avg.NREM;
            Events_Stats.PropagationGlobal_Avg(i_mouse).REM = tmpEvents_Stats(1).PropagationGlobal_Avg.REM;
            Events_Stats.PropagationGlobal_Std(i_mouse).Awake = tmpEvents_Stats(1).PropagationGlobal_Std.Awake;
            Events_Stats.PropagationGlobal_Std(i_mouse).NREM = tmpEvents_Stats(1).PropagationGlobal_Std.NREM;
            Events_Stats.PropagationGlobal_Std(i_mouse).REM = tmpEvents_Stats(1).PropagationGlobal_Std.REM;
            
            % n Events Local
            Events_Stats.n_EventsLocal_Avg(i_mouse).Awake = tmpEvents_Stats(1).n_EventsLocal_Avg.Awake;
            Events_Stats.n_EventsLocal_Avg(i_mouse).NREM = tmpEvents_Stats(1).n_EventsLocal_Avg.NREM;
            Events_Stats.n_EventsLocal_Avg(i_mouse).REM = tmpEvents_Stats(1).n_EventsLocal_Avg.REM;
            Events_Stats.n_EventsLocal_Std(i_mouse).Awake = tmpEvents_Stats(1).n_EventsLocal_Std.Awake;
            Events_Stats.n_EventsLocal_Std(i_mouse).NREM = tmpEvents_Stats(1).n_EventsLocal_Std.NREM;
            Events_Stats.n_EventsLocal_Std(i_mouse).REM = tmpEvents_Stats(1).n_EventsLocal_Std.REM;
            
            % n Events Global
            Events_Stats.n_EventsGlobal_Avg(i_mouse).Awake = tmpEvents_Stats(1).n_EventsGlobal_Avg.Awake;
            Events_Stats.n_EventsGlobal_Avg(i_mouse).NREM = tmpEvents_Stats(1).n_EventsGlobal_Avg.NREM;
            Events_Stats.n_EventsGlobal_Avg(i_mouse).REM = tmpEvents_Stats(1).n_EventsGlobal_Avg.REM;
            Events_Stats.n_EventsGlobal_Std(i_mouse).Awake = tmpEvents_Stats(1).n_EventsGlobal_Std.Awake;
            Events_Stats.n_EventsGlobal_Std(i_mouse).NREM = tmpEvents_Stats(1).n_EventsGlobal_Std.NREM;
            Events_Stats.n_EventsGlobal_Std(i_mouse).REM = tmpEvents_Stats(1).n_EventsGlobal_Std.REM;
            
            % Events Freq Local
            Events_Stats.Events_Freq_Local_Avg(i_mouse).Awake = tmpEvents_Stats(1).Events_Freq_Local_Avg.Awake;
            Events_Stats.Events_Freq_Local_Avg(i_mouse).NREM = tmpEvents_Stats(1).Events_Freq_Local_Avg.NREM;
            Events_Stats.Events_Freq_Local_Avg(i_mouse).REM = tmpEvents_Stats(1).Events_Freq_Local_Avg.REM;
            Events_Stats.Events_Freq_Local_Std(i_mouse).Awake = tmpEvents_Stats(1).Events_Freq_Local_Std.Awake;
            Events_Stats.Events_Freq_Local_Std(i_mouse).NREM = tmpEvents_Stats(1).Events_Freq_Local_Std.NREM;
            Events_Stats.Events_Freq_Local_Std(i_mouse).REM = tmpEvents_Stats(1).Events_Freq_Local_Std.REM;
            
            % Events Freq Global
            Events_Stats.Events_Freq_Global_Avg(i_mouse).Awake = tmpEvents_Stats(1).Events_Freq_Global_Avg.Awake;
            Events_Stats.Events_Freq_Global_Avg(i_mouse).NREM = tmpEvents_Stats(1).Events_Freq_Global_Avg.NREM;
            Events_Stats.Events_Freq_Global_Avg(i_mouse).REM = tmpEvents_Stats(1).Events_Freq_Global_Avg.REM;
            Events_Stats.Events_Freq_Global_Std(i_mouse).Awake = tmpEvents_Stats(1).Events_Freq_Global_Std.Awake;
            Events_Stats.Events_Freq_Global_Std(i_mouse).NREM = tmpEvents_Stats(1).Events_Freq_Global_Std.NREM;
            Events_Stats.Events_Freq_Global_Std(i_mouse).REM = tmpEvents_Stats(1).Events_Freq_Global_Std.REM;
            
        end

        EventsPropagation_DendriteAvg_all = [EventsPropagation_DendriteAvg_all, EventsPropagation_DendriteAvg];        
        EventsLocalPropagation_DendriteAvg_all = [EventsLocalPropagation_DendriteAvg_all, EventsLocal_Propagation_DendriteAvg];     
        EventsGlobalPropagation_DendriteAvg_all = [EventsGlobalPropagation_DendriteAvg_all, EventsGlobal_Propagation_DendriteAvg];     
        
        DUMMY = 0;
    end
    clear tmpEvents_Stats
    
end

DUMMY = 1; % Just here to collapse the section - for order
% Get the mouse averages
while DUMMY == 1
    
    EventsPropagation_Avg.Awake = nanmean([Events_Stats.Propagation_Avg.Awake]);
    EventsPropagation_Avg.NREM = nanmean([Events_Stats.Propagation_Avg.NREM]);
    EventsPropagation_Avg.REM = nanmean([Events_Stats.Propagation_Avg.REM]);
    EventsPropagation_StE.Awake = nanstd([Events_Stats.Propagation_Avg.Awake])./sqrt(n_mice);
    EventsPropagation_StE.NREM = nanstd([Events_Stats.Propagation_Avg.NREM])./sqrt(n_mice);
    EventsPropagation_StE.REM = nanstd([Events_Stats.Propagation_Avg.REM])./sqrt(n_mice);
    
    EventsPropagationLocal_Avg.Awake = nanmean([Events_Stats.PropagationLocal_Avg.Awake]);
    EventsPropagationLocal_Avg.NREM = nanmean([Events_Stats.PropagationLocal_Avg.NREM]);
    EventsPropagationLocal_Avg.REM = nanmean([Events_Stats.PropagationLocal_Avg.REM]);
    EventsPropagationLocal_StE.Awake = nanstd([Events_Stats.PropagationLocal_Avg.Awake])./sqrt(n_mice);
    EventsPropagationLocal_StE.NREM = nanstd([Events_Stats.PropagationLocal_Avg.NREM])./sqrt(n_mice);
    EventsPropagationLocal_StE.REM = nanstd([Events_Stats.PropagationLocal_Avg.REM])./sqrt(n_mice);
    
    EventsPropagationGlobal_Avg.Awake = nanmean([Events_Stats.PropagationGlobal_Avg.Awake]);
    EventsPropagationGlobal_Avg.NREM = nanmean([Events_Stats.PropagationGlobal_Avg.NREM]);
    EventsPropagationGlobal_Avg.REM = nanmean([Events_Stats.PropagationGlobal_Avg.REM]);
    EventsPropagationGlobal_StE.Awake = nanstd([Events_Stats.PropagationGlobal_Avg.Awake])./sqrt(n_mice);
    EventsPropagationGlobal_StE.NREM = nanstd([Events_Stats.PropagationGlobal_Avg.NREM])./sqrt(n_mice);
    EventsPropagationGlobal_StE.REM = nanstd([Events_Stats.PropagationGlobal_Avg.REM])./sqrt(n_mice);
    
    n_EventsLocal_Avg.Awake = nanmean([Events_Stats.n_EventsLocal_Avg.Awake]);
    n_EventsLocal_Avg.NREM = nanmean([Events_Stats.n_EventsLocal_Avg.NREM]);
    n_EventsLocal_Avg.REM = nanmean([Events_Stats.n_EventsLocal_Avg.REM]);
    n_EventsLocal_StE.Awake = nanstd([Events_Stats.n_EventsLocal_Avg.Awake])./sqrt(n_mice);
    n_EventsLocal_StE.NREM = nanstd([Events_Stats.n_EventsLocal_Avg.NREM])./sqrt(n_mice);
    n_EventsLocal_StE.REM = nanstd([Events_Stats.n_EventsLocal_Avg.REM])./sqrt(n_mice);
    
    n_EventsGlobal_Avg.Awake = nanmean([Events_Stats.n_EventsGlobal_Avg.Awake]);
    n_EventsGlobal_Avg.NREM = nanmean([Events_Stats.n_EventsGlobal_Avg.NREM]);
    n_EventsGlobal_Avg.REM = nanmean([Events_Stats.n_EventsGlobal_Avg.REM]);
    n_EventsGlobal_StE.Awake = nanstd([Events_Stats.n_EventsGlobal_Avg.Awake])./sqrt(n_mice);
    n_EventsGlobal_StE.NREM = nanstd([Events_Stats.n_EventsGlobal_Avg.NREM])./sqrt(n_mice);
    n_EventsGlobal_StE.REM = nanstd([Events_Stats.n_EventsGlobal_Avg.REM])./sqrt(n_mice);
    
    EventsFreq_Local_Avg.Awake = nanmean([Events_Stats.Events_Freq_Local_Avg.Awake]);
    EventsFreq_Local_Avg.NREM = nanmean([Events_Stats.Events_Freq_Local_Avg.NREM]);
    EventsFreq_Local_Avg.REM = nanmean([Events_Stats.Events_Freq_Local_Avg.REM]);
    EventsFreq_Local_StE.Awake = nanstd([Events_Stats.Events_Freq_Local_Avg.Awake])./sqrt(n_mice);
    EventsFreq_Local_StE.NREM = nanstd([Events_Stats.Events_Freq_Local_Avg.NREM])./sqrt(n_mice);
    EventsFreq_Local_StE.REM = nanstd([Events_Stats.Events_Freq_Local_Avg.REM])./sqrt(n_mice);
    
    EventsFreq_Global_Avg.Awake = nanmean([Events_Stats.Events_Freq_Global_Avg.Awake]);
    EventsFreq_Global_Avg.NREM = nanmean([Events_Stats.Events_Freq_Global_Avg.NREM]);
    EventsFreq_Global_Avg.REM = nanmean([Events_Stats.Events_Freq_Global_Avg.REM]);
    EventsFreq_Global_StE.Awake = nanstd([Events_Stats.Events_Freq_Global_Avg.Awake])./sqrt(n_mice);
    EventsFreq_Global_StE.NREM = nanstd([Events_Stats.Events_Freq_Global_Avg.NREM])./sqrt(n_mice);
    EventsFreq_Global_StE.REM = nanstd([Events_Stats.Events_Freq_Global_Avg.REM])./sqrt(n_mice);
    
    total_events_freq_avg.Awake = EventsFreq_Local_Avg.Awake + EventsFreq_Global_Avg.Awake;
    total_events_freq_avg.NREM = EventsFreq_Local_Avg.NREM + EventsFreq_Global_Avg.NREM;
    total_events_freq_avg.REM = EventsFreq_Local_Avg.REM + EventsFreq_Global_Avg.REM;
    
    total_events_freq_StE.Awake = EventsFreq_Local_StE.Awake + EventsFreq_Global_StE.Awake;
    total_events_freq_StE.NREM = EventsFreq_Local_StE.NREM + EventsFreq_Global_StE.NREM;
    total_events_freq_StE.REM = EventsFreq_Local_StE.REM + EventsFreq_Global_StE.REM;
    
    DUMMY = 0;
end


% Mean of all dendrites together
n_dendrites_total = numel(allDendrites_Events_Freq_Global);

allDendrites_PropagationAvg_Global_Avg.Awake = nanmean([allDendrites_Events_Propagation_Global.Awake]);
allDendrites_PropagationAvg_Global_Avg.NREM = nanmean([allDendrites_Events_Propagation_Global.NREM]);
allDendrites_PropagationAvg_Global_Avg.REM = nanmean([allDendrites_Events_Propagation_Global.REM]);
allDendrites_PropagationAvg_Global_StE.Awake = nanstd([allDendrites_Events_Propagation_Global.Awake])./sqrt(n_dendrites_total);
allDendrites_PropagationAvg_Global_StE.NREM = nanstd([allDendrites_Events_Propagation_Global.NREM])./sqrt(n_dendrites_total);
allDendrites_PropagationAvg_Global_StE.REM = nanstd([allDendrites_Events_Propagation_Global.REM])./sqrt(n_dendrites_total);

allDendrites_PropagationAvg_Local_Avg.Awake = nanmean([allDendrites_Events_Propagation_Local.Awake]);
allDendrites_PropagationAvg_Local_Avg.NREM = nanmean([allDendrites_Events_Propagation_Local.NREM]);
allDendrites_PropagationAvg_Local_Avg.REM = nanmean([allDendrites_Events_Propagation_Local.REM]);
allDendrites_PropagationAvg_Local_StE.Awake = nanstd([allDendrites_Events_Propagation_Local.Awake])./sqrt(n_dendrites_total);
allDendrites_PropagationAvg_Local_StE.NREM = nanstd([allDendrites_Events_Propagation_Local.NREM])./sqrt(n_dendrites_total);
allDendrites_PropagationAvg_Local_StE.REM = nanstd([allDendrites_Events_Propagation_Local.REM])./sqrt(n_dendrites_total);

allDendrites_Events_Freq_Global_Avg.Awake = nanmean([allDendrites_Events_Freq_Global.Awake]);
allDendrites_Events_Freq_Global_Avg.NREM = nanmean([allDendrites_Events_Freq_Global.NREM]);
allDendrites_Events_Freq_Global_Avg.REM = nanmean([allDendrites_Events_Freq_Global.REM]);
allDendrites_Events_Freq_Global_StE.Awake = nanstd([allDendrites_Events_Freq_Global.Awake])./sqrt(n_dendrites_total);
allDendrites_Events_Freq_Global_StE.NREM = nanstd([allDendrites_Events_Freq_Global.NREM])./sqrt(n_dendrites_total);
allDendrites_Events_Freq_Global_StE.REM = nanstd([allDendrites_Events_Freq_Global.REM])./sqrt(n_dendrites_total);

allDendrites_Events_Freq_Local_Avg.Awake = nanmean([allDendrites_Events_Freq_Local.Awake]);
allDendrites_Events_Freq_Local_Avg.NREM = nanmean([allDendrites_Events_Freq_Local.NREM]);
allDendrites_Events_Freq_Local_Avg.REM = nanmean([allDendrites_Events_Freq_Local.REM]);
allDendrites_Events_Freq_Local_StE.Awake = nanstd([allDendrites_Events_Freq_Local.Awake])./sqrt(n_dendrites_total);
allDendrites_Events_Freq_Local_StE.NREM = nanstd([allDendrites_Events_Freq_Local.NREM])./sqrt(n_dendrites_total);
allDendrites_Events_Freq_Local_StE.REM = nanstd([allDendrites_Events_Freq_Local.REM])./sqrt(n_dendrites_total);

allDendrites_n_Events_Global_Avg.Awake = nanmean([allDendrites_n_Events_Global.Awake]);
allDendrites_n_Events_Global_Avg.NREM = nanmean([allDendrites_n_Events_Global.NREM]);
allDendrites_n_Events_Global_Avg.REM = nanmean([allDendrites_n_Events_Global.REM]);
allDendrites_n_Events_Global_StE.Awake = nanstd([allDendrites_n_Events_Global.Awake])./sqrt(n_dendrites_total);
allDendrites_n_Events_Global_StE.NREM = nanstd([allDendrites_n_Events_Global.NREM])./sqrt(n_dendrites_total);
allDendrites_n_Events_Global_StE.REM = nanstd([allDendrites_n_Events_Global.REM])./sqrt(n_dendrites_total);

allDendrites_n_Events_Local_Avg.Awake = nanmean([allDendrites_n_Events_Local.Awake]);
allDendrites_n_Events_Local_Avg.NREM = nanmean([allDendrites_n_Events_Local.NREM]);
allDendrites_n_Events_Local_Avg.REM = nanmean([allDendrites_n_Events_Local.REM]);
allDendrites_n_Events_Local_StE.Awake = nanstd([allDendrites_n_Events_Local.Awake])./sqrt(n_dendrites_total);
allDendrites_n_Events_Local_StE.NREM = nanstd([allDendrites_n_Events_Local.NREM])./sqrt(n_dendrites_total);
allDendrites_n_Events_Local_StE.REM = nanstd([allDendrites_n_Events_Local.REM])./sqrt(n_dendrites_total);

DendritesTogether_EventsFrequency_Local = [];
DendritesTogether_EventsFrequency_Global = [];
for i_mouse = 1:n_mice
    current_mouse = Events_Stats_perMouse{i_mouse};
    DendritesTogether_EventsFrequency_Local = [DendritesTogether_EventsFrequency_Local, current_mouse.Events_Freq_Local];
    DendritesTogether_EventsFrequency_Global = [DendritesTogether_EventsFrequency_Global, current_mouse.Events_Freq_Global];
end
Events_Stats.EventsFrequencyAllDendrites_Local = DendritesTogether_EventsFrequency_Local;
Events_Stats.EventsFrequencyAllDendrites_Global = DendritesTogether_EventsFrequency_Global;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% Plots %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


marker_size = 10;
% number_of_datapoints = number_of_cells*3;


%% Figure 0 - Distribution of the average propagation per dendrite

figure('units','normalized','outerposition',[0 0 1 1]);

n_datapoints = numel(EventsPropagation_DendriteAvg_all);
cell_conditions = cell(n_datapoints*3, 1);
for i = 1:3:n_datapoints*3
    cell_conditions{i} = 'Awake';
    cell_conditions{i+1} = 'Non-REM';
    cell_conditions{i+2} = 'REM';
end
data_tmp = zeros(1, n_datapoints);
clear y
for i = 0:n_datapoints-1
    data_tmp(i*3 + 1) = EventsPropagation_DendriteAvg_all(i+1).Awake;
    data_tmp(i*3 + 2) = EventsPropagation_DendriteAvg_all(i+1).NREM;
    data_tmp(i*3 + 3) = EventsPropagation_DendriteAvg_all(i+1).REM;
    y(i*3 + 1) = i;
    y(i*3 + 2) = i;
    y(i*3 + 3) = i;
end
y = y + 1;

h = scatterhist(data_tmp, y, 'Kernel', 'on', 'Group', cell_conditions, 'LineWidth', 2, 'Marker', '.', 'MarkerSize', marker_size);
delete(h(3));
bc = get(gcf,'color');
set(h(2),'visible','on','color',bc,'box','off');
% - x-axis hist
tmp_tick = get(h(2),'ytick');
tmp_tick_2 = tmp_tick(end) + abs(tmp_tick(1) - tmp_tick(2));
set(h(2), 'YLim', [0, 0.3]);
set(h(2), 'ytick', [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]);
set(h(2), 'yticklabel', abs(get(h(2),'ytick')));
% set(h(2), 'ylabel', 'Marginal distribution');

grid on;
axis tight;
ylabel('Dendrite ID')
xlabel('Average events propagation [um]');

title(sprintf('Distribution of the average propagation per dendrite\n according to state'))



%% Figure 0b - Distribution of the average propagation per dendrite - Local
% events only
figure('units','normalized','outerposition',[0 0 1 1]);

n_datapoints = numel(EventsLocalPropagation_DendriteAvg_all);
cell_conditions = cell(n_datapoints*3, 1);
for i = 1:3:n_datapoints*3
    cell_conditions{i} = 'Awake';
    cell_conditions{i+1} = 'Non-REM';
    cell_conditions{i+2} = 'REM';
end
data_tmp = zeros(1, n_datapoints);
clear y
for i = 0:n_datapoints-1
    data_tmp(i*3 + 1) = EventsLocalPropagation_DendriteAvg_all(i+1).Awake;
    data_tmp(i*3 + 2) = EventsLocalPropagation_DendriteAvg_all(i+1).NREM;
    data_tmp(i*3 + 3) = EventsLocalPropagation_DendriteAvg_all(i+1).REM;
    y(i*3 + 1) = i;
    y(i*3 + 2) = i;
    y(i*3 + 3) = i;
end
y = y + 1;

h = scatterhist(data_tmp, y, 'Kernel', 'on', 'Group', cell_conditions, 'LineWidth', 2, 'Marker', '.', 'MarkerSize', marker_size);
delete(h(3));
bc = get(gcf,'color');
set(h(2),'visible','on','color',bc,'box','off');
% - x-axis hist
tmp_tick = get(h(2),'ytick');
tmp_tick_2 = tmp_tick(end) + abs(tmp_tick(1) - tmp_tick(2));
set(h(2), 'YLim', [0, 0.4]);
set(h(2), 'ytick', [0, 0.1, 0.2, 0.3, 0.4]);
set(h(2), 'yticklabel', abs(get(h(2),'ytick')));
% set(h(2), 'ylabel', 'Marginal distribution');

grid on;
axis tight;
ylabel('Dendrite ID')
xlabel('Average events propagation [um]');

title(sprintf('Distribution of the average local event propagation \n per dendrite \n according to state'))


%% Figure 0c - Distribution of the average propagation per dendrite - Local
% events only
figure('units','normalized','outerposition',[0 0 1 1]);

n_datapoints = numel(EventsGlobalPropagation_DendriteAvg_all);
cell_conditions = cell(n_datapoints*3, 1);
for i = 1:3:n_datapoints*3
    cell_conditions{i} = 'Awake';
    cell_conditions{i+1} = 'Non-REM';
    cell_conditions{i+2} = 'REM';
end
data_tmp = zeros(1, n_datapoints);
clear y
for i = 0:n_datapoints-1
    data_tmp(i*3 + 1) = EventsGlobalPropagation_DendriteAvg_all(i+1).Awake;
    data_tmp(i*3 + 2) = EventsGlobalPropagation_DendriteAvg_all(i+1).NREM;
    data_tmp(i*3 + 3) = EventsGlobalPropagation_DendriteAvg_all(i+1).REM;
    y(i*3 + 1) = i;
    y(i*3 + 2) = i;
    y(i*3 + 3) = i;
end
y = y + 1;

h = scatterhist(data_tmp, y, 'Kernel', 'on', 'Group', cell_conditions, 'LineWidth', 2, 'Marker', '.', 'MarkerSize', marker_size);
delete(h(3));
bc = get(gcf,'color');
set(h(2),'visible','on','color',bc,'box','off');
% - x-axis hist
tmp_tick = get(h(2),'ytick');
tmp_tick_2 = tmp_tick(end) + abs(tmp_tick(1) - tmp_tick(2));
set(h(2), 'YLim', [0, 0.4]);
set(h(2), 'ytick', [0, 0.1, 0.2, 0.3, 0.4]);
set(h(2), 'yticklabel', abs(get(h(2),'ytick')));
% set(h(2), 'ylabel', 'Marginal distribution');

grid on;
axis tight;
ylabel('Dendrite ID')
xlabel('Average events propagation [um]');

title(sprintf('Distribution of the average global event propagation \n per dendrite \n according to state'))


%% Figure 1 - Total Events Frequency
figure;
X_Location = [1, 2, 3];
Y = [total_events_freq_avg.Awake, total_events_freq_avg.NREM, total_events_freq_avg.REM];
errhigh = [total_events_freq_StE.Awake, total_events_freq_StE.NREM, total_events_freq_StE.REM];
errlow  = [total_events_freq_StE.Awake, total_events_freq_StE.NREM, total_events_freq_StE.REM];


h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title('Average Events Frequency per Dendrite')
ylabel('Frequency(Hz)')
h_axis = gca;
h_axis.FontSize = 14;


%% Figure 2 - Events Frequency per Event Type
figure;
X_Location = [1, 2, 3, 4, 5, 6];
Y = [EventsFreq_Local_Avg.Awake, EventsFreq_Global_Avg.Awake, EventsFreq_Local_Avg.NREM, EventsFreq_Global_Avg.NREM, EventsFreq_Local_Avg.REM, EventsFreq_Global_Avg.REM];
errhigh = [EventsFreq_Local_StE.Awake, EventsFreq_Global_StE.Awake, EventsFreq_Local_StE.NREM, EventsFreq_Global_StE.NREM, EventsFreq_Local_StE.REM, EventsFreq_Global_StE.REM];
errlow  = [EventsFreq_Local_StE.Awake, EventsFreq_Global_StE.Awake, EventsFreq_Local_StE.NREM, EventsFreq_Global_StE.NREM, EventsFreq_Local_StE.REM, EventsFreq_Global_StE.REM];


h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticks([1.5, 3.5, 5.5]);
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title(sprintf('Average Events Frequency per Dendrite\nLocal vs Global'))
ylabel('Frequency(Hz)')
h_axis = gca;
h_axis.FontSize = 14;


%% Figure 3 - Events Frequency per Event Type
figure;

X_Location = [1, 2, 3];
Y = [EventsFreq_Local_Avg.Awake, EventsFreq_Local_Avg.NREM, EventsFreq_Local_Avg.REM];
errhigh = [EventsFreq_Local_StE.Awake, EventsFreq_Local_StE.NREM, EventsFreq_Local_StE.REM];
errlow  = [EventsFreq_Local_StE.Awake, EventsFreq_Local_StE.NREM, EventsFreq_Local_StE.REM];
Y_max = (nanmax(Y) + nanmax(errhigh));

subplot(2, 1, 1)
h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticks([1, 2, 3]);
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title(sprintf('Average Events Frequency per Dendrite\nLocal'))
% ylim([0, 1]);
ylim([0, 0.2]);
ylabel('Frequency(Hz)')
h_axis = gca;
h_axis.FontSize = 14;

Y = [EventsFreq_Global_Avg.Awake, EventsFreq_Global_Avg.NREM, EventsFreq_Global_Avg.REM];
errhigh = [EventsFreq_Global_StE.Awake, EventsFreq_Global_StE.NREM, EventsFreq_Global_StE.REM];
errlow  = [EventsFreq_Global_StE.Awake, EventsFreq_Global_StE.NREM, EventsFreq_Global_StE.REM];
Y_max = (nanmax(Y) + nanmax(errhigh));

subplot(2, 1, 2)
h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticks([1, 2, 3]);
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title(sprintf('Average Events Frequency per Dendrite\nGlobal'))
% ylim([0, 0.3]);
ylim([0, 0.02]);
ylabel('Frequency(Hz)')
h_axis = gca;
h_axis.FontSize = 14;


%% Figure 4

figure;
X_Location = [1, 2, 3];
Y = [EventsPropagation_Avg.Awake, EventsPropagation_Avg.NREM, EventsPropagation_Avg.REM];
errhigh = [EventsPropagation_StE.Awake, EventsPropagation_StE.NREM, EventsPropagation_StE.REM];
errlow  = [EventsPropagation_StE.Awake, EventsPropagation_StE.NREM, EventsPropagation_StE.REM];


h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title('Average Events propagation per Dendrite, per Mouse')
ylabel('Propagation Distance [um]')
h_axis = gca;
h_axis.FontSize = 14;


%% Figure 2b - Events Frequency per Event Type
figure;
X_Location = [1, 2, 3, 4, 5, 6];
Y = [allDendrites_Events_Freq_Local_Avg.Awake, allDendrites_Events_Freq_Global_Avg.Awake, allDendrites_Events_Freq_Local_Avg.NREM, allDendrites_Events_Freq_Global_Avg.NREM, allDendrites_Events_Freq_Local_Avg.REM, allDendrites_Events_Freq_Global_Avg.REM];
errhigh = [allDendrites_Events_Freq_Local_StE.Awake, allDendrites_Events_Freq_Global_StE.Awake, allDendrites_Events_Freq_Local_StE.NREM, allDendrites_Events_Freq_Global_StE.NREM, allDendrites_Events_Freq_Local_StE.REM, allDendrites_Events_Freq_Global_StE.REM];
errlow  = [allDendrites_Events_Freq_Local_StE.Awake, allDendrites_Events_Freq_Global_StE.Awake, allDendrites_Events_Freq_Local_StE.NREM, allDendrites_Events_Freq_Global_StE.NREM, allDendrites_Events_Freq_Local_StE.REM, allDendrites_Events_Freq_Global_StE.REM];


h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticks([1.5, 3.5, 5.5]);
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title(sprintf('Average Events Frequency per Dendrite\nLocal vs Global - Average per dendrite'))
ylabel('Frequency(Hz)')
h_axis = gca;
h_axis.FontSize = 14;


%% Figure 4b - Events Propagation per Event Type
figure;
X_Location = [1, 2, 3, 4, 5, 6];
Y = [EventsPropagationLocal_Avg.Awake, EventsPropagationGlobal_Avg.Awake, EventsPropagationLocal_Avg.NREM, EventsPropagationGlobal_Avg.NREM, EventsPropagationLocal_Avg.REM, EventsPropagationGlobal_Avg.REM];
errhigh = [EventsPropagationLocal_StE.Awake, EventsPropagationGlobal_StE.Awake, EventsPropagationLocal_StE.NREM, EventsPropagationGlobal_StE.NREM, EventsPropagationLocal_StE.REM, EventsPropagationGlobal_StE.REM];
errlow  = [EventsPropagationLocal_StE.Awake, EventsPropagationGlobal_StE.Awake, EventsPropagationLocal_StE.NREM, EventsPropagationGlobal_StE.NREM, EventsPropagationLocal_StE.REM, EventsPropagationGlobal_StE.REM];


h_bar = bar(X_Location, Y, 'EdgeColor',[0, 0, 0]);
hold on;
h_error = errorbar(X_Location, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
xticks([1.5, 3.5, 5.5]);
xticklabels({'Awake', 'NREM', 'REM'});
grid on;
title(sprintf('Average Events Propagation per Dendrite\nLocal vs Global, mice average'))
ylabel('Propagation average [um]')
h_axis = gca;
h_axis.FontSize = 14;


% % Statistics
% [T_test.GlobalEvents.Awake_vs_NREM.h, T_test.GlobalEvents.Awake_vs_NREM.p, T_test.GlobalEvents.Awake_vs_NREM.CI, T_test.GlobalEvents.Awake_vs_NREM.Stats] = ttest2([Events_Stats.Events_Freq_Global_Avg.Awake], [Events_Stats.Events_Freq_Global_Avg.NREM], 'Vartype', 'unequal');
% [T_test.GlobalEvents.Awake_vs_REM.h, T_test.GlobalEvents.Awake_vs_REM.p, T_test.GlobalEvents.Awake_vs_REM.CI, T_test.GlobalEvents.Awake_vs_REM.Stats] = ttest2([Events_Stats.Events_Freq_Global_Avg.Awake], [Events_Stats.Events_Freq_Global_Avg.REM], 'Vartype', 'unequal');
% [T_test.GlobalEvents.NREM_vs_REM.h, T_test.GlobalEvents.NREM_vs_REM.p, T_test.GlobalEvents.NREM_vs_REM.CI, T_test.GlobalEvents.NREM_vs_REM.Stats] = ttest2([Events_Stats.Events_Freq_Global_Avg.NREM], [Events_Stats.Events_Freq_Global_Avg.REM], 'Vartype', 'unequal');
% 
% [T_test.LocalEvents.Awake_vs_NREM.h, T_test.LocalEvents.Awake_vs_NREM.p, T_test.LocalEvents.Awake_vs_NREM.CI, T_test.LocalEvents.Awake_vs_NREM.Stats] = ttest2([Events_Stats.Events_Freq_Local_Avg.Awake], [Events_Stats.Events_Freq_Local_Avg.NREM], 'Vartype', 'unequal');
% [T_test.LocalEvents.Awake_vs_REM.h, T_test.LocalEvents.Awake_vs_REM.p, T_test.LocalEvents.Awake_vs_REM.CI, T_test.LocalEvents.Awake_vs_REM.Stats] = ttest2([Events_Stats.Events_Freq_Local_Avg.Awake], [Events_Stats.Events_Freq_Local_Avg.REM], 'Vartype', 'unequal');
% [T_test.LocalEvents.NREM_vs_REM.h, T_test.LocalEvents.NREM_vs_REM.p, T_test.LocalEvents.NREM_vs_REM.CI, T_test.LocalEvents.NREM_vs_REM.Stats] = ttest2([Events_Stats.Events_Freq_Local_Avg.NREM], [Events_Stats.Events_Freq_Local_Avg.REM], 'Vartype', 'unequal');

