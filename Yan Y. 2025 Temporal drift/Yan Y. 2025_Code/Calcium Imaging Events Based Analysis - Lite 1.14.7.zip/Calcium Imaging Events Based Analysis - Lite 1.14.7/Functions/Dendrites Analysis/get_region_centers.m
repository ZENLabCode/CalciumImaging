function region_centers = get_region_centers (region_pixels)
% This function returns the most central pixel of an ROI.

region_pixels_mat = cell2mat(region_pixels');
region_centers(1,1) = round(nanmedian(region_pixels_mat(:, 1)));
region_centers(1,2) = round(nanmedian(region_pixels_mat(:, 2)));

