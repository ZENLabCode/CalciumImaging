function [Dendrites, Dendrites_Bord_1, Dendrites_Bord_2] = load_dendrites_ROIs_singleMouse(Dir_Dendrites, Opts_Dendrites)
% This function loads all the dendrite ROIs (to be added each in its .zip
% format) of a single mouse recording session.
% Each entry in the Dendrites file corresponds to a dendrite, with 1xN
% sub-ROIs each.

% Remove '.' and '..'  items
tmp_dir_list = dir(Dir_Dendrites);
i_remove = [];
for i_1 = 1:numel(tmp_dir_list)
    if strcmpi(tmp_dir_list(i_1).name, '.') == 1 || strcmpi(tmp_dir_list(i_1).name, '..') == 1
        i_remove = [i_remove, i_1];
    end
end
tmp_dir_list(i_remove) = [];

% Get the list of Dendrites ROI
FilesList = tmp_dir_list;
n_dendrites = numel(FilesList);

% Load ROIs for each dendrite and put them in a convenient variable.
Dendrites = cell(1, n_dendrites);
Dendrites_Bord_1 = cell(1, n_dendrites);
Dendrites_Bord_2 = cell(1, n_dendrites);
for i_dendrite = 1:n_dendrites
    ROI_FileName = FilesList(i_dendrite).name;
    ROI_FilePath = [Dir_Dendrites, '\', ROI_FileName];
    [tmp_dendrite_ROIs] = ReadImageJROI(ROI_FilePath);
    subROIcoords = cell(numel(tmp_dendrite_ROIs), 1);
    subROIcoords_border1 = cell(numel(tmp_dendrite_ROIs), 1);
    subROIcoords_border2 = cell(numel(tmp_dendrite_ROIs), 1);
    for i_subROI = 1:numel(tmp_dendrite_ROIs)
        % Get the subROI coordinates
        subROI = tmp_dendrite_ROIs{i_subROI};
        subROIcoords{i_subROI} = get_rectROIcoord (subROI);
        
        % Consider bordering rectangles of fixed dimension
        [subROIcoords_border1{i_subROI}, subROIcoords_border2{i_subROI}] = get_rectROIcoord_neighbour(subROIcoords{i_subROI}, Opts_Dendrites);
    end
    Dendrites{i_dendrite} = subROIcoords;
    Dendrites_Bord_1{i_dendrite} = subROIcoords_border1;
    Dendrites_Bord_2{i_dendrite} = subROIcoords_border2;
end