X = reshape(current_ROI_Surface, size(current_ROI_Surface,1)*size(current_ROI_Surface,2), 1);
coeff = pca(X);
Itransformed = X*coeff;
Ipc1 = reshape(Itransformed(:,1),size(current_ROI_Surface,1),size(current_ROI_Surface,2));
Ipc2 = reshape(Itransformed(:,1),size(current_ROI_Surface,1),size(current_ROI_Surface,2));
Ipc3 = reshape(Itransformed(:,3),size(current_ROI_Surface,1),size(current_ROI_Surface,2));
figure, imshow(Ipc1,[]);
figure, imshow(Ipc2,[]);
figure, imshow(Ipc3,[]);




ROI_Line_selection = imline;
pos = getPosition(ROI_Line_selection);

dy = pos(1, 2) - pos(2, 2);
dx = pos(1, 1) - pos(2, 1);
theta = atan(dy/dx);
theta = 180/pi % rads to degs


J = imrotate(current_ROI_Surface, theta);

figure; imshow(J);

J = imrotate(current_ROI_Surface, -theta);

figure; imshow(J);