function neighbour_regions = get_neighbouring_regions(current_region)

neighbour_regions = current_region;
neighbour_regions(isnan(neighbour_regions)) = 0;
neighbour_regions = find(neighbour_regions);