function Events_Dendrite_perMouse = events_memory_reduction(Events_Dendrite_perMouse)
% Decreases the memory load by cutting down on unnecessary measures for
% this analysis.

for i_mouse = 1:numel(Events_Dendrite_perMouse)
    Events_Dendrite_perSession = Events_Dendrite_perMouse{i_mouse};
    for i_session = 1:numel(Events_Dendrite_perSession)
        Events_perDendrite = Events_Dendrite_perSession{i_session};
        for i_dendrite = 1:numel(Events_perDendrite)
            Events_Dendrite = Events_perDendrite{i_dendrite};
            Events_Dendrite = rmfield(Events_Dendrite, 'Composite');
            Events_perDendrite{i_dendrite} = Events_Dendrite;
            clear Events_Dendrite
        end
        Events_Dendrite_perSession{i_session} = Events_perDendrite;
        clear Events_perDendrite
    end
    Events_Dendrite_perMouse{i_mouse} = Events_Dendrite_perSession;
    clear Events_Dendrite_perSession
end