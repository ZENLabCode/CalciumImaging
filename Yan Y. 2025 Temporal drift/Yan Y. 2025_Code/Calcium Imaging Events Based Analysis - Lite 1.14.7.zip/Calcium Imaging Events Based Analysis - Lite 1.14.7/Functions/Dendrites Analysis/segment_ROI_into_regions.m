function [ROI_fragmented_overlay, ROI_masks, overlay_tag] = segment_ROI_into_regions (selected_ROI, grid_size_input, overlay_tag_input)
% This function will segment the ROI in various regions: the borders of 
% the ROI are returned as output, together with a grid which divides the 
% larger areas of the ROI; the smaller areas are considered as single 
% regions and no grid is applied on them. 
% The length of the squares sides composing the grid is selectable. 
% INPUTS: 
%       - "selected_ROI" is the ROI which will be segmented.
%       - (optional) "grid_size_input" is the length of the squares sides
%       composing the grid.
%       - (optional) "overlay_tag_input" is the tag value which will be
%       used in the overlay image (for the borders + grid).
% OUTPUTS:
%       - "ROI_fragmented_overlay" is an image in double format composed by
%       the borders of the "selected_ROI", and the grip overimposed on its
%       big regions.
%       - "ROI_masks" is a structure containing 2 masks: "holes" is the 
%       mask for the holes (pixels = 0 inside areas with pixels = 1)
%       in "selected_ROI"; "regions" is the mask containing the regions of
%       "selected_ROI" (ignoring the grid!).
%       - overlay_tag is the tag value which was used in the overlay image 
%       (for the borders + grid).

%% Check input and initialize parameters.
switch nargin
    case 1
        grid_size_input = 10;
        overlay_tag_input = 2;
    case 2
        overlay_tag_input = 2;
    case 3
    otherwise
        error('Wrong number of inputs, check function INPUT section for more info.\n');
end

[Height, Width] = size(selected_ROI);
grid_size = uint16(grid_size_input);
grid_number_height = idivide(Height, grid_size, 'floor');
grid_number_width = idivide(Width, grid_size, 'floor');
threshold_area = (grid_size^2)*2;
overlay_tag = overlay_tag_input;

%% ~~~ Get Image Borders ~~~ %%
% Get external borders (not considering the internal holes)
[img_boundaries_external_only, img_region_labels_external_only, img_number_of_regions] = bwboundaries(selected_ROI, 8, 'noholes');
% Get both external and internal borders (considering the holes)
[img_boundaries_ext_int, img_region_labels_ext_int, ~] = bwboundaries(selected_ROI, 8, 'holes');
% Get the holes and label their regions with negative number labels
img_number_of_holes = numel(img_boundaries_ext_int) - img_number_of_regions;

img_boundaries_holes = cell(img_number_of_holes,1);
img_region_labels = img_region_labels_ext_int;
img_holes_labels = zeros(Height, Width);
label_tmp = zeros(1, img_number_of_holes);
i_hole = 0;
for i_1_pixel = 1:Height
    for j_1_pixel = 1:Width
        if img_region_labels(i_1_pixel, j_1_pixel) ~= img_region_labels_external_only(i_1_pixel, j_1_pixel)
            % It's a hole pixel!
            i_hole = i_hole + 1;
            % Take note of the label (save into an array "label_tmp").
            current_label = img_region_labels(i_1_pixel, j_1_pixel);
            label_tmp(i_hole, 1) = current_label;
            % The label at this point corresponds to the img_boundaries_ext_int
            % cell index:
            
            % - save the corresponding cell element to build the img_boundaries_holes.
            img_boundaries_holes(i_hole, 1) = img_boundaries_ext_int(current_label);
            % - set all the tags with the hole label to zero, to skip every
            %   other pixel in that hole at the next iteration.
            for i_2_pixel = 1:Height
                for j_2_pixel = 1:Width
                    if (img_region_labels(i_2_pixel, j_2_pixel) == current_label)
                        img_region_labels(i_2_pixel, j_2_pixel) = 0;
                        % Also make a new mask containing only the holes.
                        img_holes_labels(i_2_pixel, j_2_pixel) = - i_hole;
                    end
                end
            end
            % At this point I have a translation tool for the label in the
            % originary img_boundaries_ext_int cell, and the new label_holes.            
        end
    end
end

% Measure the area of each ROI region.
img_regions_area = regionprops(selected_ROI, 'area');

% Remove regions with area greater than threshold. 
% (they will be handled separately).
labels_to_grid = [];
number_of_regions_to_grid = 0;
img_boundaries = img_boundaries_external_only;
for i_region = img_number_of_regions:-1:1 % Going on the opposite, so the indexes doesn't get shifted while erasing elements.
   if (img_regions_area(i_region).Area > threshold_area)
       number_of_regions_to_grid = number_of_regions_to_grid + 1;
       img_boundaries(i_region) = [];
       img_regions_area(i_region) = [];
       labels_to_grid(number_of_regions_to_grid) = i_region;
   end
end
img_number_of_small_regions = numel(img_boundaries);

% Make the grid.
grid_overlay_tmp = uint16(zeros(Height, Width));
i_pixel = 1;
j_pixel = 1;
for i_grid = 1:grid_number_height
    grid_overlay_tmp(i_pixel, :) = overlay_tag;
    i_pixel = i_pixel + grid_size;
end
for j_grid = 1:grid_number_width
    grid_overlay_tmp(:, j_pixel) = overlay_tag;
    j_pixel = j_pixel + grid_size;
end

% Put the grid on top of (only) the big regions, skipping the holes.
ROI_with_grid_tmp = uint16(selected_ROI);
grid_overlay = zeros(Height, Width);
for i_pixel = 1:Height
    for j_pixel = 1:Width   % Scroll to find the ROI.
        for i_region = 1:number_of_regions_to_grid
           if ((img_region_labels_external_only(i_pixel, j_pixel) ~= 0) && (img_region_labels_external_only(i_pixel, j_pixel) == labels_to_grid(i_region))); % If the pixel is part of a region to grid...
               if (img_holes_labels(i_pixel, j_pixel) >= 0) % If it's not inside a hole...
                   ROI_with_grid_tmp(i_pixel, j_pixel) = grid_overlay_tmp(i_pixel, j_pixel);
                   grid_overlay(i_pixel, j_pixel) = grid_overlay_tmp(i_pixel, j_pixel);
               end
           end
        end
    end
end

% Make the borders overlay.
borders_overlay = zeros(Height, Width);
for i_border = 1:numel((img_boundaries_ext_int))
    border = img_boundaries_ext_int{i_border};
    [pixels_in_border, ~] = size(border);
    for i_coord = 1:pixels_in_border
        coord_1 = border(i_coord, 1);
        coord_2 = border(i_coord, 2);
        borders_overlay(coord_1, coord_2) = overlay_tag; 
    end
end

% Make the final overlay.
ROI_fragmented_overlay = borders_overlay;
for i_pixel = 1:Height
    for j_pixel = 1:Width
        if (grid_overlay(i_pixel, j_pixel) ~= 0)
            ROI_fragmented_overlay(i_pixel, j_pixel) = grid_overlay(i_pixel, j_pixel);
        end
    end
end

ROI_masks.holes = img_holes_labels;
ROI_masks.regions = img_region_labels;

end