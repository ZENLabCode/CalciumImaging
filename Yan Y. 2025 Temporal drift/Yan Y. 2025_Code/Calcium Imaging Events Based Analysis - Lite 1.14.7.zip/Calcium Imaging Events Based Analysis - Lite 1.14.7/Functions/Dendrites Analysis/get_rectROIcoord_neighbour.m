function [neigh_top_coord, neigh_bottom_coord] = get_rectROIcoord_neighbour(subROI_coords, Opts_Dendrites)


neigh_length = Opts_Dendrites.Neighbourhood_Length;

subROI_coords_1 = subROI_coords(:, 1);
subROI_coords_2 = subROI_coords(:, 2);

dim1 = numel(unique(subROI_coords_1));
dim2 = numel(unique(subROI_coords_2));

% If the dimensions are inverted, re-invert them
if dim1 > dim2
    subROI_coords_1 = subROI_coords(:, 2);
    subROI_coords_2 = subROI_coords(:, 1);
    dim1 = numel(unique(subROI_coords_1));
    dim2 = numel(unique(subROI_coords_2));
end

dim1_max = nanmax(subROI_coords_1);
dim1_min = nanmin(subROI_coords_1);

dim2_max = nanmax(subROI_coords_2);
dim2_min = nanmin(subROI_coords_2);

neigh_top_coord = NaN(size(subROI_coords));
neigh_bottom_coord = NaN(size(subROI_coords));

% Get the top Neighbourhood
i = 1;
for x_pixel = dim1_min:(dim1_min+dim1)-1
    for y_pixel = dim2_max+1:(dim2_max+neigh_length)
        neigh_top_coord(i, 1) = x_pixel;
        neigh_top_coord(i, 2) = y_pixel;
        i = i + 1;
    end
end
% Get the bottom Neighbourhood
i = 1;
for x_pixel = dim1_min:(dim1_min+dim1)-1
    for y_pixel = dim2_min-1:-1:(dim2_min-neigh_length)
        neigh_bottom_coord(i, 1) = x_pixel;
        neigh_bottom_coord(i, 2) = y_pixel;
        i = i + 1;
    end
end
