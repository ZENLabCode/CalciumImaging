function plot_all_traces (CalciumTraces_Current_Mouse, Hypnogram_Current_Mouse)
% This function plots all the traces (raw and binary)of a single recordings
% session.

Trace_Shift = 20;
[~, n_traces] = size(CalciumTraces_Current_Mouse);
Trace_LineWidth = 1;

figure(); set(gcf,'position', get(0,'screensize'));
% Subplot 1
subplot(2, 1, 1)
hold on; grid on; box on;
for i_trace = 1:n_traces
    tmp_Trace = CalciumTraces_Current_Mouse(:, i_trace) + i_trace*Trace_Shift;
    plot(tmp_Trace, 'k', 'LineWidth', Trace_LineWidth)
end
axis tight
Y_limits = ylim;
set(gca, 'YTick',[]);
xlim([0, inf]);
set(gca, 'FontSize', 12);

% Subplot 2 - with state overlay
subplot(2, 1, 2)
hold on; grid on; box on;
for i_trace = 1:n_traces
    tmp_Trace = CalciumTraces_Current_Mouse(:, i_trace) + i_trace*Trace_Shift;
    plot(tmp_Trace, 'k', 'LineWidth', Trace_LineWidth)
end
axis tight
Y_limits = ylim;
set(gca, 'YTick',[]);
xlim([0, inf]);
set(gca, 'FontSize', 12);

n_datapoints = numel(Hypnogram_Current_Mouse.Hypnogram);
for i_state_change = 1:numel(Hypnogram_Current_Mouse.StateChanges)
    current_state_change = Hypnogram_Current_Mouse.StateChanges(i_state_change);
    if i_state_change == numel(Hypnogram_Current_Mouse.StateChanges)
        next_state_change = n_datapoints - 1;
    else
        next_state_change = Hypnogram_Current_Mouse.StateChanges(i_state_change + 1) - 1;
    end
    current_x_array = zeros(1, n_datapoints);

    current_x_array(1, current_state_change:next_state_change) = (Y_limits(2).*ones(1, numel(current_state_change:next_state_change)));
    
    h_area = area(current_x_array);
    
    if Hypnogram_Current_Mouse.Hypnogram(Hypnogram_Current_Mouse.StateChanges(i_state_change)) == 1
        h_area.FaceColor = 'b';
    elseif Hypnogram_Current_Mouse.Hypnogram(Hypnogram_Current_Mouse.StateChanges(i_state_change)) == 2
        h_area.FaceColor = 'r';
    elseif Hypnogram_Current_Mouse.Hypnogram(Hypnogram_Current_Mouse.StateChanges(i_state_change)) == 4
        h_area.FaceColor = 'g';
    end
    
    h_area.FaceAlpha = 0.2;
end

