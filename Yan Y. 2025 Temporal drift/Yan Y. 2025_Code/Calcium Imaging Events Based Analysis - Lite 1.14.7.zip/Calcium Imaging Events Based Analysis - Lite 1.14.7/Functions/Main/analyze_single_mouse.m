function [Events_AllTraces, StateChanges, StateLength, n_removed, CalciumTraces_Clean] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts)
% This function analyzes all traces for the same recordings session.

% Options.
if nargin < 4
    Opts.SingleTraceAnalysis.CheckEveryTrace = 0;
    Opts.SingleTraceAnalysis.FLAG_display = 0;
    Opts.SingleTraceAnalysis.FLAG_display_neg_peak = 0;
    Opts.SingleTraceAnalysis.FrameRate = 3; % (3 for Mattia experiments)
    Opts.SingleTraceAnalysis.FLAG_Verbose = 0; % Stop printing all messaged.
    Opts.SingleTraceAnalysis.Interp_step = 0.01; % Default is 0.01
end


%% Load data (needs to change for automatization)
% Load Trace.
[n_time, n_traces] = size(CalciumTraces);

if Opts.SingleTraceAnalysis.CheckEveryTrace == 0 % Check Traces 1 by 1?
    Opts.SingleTraceAnalysis.FLAG_display = 0;
end

trace_mean = nanmean(CalciumTraces, 2);

% Analyze single traces.
i_trace = 1;
fprintf('Analyzing Trace #%d.\n', i_trace);
trace_unclean = CalciumTraces(:, i_trace);
tmp_n_removed = NaN(1, n_traces);
CalciumTraces_Clean = NaN(n_time, n_traces);
if Opts.SingleTraceAnalysis.FLAG_display == 1
    plot_ImagingAndHypno(trace_unclean, Hypnogram, calTime);
end
[Events_SingleTrace, StateChanges, StateLength, tmp_n_removed(1, 1), tmp_traces_clean] = analyze_single_trace (trace_unclean, Hypnogram, trace_mean, i_trace, Opts.SingleTraceAnalysis);
CalciumTraces_Clean(:, 1) = tmp_traces_clean;
if Opts.SingleTraceAnalysis.CheckEveryTrace == 1 % Check Traces 1 by 1?
    fprintf('Trace #%d is analysed. Press a key to continue.\n', i_trace);
    pause;
    close all;
else
    fprintf('Trace #%d is analysed.\n', i_trace);
end
Events_AllTraces = Events_SingleTrace;

for i_trace = 2:n_traces
    fprintf('Analyzing Trace #%d.\n', i_trace);
    clear Events_SingleTrace
    trace_unclean = CalciumTraces(:, i_trace);
    if Opts.SingleTraceAnalysis.FLAG_display == 1
        plot_ImagingAndHypno(trace_unclean, Hypnogram, calTime);
    end
    [Events_SingleTrace, StateChanges, StateLength, tmp_n_removed(i_trace), tmp_traces_clean] = analyze_single_trace (trace_unclean, Hypnogram, trace_mean, i_trace, Opts.SingleTraceAnalysis);
    CalciumTraces_Clean(:, i_trace) = tmp_traces_clean;
    try
        if ~isempty (Events_SingleTrace)
            Events_AllTraces = [Events_AllTraces, Events_SingleTrace];
        else
            fprintf('Trace #%d has no events.\n', i_trace);
        end
    catch
        keyboard
    end
    if Opts.SingleTraceAnalysis.CheckEveryTrace == 1
        fprintf('Trace #%d is analysed. Press a key to continue.\n', i_trace);
        pause;
        close all;
    else
        fprintf('Trace #%d is analysed.\n', i_trace);
    end
end

n_removed = nansum(tmp_n_removed);
