function [Neg_Peaks] = get_negative_peaks(mean_trace, Hypnogram, Opts)

% This function gets the negative peaks in the Ca2+ signal 
% (candidate artifacts), their characteristics, 
% and sets the ground for their removal.
% The output is a structure describing the peaks found.


%% Options
warning('off', 'signal:findpeaks:largeMinPeakHeight'); % Ignore no negative datapoints warning
interp_step = Opts.Interp_step; % 0.01 default
smoothing_steps = Opts.NegativePeaks.Smoothing_Steps; 
% Options - Integrity checks. UNUSED
% Opts.NegativePeaks.IntCheck.MinBaseWidth
% Opts.NegativePeaks.IntCheck.MinHalfWidth
% Opts.NegativePeaks.IntCheck.MinAmplitude
% Opts.NegativePeaks.IntCheck.MinIntegral


%% Preliminary peaks localization.
% Get signal negative peaks. (same as before, inverted signal)
trace_neg = - mean_trace;
n_datapoints = numel(mean_trace);

% Smooth the signal.
trace_neg_smooth = trace_neg;
for i_smoothing = 1:smoothing_steps
    trace_neg_smooth = smooth(trace_neg_smooth);
end

% Get Median & Std
trace_neg_smooth_median = nanmedian(trace_neg_smooth);
trace_neg_smooth_std = nanstd(trace_neg_smooth);

trace_neg_tmp = trace_neg_smooth;

% Compute derivative.
trace_neg_tmp_diff = diff(trace_neg_tmp);
trace_neg_tmp_diff = [NaN; trace_neg_tmp_diff];
trace_neg_tmp_diff2 = diff(trace_neg_tmp_diff);
trace_neg_tmp_diff2 = [NaN; trace_neg_tmp_diff2];

% Estimate derivative std, in 2 steps.
trace_neg_tmp_diff_std_tmp = nanstd(trace_neg_tmp_diff);
tmp = trace_neg_tmp_diff;
for i = 1:numel(trace_neg_tmp_diff)
    if tmp(i) > trace_neg_tmp_diff_std_tmp || tmp(i) < -trace_neg_tmp_diff_std_tmp
        tmp(i) = NaN;
    end
end

% Get Threshold.
trace_neg_tmp_diff_std = nanstd(tmp);
noise_thr_diff = trace_neg_tmp_diff_std/2;

MinPeak_Dist = 3;
MinPeak_Heigth = 0; % trace_neg_smooth_median - 2*trace_neg_smooth_std; % Should be = baseline + noise.
MinPeak_Prom = trace_neg_smooth_std;
MinPeak_Width = 3;
MinPeak_Threshold = trace_neg_smooth_std/300;
MaxPeak_Width = 50;
[peaks_amplitude, peaks_location, peaks_width, peaks_prominence] = findpeaks(trace_neg_tmp, 'MinPeakHeight', MinPeak_Heigth, 'MinPeakProminence', MinPeak_Prom,'MinPeakDistance', MinPeak_Dist, 'MinPeakWidth', MinPeak_Width, 'MaxPeakWidth', MaxPeak_Width, 'Threshold', MinPeak_Threshold, 'Annotate', 'extents');

% Plot Check
if Opts.NegativePeaks.FLAG_Display == 1
    figure;
    subplot(4,1,1); plot(trace_neg_smooth); hold on; grid on; grid minor; axis tight;
    line([0, n_datapoints], [trace_neg_smooth_median - trace_neg_smooth_std/1.5, trace_neg_smooth_median - trace_neg_smooth_std], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    ylabel(sprintf('\\DeltaF/F \n Smoothed')); 
    title('Signal Control', 'FontSize', 14)
    subplot(4,1,2); plot(trace_neg_tmp); grid on; grid minor; axis tight;
    ylabel(sprintf('\\DeltaF/F \n Smoothed Cut')); 
    subplot(4,1,3); plot((trace_neg_tmp_diff)); grid on; grid minor; axis tight; hold on;
    line([0, n_datapoints], [noise_thr_diff, noise_thr_diff], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    line([0, n_datapoints], [-noise_thr_diff, -noise_thr_diff], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    ylabel('d`\DeltaF/F')
    subplot(4,1,4); plot(trace_neg_tmp_diff2); grid on; grid minor; axis tight;
    ylabel('d``\DeltaF/F'); xlabel ('Frames');
    
    figure;
    findpeaks(trace_neg_tmp, 'MinPeakHeight', MinPeak_Heigth, 'MinPeakProminence', MinPeak_Prom,'MinPeakDistance', MinPeak_Dist,'MinPeakWidth', MinPeak_Width, 'MaxPeakWidth', MaxPeak_Width, 'Threshold', MinPeak_Threshold, 'Annotate', 'extents');
    ylabel('\DeltaF/F Smoothed Cut'); xlabel ('Frames');
    title('Identified (Negative) Peaks', 'FontSize', 14)
end


%% Get actual Peaks and their characteristics.

% Initialize.
Events = cell(1, numel(peaks_location));
Events_interpolated = cell(1, numel(peaks_location));
Events_Start = NaN(1, numel(peaks_location));
Events_End = NaN(1, numel(peaks_location));
Peaks_BaseWidth = NaN(1, numel(peaks_location));
Peaks_HalfWidth = NaN(1, numel(peaks_location));
Peaks_peak_value = NaN(1, numel(peaks_location));
Peaks_amp_from_base = NaN(1, numel(peaks_location));
peaks_loc = NaN(1, numel(peaks_location));
Peaks_Integral = NaN(1, numel(peaks_location));

% Scroll each candidate peak.
for i_peak = 1:numel(peaks_location)
    counter_width_1 = 0;
    counter_width_2 = 0;
    % Count backwards till the derivative > threshold value (noise_thr_diff)
    for i_frame = peaks_location(i_peak):-1:1
        if ~isnan(trace_neg_tmp_diff(i_frame)) && (trace_neg_tmp_diff(i_frame-1) > noise_thr_diff)
            Events_Start(i_peak) = i_frame;
            counter_width_1 = counter_width_1 + 1; 
        else
            if counter_width_1 >= 1 % 1st point might be with derivative close to zero, try moving on if no detection.
                break
            end
        end
    end
    % Count forwards till the derivative is < threshold value (-noise_thr_diff)
    for i_frame = peaks_location(i_peak):1:numel(trace_neg_tmp_diff)-1
        if ~isnan(trace_neg_tmp_diff(i_frame)) && (trace_neg_tmp_diff(i_frame+1) < -noise_thr_diff)
            Events_End(i_peak) = i_frame;
            counter_width_2 = counter_width_2 + 1;
        else
            if counter_width_2 >= 1 % 1st point might be with derivative close to zero, try moving on if no detection.
                break
            end
        end
    end
    
    %--- Peak Characteristics ---% 
    
    % Event
    event_tmp = trace_neg(Events_Start(i_peak):Events_End(i_peak));
    Events{i_peak} = event_tmp;
    Event_baseline_value = nanmin(event_tmp);
    event_tmp_bas_corr = event_tmp - Event_baseline_value;
    %   (Fit Spline to data)
    tmpX_raw = 1:1:numel(event_tmp);
    tmpX_interp = 0:interp_step:numel(event_tmp);
    Events_interpolated{i_peak} = spline(tmpX_raw, event_tmp, tmpX_interp);

    % Peak
    [Peaks_peak_value(i_peak), peaks_loc(i_peak)] = nanmax(event_tmp); % Remember that, for negative peaks, this is a negative value.
    % Amplitude
    Peaks_amp_from_base(i_peak) = nanmax(event_tmp_bas_corr);
    % Base-Width
    Peaks_BaseWidth(i_peak) = counter_width_1 + counter_width_2;
    % Half-Width
    tmp1 = Peaks_amp_from_base(i_peak)/2; % Mid-amplitude - baseline
    %   (Fit Spline to data)
    tmpX_raw = 1:1:numel(event_tmp_bas_corr);
    tmpX_interp = 0:interp_step:numel(event_tmp_bas_corr);
    event_corr_interpolated = spline(tmpX_raw, event_tmp_bas_corr, tmpX_interp);
    %   (Get left and right side values)
    [newMax_value, newMax_loc] = nanmax(event_corr_interpolated);
    event_left = event_corr_interpolated(1:newMax_loc);
    event_right = event_corr_interpolated(newMax_loc+1:end);
    [amp_left_error, half_amplitude_loc_left] = nanmin( abs(event_left - tmp1) );
    half_amplitude_left = event_left(half_amplitude_loc_left);
    [amp_right_error, half_amplitude_loc_right] = nanmin( abs(event_right - tmp1) );
    half_amplitude_right = event_right(half_amplitude_loc_right);
    %   (Get actual HalfWidth)
    if isempty(half_amplitude_left) || isempty(half_amplitude_right)
        Peaks_HalfWidth(i_peak) = NaN;
    else
        Peaks_HalfWidth(i_peak) = abs(find(event_corr_interpolated == half_amplitude_left) - find(event_corr_interpolated == half_amplitude_right)).*interp_step;
    end
    % Integral
    Peaks_Integral(i_peak) = sum(event_corr_interpolated(event_corr_interpolated > 0));
end

% Save Output Structure.
if numel(peaks_location) > 0
    Neg_Peaks = struct;
    for i_peak = 1:numel(peaks_location)
        Neg_Peaks(i_peak).Event = Events{i_peak};
        Neg_Peaks(i_peak).Event_Interpolated = Events_interpolated{i_peak};
        Neg_Peaks(i_peak).Start = Events_Start(i_peak);
        Neg_Peaks(i_peak).End = Events_End(i_peak);
        Neg_Peaks(i_peak).Location = peaks_location(i_peak);
        Neg_Peaks(i_peak).Amp_from_Base = Peaks_amp_from_base(i_peak);
        Neg_Peaks(i_peak).PeakValue = Peaks_peak_value(i_peak);
        Neg_Peaks(i_peak).BaseWidth = Peaks_BaseWidth(i_peak);
        Neg_Peaks(i_peak).HalfWidth = Peaks_HalfWidth(i_peak);
        Neg_Peaks(i_peak).Integral = Peaks_Integral(i_peak);
    end
    n_peaks = numel(Neg_Peaks);
else
    Neg_Peaks = struct;
    n_peaks = 0;
end


%% Integrity checks.
% Should add a check for the selected negative peaks
if n_peaks > 0 && ~isempty(Neg_Peaks)
    Events_to_remove = [];
    n_removed_Asleep = 0;
    for i_peak = n_peaks:-1:1
        if isfield(Neg_Peaks, 'Location')
            % Check that the peaks found are happening during Awake state.
            if Hypnogram(Neg_Peaks(i_peak).Location) ~= 1
                Events_to_remove = [Events_to_remove, i_peak];
                n_removed_Asleep = n_removed_Asleep + 1;
            end
        else
            warning('Location field missing in Negative Peaks Detection!')
        end
        % Check minimum base width.
        
        % Check minimum amplitude.
        
    end
    
    % Remove False Positives.
    Neg_Peaks_Removed = Neg_Peaks(Events_to_remove); % For Debug purposes.
    Neg_Peaks(Events_to_remove) = [];
end


end