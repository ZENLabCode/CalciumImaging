function [Events, n_removed] = get_peaks(trace, TraceNumber, StateChanges, Opts)
% This function gets the peaks in the Ca2+ signal, their characteristics,
% and saves them as output.

% Peaks candidates are first identified, their characteristics measured,
% then a sanity check is made for the peak candidates, removing the ones
% with implausible characteristics.


%% Options
if nargin < 4
    fprintf('Options variable not found for function "get_peaks": loading defaults.\n\n');
    Opts = set_options ();
end

prePeak_interval_length = Opts.GetPeaks.prePeak_interval_length; % Raise duration should be 200~300 for Pyr neurons 
% Options - Integrity checks.
IntCheck = Opts.GetPeaks.IntCheck;

%% Preliminary peaks localization.
n_datapoints = numel(trace);
if numel(trace(isnan(trace))) >= n_datapoints - 2
    Events = [];
    n_removed = 0;
    return
end

% Get an estimation of the noise. (multiple steps of std estimation)
[noise_estimate, median_estimate, ~] = estimate_noise (trace, Opts.noise_estimation_steps);
IntCheck.MinAmplitude = nanmax([IntCheck.MinAmplitude, noise_estimate*IntCheck.MinAmplitudeNoiseMultiplier]); % Update the MinAmplitude Criteria.
Opts.GetPeaks.IntCheck.MinAmplitude = IntCheck.MinAmplitude;

% Interpolate trace.
tmpX_raw = 1:1:n_datapoints;
tmpX_interp = 0:Opts.Interp_step:n_datapoints;
trace_interp = spline(tmpX_raw, trace, tmpX_interp);

% Restore NaNs lost during the interpolation.
trace_interp = Restore_NaNs_InterpSmooth (trace, trace_interp, Opts.Interp_step);

% Find Peaks
NoiseMultiplier_MinHeight = Opts.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight;
NoiseMultiplier_MinProm = Opts.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm;
Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth = median_estimate + NoiseMultiplier_MinHeight*noise_estimate; % Should be = baseline + noise.
Opts.FindPeaks_Opt.trace_interp.MinPeak_Prom = NoiseMultiplier_MinProm*noise_estimate;
[~, peaks_location, ~, ~] = findpeaks_shortform (trace_interp, Opts.FindPeaks_Opt.trace_interp);
n_peaks = numel(peaks_location);

% Compute derivative.
trace_interp_diff = diff(trace_interp);
trace_interp_diff = [NaN; trace_interp_diff];
trace_interp_diff2 = diff(trace_interp_diff);
trace_interp_diff2 = [NaN; trace_interp_diff2];

% Take the moving average of the second derivative, in case of presence of
% slow rising events (e.g. Astrocytes)
if Opts.GetPeaks.FLAG_SmoothDiff == 1
    trace_interp_diff = movmean(trace_interp_diff, Opts.GetPeaks.MovingAverageWinLength);
end

% Take the moving average of the second derivative, in case of presence of
% slow rising events (e.g. Astrocytes)
if Opts.GetPeaks.FLAG_SmoothDiff2 == 1
    trace_interp_diff2 = movmean(trace_interp_diff2, Opts.GetPeaks.MovingAverageWinLength);
end

% Estimate derivative std, in 2 steps.
trace_interp_diff_std_tmp = nanstd(trace_interp_diff);
tmp = trace_interp_diff;
for i = 1:numel(trace_interp_diff)
    if tmp(i) > trace_interp_diff_std_tmp || tmp(i) < -trace_interp_diff_std_tmp
        tmp(i) = NaN;
    end
end

% Get the up/down states of the 1st derivative of the interpolated signal.
diff_binary = get_deriv_updown(trace_interp, trace_interp_diff, Opts);

% Initialize.
tmp_Events = cell(1, n_peaks);
tmp_Events_NoN_Interpolated = cell(1, n_peaks);
tmp_Events_Start = NaN(1, n_peaks);
tmp_Events_End = NaN(1, n_peaks);
tmp_Events_Duration = NaN(1, n_peaks);
tmp_Events_Baseline = NaN(1, n_peaks);
tmp_Events_HalfWidth = NaN(1, n_peaks);
tmp_Events_peak_value = NaN(1, n_peaks);
tmp_Events_peak_loc = NaN(1, n_peaks);
tmp_Events_Amp_StartEnd = NaN(1, n_peaks);
tmp_Events_Amp_Baseline = NaN(1, n_peaks);
tmp_Events_Integral = NaN(1, n_peaks);
tmp_Events_Composite = cell(1, n_peaks);
tmp_Events_Composite_NoN_Interpolated = cell(1, n_peaks);
tmp_Events_Composite_Tag = NaN(1, n_peaks);
tmp_Events_Composite_Group_Tag = NaN(1, n_peaks);
tmp_Events_Composite_Start = NaN(1, n_peaks);
tmp_Events_Composite_End = NaN(1, n_peaks);
tmp_Events_Composite_Duration = NaN(1, n_peaks);
tmp_Events_Composite_Baseline = NaN(1, n_peaks);
tmp_Events_Composite_Amp_StartEnd = NaN(1, n_peaks);
tmp_Events_Composite_Amp_Baseline = NaN(1, n_peaks);
tmp_Events_Composite_Peak = NaN(1, n_peaks);
tmp_Events_Composite_Peak_loc = NaN(1, n_peaks);
tmp_Events_Composite_HalfWidth = NaN(1, n_peaks);
tmp_Events_Composite_Integral = NaN(1, n_peaks);
i_composite = 1;

% Scroll each candidate peak & get characteristics.
for i_peak = 1:n_peaks
    % Get a fixed interval before the peak.
    if peaks_location(i_peak) > prePeak_interval_length
        tmp_start = peaks_location(i_peak) - prePeak_interval_length;
    else
        tmp_start = 1;
    end
    tmp_pre_event = trace_interp(tmp_start:peaks_location(i_peak)-1);
    tmp_pre_event_diff2 = trace_interp_diff2(tmp_start:peaks_location(i_peak)-1);
    [tmp_noise_estimate_diff2, tmp_median_estimate_diff2, ~] = estimate_noise (tmp_pre_event_diff2, Opts.noise_estimation_steps);
    Opts.GetPeaks.FindPeaksDiff2.MinPeak_Heigth = Opts.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier * tmp_noise_estimate_diff2; % Should be = 0 + 1*noise.
    Opts.GetPeaks.FindPeaksDiff2.MinPeak_Prom = Opts.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier * tmp_noise_estimate_diff2;

    % Find 2nd derivative peaks here.
    [tmp_peaks_amplitude, tmp_peaks_location, tmp_peaks_width, tmp_peaks_prominence] = findpeaks_shortform (tmp_pre_event_diff2, Opts.GetPeaks.FindPeaksDiff2);
    if isempty(tmp_peaks_location)
        continue
    end
    
    % Find the 2nd derivative peak that is closest to the signal peak:
    % this is the event_start.
    tmp_event_start = tmp_peaks_location(end);
    tmp_Events_Start(i_peak) = peaks_location(i_peak) - (prePeak_interval_length - tmp_event_start);
    if tmp_Events_Start(i_peak) < 0 
        tmp_Events_Start(i_peak) = 1;
    end
    % Get the median of the interval of values before the starting of the
    % event. This is the "baseline" value of the event neighbourhood.
    % Get new points, in case another event is present...
    tmp_Events_Baseline(i_peak) = nanmedian(tmp_pre_event(1:tmp_event_start));
    
    if i_peak > 1 % Does not apply to the 1st event.
            if abs(tmp_Events_End(i_peak - 1) - tmp_Events_Start(i_peak)) < prePeak_interval_length % If the previous event inside the "pre-event" zone of the following event
                % Extend length of the pre-event area of the event i, of the
                % duration of the event i-1; then set all the values
                % corresponding to the event i-1 to NaNs, and recompute the
                % baseline level.
                prePeak_interval_length_2 = prePeak_interval_length + tmp_Events_Duration(i_peak - 1);
                if peaks_location(i_peak) > prePeak_interval_length_2 % Set the tmp_start = 1 if the event is very early in the trace.
                    tmp_start_2 = peaks_location(i_peak) - prePeak_interval_length_2;
                else
                    tmp_start_2 = 1;
                end
                tmp_pre_event_2 = trace_interp(tmp_start_2:peaks_location(i_peak)-1);
                try
                    tmp_c1 = find(tmp_pre_event_2 == trace_interp(tmp_Events_End(i_peak - 1)));
                    tmp_c2 = find(tmp_pre_event_2 == trace_interp(tmp_Events_Start(i_peak - 1)));
                catch
                    continue
                end
                tmp_pre_event_2(tmp_c2:tmp_c1) = NaN(numel(tmp_c2:tmp_c1), 1);
                % Recompute baseline.
                tmp_Events_Baseline(i_peak) = nanmedian(tmp_pre_event_2(1:tmp_event_start));
            end
    end
    clear tmp_event_start
    
    % Check when the event will reach baseline (+ noise) again, 
    % this is the end of the event. 
    % (unless another event will start during this time, in
    % this case, that will also become the end of the previous event.
    for i_t = peaks_location(i_peak):numel(trace_interp)
        if trace_interp(i_t) <= tmp_Events_Baseline(i_peak) + noise_estimate*Opts.GetPeaks.event_end_thr_multiplier
            tmp_Events_End(i_peak) = i_t;
            
            if i_peak == 1 % Assign the 1st tag.
                tmp_Events_Composite_Group_Tag(1) = 1;
            elseif i_peak > 1
                % If another event starts before the previous one finishes, that becomes the end of the previous event
                if tmp_Events_Start(i_peak) <= tmp_Events_End(i_peak - 1)% Events are together.
                    tmp_Events_End(i_peak - 1) = tmp_Events_Start(i_peak);
                    tmp_Events_Composite_Group_Tag(i_peak) = i_composite; % Assign the same tag to the composite event.
                elseif tmp_Events_Start(i_peak) > tmp_Events_End(i_peak - 1) % Events are separated.
                    i_composite = i_composite + 1;
                    tmp_Events_Composite_Group_Tag(i_peak) = i_composite;
                end
            end
            break
        end
    end
    
    if isnan(tmp_Events_Start(i_peak)) || isnan(tmp_Events_End(i_peak))
        continue
    end
    % Event (interpolated)
    try
        tmp_Events{i_peak} = trace_interp(tmp_Events_Start(i_peak):tmp_Events_End(i_peak));
    catch
        tmp_Events{i_peak} = NaN;
    end
    % Get Event Duration (End - Start + 1)
    tmp_Events_Duration(i_peak) = tmp_Events_End(i_peak) - tmp_Events_Start(i_peak) + 1;
    % Peak value & loc
    [tmp_Events_peak_value(i_peak), ~] = nanmax(tmp_Events{i_peak});
    tmp1 = double(int32(find(trace_interp == tmp_Events_peak_value(i_peak))*Opts.Interp_step));
    if numel(tmp1) == 1 % In the rare case that the search gives 2 outputs, try to get the most likely one.
        tmp_Events_peak_loc(i_peak) = tmp1;
    else
        warning('Found %d peaks with the same values.', numel(tmp1));
        try
            if nanmin(tmp1) < nanmax(tmp_Events_peak_loc) && find(tmp_Events_peak_loc == nanmin(tmp1))
                tmp_Events_peak_loc(i_peak) = nanmax(tmp1);
            elseif nanmin(tmp1) > nanmax(tmp_Events_peak_loc)
                tmp_Events_peak_loc(i_peak) = nanmin(tmp1);
            end
        catch
            try
                tmp_Events_peak_loc(i_peak) = nanmin(tmp1);
            catch
                warning('Unable to perform assignment because the left and right sides have a different number of elements.');
                tmp_Events_peak_loc(i_peak) = NaN;
                tmp_base = NaN;
                tmp_Events_Amp_StartEnd = NaN;
                tmp_Events_Amp_Baseline = NaN;
                tmp_Events_HalfWidth = NaN;
                tmp_Events_Integral = NaN;
                continue
            end
        end
    end
    % Amplitude from Start/End
    tmp_base = nanmean([trace_interp(tmp_Events_End(i_peak)), trace_interp(tmp_Events_Start(i_peak))]);
    tmp_Events_Amp_StartEnd(i_peak) = nanmax(tmp_Events{i_peak} - tmp_base);
    % Amplitude from Baseline
    tmp_Events_Amp_Baseline(i_peak) = nanmax(tmp_Events{i_peak} - tmp_Events_Baseline(i_peak));
    % HalfWidth from Start/End
    try
        tmp_Events_HalfWidth(i_peak) = compute_HalfWidth(tmp_Events_Amp_StartEnd(i_peak), tmp_Events{i_peak}, Opts.Interp_step);
    catch
        warning('Could not compute half-witdh')
        tmp_Events_HalfWidth(i_peak) = NaN;
    end
    % Integral
    tmp_Events_Integral(i_peak) = sum(tmp_Events{i_peak}(tmp_Events{i_peak} > 0));
end

% Set Composite Event Binary Tag.
for i_peak = 1:n_peaks
    count_grp = numel(find(tmp_Events_Composite_Group_Tag == tmp_Events_Composite_Group_Tag(i_peak)));
    if count_grp > 1
        tmp_Events_Composite_Tag(i_peak) = 1;
    else
        tmp_Events_Composite_Tag(i_peak) = 0;
    end
end

% --- End point for composite events. --- %
% Interpolate NaNs
trace_interp_NaNless = NaN_to_NeighbourhoodMean(trace_interp);

% Get signal envelope.
maxima_EnvPeakSep = 250;
[trace_envelope, ~] = envelope(trace_interp_NaNless, maxima_EnvPeakSep, 'peak');
trace_envelope_diff = diff(trace_envelope);
trace_envelope_diff = [NaN; trace_envelope_diff];
trace_envelope_diff = Restore_NaNs_InterpSmooth (trace, trace_envelope_diff, Opts.Interp_step);

% Get the end of the composite events through the envelope derivative.
% (gets only the end of single events, or of the last event of a complex)
% Estimate derivative noise FIRST
[noise_envelope_diff, ~, ~] = estimate_noise (trace_envelope_diff, Opts.noise_estimation_steps);
% Get new event end.
tmp_Events_End_2 = tmp_Events_End;
i_peak = 1;
while i_peak <= n_peaks
    current_group_tag = tmp_Events_Composite_Group_Tag(i_peak);
    last_event_group = nanmax(find(tmp_Events_Composite_Group_Tag == current_group_tag));
    i_peak = last_event_group;
    for i_t = peaks_location(i_peak)+4/Opts.Interp_step:numel(trace_interp)
        if ~isnan(trace_envelope_diff(i_t))
            if (trace_envelope_diff(i_t) >= -(noise_envelope_diff*Opts.deriv_envelope_multiplier)) && (nanmax(trace_envelope_diff(i_t - double(idivide(maxima_EnvPeakSep, int32(10))):i_t-1)) <= 0) % Derivative needs to be >= threshold in the end point, and negative before.
                tmp_Events_End_2(i_peak) = i_t;
                break
            end
        else
            tmp_Events_End_2(i_peak) = i_t;
            break
        end
    end
    i_peak = i_peak + 1;
end

for i_peak = 1:n_peaks
    if tmp_Events_End_2(i_peak) <= tmp_Events_Start(i_peak) && tmp_Events_End(i_peak) <= tmp_Events_Start(i_peak)
        tmp_Events_End_2(i_peak) = NaN;
    elseif tmp_Events_End_2(i_peak) <= tmp_Events_Start(i_peak) && tmp_Events_End(i_peak) > tmp_Events_Start(i_peak)
        tmp_Events_End_2(i_peak) = tmp_Events_End(i_peak);
    end
    if tmp_Events_End_2(i_peak) < tmp_Events_Start(i_peak)
       warning('Event End < Event Start. Peak candidate #%d.\n', i_peak) 
    end
end


% --- --- --- %

% Plot to visualize event start-end.

% Plot Check
DUMMY = 1; % This is just for readability (to collapse the while)
n_sublot_row = 5;

while ((Opts.FLAG_display == 1) || (Opts.GetPeaks.FLAG_PeakDetectionCheck == 1)) && DUMMY == 1
    figure; set(gcf,'position', get(0,'screensize'));
    subplot(n_sublot_row,1,1); plot(trace_interp); grid on; grid minor; axis tight;
    ylabel('\DeltaF/F');
    title('Signal Control', 'FontSize', 14)
    hold on;
    line([0, numel(trace_interp)], [Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth, Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth], 'Color', 'k', 'LineWidth', 1.5, 'LineStyle', '--')
    hold off;

    subplot(n_sublot_row,1,2); plot(trace_interp_diff2); grid on; grid minor; axis tight;
    ylabel('d``\DeltaF/F'); xlabel ('Frames');
    
    subplot(n_sublot_row,1,3);
    findpeaks(trace_interp, ...
        'MinPeakHeight', Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth, ...
        'MinPeakProminence', Opts.FindPeaks_Opt.trace_interp.MinPeak_Prom, ...
        'MinPeakDistance', Opts.FindPeaks_Opt.trace_interp.MinPeak_Dist, ...
        'MinPeakWidth', Opts.FindPeaks_Opt.trace_interp.MinPeak_Width, ...
        'MaxPeakWidth', Opts.FindPeaks_Opt.trace_interp.MaxPeak_Width, ...
        'Annotate', 'extents');
    s = findobj('type','legend');
    delete(s); grid minor; axis tight;
    ylabel('\DeltaF/F'); xlabel ('Frames');
    title('Identified Peaks', 'FontSize', 14)
    
    subplot(n_sublot_row, 1, 4);
    plot(trace_interp, 'LineWidth', 1);
    hold on; box on; grid on; grid minor; axis tight;
    plot(tmp_Events_Start, tmp_Events_Baseline, '^r');
    plot(tmp_Events_End, tmp_Events_Baseline, 'vr');
    plot(trace_envelope, 'g');
    plot(tmp_Events_End_2, tmp_Events_Baseline, 'vk');
    line([0, numel(trace_interp)], [Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth, Opts.FindPeaks_Opt.trace_interp.MinPeak_Heigth], 'Color', 'k', 'LineWidth', 1.5, 'LineStyle', '--')
    hold off;
    legend({'Signal', 'Event Start', 'Event End', 'Envelope', 'Event End Updated', 'MinEventHeight'})
    
    subplot(n_sublot_row, 1, 5);
    plot(trace_envelope_diff, 'g');
    hold on; box on; grid on; grid minor; axis tight;
    if ~isempty(tmp_Events_End_2)
        plot(tmp_Events_End_2, 0, 'vk');
    end
    line([0, numel(trace_envelope_diff)], [-(noise_envelope_diff*Opts.deriv_envelope_multiplier), -(noise_envelope_diff*Opts.deriv_envelope_multiplier)], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    legend({'d(Envelope)', 'd(Envelope) Threshold', 'Event End Updated'})
    if Opts.GetPeaks.FLAG_PeakDetectionCheck == 1
        fprintf('Press a key to continue\n')
        pause
    end
    DUMMY = 0;
end

% Update {Event, Event_interpolated, Duration, Amplitudes, HalfWidth, Integral} of events.
for i_peak = 1:n_peaks
    if isnan(tmp_Events_Start(i_peak)) || tmp_Events_Start(i_peak) == 0
        continue
    end
    if i_peak < n_peaks % Try to fix case where event end = next event start
        if (tmp_Events_End_2(i_peak) <= tmp_Events_Start(i_peak) || isnan(tmp_Events_End_2(i_peak))) && (~isnan(tmp_Events_Start(i_peak + 1)) && tmp_Events_End_2(i_peak) == tmp_Events_Start(i_peak + 1))
            tmp_Events_End_2(i_peak) = tmp_Events_Start(i_peak + 1);
        elseif (tmp_Events_End_2(i_peak) <= tmp_Events_Start(i_peak) || isnan(tmp_Events_End_2(i_peak))) && isnan(tmp_Events_Start(i_peak + 1))
            tmp_Events_End_2(i_peak) = NaN;
            continue
        end
    end
    if isnan(tmp_Events_End_2(i_peak))
        continue
    end
    tmp_trace_raw_start = double(int32(tmp_Events_Start(i_peak)*Opts.Interp_step));
    tmp_trace_raw_end = double(int32(tmp_Events_End_2(i_peak)*Opts.Interp_step));
    if tmp_trace_raw_start == 0
        tmp_trace_raw_start = 1;
    end
    if tmp_trace_raw_end == 0
        tmp_trace_raw_end = 1;
    end
    tmp_Events_NoN_Interpolated{i_peak} = trace(tmp_trace_raw_start:tmp_trace_raw_end);
    tmp_Events{i_peak} = trace_interp(tmp_Events_Start(i_peak):tmp_Events_End_2(i_peak));
    tmp_Events_Duration(i_peak) = tmp_Events_End_2(i_peak) - tmp_Events_Start(i_peak) + 1;
    try
        tmp_Events_Amp_StartEnd(i_peak) = nanmax(tmp_Events{i_peak} - tmp_base);
    catch
        warning('Event Canditate %d Amplitude could not be computed. NaN value assigned.')
    end
    tmp_Events_Amp_Baseline(i_peak) = nanmax(tmp_Events{i_peak} - tmp_Events_Baseline(i_peak));
    if tmp_Events_Duration(i_peak) > 3
        try
            tmp_Events_HalfWidth(i_peak) = compute_HalfWidth(tmp_Events_Amp_StartEnd(i_peak), tmp_Events{i_peak}, Opts.Interp_step); % HalfWidth from Start/End
        catch
            tmp_Events_HalfWidth(i_peak) = NaN;
        end        
    end
    tmp_Events_Integral(i_peak) = sum(tmp_Events{i_peak}(tmp_Events{i_peak} > 0));
end

% Get Composite Event characteristics.
for i_peak = 1:n_peaks
    current_group_tag = tmp_Events_Composite_Group_Tag(i_peak);
    current_group = find(tmp_Events_Composite_Group_Tag == current_group_tag);
    if isnan(tmp_Events_Start(i_peak)) || tmp_Events_Start(i_peak) == 0
        tmp_Events_Start(i_peak) = 1;
        warning('Event peak position = 0, set to = 1 automatically.')
    end
    if isempty(current_group)
        continue
    end
    % Start & End
    tmp_Start = tmp_Events_Start(current_group);
    tmp_End = tmp_Events_End_2(current_group);
    tmp_Events_Composite_Start(i_peak) = tmp_Start(1);
    tmp_Events_Composite_End(i_peak) = tmp_End(end);
    tmp_trace_raw_start = double(int32(tmp_Events_Composite_Start(i_peak)*Opts.Interp_step));
    if tmp_trace_raw_start == 0 % Avoid rounding error at 1st point (rare exception).
        tmp_trace_raw_start = 1;
    end
    tmp_trace_raw_end = double(int32(tmp_Events_Composite_End(i_peak)*Opts.Interp_step));
    % Events
    tmp_Events_Composite{i_peak} = trace_interp(tmp_Events_Start(current_group(1)):tmp_Events_End_2(current_group(end)));
    tmp_Events_Composite_NoN_Interpolated{i_peak} = trace(tmp_trace_raw_start:tmp_trace_raw_end);

    % Duration
    tmp_Events_Composite_Duration(i_peak) = numel(tmp_Events_Composite{i_peak});
    % Baseline
    tmp_Events_Composite_Baseline(i_peak) = tmp_Events_Baseline(current_group(1));
    % Max peak value & peak loc
    [tmp_Events_Composite_Peak(i_peak), ~] = nanmax(tmp_Events_Composite{i_peak});
    tmp1 = double(int32(find(trace_interp == tmp_Events_Composite_Peak(i_peak))*Opts.Interp_step));
    if numel(tmp1) == 1 
        tmp_Events_Composite_Peak_loc(i_peak) = tmp1;
    else % In the rare case that the search gives 2 outputs, try to get the most likely one.
        warning('Found %d peaks with the same values.', numel(tmp1));
        try
            if nanmin(tmp1) < nanmax(tmp_Events_Composite_Peak_loc) && find(tmp_Events_Composite_Peak_loc == nanmin(tmp1))
                tmp_Events_Composite_Peak_loc(i_peak) = nanmax(tmp1);
            elseif nanmin(tmp1) > nanmax(tmp_Events_Composite_Peak_loc)
                tmp_Events_Composite_Peak_loc(i_peak) = nanmin(tmp1);
            end
        catch
            tmp_Events_Composite_Peak_loc(i_peak) = nanmin(tmp1);
        end
    end
    % Amplitude from Start/End
    tmp_base = nanmean([trace_interp(tmp_Events_Composite_End(i_peak)), trace_interp(tmp_Events_Composite_Start(i_peak))]);
    tmp_Events_Composite_Amp_StartEnd(i_peak) = nanmax(tmp_Events_Composite{i_peak} - tmp_base);
    % Amplitude from Baseline
    tmp_Events_Composite_Amp_Baseline(i_peak) = nanmax(tmp_Events_Composite{i_peak} - tmp_Events_Composite_Baseline(i_peak));
    % HalfWidth from Start/End
    try
        tmp_Events_Composite_HalfWidth(i_peak) = compute_HalfWidth(tmp_Events_Composite_Amp_StartEnd(i_peak), tmp_Events_Composite{i_peak}, Opts.Interp_step);
    catch
        tmp_Events_Composite_HalfWidth(i_peak) = NaN;
    end
    % Integral
    tmp_Events_Composite_Integral(i_peak) = sum(tmp_Events_Composite{i_peak}(tmp_Events_Composite{i_peak} > 0));
end

% Save into structure format.
Events = struct;
for i_peak = 1:n_peaks
    if Opts.GetPeaks.Save_EventShape == 1
        Events(i_peak).Event = tmp_Events(i_peak);
        Events(i_peak).Event_NoN_Interpolated = tmp_Events_NoN_Interpolated(i_peak);
    end
    if ~isnan(tmp_Events_Start(i_peak)) % If NaN, do not convert to 0
        Events(i_peak).Start = double(int32(tmp_Events_Start(i_peak).*Opts.Interp_step));
    else
        Events(i_peak).Start = NaN;
    end
    if ~isnan(tmp_Events_End_2(i_peak)) % If NaN, do not convert to 0
        Events(i_peak).End = double(int32(tmp_Events_End_2(i_peak).*Opts.Interp_step));
    else
        Events(i_peak).End = NaN;
    end
    if Events(i_peak).Start == 0 % Rare exception due to approx.
        Events(i_peak).Start = 1;
    end
    Events(i_peak).Duration = (tmp_Events_Duration(i_peak).*Opts.Interp_step)/Opts.FrameRate; % [s]
    Events(i_peak).Duration_Rise = ((tmp_Events_peak_loc(i_peak) - Events(i_peak).Start))/Opts.FrameRate; % [s]
    Events(i_peak).Duration_Decay = ((Events(i_peak).End - tmp_Events_peak_loc(i_peak)))/Opts.FrameRate; % [s]
    Events(i_peak).Baseline = tmp_Events_Baseline(i_peak);
    Events(i_peak).HalfWidth = tmp_Events_HalfWidth(i_peak)/Opts.FrameRate; 
    Events(i_peak).PeakValue = tmp_Events_peak_value(i_peak);
    Events(i_peak).PeakLoc = tmp_Events_peak_loc(i_peak);
    Events(i_peak).Amp_StartEnd = tmp_Events_Amp_StartEnd(i_peak);
    Events(i_peak).Amp_Baseline = tmp_Events_Amp_Baseline(i_peak);
    Events(i_peak).Integral = (tmp_Events_Integral(i_peak).*Opts.Interp_step)/Opts.FrameRate; % [s]
%     [Events(i_peak).DecayRate, Events(i_peak).DecayMultiplier, ~, ~] = fit_exponential(tmp_Events{i_peak}, Opts.FrameRate); % Exponential Fit
    Events(i_peak).DecayRate = NaN; % Exponential Fit
    Events(i_peak).DecayMultiplier = NaN; % Exponential Fit
    if Opts.GetPeaks.Save_EventShape == 1
        Events(i_peak).Composite.Event = tmp_Events_Composite(i_peak);
        Events(i_peak).Composite.Event_NoN_Interpolated = tmp_Events_Composite_NoN_Interpolated(i_peak);
    end
    Events(i_peak).Composite.CompositeTag = tmp_Events_Composite_Tag(i_peak);
    Events(i_peak).Composite.EventTag = tmp_Events_Composite_Group_Tag(i_peak);
    Events(i_peak).Composite.Start = double(int32(tmp_Events_Composite_Start(i_peak).*Opts.Interp_step));
    Events(i_peak).Composite.End = double(int32(tmp_Events_Composite_End(i_peak).*Opts.Interp_step));
    Events(i_peak).Composite.Duration = (tmp_Events_Composite_Duration(i_peak).*Opts.Interp_step)/Opts.FrameRate;
    Events(i_peak).Composite.Duration_Rise = ((tmp_Events_Composite_Peak_loc(i_peak) - Events(i_peak).Composite.Start).*Opts.Interp_step)/Opts.FrameRate; % [s]
    Events(i_peak).Composite.Duration_Decay = ((Events(i_peak).Composite.End - tmp_Events_Composite_Peak_loc(i_peak)).*Opts.Interp_step)/Opts.FrameRate; % [s]
    Events(i_peak).Composite.Baseline = tmp_Events_Composite_Baseline(i_peak);
    Events(i_peak).Composite.HalfWidth = tmp_Events_Composite_HalfWidth(i_peak)/Opts.FrameRate;
    Events(i_peak).Composite.PeakValue = tmp_Events_Composite_Peak(i_peak);
    Events(i_peak).Composite.PeakLoc = tmp_Events_Composite_Peak_loc(i_peak);
    % Lag to Previous State Change
    StateChanges(StateChanges == 1) = NaN; % Set the 1st point to NaN (not a state change, just the trace beginning).
    tmp_Lag = StateChanges - Events(i_peak).Composite.Start;
    tmp_Lag(tmp_Lag < 0) = NaN;
    Events(i_peak).Composite.Lag2StateChange = nanmin(tmp_Lag);
    
    if i_peak > 1
        Events(i_peak).Composite.InterEventInterval = abs(tmp_Events_peak_loc(i_peak) - tmp_Events_peak_loc(i_peak - 1))/Opts.FrameRate;
        if Events(i_peak).Composite.InterEventInterval == 0 || Events(i_peak).Composite.InterEventInterval <= 1/Opts.FrameRate
            Events(i_peak).Composite.InterEventInterval = NaN;
        end
    elseif i_peak == 1
        Events(i_peak).Composite.InterEventInterval = NaN;
    end
    
    Events(i_peak).Composite.Amp_StartEnd = tmp_Events_Composite_Amp_StartEnd(i_peak);
    Events(i_peak).Composite.Amp_Baseline = tmp_Events_Composite_Amp_Baseline(i_peak);
    Events(i_peak).Composite.Integral = (tmp_Events_Composite_Integral(i_peak).*Opts.Interp_step)/Opts.FrameRate;
    if Events(i_peak).Start == 0
        Events(i_peak).Start = 1;
    end
    if Events(i_peak).Composite.Start == 0
        Events(i_peak).Composite.Start = 1;
    end
end
clear tmp*


%% Consistency checks.
Events_to_remove = [];
n_removed_duration = 0;
n_removed_duration_rise = 0;
n_removed_rise_decay_ratio = 0;
n_removed_CompositeStartEnd = 0;
n_removed_NaNStart = 0;
n_removed_amplitude = 0;
n_removed_integral = 0;
n_removed_duration_long_composite = 0;
n_removed_duration_composite = 0;
n_removed_amplitude_composite = 0;
n_removed_amplitude_single = 0;
n_removed_MinPeakHeight_single = 0;
for i_peak = n_peaks:-1:1
    % Start/End of Composite
    if Events(i_peak).Composite.Start > Events(i_peak).Composite.End
        if Events(i_peak).Composite.CompositeTag == 0
            Events(i_peak).Composite.Start = Events(i_peak).Start;
            Events(i_peak).Composite.End = Events(i_peak).End;
            Events(i_peak).Composite.Duration = Events(i_peak).Duration;
            Events(i_peak).Composite.Baseline = Events(i_peak).Baseline;
            Events(i_peak).Composite.HalfWidth = Events(i_peak).HalfWidth;
            Events(i_peak).Composite.PeakValue = Events(i_peak).PeakValue;
            Events(i_peak).Composite.PeakLoc = Events(i_peak).PeakLoc;
        else
            n_removed_CompositeStartEnd = n_removed_CompositeStartEnd + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        end
    end
    % NaN
    if isnan(Events(i_peak).Start) || isnan(Events(i_peak).End) || isnan(Events(i_peak).Duration)
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Could not find Start/End.\n', TraceNumber, i_peak)
            end
            n_removed_NaNStart = n_removed_NaNStart + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Could not find Start/End.\n', i_peak)
            end
        end
    end
    % Min Duration of Composite
    if Events(i_peak).Composite.Duration < IntCheck.MinDurationComposite
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Duration too low.\n', TraceNumber, i_peak)
            end
            n_removed_duration_composite = n_removed_duration_composite + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Duration too low.\n', i_peak)
            end
        end
    end
    % Max Duration of Composite
    if Events(i_peak).Composite.Duration > IntCheck.MaxDurationComposite
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Duration too long.\n', TraceNumber, i_peak)
            end
            n_removed_duration_long_composite = n_removed_duration_long_composite + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Duration too long.\n', i_peak)
            end
        end
    end
    % Min Amplitude of Composite
    if Events(i_peak).Composite.Amp_StartEnd < IntCheck.MinAmplitude
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Amplitude too low.\n', TraceNumber, i_peak);
            end
            n_removed_amplitude_composite = n_removed_amplitude_composite + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Amplitude too low.\n', i_peak);
            end
        end
    end
    
    % Min Amplitude of Composite
    if Events(i_peak).Amp_StartEnd < IntCheck.MinAmplitudeSingle
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Amplitude of single too low.\n', TraceNumber, i_peak);
            end
            n_removed_amplitude_single = n_removed_amplitude_single + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Amplitude of single too low.\n', i_peak);
            end
        end
    end
    
    % Min Peak Height
    if Events(i_peak).Amp_StartEnd < IntCheck.MinPeakHeight
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: PeakHeight too low.\n', TraceNumber, i_peak);
            end
            n_removed_MinPeakHeight_single = n_removed_MinPeakHeight_single + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: PeakHeigth too low.\n', i_peak);
            end
        end
    end
    
    % Min Duration (of single-event)
    if Events(i_peak).Duration < IntCheck.MinDurationSingle
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Amplitude too low.\n', TraceNumber, i_peak);
            end
            n_removed_duration = n_removed_duration + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: (Sub-)Distance shorter than time res.\n', i_peak);
            end
        end
    end
    % Min Integral (of single-event)
    if Events(i_peak).Integral < IntCheck.MinIntegralSingle
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Integral too small.\n', TraceNumber, i_peak);
            end
            n_removed_integral = n_removed_integral + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Integral of single event too small.\n', i_peak);
            end
        end
    end
    
    
    % Max Rise Duration (only for single-isolated events)
    if (Events(i_peak).Composite.CompositeTag == 0) && Events(i_peak).Duration_Rise > IntCheck.MaxRiseDuration
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Rise Duration too long.\n', TraceNumber, i_peak);
            end
            n_removed_duration_rise = n_removed_duration_rise + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Rise Duration too long.\n', i_peak);
            end
        end
    end
    % Rise/Decay Duration Ratio (only for single-isolated events)
    if (Events(i_peak).Composite.CompositeTag == 0) && abs(Events(i_peak).Duration_Rise/Events(i_peak).Duration_Decay) > IntCheck.MaxRiseDecayRatio
        if numel(find(Events_to_remove == i_peak)) == 0 % Check that event is not already in the removal list.
            if Opts.FLAG_Verbose == 1
                fprintf('Event Candidate Removed: Trace %d, Peak %d.\n Reason: Rise/Decay ratio too high.\n', TraceNumber, i_peak);
            end
            n_removed_rise_decay_ratio = n_removed_rise_decay_ratio + 1;
            Events_to_remove = [Events_to_remove, i_peak];
        else
            if Opts.FLAG_Verbose == 1
                fprintf('Peak %d.\n Removed: Rise/Decay ratio too high.\n', i_peak);
            end
        end
    end
end

n_peaks = numel(Events);
n_removed = numel(Events_to_remove);

% Remove False Positives.
Events_Removed = Events(Events_to_remove); % For Debug purposes.
Events(Events_to_remove) = [];
fprintf('Trace #%d - Events Confirmed: %d. Events Filtered: %d \n', TraceNumber, n_peaks, n_removed);
fprintf('          - Events Filtered for short Duration: %d \n', n_removed_duration);
fprintf('          - Events Filtered for long Rise Duration: %d \n', n_removed_duration_rise);
fprintf('          - Events Filtered for high Rise/Decay Ratio: %d \n', n_removed_rise_decay_ratio);
fprintf('          - Events Filtered for min Amplitude respect to noise of complex: %d \n', n_removed_amplitude_composite);
fprintf('          - Events Filtered for min Amplitude respect to noise of single: %d \n', n_removed_amplitude_single);
fprintf('          - Events Filtered for min Peak Height: %d \n', n_removed_MinPeakHeight_single);
fprintf('          - Events Filtered for short Duration of Complex: %d \n', n_removed_duration_composite);
fprintf('          - Events Filtered for too long Duration of Complex: %d \n', n_removed_duration_long_composite);
fprintf('          - Events Filtered for too small Integral: %d \n', n_removed_integral);
fprintf('          - Events Filtered for NaN Start/End: %d \n', n_removed_NaNStart);
fprintf('          - Events Filtered for Faulty Composite Start/End: %d \n', n_removed_CompositeStartEnd);


