function [Events, StateChanges, StateLength, n_removed, trace_clean] = analyze_single_trace (trace_unclean, Hypnogram, trace_mean, TraceNumber, Opts)
% This function analyzes a single trace.

% Options.
if nargin < 5
    fprintf('Options variable not found for function "get_peaks": loading defaults.\n\n');
    Opts = set_options ();
    Opts.FLAG_display = 0; % Shows plots during analysis.
    Opts.FLAG_display_neg_peak = 0; % Shows plots during neg. peaks analysis.
    Opts.Interp_step = 0.01; % Default = 0.01
end

%% Analyze
% Get negative peaks.
Neg_Peaks = get_negative_peaks(trace_mean, Hypnogram, Opts);

% Remove negative peaks from trace
trace_clean = Remove_Neg_Peaks (trace_unclean, Neg_Peaks, Opts.FLAG_display);

% Gets the closest state change, before the event.
HypnogramDiff = diff(Hypnogram);
HypnogramDiff = [NaN, HypnogramDiff];

StateChanges = find(HypnogramDiff ~= 0);
StateLength = NaN(1, numel(Hypnogram));
for i_state_change = 1:numel(StateChanges)
    if i_state_change == numel(StateChanges)
        tmp_StateLength(i_state_change) = numel(Hypnogram) - StateChanges(i_state_change);
        StateLength(StateChanges(i_state_change):numel(Hypnogram)) = tmp_StateLength(i_state_change);
    else
        tmp_StateLength(i_state_change) = StateChanges(i_state_change + 1) - StateChanges(i_state_change);
        StateLength(StateChanges(i_state_change):StateChanges(i_state_change + 1)) = tmp_StateLength(i_state_change);
    end
end

% Get positive peaks.
[Events, n_removed] = get_peaks(trace_clean, TraceNumber, StateChanges, Opts);

% Check that there is at least an event.
if numel(Events) == 0 || (~isfield(Events, 'Start') && ~isfield(Events, 'End'))
    Events = [];
    return
end

% Add State Classification.       <------------------------------------------------ TO COMPLETE
States{1} = 'Awake'; States{2} = 'Sleep'; States{3} = '---'; States{4} = 'REM';
Classification_type = 'EventStart';
if strcmpi(Classification_type, 'EventStart')
    for i_event = 1:numel(Events)
        %         EStartRaw = double(int32(Events(i_event).Start.*interp_step));
        EStartRaw = Events(i_event).Composite.Start;
        StateChanges_tmp = StateChanges;
        StateChanges_tmp(StateChanges_tmp == 1) = NaN;
        tmp_lag = StateChanges_tmp - EStartRaw;
        Events(i_event).StateTag = Hypnogram(EStartRaw);
        try
            Events(i_event).State = States{Events(i_event).StateTag};
        catch
            keyboard
        end
        Events(i_event).StateLength = StateLength(EStartRaw);
        Events(i_event).Composite.StateTag = Hypnogram(EStartRaw);
        Events(i_event).Composite.State = States{Events(i_event).StateTag};
        
        tmp_dist_Pre = nanmin(abs(tmp_lag(tmp_lag <= 0))); % Gets the closest state change, before the event.
        tmp_dist_Next = nanmin(abs(tmp_lag(tmp_lag > 0))); % Gets the closest state change, before the event.
        
        % Get distance with previous state change, and the old state tag.
        if ~isempty (tmp_dist_Pre)
            Events(i_event).Dist_PreState = tmp_dist_Pre;
            if isnan(StateChanges_tmp(abs(tmp_lag) == tmp_dist_Pre))
                Events(i_event).PreStateTag = NaN;
            elseif StateChanges_tmp(abs(tmp_lag) == tmp_dist_Pre) > 1
                Events(i_event).PreStateTag = Hypnogram(EStartRaw - tmp_dist_Pre - 1);
            else
                Events(i_event).PreStateTag = NaN;
                Events(i_event).Dist_PreState = NaN;
            end
        else
            Events(i_event).Dist_PreState = NaN;
            Events(i_event).PreStateTag = NaN;
        end
        
        % Get distance with following state change, and the new state tag.
        if ~isempty (tmp_dist_Next)
            Events(i_event).Dist_NextState = tmp_dist_Next;
            if isnan(StateChanges_tmp(abs(tmp_lag) == tmp_dist_Next))
                Events(i_event).NextStateTag = NaN;
            elseif StateChanges_tmp(abs(tmp_lag) == tmp_dist_Next) < numel(Hypnogram)
                Events(i_event).NextStateTag = Hypnogram(tmp_dist_Next + EStartRaw);
            else
                Events(i_event).NextStateTag = NaN;
                Events(i_event).NextStateTag = NaN;
            end
        else
            Events(i_event).Dist_NextState = NaN;
            Events(i_event).NextStateTag = NaN;
        end
        Events(i_event).Composite.PreStateTag = Events(i_event).PreStateTag;
        Events(i_event).Composite.NextStateTag = Events(i_event).NextStateTag;
    end
end

% Fix time dimension to be in [s] (divide by the frame rate)
for i_event = 1:numel(Events)
    Events(i_event).Dist_PreState = Events(i_event).Dist_PreState ./ Opts.FrameRate;
    Events(i_event).Dist_NextState = Events(i_event).Dist_NextState ./ Opts.FrameRate;
    Events(i_event).Composite.Dist_PreState = Events(i_event).Dist_PreState ./ Opts.FrameRate;
    Events(i_event).Composite.Dist_NextState = Events(i_event).Dist_NextState ./ Opts.FrameRate;
end

% Add Trace #.
for i_event = 1:numel(Events)
    Events(i_event).TraceNumber = TraceNumber;
    Events(i_event).Composite.TraceNumber = TraceNumber;
end



