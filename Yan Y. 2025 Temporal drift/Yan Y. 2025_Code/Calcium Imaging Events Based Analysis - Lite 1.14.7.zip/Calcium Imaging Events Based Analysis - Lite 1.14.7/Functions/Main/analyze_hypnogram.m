function state_duration = analyze_hypnogram (Hypnogram, FrameRate)
% This function analyzes the hypnogram of a single recording session.
% In output a variable that gives the total duration of each state.

% Initialize.
state_duration.Awake = 0;
state_duration.NoNREM = 0;
state_duration.REM = 0;

n_datapoints = numel(Hypnogram);

for i_DP = 1:n_datapoints
    if Hypnogram(i_DP) == 1
        state_duration.Awake = state_duration.Awake + 1;
    elseif Hypnogram(i_DP) == 2
        state_duration.NoNREM = state_duration.NoNREM + 1;
    elseif Hypnogram(i_DP) == 4
        state_duration.REM = state_duration.REM + 1;
    end
end

state_duration.Awake = state_duration.Awake/FrameRate;
state_duration.NoNREM = state_duration.NoNREM/FrameRate;
state_duration.REM = state_duration.REM/FrameRate;



