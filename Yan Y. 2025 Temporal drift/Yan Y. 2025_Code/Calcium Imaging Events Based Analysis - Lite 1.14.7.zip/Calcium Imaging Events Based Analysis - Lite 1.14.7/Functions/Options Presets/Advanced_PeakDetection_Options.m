function Opts = Advanced_PeakDetection_Options (Opts)
% Setting options for the first phase of Peak Detections



%% Single Traces Analysis
Opts.SingleTraceAnalysis.FLAG_display = 1;
Opts.SingleTraceAnalysis.FLAG_display_neg_peak = 1;

Opts.SingleTraceAnalysis.FLAG_Verbose = 0; % Stop printing all messaged.
Opts.SingleTraceAnalysis.Interp_step = 0.01; % Default is 0.01
Opts.SingleTraceAnalysis.noise_estimation_steps = 2; % Estimate noise ignoring values vastly over the noise: repeat this steps N times
Opts.SingleTraceAnalysis.deriv_envelope_multiplier = 0; % value of 0, will set the derivative threshold to 0

% % Find Peaks (with trace interpolation)
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 10;
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 1; % 1 Default. Controls the multiplier to the noise, for the minimum peak prominence.
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 10;
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = 50/Opts.SingleTraceAnalysis.Interp_step;
% Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;