function Opts = Other_Options (Opts)
% Set other options

%% Binarization of calcium events.
% This option decides what to set as '1' value in the events binarization:
% it can consider only the start or peak of every event.
Opts.General.FolderNameDelimiter = '\';
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'. Default is 'StartComposite'.



%% SingleState Analysis (SingleState_Analysis_per_mouse)
% Binning.
Opts.SingleStateAnalysis.Sync_BinType = 'Weighted'; % 'Weighted' or 'Flat'.
Opts.SingleStateAnalysis.Sync_BinSize = 1; % A BinSize = 0 will make use of only the central bin.
Opts.SingleStateAnalysis.Sync_BinWeights = 'Gauss'; % To use in case of 'Weighted' BinTypes

% Which criteria to use for binarizing the signal?
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'

% Integrals Plot.
Opts.SingleStateAnalysis.Integrals.Plot.FLAG_Plot_SingleStates = 0; % Plot every single state trace (or just the average)?


%% Options Correlation Analysis (Analyze_Correlation_Film)
Opts.CorrAnalysis.n_shuffle_iterations = 200;
Opts.CorrAnalysis.Window_Length = 6*Opts.General.FrameRate; % 18 frames = 6 seconds
Opts.CorrAnalysis.FLAG_SkipUnstableStates = 1;
Opts.CorrAnalysis.FLAG_Plot_Graphs_All = 0;
Opts.CorrAnalysis.FLAG_Plot_Graphs_perMouse = 1;
Opts.CorrAnalysis.FLAG_Save_Film = 0;
Opts.CorrAnalysis.FLAG_Save_Plots = 1;
% The criterion for the correlations to be considered significant:              
% 'Shuffle Mean' threshold is the shuffle correlation mean + k* shuffle
%   correlation standard deviation, computed for each state separately.
% 'Shuffle Mean Uniform' is the same as before, but computed using the
% average standard deviation between all 
Opts.CorrAnalysis.Corr_Thr_Criterion = 'Shuffle Mean'; % 'Shuffle Mean', 'Shuffle Mean Uniform', 'Mean' ('Mean' and 'pValue' are partly supported, might return errors')
Opts.CorrAnalysis.Corr_Thr_Std_Multiplier = 2.5;
Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean = Opts.CorrAnalysis.Corr_Thr_Std_Multiplier;
% Reorder Traces and Correlation
Opts.CorrAnalysis.BaselineStateTag = 1; % Sort according to State with Tag = N (N = 1 -> Awake)
% Plot Options - Graphs
Opts.CorrAnalysis.Opts_GraphPlot.Centrality_Displayed = 'Degree Weighted'; % Centrality measure to be displayed
Opts.CorrAnalysis.Opts_GraphPlot.Marker_Thickness_Mult = 2;
% Plot Options - Mean of States Correlation Plots
Opts.CorrAnalysis.Opts_MeanStatesPlots.FLAG_Save = 1;


%% Continuous Analysis (Continuous_Raw_Analysis)
Opts.ContinuousAnalys.FLAG_AddWhiteNoise = 1; % Add white noise to calcium traces before computing the correlations? (destroy correlated noise), Default = 1
Opts.ContinuousAnalys.FLAG_Save_Film = 0; % Saves the correlation films Default = 1
Opts.ContinuousAnalys.FLAG_ReorderCorr = 0; % Reorder trace and repeat (part of) the analysis
% Plot Options
Opts.ContinuousAnalys.PlotEntropy.FLAG_Save = 1; % Default = 1
Opts.ContinuousAnalys.PlotEntropy.BoxHeight_Multiplier = 1.5; % Default 1.5
Opts.ContinuousAnalys.PlotEntropy.FontSize_ylabel = 12; % Default 12
Opts.ContinuousAnalys.PlotEntropy.FontSize_suptitle = 18; % Default 18


%% Continuous Analysis (Binarized Signal - PointSync Analysis)
Opts.ContinuousPointAnalysis.Window_Length = 3*Opts.General.FrameRate;
Opts.ContinuousPointAnalysis.FLAG_Plot = 1;
Opts.ContinuousPointAnalysis.FLAG_Save = 1;
Opts.ContinuousPointAnalysis.Entropy.Window_Length = 10*Opts.General.FrameRate;


%% Sync
Opts.Sync.NLagBins = 5;
% Plots
Opts.Sync.Plot.StE_alpha = 0.2;
Opts.Sync.Plot.Avg_LineWidth = 2;
Opts.Sync.Plot.n_bins = 50;
Opts.Sync.Plot.marker_size = 10;
Opts.Sync.Plot.dist_grid = 'on';
Opts.Sync.Plot.FLAG_Save = 1;
Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates = 1; % Plot also the separate Awake after NoN-REM & Awake after REM states? 


%% EEG
% Frequency Bands
Opts.EEG.FBand_tot = [0.5, 99];
Opts.EEG.FBand_delta = [0.5, 4.5];
Opts.EEG.FBand_delta1 = [0.5, 1.5];
Opts.EEG.FBand_delta2 = [1.5, 4.5];
Opts.EEG.FBand_theta = [5, 9];
Opts.EEG.FBand_sigma = [11, 16];
Opts.EEG.FBand_gamma = [30, 99];
Opts.EEG.TimeFreqAnalyis.WinLengthMultiplier = 2; % Window Length = WinLengthMultiplier * SamplingRate_EEG
Opts.EEG.TimeFreqAnalyis.WindowStep = 20;  % That's the window advance step
Opts.EEG.TimeFreqAnalyis.FLAG_use_PSD = 0; % I suggest to keep = 0, as it is an untested feature
Opts.EEG.TimeFreqAnalyis.Plot.SmoothSpanWidth = 30; % How large is the smoothing window
Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Plot = 1;
Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Save_Plot = 1;
Opts.EEG.FLAG_Resample2Calcium = 1; % Adapt the EEG Analysis (FreqPower & Spindles) to fit with the Calcium Imaging and its FrameRate.