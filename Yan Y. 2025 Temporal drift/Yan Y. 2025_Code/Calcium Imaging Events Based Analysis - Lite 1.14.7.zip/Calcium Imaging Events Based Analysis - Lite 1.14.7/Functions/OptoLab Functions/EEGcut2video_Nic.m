 % EEGcut2video
%-------------------------------------------------------------------------
% Cut OpenBCI data to video. Saves data in OpenBCI text format.
% Plots TTL to select start point of cutting.
%
% Thomas Rusterholz, 6 Nov 2018

% Niccolo' Calcini, 3/3/2020
% Removed addition of margins.
% Some variables names made more clear
% Removed the dangerous clc, clear, close, etc... and made into a function.
% Automatized the following step (convert_OpenBCI), so that the whole thing
% returns already the correct .mat files.
% Typos
%-------------------------------------------------------------------------


%% Options
N_Frames = 2283;
SamplingRate_EEG = 200;
SamplingRate_CalciumImaging = 3;
StartingFolder = '\\archie\zenstorage\Mattia\Analysis\2photon imaging\';

% Number of data points of ROI (Segment of interest)
noPoints = N_Frames*SamplingRate_EEG/SamplingRate_CalciumImaging; 
% Get the path of the OpenBCI toolbox, in case other function are called
Path_Main = genpath(pwd);
addpath(Path_Main);
Path_OpenBCI = '\\archie\zenstorage\OptoLab_v4.1\';
if exist(Path_OpenBCI, 'dir') == 0
    Path_OpenBCI = uigetdir(Path_Main, 'Specify OpenBCI Main Directory.');
    if isa(Path_OpenBCI, 'double')
        error ('Could not find OpenBCI Folder.')
    end
end
addpath(genpath(Path_OpenBCI));


%% MAIN PROGRAM
%-------------
% READ FILE
[InputFileName, InputFileFolder] = uigetfile('.txt', 'SELECT FILE TO READ', StartingFolder);
if ~ischar(InputFileName)
    fprintf('[\bNo File Selected!\n]\b')
    return
end

rname = fullfile(InputFileFolder, InputFileName);
fprintf('Read file: %s\n', rname)

%READ DATA (and save header)
%header
hdrLines = -1; %initiaization
fid=fopen(rname, 'r');
while true
    str=fgetl(fid);
    hdrLines=hdrLines+1;
    if ~isempty(str) && str(1)~='%'
        break
    end
    if isempty(str)
        continue
    end
    %data check
    tmp=regexp(str(2:end),' ','split');
    if hdrLines==0 && ~strcmpi(tmp{1},'OpenBCI')
        fprintf('  [\bThis is not an OpenBCI-rname]\b\n')
        fclose(fid);
    end
    %read some data
    tmp=regexp(str(2:end),'=','split');
    switch lower(strtrim(tmp{1}))
        case 'sample rate'
            tmp=textscan(tmp{2},'%f');
            SampRate=tmp{1};
    end
end
%data
fseek(fid,0,'bof');
Data=textscan(fid,'%s %s %s %s %s %s %s %s %s','delimiter',',',...
    'HeaderLines',hdrLines);
fclose(fid);
%crop missing data (last line often incomplete)
N=cellfun(@numel,Data);
Data=cellfun(@(x) x(1:min(N)),Data,'UniformOutput',false);
TTL=cellfun(@str2double,Data{5});


%% FIND START INDEX
figure('position',[10,10,900,630],'name',...
    sprintf('Select cut start point (N = %i)',noPoints));
movegui(gcf,'center')
plot(1:numel(TTL),TTL-median(TTL));
ylabel('TTL - median(TTL)'); xlabel('Samples')
title({'Set data cursor to select start point','then press Enter',...
    'PS: margin at start/end automatically added'})
%settings
pos=get(gca,'position');
set(gca,'ylim',1.01*[-1,1]*max(abs(TTL)),'position',pos);
zoom on
%pushbutton
clear cursorInfo
wid=1-sum(pos([1,3])); dx=wid/10; x=wid-2*dx;

uicontrol('style','pushbutton', 'string', 'OK', 'unit', 'normalized', 'position', [1-x-dx, sum(pos([2,4]))-x,x,x],...
    'callback', ['cursorInfo = getCursorInfo(datacursormode(gcf));',...
    'if isempty(cursorInfo);',... % Wait till Button is pressed: at that point return the cursorInfo variable and close figure.
    'warndlg(''Data Cursor Not Set'');',...
    'else; delete(gcf); end']);
waitfor(gcf); % Pause execution till figure is closed.

if ~exist('cursorInfo', 'var') || isempty(cursorInfo)
    fprintf('[\bNo start point selected]\b\n')
    return
end


%% SAVE DATA
[OutputFileName, OutputFilesFolder] = uiputfile('.txt','Save file as:', strrep(rname,'.txt','_cut.txt'));
if ischar(OutputFileName)
    OutputFullPath = fullfile(OutputFilesFolder, OutputFileName);
    fis = fopen(OutputFullPath, 'w+');
    
    % cursorInfo index
    SelectedTimeSegment = (0:noPoints - 1) + cursorInfo.DataIndex;
    
    % cut correction
    ind=SelectedTimeSegment<1;
    if any(ind)
        warning('Margin too large, corrected at start to: %gs',...
            sum(ind)*SampRate)
        SelectedTimeSegment(ind)=[];
    end
    ind=SelectedTimeSegment>numel(Data{1});
    if any(ind)
        warning('Margin too large, corrected at end to: %gs',...
            sum(ind)*SampRate)
        SelectedTimeSegment(ind)=[];
    end
    
    %header
    fid=fopen(rname,'r');
    for k=1:hdrLines
        str=fgetl(fid);
        if k==2
            fprintf(fis,'%% Cut of ''%s''\n',InputFileName);
            fprintf(fis,'%% Samples Cut %i to %i (N = %i)\n',...
                SelectedTimeSegment(1),SelectedTimeSegment(end),numel(SelectedTimeSegment));
            fprintf(fis,'%% Samples ROI %i to %i (N = %i)\n',...
                SelectedTimeSegment(1),SelectedTimeSegment(end),numel(SelectedTimeSegment));
        end
        fprintf(fis,'%s\n',str);
    end
    fclose(fid);
    %data
    Data2=[Data{:}];
    for k=1:numel(SelectedTimeSegment)
        str=sprintf('%s, ',Data2{SelectedTimeSegment(k),:});
        fprintf(fis,'%s\n',str(1:end-2));
    end
    fclose(fis);
    fprintf('Saved: %s\n',OutputFullPath)
else
    fprintf('[\bData NOT saved!\n]\b')
end

%% Convert in .mat & OpenBCI

convert_OpenBCI_Nic (OutputFileName, OutputFilesFolder)




