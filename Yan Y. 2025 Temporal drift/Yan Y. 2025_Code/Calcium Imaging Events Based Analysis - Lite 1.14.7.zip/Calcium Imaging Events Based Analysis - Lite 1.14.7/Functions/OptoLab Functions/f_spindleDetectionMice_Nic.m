function [spindle, param] = f_spindleDetectionMice_Nic(EEG_Trace, Hypnogram, SamplingRate_EEG, idxNREM)
% Spindle detection using optimal wavelet function: 
% Provide as input a single EEG Raw Trace and its Hypnogram, both with the
% same number of time points and sampling resolution "SamplingRate_EEG".
% idxNREM is the lable assigned to the NoNREM state.
%
%   Mojtaba Bandarabadi, Bern, June 2015
%   m.bandarabadi@gmail.com
%
% UPDATE, thomas rusterholz
%   - one file only
%   - providing data instead of reading data
% UPDATE, Niccolo' Calcini (14/1/2020)
%   - Adapted to get input as function arguments instead of loading
%   external files.
%   - Removed Downsampling part: EEG and Hypnogram inputs are assumed to 
%   have the same rampling rates (200Hz at present day 14/1/2020)
%   - Changed saving of a spindles file into returning an output variable
%   - Introduced some comments
%   - Changed structure field names to be more comprehensible by humans

if exist('idxNREM', 'var') == 0
    if isempty(idxNREM)
        idxNREM = 2;
    end
end


%% SPINDLE DETECTION PARAMETERS
param.freq = [9 10 14 16];
param.thrF = [1 3 20];
param.minDur = 0.4;
param.maxDur = 2;
param.minCycle = 5;
param.maxCycle = 30;
waveName = 'fbsp1-1-3';
wavCentFreq = centfrq(waveName);
freqCent = param.freq(2):0.5:param.freq(3);


%% Pre-Processing.
fprintf('\nDetecting Spindles...\n...\n')
n_timepoints = numel(EEG_Trace);

% Detrend
FilterOrder = 5;
[b1, a1] = ellip(FilterOrder, 0.05, 40, 40/(SamplingRate_EEG/2)); % Initialize Lowpass Elliptic Filter
EEG_Filtered = filtfilt(b1, a1, EEG_Trace);
EEG_Detrended = detrend(EEG_Filtered);


%% SPINDLE DETECTION
spindle = struct('Start',[],'End',[],'Duration',[],'CharacteristicFrequency',[],'NegPeak',[],...
    'PosPeak',[],'peak2peak',[],'nCycles',[],'sym',[]);
    
rejected = struct();

% Wavelet
scales = wavCentFreq./(freqCent./SamplingRate_EEG);

% cwtCoef = cwt(EEG_Detrended, waveName, SamplingRate_EEG); % Continuous Wavelet Transform (1-Dimensional), new matlab version (does not work with wavelets of the fbsp family)
cwtCoef = cwt(EEG_Detrended, scales, waveName); % Continuous Wavelet Transform (1-Dimensional), old version
cwtCoef = abs(cwtCoef.^2);
cwtPower = freqCent*cwtCoef;
% Initialize window
smWin = hann(round(SamplingRate_EEG/5))./sum(hann(round(SamplingRate_EEG/5)));
% Convolve with window
cwtPower = conv(cwtPower,smWin,'same');
%TR: no transpose EEG_Downsampled
filtRawData = f_eegfilt(EEG_Detrended, SamplingRate_EEG, param.freq(1), param.freq(4));
if ~isempty(Hypnogram)
    cwtPowerThr = cwtPower(Hypnogram == idxNREM);
else
    cwtPowerThr = cwtPower;
end
cwtPowerThr = cwtPowerThr(cwtPowerThr<10*nanstd(cwtPowerThr));
param.thrL = nanmean(cwtPowerThr)+param.thrF(1)*nanstd(cwtPowerThr);
param.thrH = nanmean(cwtPowerThr)+param.thrF(2)*nanstd(cwtPowerThr);
param.thrM = nanmean(cwtPowerThr)+param.thrF(3)*nanstd(cwtPowerThr);
strSpin = find(diff(sign(cwtPower-param.thrH))==2);
endSpin = find(diff(sign(cwtPower-param.thrH))==-2);

if endSpin(1)<strSpin(1)
    endSpin(1) = [];
end
if length(strSpin)>length(endSpin)
    strSpin(end) = [];
end
for i = 1:length(strSpin)
    strTemp = find((cwtPower(1:strSpin(i))-param.thrL)<0,1,'last');
    endTemp = find((cwtPower(endSpin(i):end)-param.thrL)<...
        0,1,'first')+endSpin(i);
    if isempty(strTemp)||isempty(endTemp)
        strSpin(i) = NaN;
        endSpin(i) = NaN;
    else
        strSpin(i) = strTemp;
        endSpin(i) = endTemp;
    end
end
strSpin(isnan(strSpin)) = [];
endSpin(isnan(endSpin)) = [];
strSpin = unique(strSpin);
endSpin = unique(endSpin);
spinLen = (endSpin-strSpin)./SamplingRate_EEG;
nSp = 0;
nRej.durMin = 0;
nRej.durMax = 0;
nRej.cycles = 0;
nRej.pow = 0;
nRej.freq = 0;
for i = 1:length(strSpin)
    if spinLen(i)<param.minDur
        nRej.durMin = nRej.durMin+1;
        continue
    end
    if spinLen(i)>param.maxDur
        nRej.durMax = nRej.durMax+1;
        continue
    end
    [pkPos,locPos] = findpeaks(filtRawData(strSpin(i):endSpin(i)));
    [pkNeg,locNeg] = findpeaks(-filtRawData(strSpin(i):endSpin(i)));
    if length(pkPos)<param.minCycle || length(pkPos)>param.maxCycle
        nRej.cycles = nRej.cycles+1;
        continue
    end
    [~,idxPkPos] = max(pkPos);
    if nanmax(cwtPower(strSpin(i):endSpin(i)))>param.thrM
        nRej.pow = nRej.pow+1;
        continue
    end
    if i==1 || i==length(strSpin)
        segSpin = EEG_Detrended(strSpin(i):endSpin(i));
    else
        segSpin = EEG_Detrended(strSpin(i)-floor(SamplingRate_EEG/4):endSpin(i)+...
            floor(SamplingRate_EEG/4));
    end
    [pxx,f] = pwelch(segSpin,hann(length(segSpin)),0,2*SamplingRate_EEG,SamplingRate_EEG);
    pxx = f.*pxx;
    [~,idxFreq] = max(pxx(f>=param.freq(1)&f<=param.freq(4)));
    freqSpin = param.freq(1)+(idxFreq-1)*0.5;
    fTot = [6:8.5,16.5:20];
    [~,loc] = ismember(fTot,f);
    pxxMrgn = pxx(loc);
    pxxSpin = pxx(f>param.freq(1)&f<param.freq(4));
    if max(pxxSpin)<max(pxxMrgn)
        nRej.freq = nRej.freq+1;
        rejected(nRej.freq,:).pxx = pxx;
        rejected(nRej.freq,:).f = f;
        rejected(nRej.freq,:).seg = segSpin;
        continue
    end
    nSp = nSp+1;
    spindle(nSp).Start = strSpin(i); % Start [time points]
    spindle(nSp).End = endSpin(i); % End [time points]
    spindle(nSp).Duration = spinLen(i); % Duration of Spindle [s]
    spindle(nSp).CharacteristicFrequency = freqSpin; % Seems like the estimated characteristic frequency of the spindle, likely in [Hz]
    spindle(nSp).NegPeak = -max(pkNeg); % Units?? Do not trust as it is computed on filtered and detrended signal
    spindle(nSp).PosPeak = max(pkPos); % Units?? Do not trust as it is computed on filtered and detrended signal
    spindle(nSp).peak2peak = max(pkPos)+max(pkNeg); % Units?? Do not trust as it is computed on filtered and detrended signal
    spindle(nSp).nCycles = length(pkPos); % Probably the number of oscillations
    spindle(nSp).sym = locPos(idxPkPos)./(SamplingRate_EEG.*spinLen(i)); % No idea of what this is
end


fprintf('Spindle Detection Finished!\n')

