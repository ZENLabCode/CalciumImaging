% Clustering Data Mattia

%% Analysis
main_program_directory = pwd;
addpath(genpath(main_program_directory));

[DFoF_FileName, DFoF_FilePath] = uigetfile('.mat', 'Select DFoF File', pwd);
fprintf('File "%s" Loaded.\n\n', DFoF_FileName);
tmp_data_struct = load([DFoF_FilePath, DFoF_FileName]);

% Add Figures Directories.
Dir_Figures = sprintf('%s\\Figures', main_program_directory);
if exist(Dir_Figures, 'dir') == 0
    Dir_Figures = uigetdir(main_program_directory, 'Choose Figures Folder');
end

% Convert into standard name.
tmp_var_1 = struct2cell(tmp_data_struct);
tmp_var_2 = tmp_var_1{1, 1};
DataCell = tmp_var_2;

number_of_cells = size(DataCell, 1);

% Rename mouse number column.
if iscell(DataCell)
    DataMatrix_full = cell2mat(DataCell);
    tmp = DataMatrix_full(:, 1);
    for i_cell = 1:(number_of_cells-1)
        if ~isnan(tmp(i_cell)) && isnan(tmp(i_cell+1))
            tmp(i_cell+1) = tmp(i_cell);
        end
    end
    DataMatrix_full(:, 1) = tmp;
    DataMatrix = DataMatrix_full(:, 2:4);
else
    DataMatrix_full = DataCell;
    DataMatrix = DataMatrix_full;
end

% Analyze
for i_cell = 1:number_of_cells
    DataAnalyzed(i_cell).mouse = DataMatrix_full(i_cell, 1);
    DataAnalyzed(i_cell).cell_ID = i_cell;
    [DataAnalyzed(i_cell).max_value, DataAnalyzed(i_cell).max_condition] = max(DataMatrix(i_cell, :));
    [DataAnalyzed(i_cell).min_value, DataAnalyzed(i_cell).min_condition] = min(DataMatrix(i_cell, :));
    DataAnalyzed(i_cell).Delta1_2 = DataMatrix(i_cell, 1) - DataMatrix(i_cell, 2);
    DataAnalyzed(i_cell).Delta2_3 = DataMatrix(i_cell, 2) - DataMatrix(i_cell, 3);
    DataAnalyzed(i_cell).Delta1_3 = DataMatrix(i_cell, 1) - DataMatrix(i_cell, 3);
    DataAnalyzed(i_cell).mean_value = mean(DataMatrix(i_cell, :));
    % DataAnalyzed(i_cell).median_condition
end

% Isolate cell groups
tmp = [DataAnalyzed(:).max_condition];
cell_group.Max1.group = DataAnalyzed(find(tmp == 1));
cell_group.Max2.group = DataAnalyzed(find(tmp == 2));
cell_group.Max3.group = DataAnalyzed(find(tmp == 3));
tmp_cat = categorical(tmp);


%% Plots
if Opts.General.Suite2p_Format == 1
    f1_options.bins_width = 0.05;
    f1_options.bins_max = 1.2;
    f1_options.bins_min = -0.1;
    f2_options.bins_width = 0.05;
    f2_options.bins_max = 1;
    f2_options.bins_min = -0.1;
    f2_options.bins_delta_max = 1;
    f2_options.bins_delta_min = -0.1;
else
    f1_options.bins_width = 0.5;
    f1_options.bins_max = 10;
    f1_options.bins_min = -3;
end

plot_figure_0 (DataMatrix, number_of_cells, Dir_Figures)

plot_figure_1 (DataMatrix, number_of_cells, f1_options, Dir_Figures);

plot_figure_2 (DataAnalyzed, cell_group, tmp_cat, number_of_cells, f2_options, Dir_Figures);

