function plot_figure_0 (DataMatrix, number_of_cells, Dir_Figures)

% Options
marker_size = 10;
number_of_datapoints = number_of_cells*3;
cell_conditions = cell(number_of_datapoints, 1);
for i = 1:3:number_of_datapoints
    cell_conditions{i} = 'Awake';
    cell_conditions{i+1} = 'Non-REM';
    cell_conditions{i+2} = 'REM';
end

data_tmp = zeros(1, number_of_cells);
for i = 0:number_of_cells-1
    data_tmp(i*3 + 1) = DataMatrix(i+1, 1);
    data_tmp(i*3 + 2) = DataMatrix(i+1, 2);
    data_tmp(i*3 + 3) = DataMatrix(i+1, 3);
end

figure;
hold on;
h = scatterhist(data_tmp, 1:numel(data_tmp), 'Kernel', 'on', 'Group', cell_conditions, 'LineWidth', 2, 'Marker', '.', 'MarkerSize', marker_size);
delete(h(3));
bc = get(gcf,'color');
set(h(2),'visible','on','color',bc,'box','off');
% - x-axis hist
tmp_tick = get(h(2),'ytick');
tmp_tick_2 = tmp_tick(end) + abs(tmp_tick(1) - tmp_tick(2));
% set(h(2), 'YLim', [0, tmp_tick_2]);
% set(h(2), 'ytick', [tmp_tick, tmp_tick_2]);
% set(h(2), 'yticklabel', abs(get(h(2),'ytick')));

set(h(2), 'YLim', [0, 0.8]);
set(h(2), 'ytick', [0, 0.2, 0.4, 0.6, 0.8]);
set(h(2), 'yticklabel', abs(get(h(2),'ytick')));

grid on;
axis tight;
ylabel('Data Point')
xlabel('\DeltaF/F');

% Save File.
FileName = 'Max DFoF - ScatterHist';
FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))

close gcf