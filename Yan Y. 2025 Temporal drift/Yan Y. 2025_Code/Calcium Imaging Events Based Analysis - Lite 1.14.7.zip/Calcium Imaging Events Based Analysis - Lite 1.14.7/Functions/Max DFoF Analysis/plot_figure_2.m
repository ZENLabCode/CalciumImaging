function H_figure = plot_figure_2 (DataAnalyzed, cell_group, tmp_cat, number_of_cells, f2_options, Dir_Figures)

% Plots
bins_width = f2_options.bins_width;
bins_max = f2_options.bins_max;
bins_min = f2_options.bins_min;
bins_delta_max = f2_options.bins_delta_max;
bins_delta_min = f2_options.bins_delta_min;
hist_alpha = 0.5;

figure();
set(gcf,'position', get(0,'screensize'));
% Plot Pie
subplot(2, 2, 1);
h_piechart = pie(tmp_cat);
% Adjust text
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
tmp_percentValues{1} = tmp_percentValues{1}(3:end);% Remove 1-2-3 in front of percentage value
tmp_percentValues{2} = tmp_percentValues{2}(3:end);% Remove 1-2-3 in front of percentage value
tmp_percentValues{3} = tmp_percentValues{3}(3:end);% Remove 1-2-3 in front of percentage value
tmp_txt1 = sprintf('Max \\DeltaF/F in Awake State:\n');
tmp_txt2 = sprintf('Max \\DeltaF/F in Non-REM State:\n');
tmp_txt3 = sprintf('Max \\DeltaF/F in REM State:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
tmp_pText(3).String = tmp_combinedtxt(3);

title(sprintf('Distribution of cells in conditions with max \\DeltaF/F.\n Cells Number = %d.', number_of_cells), 'FontSize', 14)

% Histograms Deltas
subplot(2, 2, 2); 
hold on;

bins_edges = bins_delta_min:bins_width:bins_delta_max;

histogram([DataAnalyzed.Delta1_2], bins_edges, 'FaceColor', 'b', 'FaceAlpha', hist_alpha);
histogram([DataAnalyzed.Delta2_3], bins_edges, 'FaceColor', 'r', 'FaceAlpha', hist_alpha);
histogram([DataAnalyzed.Delta1_3], bins_edges, 'FaceColor', 'y', 'FaceAlpha', hist_alpha);
legend({'\Delta(Awake-NonREM)','\Delta(NonREM-REM)','\Delta(Awake-REM)'});
xlabel('Difference in \DeltaF/F'); ylabel('Cell Count');
box on; grid on;
axis tight; axis square
title('\DeltaF/F Difference between conditions.', 'FontSize', 14)

% Histogram Mean DF/F
subplot(2, 2, 3); 
hold on;
bins_edges = bins_min:bins_width:bins_max;
histogram([cell_group.Max1.group.mean_value], bins_edges, 'FaceColor', 'b', 'FaceAlpha', hist_alpha);
histogram([cell_group.Max2.group.mean_value], bins_edges, 'FaceColor', 'r', 'FaceAlpha', hist_alpha);
histogram([cell_group.Max3.group.mean_value], bins_edges, 'FaceColor', 'y', 'FaceAlpha', hist_alpha);
legend({'Max \DeltaF/F in Awake','Max \DeltaF/F in Non-REM','Max \DeltaF/F in REM'});
xlabel('Mean value \DeltaF/F between all conditions'); ylabel('Cell Count');
box on; grid on;
axis tight; axis square
title('Mean value \DeltaF/F between all conditions.', 'FontSize', 14)

% Histogram Max DF/F
subplot(2, 2, 4); 
hold on;
bins_edges = bins_min:bins_width:bins_max;
histogram([cell_group.Max1.group.max_value], bins_edges, 'FaceColor', 'b', 'FaceAlpha', hist_alpha);
histogram([cell_group.Max2.group.max_value], bins_edges, 'FaceColor', 'r', 'FaceAlpha', hist_alpha);
histogram([cell_group.Max3.group.max_value], bins_edges, 'FaceColor', 'y', 'FaceAlpha', hist_alpha);
legend({'Max \DeltaF/F in Awake','Max \DeltaF/F in Non-REM','Max \DeltaF/F in REM'});
xlabel('Max value \DeltaF/F between all conditions'); ylabel('Cell Count');
box on; grid on;
axis tight; axis square
title('Max value \DeltaF/F between all conditions.', 'FontSize', 14)

suptitle_string = 'Cells classified by max \DeltaF/F';

% Save File.
FileName = 'Max DFoF - Histograms 2';
FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))

close gcf