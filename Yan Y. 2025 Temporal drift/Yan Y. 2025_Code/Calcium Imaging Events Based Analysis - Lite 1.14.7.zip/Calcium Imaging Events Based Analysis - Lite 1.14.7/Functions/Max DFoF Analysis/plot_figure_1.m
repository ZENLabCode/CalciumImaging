function plot_figure_1 (DataMatrix, number_of_cells, f1_options, Dir_Figures)

% Set default values
if nargin < 4
    Dir_Figures = pwd;
end
if nargin < 3
   f1_options.bins_width = 0.25; % Default value
   Dir_Figures = pwd;
end
if nargin >= 3 && ~isfield(f1_options, 'bins_width')
    f1_options.bins_width = 0.25; % Default value
end

bins_width = f1_options.bins_width;
bins_max = f1_options.bins_max;
bins_min = f1_options.bins_min;
hist_alpha = 0.5;
FLAGs.gaussian_model = 'gauss1';
FLAGs.fit_G1 = 1;
FLAGs.fit_G2 = 1;
% options for gaussian

figure; 
set(gcf,'position', get(0,'screensize'));

% Plot Data Points
subplot(2,3,1); hold on;
scatter (1:number_of_cells, DataMatrix(:, 1), 'filled')
scatter (1:number_of_cells, DataMatrix(:, 2), 'filled')
scatter (1:number_of_cells, DataMatrix(:, 3), 'filled')
axis tight; box on; grid on;
xlabel('Cell ID'); ylabel('\DeltaF/F');

% Plot Awake
subplot(2,3,2);
bins_edges = bins_min:bins_width:bins_max;
h = histogram(DataMatrix(:, 1), bins_edges, 'FaceColor', 'b', 'FaceAlpha', hist_alpha);
box on; grid on;
options.Color = 'b';
[gauss_plot, fit_results_Awake] = fit_gaussian (DataMatrix(:, 1), bins_edges, FLAGs, options);
title('Data Distribution (\DeltaF/F)', 'FontSize', 18)
xlabel('\DeltaF/F'); ylabel('Count');
legend({'Awake'}, 'Location', 'NorthEast');

% Plot non-REM
subplot(2,3,3);
bins_edges = bins_min:bins_width:bins_max;
h = histogram(DataMatrix(:, 2), bins_edges, 'FaceColor', 'r', 'FaceAlpha', hist_alpha);
box on; grid on;
options.Color = 'r';
[gauss_plot_Non_REM, fit_results_Non_REM] = fit_gaussian (DataMatrix(:, 2), bins_edges, FLAGs, options);
xlabel('\DeltaF/F'); ylabel('Count');
legend({'Non-REM Sleep'}, 'Location', 'NorthEast');

% Plot REM State
subplot(2,3,4);
bins_edges = bins_min:bins_width:bins_max;
h = histogram(DataMatrix(:, 3), bins_edges, 'FaceColor', 'y', 'FaceAlpha', hist_alpha);
box on; grid on;
options.Color = 'y';
[gauss_plot_REM, fit_results_REM] = fit_gaussian (DataMatrix(:, 3), bins_edges, FLAGs, options);
xlabel('\DeltaF/F'); ylabel('Count');
legend({'REM Sleep'}, 'Location', 'NorthEast');

% 3 States overlapping
subplot(2,3,5); hold on;
bins_edges = bins_min:bins_width:bins_max;
h1 = histogram(DataMatrix(:, 1), bins_edges, 'FaceColor', 'b', 'FaceAlpha', hist_alpha);
options.Color = 'b';
[gauss_plot_REM, fit_results_REM] = fit_gaussian (DataMatrix(:, 1), bins_edges, FLAGs, options);
h2 = histogram(DataMatrix(:, 2), bins_edges, 'FaceColor', 'r', 'FaceAlpha', hist_alpha);
options.Color = 'r';
[gauss_plot_REM, fit_results_REM] = fit_gaussian (DataMatrix(:, 2), bins_edges, FLAGs, options);
h3 = histogram(DataMatrix(:, 3), bins_edges, 'FaceColor', 'y', 'FaceAlpha', hist_alpha);
options.Color = 'y';
[gauss_plot_REM, fit_results_REM] = fit_gaussian (DataMatrix(:, 3), bins_edges, FLAGs, options);
max_count = max([nanmax(h1.BinCounts), nanmax(h2.BinCounts), nanmax(h3.BinCounts)]);
box on; grid on;
xlabel('\DeltaF/F'); ylabel('Count');
legend([h1, h2, h3], {'Awake', 'Non-REM Sleep', 'REM Sleep'}, 'Location', 'NorthEast');

% Plot All Cells.
subplot(2,3,6);
data_tmp = [DataMatrix(:, 1); DataMatrix(:, 2); DataMatrix(:, 3)];
n_bins = 12;
bins_edges = bins_min:bins_width:bins_max;
h = histogram(data_tmp, bins_edges, 'FaceColor', 'g', 'FaceAlpha', hist_alpha);
axis ([-inf, inf, 0, nanmax(h.BinCounts)+5]); box on; grid on;

% Fit 2 Gaussians.
FLAGs.gaussian_model = 'gauss2'; FLAGs.fit_G1 = 1; FLAGs.fit_G2 = 1;
options.Color = 'g';
[gauss_plot, gauss2_fit_results] = fit_gaussian (data_tmp, bins_edges, FLAGs, options);

xlabel('\DeltaF/F'); ylabel('Count (All Cells)');
legend({'All Cells', 'Fitted Gaussian 1', 'Fitted Gaussian 2', 'Fitted double gaussian'}, 'Location', 'NorthEast');

% Fix Y-Axis
subplot(2,3,2); axis ([-inf, inf, 0, max_count+5]);
subplot(2,3,3); axis ([-inf, inf, 0, max_count+5]);
subplot(2,3,4); axis ([-inf, inf, 0, max_count+5]);

% Save File.
FileName = 'Max DFoF - Histograms';
FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))

close gcf