function CellType_Folder = set_figuresFolder (Opts)
% Automatically sets the figures folder for the current Cell Type. CellType
% is simply a string that indicates the name of the cells or analysis that is run.

if ~isfield (Opts, 'CellType')
    Opts.CellType = 'Unknown Cell Type';
end

if exist(Opts.Dir_Figures, 'dir') == 0
    tmp = pwd;
    Opts.Dir_Figures = [tmp, Opts.General.FolderNameDelimiter, 'Figures'];
    if exist(Opts.Dir_Figures, 'dir') == 0
        mkdir (Opts.Dir_Figures)
    end
    addpath(genpath(Opts.Dir_Figures));
end

CellType_Folder = [Opts.Dir_Figures, Opts.General.FolderNameDelimiter, Opts.CellType];
if exist(CellType_Folder, 'dir') == 0
    mkdir (CellType_Folder)
    addpath(genpath(CellType_Folder));
    fprintf('\n%s - Figures Folder created in\n%s\n\n', Opts.CellType, Opts.Dir_Figures)
end

