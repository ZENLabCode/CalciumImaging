function Events_HalfWidth = compute_HalfWidth(Events_Amp_StartEnd, Event_Interp, interp_step)
    % Computes the HalfWidth of a calcium event
    % Input: 
    % - Amplitude, computed from the start / end points of the event. 
    % - Event interpolated (with a spline)
    % - Interpolation Step (ratio old_datapoint / interp_datapoint )
    
    Half_Amplitude = Events_Amp_StartEnd/2; % Mid-amplitude - baseline

    %   (Get left and right side values)
    [newMax_value, newMax_loc] = nanmax(Event_Interp);
    event_left = Event_Interp(1:newMax_loc);
    event_right = Event_Interp(newMax_loc+1:end);
    [amp_left_error, half_amplitude_loc_left] = nanmin( abs(event_left - Half_Amplitude) );
    half_amplitude_left = event_left(half_amplitude_loc_left);
    [amp_right_error, half_amplitude_loc_right] = nanmin( abs(event_right - Half_Amplitude) );
    half_amplitude_right = event_right(half_amplitude_loc_right);
    %   (Get actual HalfWidth)

    if isempty(half_amplitude_left) || isempty(half_amplitude_right)
        Events_HalfWidth = NaN;
    else
        Events_HalfWidth = abs(find(Event_Interp == half_amplitude_left) - find(Event_Interp == half_amplitude_right)).*interp_step;
    end