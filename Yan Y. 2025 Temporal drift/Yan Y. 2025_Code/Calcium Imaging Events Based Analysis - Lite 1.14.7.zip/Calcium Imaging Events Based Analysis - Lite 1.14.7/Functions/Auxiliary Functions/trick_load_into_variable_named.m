% This trick loads the variable from a file, and renames it into a name
% decided in the code, which is "variable_name"
[FileName, FilePath] = uigetfile('*.mat', 'Select File to load');
data_tmp_struct = load(strcat(FilePath, FileName));

% Convert into standard name.
tmp_var_1 = struct2cell(data_tmp_struct);
tmp_var_2 = tmp_var_1{1, 1};
variable_name = tmp_var_2;
