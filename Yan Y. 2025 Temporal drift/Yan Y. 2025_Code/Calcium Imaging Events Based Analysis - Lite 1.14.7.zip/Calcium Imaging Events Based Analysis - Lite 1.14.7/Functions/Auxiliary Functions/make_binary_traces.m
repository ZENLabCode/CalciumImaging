function Binary_Traces_AllMice = make_binary_traces (Events_AllMice, Hypnogram_AllMice, calTime, Opts)
% This function gives in output a binary matrix, where values of 1
% correspond to period between event start and end.
% This function is intented for use in the syncro_analysis.

n_mouse = numel(Hypnogram_AllMice);
n_Events_Tot = numel(Events_AllMice);

% Get Mouse Tag.
Current_Mouse = Events_AllMice(1).MouseTag;
Binary_Traces_AllMice = cell(1, n_mouse);
i2_event = 1;
i_event = 1;
if exist('Current_Mouse_Events' , 'var') ~= 0
   clear Current_Mouse_Events
end

for i_mouse = 1:n_mouse
    counter_event_binarized = 0;
    % Get Hypnogram
    Current_Hypnogram = Hypnogram_AllMice(i_mouse).Hypnogram;
    
    n_DataPoints = numel(Current_Hypnogram);
    
    % Get events from a single mouse
    while i_event <= n_Events_Tot && strcmpi(Events_AllMice(i_event).MouseTag, Current_Mouse) == 1
        Current_Mouse_Events(i2_event) = Events_AllMice(i_event);
        i2_event = i2_event + 1;
        i_event = i_event + 1;
    end
    
    fprintf('Current Mouse: "%s" (# Events = %d)\n', Current_Mouse, numel(Current_Mouse_Events))
    
    % Get Events from a single trace.
    n_current_traces = nanmax([Current_Mouse_Events.TraceNumber]);
    Binary_Traces = cell(1, n_current_traces);
    for i_trace = 1:n_current_traces
        current_trace_Events = Current_Mouse_Events([Current_Mouse_Events.TraceNumber] == i_trace);
        % Make a binary trace, Event / NoN-Event.
        current_trace_Binary = zeros(1, n_DataPoints);
        for j_event = 1:numel(current_trace_Events)
            if strcmpi(Opts.EventIdentifier, 'StartEnd') % Sets as 1 the frames between the first and last point of an event.
                tmp_compositeTag = current_trace_Events(j_event).Composite.CompositeTag;
                tmp_event_start = current_trace_Events(j_event).Composite.Start;
                tmp_event_end = current_trace_Events(j_event).Composite.End;
                if tmp_compositeTag == 0 || isnan(tmp_event_loc)
                    tmp_event_start = current_trace_Events(j_event).Start;
                    tmp_event_end = current_trace_Events(j_event).End;
                end
                current_trace_Binary(tmp_event_start:tmp_event_end) = ones(1, numel(tmp_event_start:tmp_event_end));
                counter_event_binarized = counter_event_binarized + 1;
            elseif strcmpi(Opts.EventIdentifier, 'RiseSlope') % Sets as 1 the frames between the start point and the max peak of an event.
                tmp_compositeTag = current_trace_Events(j_event).Composite.CompositeTag;
                tmp_event_start = current_trace_Events(j_event).Composite.Start;
                tmp_event_MaxPeakLoc = current_trace_Events(j_event).Composite.PeakLoc;
                if tmp_compositeTag == 0 || isnan(tmp_event_start) || isnan(tmp_event_MaxPeakLoc)
                    tmp_event_start = current_trace_Events(j_event).Start;
                    tmp_event_MaxPeakLoc = current_trace_Events(j_event).PeakLoc;
                    
                end
                current_trace_Binary(tmp_event_start:tmp_event_MaxPeakLoc) = ones(1, numel(tmp_event_start:tmp_event_MaxPeakLoc));
                counter_event_binarized = counter_event_binarized + 1;
            end
        end
        
        Binary_Traces{i_trace} = current_trace_Binary; 
    end
    
    % Save all traces for a mouse.
    Binary_Traces_AllMice{i_mouse} = Binary_Traces;
    fprintf('Events correctly represented in the binary traces for mouse "%s": %d.\n', Current_Mouse, counter_event_binarized);

    % Get to next mouse
    if i_event >= n_Events_Tot
        break
    end
    
    clear Current_Mouse
    Current_Mouse = Events_AllMice(i_event).MouseTag;
    i2_event = 1;
    
    % Empty tmp variable
    if i_mouse ~= n_mouse
        clear Current_Mouse_Events
        clear Binary_Traces
        clear current_trace_Binary
    end
end

