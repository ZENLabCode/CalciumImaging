function Mouse_Cells = cmp_number_of_cells (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names)
% This function outputs a variable that tracks the number of cells per
% mouse, per session

n_sessions = numel(CalciumTraces_Clean_AllSessions);
n_mice = numel(Mouse_Names);


n_cells = NaN(n_sessions, 1);
n_frames = NaN(n_sessions, 1);
SessionID = NaN(n_sessions, 1);
MouseID_Name = cell(n_sessions, 1);
for i = 1:n_sessions
    [n_frames(i), n_cells(i)] = size(CalciumTraces_Clean_AllSessions{i});
    SessionID(i) = Hypnogram_AllSessions(i).Session;
    MouseID_Name{i} = Hypnogram_AllSessions(i).MouseName;
end

for i = 1:n_sessions
    for i_mouse = 1:n_mice
        current_mouse = Mouse_Names{i_mouse};
        if strcmpi(MouseID_Name{i}, current_mouse)
            MouseID(i) = i_mouse;
        end
    end
end

Mouse_Cells = struct;
for i = 1:n_sessions
    Mouse_Cells(i).n_cells = n_cells(i);
    Mouse_Cells(i).SessionID = SessionID(i);
    Mouse_Cells(i).MouseID = MouseID(i);
end

% plot(n_cells);