function Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts)
% This function loads the hypnograms of a single mouse recordings, as
% present in the Data Directory "Dir_Data" and subdirectory "MouseName"
% and "session".


% Reconstruct the recordings folder name
if Opts.General.Suite2p_Format == 1
    mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
    tmp_sessions = dir(mouse_folder);
    for i = 1:numel(tmp_sessions)
        tmp2_sessions = tmp_sessions(i).name;
        if strcmpi(tmp2_sessions, '.') || strcmpi(tmp2_sessions, '..')
            continue
        end
        tmp3_sessions = strsplit(tmp2_sessions, Opts.General.FolderNameDelimiter);
        tmp3_sessions = tmp3_sessions{2};
        
        tmp4_sessions = strsplit(tmp3_sessions, '_');
        session_num = tmp4_sessions{2};
        
        if ~strcmpi(tmp4_sessions{1}, 'Session')
            warning(sprintf('Only folders with syntax like year.month.day-Session_SessionNumber\nExample: 2021.08.14-Session_1\n'))
        end
        
        if str2num(session_num) == i_session
            recordings_folder = sprintf('%s\\%s\\%s', Dir_Data, MouseName, tmp2_sessions);
        end
    end
    
    
else
    recordings_folder = sprintf('%s\\%s\\session_%d', Dir_Data, MouseName, i_session);
end


% Check folder existence.
if exist(recordings_folder, 'dir') ~= 0
    file_Hyp_FullPath = sprintf('%s\\%s', recordings_folder, 'hypnogram.mat');
    if exist(file_Hyp_FullPath, 'file') == 0
        file_Hyp_FullPath = sprintf('%s\\%s', recordings_folder, 'Hypnogram.mat');
        if exist(file_Hyp_FullPath, 'file') ~= 0
            warning('Please remove the capital letter in %s into "hypnogram.mat"', file_Hyp_FullPath)
        end
    end
else
    warning('Folder "%s" does not exist.', recordings_folder)
end

% If file exists, load it.
if exist(file_Hyp_FullPath, 'file') == 2 
    tmp_data_struct = load(file_Hyp_FullPath);
    % Convert into standard name.
    tmp_var_1 = struct2cell(tmp_data_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    Hypnogram = tmp_var_2;
    [dim1, dim2] = size(Hypnogram);
    if dim1 > dim2
        Hypnogram = Hypnogram';
    end
else
    error('Missing "hypnogram.mat" file in folder: %s', recordings_folder)
end

