function CalciumTraces_Normalized_AllSessions = normalize_byNoiseLevels (CalciumTraces_Clean_AllSessions, Opts)


noise_estimation_steps = Opts.SingleTraceAnalysis.noise_estimation_steps;

n_sessions = numel(CalciumTraces_Clean_AllSessions);
CalciumTraces_Normalized_AllSessions = cell(1, n_sessions);
for i_session = 1:n_sessions
    CalciumTraces = CalciumTraces_Clean_AllSessions{i_session};
    [n_datapoints, n_traces] = size(CalciumTraces);
    CalciumTraces_Normalized = NaN(n_datapoints, n_traces);
    noise_estimate = NaN(1, n_traces);
    median_estimate = NaN(1, n_traces);
    mean_estimate = NaN(1, n_traces);
    for i_trace = 1:n_traces
        current_trace = CalciumTraces(:, i_trace);
        [noise_estimate(i_trace), median_estimate(i_trace), mean_estimate(i_trace)] = estimate_noise (current_trace, noise_estimation_steps);
        CalciumTraces_Normalized(:, i_trace) = smooth(current_trace)./noise_estimate(i_trace);
    end
%     mean_trace = mean(CalciumTraces, 2 ,'omitnan');
    CalciumTraces_Normalized_AllSessions{i_session} = CalciumTraces_Normalized;
end



