function Events_Complex = get_composite_info(Events_All)
% This function isolates the complex events (intended as single events
% composed of multiple sub-events), and their characteristics.

BCK_Events_All = Events_All;
n_events = numel(Events_All);
Current_Event_trace = Events_All(1).TraceNumber;
Current_composite = Events_All(1).Composite;
Events_Complex(1) = Current_composite;

i_complex = 1;
for i_event = 2:n_events
    Current_Event = Events_All(i_event);
    Previous_Event = Events_All(i_event - 1);
    Current_Event_trace = Current_Event.TraceNumber;
    Previous_Event_trace = Previous_Event.TraceNumber;
    Current_composite = Current_Event.Composite;
    Previous_composite = Previous_Event.Composite;
    if Current_Event_trace == Previous_Event_trace && Current_composite.EventTag == Previous_composite.EventTag
        % Save only the events that are not double-occurring...
    else
        Events_Complex(i_complex) = Current_composite;
        i_complex = i_complex + 1;
    end
end