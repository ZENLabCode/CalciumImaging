function output = cmp_sync_stats (dist1, dist2)
% This function is a sub function of the sync_analysis functions, used for
% readibility purposes. It computes the statistics between different
% groups, and returns them in the proper structure.


if isempty(dist2)
    output.T_Test.h = NaN;
    output.T_Test.p = NaN;
    output.T_Test.Confidence_Interval = NaN;
    output.T_Test.TStats = NaN;
    
    output.U_test.h = NaN;
    output.U_test.p = NaN;
    output.U_test.UStats = NaN;
    
    output.KS_test.h = NaN;
    output.KS_test.p = NaN;
    output.KS_test.KSStats = NaN;
    
    output.EffectSize.CohenD = NaN;
    output.EffectSize.CohenD_unbiased = NaN;
    output.EffectSize.Hedge_G = NaN;
    
else
    
    % T-Test
    [tmp_h, tmp_p, tmp_CI, tmp_Stats] = ttest2(dist1, dist2);
    output.T_Test.h = tmp_h;
    output.T_Test.p = tmp_p;
    output.T_Test.Confidence_Interval = tmp_CI;
    output.T_Test.TStats = tmp_Stats;
    
    % U_Test (Mann-Whitney)
    
    [tmp_p, tmp_h, tmp_Stats] = ranksum(dist1, dist2);
    output.U_test.h = tmp_h;
    output.U_test.p = tmp_p;
    output.U_test.UStats = tmp_Stats;
    
    % K-S Test
    [tmp_h, tmp_p, tmp_Stats] = kstest2(dist1, dist2);
    output.KS_test.h = tmp_h;
    output.KS_test.p = tmp_p;
    output.KS_test.KSStats = tmp_Stats;
    
    % Effect Size Measures
    [CohenD, CohenD_unbiased, Hedge_G] = Effect_Size (dist1, dist2);
    output.EffectSize.CohenD = CohenD;
    output.EffectSize.CohenD_unbiased = CohenD_unbiased;
    output.EffectSize.Hedge_G = Hedge_G;
    
end