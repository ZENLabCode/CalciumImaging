function [spindles_ReS, FreqPower_ReS] = resample_EEGPower2Imaging (spindles, FreqPower, imaging_length, ImagingSamplingRate, EEG_SamplingRate)
% This function adjusts the time dimension of the EEG Analysis to fit the
% Imaging time resolution and length.
% Specifically, it resamples the FreqPower to match the sampling rate of
% the imaging, and makes the same adjustment to the spindles start/end
% times.

N_Channels = numel(FreqPower);
for i_Channel = 1:N_Channels
    EEG_length = numel(FreqPower_Channel.delta1);
    FreqPower_Channel = FreqPower{i_Channel};
    spindles_Channel = spindles{i_Channel};
    n_Spindles = numel(spindles_Channel);
    
    FreqPower_Channel.delta = resample(FreqPower_Channel.delta, imaging_length, EEG_length);
    FreqPower_Channel.delta1 = resample(FreqPower_Channel.delta1, imaging_length, EEG_length);
    FreqPower_Channel.delta2 = resample(FreqPower_Channel.delta2, imaging_length, EEG_length);
    FreqPower_Channel.theta = resample(FreqPower_Channel.theta, imaging_length, EEG_length);
    FreqPower_Channel.sigma = resample(FreqPower_Channel.sigma, imaging_length, EEG_length);
    FreqPower_Channel.gamma = resample(FreqPower_Channel.gamma, imaging_length, EEG_length);
    
    tmp_Start = [spindles_Channel.str].*(ImagingSamplingRate/EEG_SamplingRate);
    tmp_End = [spindles_Channel.end].*(ImagingSamplingRate/EEG_SamplingRate);
    for i_spindle = 1:n_Spindles
        spindles_Channel(i_spindle).str = round(tmp_Start(i_spindle));
        spindles_Channel(i_spindle).end = round(tmp_End(i_spindle));
    end
    FreqPower_ReS{i_Channel} = FreqPower_Channel;
    spindles_ReS{i_Channel} = spindles_Channel;
end