function [noise_estimate, median_estimate, mean_estimate] = estimate_noise (trace, noise_estimation_steps)
% This function attempts to give an estimation of the noise in the signal,
% by computing the standard deviation, then excluding data points that
% deviate too much, and recomputing the standard deviation without these
% outliers, that likely compose the actual signal.
% "noise_estimation_steps" is the number of these std->filtering->std steps
% used to compute the noise estimation. 
% The noise would be the final std value.

n_datapoints = numel(trace);

% Get Median & Std.
trace_median = nanmedian(trace);
trace_mean = nanmean(trace);
trace_std = nanstd(trace);

% Get an estimation of the noise. (multiple steps of std estimation)
trace_tmp = trace;
trace_median_tmp = trace_median;
trace_mean_tmp = trace_mean;
trace_std_tmp = trace_std;

for i_estimation_step = 1:noise_estimation_steps
    for i_t = 1:n_datapoints
        if trace(i_t) > trace_median_tmp + trace_std_tmp
            trace_tmp(i_t) = NaN;
        end
    end
    trace_median_tmp = nanmedian(trace_tmp);
    trace_mean_tmp = nanmean(trace_tmp);
    trace_std_tmp = nanstd(trace_tmp);
end

median_estimate = trace_median_tmp;
mean_estimate = trace_mean_tmp;
noise_estimate = trace_std_tmp;