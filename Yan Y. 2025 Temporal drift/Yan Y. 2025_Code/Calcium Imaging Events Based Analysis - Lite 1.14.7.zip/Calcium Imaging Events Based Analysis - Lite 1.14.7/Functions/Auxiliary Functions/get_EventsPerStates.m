function [Events_SelectedState, tmp_StateChangeLag, Events_Unstable, Events_Stable, StateLength_min] = get_EventsPerStates (Events, SelectedTag, Opts)
% This function returns the Events only of the selected states.
% (Intended as a sub-function of "Sync2StateChange"
% SelectedTag is the tag of the state that is to be considered (an integer
% number)

minimum_state_length = Opts.General.MinStableStateDuration;

% Isolate State
Events_SelectedState = Events([Events.StateTag] == SelectedTag);
% Get Events Lags
tmp_StateChangeLag = [Events_SelectedState.Dist_PreState];
% Isolate Events of Unstable States
Events_Unstable = Events_SelectedState([Events_SelectedState.StateLength] < minimum_state_length);
% Isolate Events of Stable States
Events_Stable = Events_SelectedState([Events_SelectedState.StateLength] > minimum_state_length);
% Get the minimum lenght of a Stable State
StateLength_min = nanmin([Events_Stable.StateLength]);
