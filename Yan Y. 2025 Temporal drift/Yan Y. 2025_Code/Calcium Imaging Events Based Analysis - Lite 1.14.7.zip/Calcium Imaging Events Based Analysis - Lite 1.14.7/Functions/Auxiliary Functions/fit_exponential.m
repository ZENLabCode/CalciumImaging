function [exp_decay_rate, exp_decay_multiplier, exp_fit_coeff_interval, exp_fit_curve] = fit_exponential(Event, FrameRate)
% This function performs an exponential fit for a single Calcium event,
% provided there are enough data points for the fit.

% Options
min_fit_points = 10;

% Isolate decay part of the event.
[e_peak, e_peak_loc] = nanmax(Event);
if numel(e_peak) > 1
    e_peak = e_peak(end);
    e_peak_loc = e_peak_loc(end);
end
event_decay = Event(e_peak_loc:end);

% Remove NaNs 
event_1stNaN = find(isnan(event_decay));
if ~isempty(event_1stNaN)
    event_decay(event_1stNaN(1):end) = [];
end
decay_duration = numel(event_decay);

% Check that the decay has enough points for a decent fit.
if decay_duration >= min_fit_points
    try
    [exp_fit_curve, ~, ~] = fit((1:decay_duration)', event_decay, 'exp1');
    catch
        keyboard
    end
    exp_fit_coeff_interval = confint(exp_fit_curve,0.95); % get the 95% confidence interval extremes for the exponential fit.
    exp_decay_rate = (exp_fit_coeff_interval(1, 2) + exp_fit_coeff_interval(2, 2))/2; % get the decay constant
    exp_decay_multiplier = (exp_fit_coeff_interval(1, 1) + exp_fit_coeff_interval(2, 1))/2;
    exp_decay_rate = - exp_decay_rate;
    exp_decay_rate = exp_decay_rate/FrameRate;
else
    exp_decay_rate = NaN;
    exp_decay_multiplier = NaN;
    exp_fit_coeff_interval = NaN;
    exp_fit_curve = NaN;
end