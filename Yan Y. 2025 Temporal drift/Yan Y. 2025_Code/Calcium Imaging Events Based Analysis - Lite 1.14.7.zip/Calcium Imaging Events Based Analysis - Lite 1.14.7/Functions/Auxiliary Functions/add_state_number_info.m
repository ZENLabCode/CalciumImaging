function Events_AllMice = add_state_number_info (Events_AllMice, Mouse_Analysis, Mouse_Names)
% This function includes the field "StateNumber" in the variable
% "Events_AllMice", to keep track of to which specific state 
% (in the same recording) an event belongs to.

n_events = numel(Events_AllMice);
n_mice = numel(Mouse_Analysis);
for i_mouse = 1:n_mice
    tmp_MouseName = Mouse_Names{i_mouse};
    tmp_States_Analysis = Mouse_Analysis(i_mouse).States_Analysis;
    tmp_States_StartEnd = [tmp_States_Analysis.StartEnd];
    current_States_StartEnd(1:numel(tmp_States_StartEnd)/2, 1) = tmp_States_StartEnd(1:2:end);
    current_States_StartEnd(1:numel(tmp_States_StartEnd)/2, 2) = tmp_States_StartEnd(2:2:end);
    [n_states, ~] = size(current_States_StartEnd);
    % Scroll Events
    for i_event = 1:n_events
        current_Event = Events_AllMice(i_event);
        % Get events from the current mouse only
        if strcmpi(current_Event.MouseTag, tmp_MouseName) == 1
            % Scroll States
            for i_state = 1:n_states
                % Assign the current event to its corresponding state.
                if current_Event.Start >= current_States_StartEnd(i_state, 1) && current_Event.Start <= current_States_StartEnd(i_state, 2)
                    Events_AllMice(i_event).StateNumber = i_state;
                    break
                end
            end
        end
        
    end
    
    
end