function [CohenD, CohenD_unbiased, Hedge_G] = Effect_Size (dist1, dist2)
% This function computes several measures of effect power.
% Cohen's D, Cohen's D unbiased, Hedge's G.
% NaN values will be ignored in the computation.
% See:
%   https://en.wikipedia.org/wiki/Effect_size
%   https://www.polyu.edu.hk/mm/effectsizefaqs/effect_size_equations2.html

% Basic Quantites
n1 = numel(dist1);
n2 = numel(dist2);
std1 = nanstd(dist1);
std2 = nanstd(dist2);
mean1 = nanmean(dist1);
mean2 = nanmean(dist2);

% Pooled Standard Deviations.
SD_Pooled = sqrt( (std1^2 + std2^2)/2 );
SD_Pooled_Weighted = sqrt( ((n1-1)*std1^2 + (n2-1)*std2^2)./(n1 + n2 - 2) );

% Cohen's D
CohenD = (mean1 - mean2)/SD_Pooled;

% Cohen's D Unbiased (see Hedges and Olkin (1985, p.81))
UnBias_Factor = 1 - 3/((4*(n1 + n2)) - 9);
CohenD_unbiased = CohenD * UnBias_Factor;

% Hedge's G
Hedge_G = (mean1 - mean2)/SD_Pooled_Weighted;