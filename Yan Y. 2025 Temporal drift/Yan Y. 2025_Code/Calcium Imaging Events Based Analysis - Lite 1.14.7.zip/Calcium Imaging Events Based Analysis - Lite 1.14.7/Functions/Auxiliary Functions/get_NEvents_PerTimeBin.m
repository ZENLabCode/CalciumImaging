function [N_Events_perBin, N_Events_perBinStats, Event_N_perState, Event_N_perStateStats] = get_NEvents_PerTimeBin (Lag_per_State, MouseState_Matrix, StateLength_min, Opts)
% This function is intended as a sub-function to Sync2StateChange. It gets
% the number of events that fall into a certain time bin of the lags after
% a state change.


bins_number = Opts.Sync.NLagBins;
bins_max = StateLength_min/Opts.General.FrameRate; % [s]
bins_duration = bins_max/bins_number; % [s]

[LagsDim1, LagsDim2] = size(Lag_per_State);
for i_bin = 1:bins_number
    tmp_Lag_per_State_Bin = NaN(LagsDim1, LagsDim2);
    for i_state = 1:LagsDim1
        tmp_Lag_per_State = Lag_per_State(i_state, :);
        tmp1 = tmp_Lag_per_State(tmp_Lag_per_State < ((i_bin)*bins_duration));
        tmp2 = tmp1(tmp1 >= ((i_bin-1)*bins_duration));
        N_Events_perBin(i_state, i_bin) = numel(tmp2);
    end
end
N_Events_perBinStats.Mean = nanmean(N_Events_perBin, 1);
N_Events_perBinStats.StE = nanstd(N_Events_perBin, 0, 1)/sqrt(LagsDim1);
% Events per State
Event_N_perState = nansum(N_Events_perBin, 2);
Event_N_perStateStats.Mean = nanmean(Event_N_perState);
Event_N_perStateStats.Std = nanstd(Event_N_perState);
Event_N_perStateStats.StE = nanstd(Event_N_perState)/sqrt(numel(Event_N_perState));
% Event_N_perStateStats.Thr = ceil(Event_N_perStateStats.Mean - Event_N_perStateStats.Std);
Event_N_perStateStats.Thr = ceil((Event_N_perStateStats.Mean - Event_N_perStateStats.Std)/2);
if Event_N_perStateStats.Thr < 1
    Event_N_perStateStats.Thr = 1;
end

% Normalization 1: divide by the total number of events (counting all states of the same type, in all mice)
N_Events_perBinStats.Mean_Norm_1 = N_Events_perBinStats.Mean/nansum(nansum(N_Events_perBin));
N_Events_perBinStats.StE_Norm_1 = N_Events_perBinStats.StE/nansum(nansum(N_Events_perBin));

% Normalization 2: divide each state separately by its total number of
% events in each bin.
N_Events_perBinStats.Mean_Norm_2 = nanmean(N_Events_perBin./Event_N_perState, 1);
N_Events_perBinStats.StE_Norm_2 = nanstd(N_Events_perBin./Event_N_perState, 0, 1)/sqrt(LagsDim1);

% Normalization 3: divide each state by the number of cells of each mouse.

tmp_norm3 = NaN(LagsDim1, bins_number);
for i_bin = 1:bins_number
    tmp_norm3(:, i_bin) = N_Events_perBin(:, i_bin)./(MouseState_Matrix(2, :)');
end

N_Events_perBinStats.Mean_Norm_3 = nanmean(tmp_norm3, 1);
N_Events_perBinStats.StE_Norm_3 = nanstd(tmp_norm3, 0, 1)/sqrt(LagsDim1);

