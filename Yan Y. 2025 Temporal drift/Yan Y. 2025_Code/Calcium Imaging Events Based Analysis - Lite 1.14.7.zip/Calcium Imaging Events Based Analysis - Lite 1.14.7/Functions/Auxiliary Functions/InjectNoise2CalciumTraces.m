function CalciumTraces_Noisy = InjectNoise2CalciumTraces (CalciumTraces)
% Adds white noise of specified interest to the Calcium Traces.

% Reset random number generator.
rng default

NoiseLevel = 1;

[n_timepoints, n_traces] = size(CalciumTraces);

% Estimate Signal Noise
for i_trace = 1:n_traces
    [tmp_noise_estimate(i_trace), ~, ~] = estimate_noise (CalciumTraces(:, i_trace), 1); % Use 1 estimation step.
end
CalciumTraces_MeanStd = nanmean(tmp_noise_estimate);

% Generate a noise signal for each trace.
WhiteNoise = normrnd(0, CalciumTraces_MeanStd, n_timepoints, n_traces);

% Add noise to traces.
CalciumTraces_Noisy = CalciumTraces + WhiteNoise;
for i_trace = 1:n_traces
    WhiteNoise = normrnd(0, CalciumTraces_MeanStd, n_timepoints, n_traces);

end