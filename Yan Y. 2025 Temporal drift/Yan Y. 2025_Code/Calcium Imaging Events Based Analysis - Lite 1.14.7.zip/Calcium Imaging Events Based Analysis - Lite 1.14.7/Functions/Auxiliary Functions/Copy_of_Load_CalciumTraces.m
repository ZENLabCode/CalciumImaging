function CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session)
% This function loads the calcium traces of a single mouse recordings, as
% present in the Data Directory "Dir_Data" and subdirectories "MouseName"
% and "session".

% Possible FileName1
FileName1 = 'dFFnormalized.mat';

% Check folder existence.
recordings_folder = sprintf('%s\\%s\\session_%d', Dir_Data, MouseName, i_session);
if exist(recordings_folder, 'dir') ~= 0
    file_dFF_FullPath = sprintf('%s\\%s', recordings_folder, FileName1);
    if exist(file_dFF_FullPath, 'file') == 0
        file_dFF_FullPath = sprintf('%s\\%s', recordings_folder, FileName1);
        if exist(file_dFF_FullPath, 'file') ~= 0
            warning('Please remove the space in %s into "%s"', file_dFF_FullPath, FileName1)
        end
    end
else
    warning('Folder "%s" does not exist.', recordings_folder)
end
% If file exists, load it.
if exist(file_dFF_FullPath, 'file') == 2 
    tmp_data_struct = load(file_dFF_FullPath);
    % Convert into standard name.
    tmp_var_1 = struct2cell(tmp_data_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    CalciumTraces = tmp_var_2;
else
    error('Missing "%s" file in folder: %s', FileName1, recordings_folder)
end