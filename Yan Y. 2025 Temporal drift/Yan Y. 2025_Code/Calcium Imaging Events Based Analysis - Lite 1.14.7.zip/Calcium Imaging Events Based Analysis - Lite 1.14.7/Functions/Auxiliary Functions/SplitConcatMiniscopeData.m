function SplitConcatMiniscopeData (CalciumTraces, Hypnogram, SessionStarts, n_sessions, MouseName, Opts)
% This function splits the data present in a single calcium imaging trace
% into several different traces, each one being a single recording session.
% It then saves each session into its own subfolder+file structure, moving
% and renaming (if necessary) the single concatenated file from the
% session_1 subfolder, to the main mouse folder.

% N Sessions of Recordings is to be given


%% Initialize
% Slide the array to Matlab array format (starting from 1 instead of 0)
if SessionStarts(1) == 0
    SessionStarts = SessionStarts + 1;
end

fprintf('\nSplitting Sessions for Mouse %s...\n', MouseName);


%% Split
% Check for the presence of data.
CurrentMouseFolder = sprintf('%s\\%s', Opts.Dir_Data, MouseName);
if exist(CurrentMouseFolder, 'dir') == 0
    error ('Can not find data folder "%s"', CurrentMouseFolder)
end
cd(CurrentMouseFolder)
SubFoldersList = dir;
cd(Opts.Dir_Main)

SubFoldersList(1:2) = []; % Remove "." and ".." elements
SubFoldersList([SubFoldersList.isdir] == 0) = []; % Remove non-folder elements
n_sessionfolders = numel(SubFoldersList);
if n_sessionfolders == 0
    warning('Mouse %s has no data.', MouseName);
    return
end
% .. check that it is actually needed to split the data
if n_sessionfolders == n_sessions
   fprintf('Data already split for mouse %s.\n', MouseName)
   return
end

% Split the data.
CalciumTraces_tmp = cell(1, n_sessions);
Hypnogram_tmp = cell(1, n_sessions);
for i_session = 1:n_sessions
    tmp_Start = SessionStarts(i_session);
    tmp_End = SessionStarts(i_session + 1) - 1;
    CalciumTraces_tmp{i_session} = CalciumTraces(tmp_Start:tmp_End, :);
    Hypnogram_tmp{i_session} = Hypnogram(tmp_Start:tmp_End);
end

% Create folders and files.
for i_session = 1:n_sessions
    % Prepare strings
    session_path = sprintf('%s\\session_%d', CurrentMouseFolder, i_session);
    filename_calcium = sprintf('%s\\dFF_%s_s%d.mat', session_path, MouseName, i_session);
    filename_ephys = sprintf('%s\\EPhys_%s_s%d.mat', session_path, MouseName, i_session);
    if i_session == 1 % Move the concatenated files to the main mouse folder.
        tmp_filename_concatCalcium = sprintf('%s\\concat_%s_DataParam.mat', session_path, MouseName);
        tmp_filename_concatEPhys = sprintf('%s\\fusedData.mat', session_path);
        if exist (tmp_filename_concatCalcium, 'file') ~= 0
            movefile(tmp_filename_concatCalcium, CurrentMouseFolder)
        end
        if exist (tmp_filename_concatEPhys, 'file') ~= 0
            movefile(tmp_filename_concatEPhys, CurrentMouseFolder)
        end
    end
    
    % Reset original data structure.
    DataParam.dataArrayEnv = CalciumTraces_tmp{i_session};
    DataParam.sessionStarts = SessionStarts;
    fusedData.Hypnogram = Hypnogram_tmp{i_session};
    if exist(session_path, 'dir') == 0
        mkdir(session_path)
        addpath(genpath(session_path));
    end
    if (exist(filename_calcium, 'file') == 0) && (exist(filename_calcium, 'file') == 0)
        save(filename_calcium, 'DataParam');
        save(filename_ephys, 'fusedData');
    end
    clear DataParam; clear fusedData
end

fprintf('Finish splitting data for mouse %s.\n', MouseName)
