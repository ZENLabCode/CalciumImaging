function [PowerSpectrum, frequencies] = power_spectrum (trace, SamplingFrequency)
% Computes the power spectrum of a trace, given the trace and sampling freq

if nargin < 2
    SamplingFrequency = 300; % Sampling frequency (3Hz* (1/0.01 Interpolation) is standard for Mattia recordings                   
end
T = 1/SamplingFrequency;             % Sampling period
L = numel(trace);     % Length of signal

trace_FT = fft(trace);

P2 = abs(trace_FT/L);
PowerSpectrum = P2(1:L/2+1);
PowerSpectrum(2:end-1) = 2*PowerSpectrum(2:end-1);

frequencies = SamplingFrequency*(0:(L/2))/L;

figure();
plot(frequencies, PowerSpectrum) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')