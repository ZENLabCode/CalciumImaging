function [CalciumTraces, EMG, Artifacts_Trace] = EMG_filtering (CalciumTraces, Hypnogram, resampled_data_mV, SampRate, Opts)
% This function applies a simple threshold of "thr_multiplier" to the EMG
% signal to detect frames that are to exclude due to likely strong
% movement artifacts.

thr_multiplier = 6;
noise_estimation_steps = 2;

% Resample the EMG to match the CalciumImaging FrameRate
EMG = resample(resampled_data_mV, Opts.General.FrameRate, SampRate);

% if Opts.
% Cut the first 10 seconds
EMG = EMG(10*Opts.General.FrameRate:end); 

% Cut the last part of the EMG to match the Hypnogram
EMG = EMG(1:numel(Hypnogram));

% Get the movement artifact threshold
[std_estimate, median_estimate, ~] = estimate_noise (EMG, noise_estimation_steps);

threshold = median_estimate + thr_multiplier*std_estimate;

% Set the correstponding movement frames to NaN

EMG_Binary = abs(EMG);
EMG_Binary(EMG_Binary < threshold) = 0;
EMG_Binary(EMG_Binary >= threshold) = 1;

[C_Dim1, C_Dim2] = size(CalciumTraces);

for i = 1:C_Dim2
    tmp = CalciumTraces(:, i);
    tmp(EMG_Binary == 1, :) = NaN;
    CalciumTraces(:, i) = tmp;
end

Artifacts_Trace = EMG_Binary;