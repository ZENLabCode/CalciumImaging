function [Events_perMouse] = get_EventsPerMouse (Events, Mouse_Names)
% This function returns the Events separated per Mouse in a cell
% "Events_perMouse"


Events_perMouse = cell(1, numel(Mouse_Names));
for i_mouse = 1:numel(Mouse_Names)
    MouseName = Mouse_Names{i_mouse};
    indexes_to_remove = NaN;
    i_remove = 1;
    for i_event = 1:numel(Events)
        if strcmpi(Events(i_event).MouseTag, MouseName) ~= 1
            indexes_to_remove(i_remove) = i_event; % Find events not belonging to this mouse and add them to the removal list
            i_remove = i_remove + 1;
        end
    end
    tmp = Events;
    tmp(indexes_to_remove) = [];
    Events_perMouse{i_mouse} = tmp;
end