function trace_tmp = NaN_to_NeighbourhoodMean(trace)
% Set NaNs in a singal to the Mean of their first left-right neighbours.

n_datapoints = numel(trace);

trace_tmp = trace;
for i_t = 1:n_datapoints
    if isnan(trace(i_t))
        % Find closest neighbours.
        for Neigh_left = i_t:-1:1
            if ~isnan(trace(Neigh_left))
                break
            end
        end
        for Neigh_right = i_t:-1:1
            if ~isnan(trace(Neigh_right))
                break
            end
        end
        % Substitute NaN with neighbours mean.
        trace_tmp(i_t) = nanmean([trace(Neigh_left), trace(Neigh_right)]);
    end
end