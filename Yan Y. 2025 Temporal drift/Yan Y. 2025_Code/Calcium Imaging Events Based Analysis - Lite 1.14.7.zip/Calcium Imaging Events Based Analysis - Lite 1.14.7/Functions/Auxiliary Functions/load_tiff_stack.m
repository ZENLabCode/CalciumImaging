function [images_stack, images_info] = load_tiff_stack (FileName, FilePath)
% Use to load an entire stack from a single tif file.

% INPUT: 
%   - file_name: the file name of the stack to load in the workspace
% OUTPUT:
%   - image_stack: the loaded tiff stack; 
%   - img_stack_projection: the selected projection of the image stack
%   - img_stack_proj_info: a struct containing the info on the projections

if isempty(FileName) || isempty(FilePath)
    [FileName, FilePath] = uigetfile('*.tif*', pwd);
end

% Save Projetion automatically?
FLAG_SaveOutput = 1;

FileFullPath = [FilePath, '\', FileName];

disp(strcat(FileName, ' was selected.'));
fprintf('...\n...\nLoading tif stack in MATLAB, please wait...\n...\n');
images_info = imfinfo(FileFullPath);
images_width = images_info(1).Width;
images_height = images_info(1).Height;
images_number = numel(images_info);
images_stack = zeros(images_height, images_width, images_number, 'uint16');

pause (0.25);

TifLink = Tiff(FileFullPath, 'r');
for i_image=1:images_number
    TifLink.setDirectory(i_image);
    images_stack(:,:,i_image)=TifLink.read();
end

TifLink.close();
fprintf('File loaded in the Workspace.\n\n');

% Compute projection
ProjectionType = 'std';
[img_stack_projection, img_stack_projection_info] = compute_img_stack_projection(images_stack, ProjectionType); 

if FLAG_SaveOutput == 1
   save(sprintf('StackProjection_%s.mat', ProjectionType), 'img_stack_projection') 
end

end