function SessionHasState = SessionsCheckStates (Hypnogram_AllMice, Opts)
% This function checks which states are present in a certain recording
% session, according to the Hypnogram.
% The output describes both the states in general, and the stable states
% only (check set_options to see the threshold for a state to be stable)


n_sessions = numel(Hypnogram_AllMice);

% Check which recordings have a specific state.

for i_session = 1:n_sessions
    current_hypnogram = Hypnogram_AllMice(i_session).Hypnogram;
    current_StateDurationArray = Hypnogram_AllMice(i_session).StateDuration_Array;
    % Check present states
    if numel(current_hypnogram(current_hypnogram == 1)) > 0
        SessionHasState(i_session).Awake = 1;
    else
        SessionHasState(i_session).Awake = 0;
    end
    if numel(current_hypnogram(current_hypnogram == 2)) > 0
        SessionHasState(i_session).NoNREM = 1;
    else
        SessionHasState(i_session).NoNREM = 0;
    end
    if numel(current_hypnogram(current_hypnogram == 4)) > 0
        SessionHasState(i_session).REM = 1;
    else
        SessionHasState(i_session).REM = 0;
    end
    % Check presence of stable states
    if numel(current_hypnogram(current_hypnogram == 1)) > 0 && nanmax(current_StateDurationArray(current_hypnogram == 1)) > Opts.General.MinStableStateDuration
        SessionHasState(i_session).Stable_Awake = 1;
    else
        SessionHasState(i_session).Stable_Awake = 0;
    end
    if numel(current_hypnogram(current_hypnogram == 2)) > 0 && nanmax(current_StateDurationArray(current_hypnogram == 2)) > Opts.General.MinStableStateDuration
        SessionHasState(i_session).Stable_NoNREM = 1;
    else
        SessionHasState(i_session).Stable_NoNREM = 0;
    end
    if numel(current_hypnogram(current_hypnogram == 4)) > 0 && nanmax(current_StateDurationArray(current_hypnogram == 4)) > Opts.General.MinStableStateDuration
        SessionHasState(i_session).Stable_REM = 1;
    else
        SessionHasState(i_session).Stable_REM = 0;
    end
end