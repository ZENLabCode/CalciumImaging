function [CalciumTraces, Hypnogram, EEG1, EMG, TTL, SessionStarts] = Load_MiniscopeData (MouseName, Dir_Data, Dir_Main, i_session)
% This function loads the calcium traces of a single mouse recordings, as
% present in the Data Directory "Dir_Data" and subdirectories "MouseName"
% and "session". Function written specifically for astrocyte data, assuming
% that the files are named as "concat_<MouseName>_DataParam.mat" for the
% Calcium Data, and "fusedData.mat" for the EEG-EMG-TTL data.


% Check folder & files existence.
MouseFolder = sprintf('%s\\%s', Dir_Data, MouseName);
recordings_folder = sprintf('%s\\%s\\session_%d', Dir_Data, MouseName, i_session);
if exist(recordings_folder, 'dir') ~= 0
    cd (recordings_folder);
    tmp_files = dir('*.mat');
    cd(Dir_Main);
    n_files = numel(tmp_files);
    if n_files == 1
        FLAG_SingleFile = 1;
    else
        FLAG_SingleFile = 0;
    end
    % Automatically finds the correct filename to variable correspondence
    tmp_Name = strsplit(tmp_files(1).name, '.'); % Remove the file extention
    tmp_Name(strcmpi(tmp_Name, 'mat')) = []; % Remove the file extention
    tmp_Name = tmp_Name{1}; % Cell to string (the cell content)
    tmp_Name = strsplit(tmp_Name, '_'); % Split the FileName
    if nansum(strcmpi(tmp_Name, 'dFF')) == 1 || nansum(strcmpi(tmp_Name, 'DataParam')) == 1 % If file 1 contains the strings "dFF" or "DataParam", that's the Calcium Imaging file, otherwise it's the other one
        tmp_FileName_DFF = tmp_files(1).name;
        if FLAG_SingleFile == 0 % There is also the case where all is in the same file...
            tmp_FileName_EEG = tmp_files(2).name;
        end
    else 
        tmp_FileName_DFF = tmp_files(2).name;
        tmp_FileName_EEG = tmp_files(1).name;
    end
    file_DFF_FullPath = sprintf('%s\\%s', recordings_folder, tmp_FileName_DFF);
    if FLAG_SingleFile == 0
        file_EEG_FullPath = sprintf('%s\\%s', recordings_folder, tmp_FileName_EEG);
    end
    
    % Load DFF file, if exist
    if exist(file_DFF_FullPath, 'file') == 0
        error('Could not find file "%s" in folder "%s".', tmp_FileName_DFF, recordings_folder)
    else
        tmp_data_struct = load(file_DFF_FullPath);
        % Convert into standard name.
        tmp_var_1 = struct2cell(tmp_data_struct);
        tmp_var_2 = tmp_var_1{1, 1};
        
        CalciumTraces = tmp_var_2.dataArrayEnv;
        SessionStarts = tmp_var_2.sessionStarts;
        if isfield(tmp_var_2, 'Hypnogram')
            Hypnogram = tmp_var_2.Hypnogram;
        end
        if isfield(tmp_var_2, 'EphysData')
            try  % Temporary measure, as the EEG is not included in the analysis atm
                EphysData = tmp_var_2.EphysData;
                EEG1 = EphysData(:, 1);
                EMG = EphysData(:, 2);
                TTL = EphysData(:, 3);
            catch
                EEG1 = [];
                EMG = [];
                TTL = [];
            end
        end
        if isfield(tmp_var_2, 'neuronShapes')
            save_ROIs(tmp_var_2, MouseFolder)
        end
        clear tmp_data_struct; clear tmp_var_1; clear tmp_var_2;
    end
    
    % Load EEG file, if exist
    if FLAG_SingleFile == 0
        if exist(file_EEG_FullPath, 'file') == 0
            error('Could not find file "%s" in folder "%s".', tmp_FileName_EEG, recordings_folder)
        else
            if FLAG_SingleFile == 0
                tmp_data_struct = load(file_EEG_FullPath);
                % Convert into standard name.
                tmp_var_1 = struct2cell(tmp_data_struct);
                tmp_var_2 = tmp_var_1{1, 1};
                Hypnogram = tmp_var_2.Hypnogram;
                try % Temporary measure, as the EEG is not included in the analysis atm
                    EphysData = tmp_var_2.EphysData;
                    EEG1 = EphysData(:, 1);
                    EMG = EphysData(:, 2);
                    TTL = EphysData(:, 3);
                catch
                    EEG1 = [];
                    EMG = [];
                    TTL = [];
                end
                clear tmp_data_struct; clear tmp_var_1; clear tmp_var_2;
            end
        end
    end
    % Standardise Hypnogram dimensions.
    [dim1, dim2] = size(Hypnogram);
    if dim1 > 1 && dim2 == 1
        Hypnogram = Hypnogram';
    end
else
    error('Folder "%s" does not exist.', recordings_folder)
end