function fix_hypnogram_integers(Hypnogram_AllSessions)
% This function fixes the 3s that are sometimes near the REM state

segment_length = 10;

n_sessions = numel(Hypnogram_AllSessions);
for i_session = 1:n_sessions
    current_hypno = Hypnogram_AllSessions(i_session).Hypnogram;
    three_indexes = find(current_hypno == 3);
    if three_indexes > 0
        for i = 1:three_indexes
            three_indexes_postsegment = (three_indexes(i)):(three_indexes(i)+segment_length);
            three_indexes_presegment = ((three_indexes(i)-segment_length):three_indexes(i));
            postsegment = current_hypno(three_indexes_postsegment);
            presegment = current_hypno(three_indexes_presegment);
            if numel(find(postsegment == 4)) > 0
                three_indexes(i) = 2;
            elseif numel(find(presegment == 4)) > 0
                three_indexes(i) = 1;
            end
        end
    end
end