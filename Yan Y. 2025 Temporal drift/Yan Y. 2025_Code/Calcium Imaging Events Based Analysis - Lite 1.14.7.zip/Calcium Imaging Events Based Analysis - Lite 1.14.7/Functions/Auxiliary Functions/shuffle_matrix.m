function ShuffledMatrix = shuffle_matrix(Matrix2Shuffle, dimension2shuffle)
% This function shuffles the input matrix on either the 1st or 2nd
% dimension (rows or columns).
% Dim 1 would shuffle 1 1 2 2 into  1 2 2 1
%                     3 3 4 4       4 3 4 3
%                     5 5 6 6       6 6 5 5


[n_rows, n_columns] = size(Matrix2Shuffle);

if dimension2shuffle == 1
    % Preserve the row indices
    rowIndex = repmat((1:n_rows)', [1 n_columns]);
    % Get randomized column indices by sorting a second random array
    [~, randomizedColIndex] = sort(rand(n_rows, n_columns), 2);
    % Need to use linear indexing to create the shuffled matrix
    newLinearIndex = sub2ind([n_rows,n_columns],rowIndex,randomizedColIndex);
    ShuffledMatrix = Matrix2Shuffle(newLinearIndex);
elseif dimension2shuffle == 2
    Matrix2Shuffle = Matrix2Shuffle';
    [n_rows, n_columns] = size(Matrix2Shuffle);
    % Preserve the row indices
    rowIndex = repmat((1:n_rows)', [1 n_columns]);
    % Get randomized column indices by sorting a second random array
    [~, randomizedColIndex] = sort(rand(n_rows, n_columns), 2);
    % Need to use linear indexing to create the shuffled matrix
    newLinearIndex = sub2ind([n_rows,n_columns],rowIndex,randomizedColIndex);
    ShuffledMatrix = Matrix2Shuffle(newLinearIndex);
    ShuffledMatrix = ShuffledMatrix';
end