function Events = separate_events_per_state (Events, Ns)
% This function returns only the events which belong to the state with
% number "Ns"

n_events = numel(Events);
Events_to_remove = [];
i_remove = 0;
for i_event = 1:n_events
    current_event = Events(i_event);
    if isfield(current_event, 'StateNumber')
        
        if current_event.StateNumber ~= Ns
            i_remove = i_remove + 1;
            Events_to_remove(i_remove) = i_event;
        end
    elseif isfield(current_event, 'StateTag')
        if current_event.StateTag ~= Ns
            i_remove = i_remove + 1;
            Events_to_remove(i_remove) = i_event;
        end
    else
        error('Missing field that indicates to which state an events belogs to')
    end
    clear current_event
end

if ~isempty(Events_to_remove)
    Events(Events_to_remove) = [];
end

