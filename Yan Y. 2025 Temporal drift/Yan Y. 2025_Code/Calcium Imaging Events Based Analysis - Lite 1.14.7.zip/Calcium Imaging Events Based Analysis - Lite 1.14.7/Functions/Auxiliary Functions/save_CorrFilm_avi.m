function save_CorrFilm_avi (correlation_film, Hypnogram_CurrentMouse, video_name)
% This function saves the correlation film in avi format for a single mouse
% recordings.

fprintf ('\nWriting output as .avi film...\n...\n');


%% Options.
Title_FontSize = 16;
Title_FontWeight = 'bold';
Title_FontColor = 'k';
Film_FrameRate = 10;

video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'

[~, ~, n_time_points] = size(correlation_film);


%% Initialize and open video object.
analysed_colour_video_obj = VideoWriter(video_name, video_profile);
analysed_colour_video_obj.FrameRate = Film_FrameRate;
open(analysed_colour_video_obj);
fig_tmp = figure;


%% Write Video.
for i_time = 1:n_time_points
    if rem(i_time, 10) == 0
        fprintf('Saving Frame #%d/%d\n', i_time, n_time_points)
    end
    if isnan(nanmean(nanmean(correlation_film(:, :, i_time))))
        str_title = 'State: ---';
        Title_FontColor = 'k';
    else
        switch Hypnogram_CurrentMouse(i_time)
            case 1
                str_title = 'State: Awake';
                Title_FontColor = 'b';
            case 2
                str_title = 'State: Non-REM';
                Title_FontColor = 'r';
            case 4
                str_title = 'State: REM';
                Title_FontColor = 'g';
        end
    end
    h = pcolor(correlation_film(:, :, i_time));
    view(2);
    colorbar;
    caxis([-1, 1]);
    axis tight;
    title(str_title, 'FontSize', Title_FontSize, 'FontWeight', Title_FontWeight, 'Color', Title_FontColor)
    
    %     set(gcf,'PaperPositionMode','auto')
    frame = getframe(fig_tmp);
    writeVideo(analysed_colour_video_obj, frame);
end


close(analysed_colour_video_obj);
close % Close the figure used to produce the film.

fprintf('\nFilm saved successfully in .avi format.\n\n')
