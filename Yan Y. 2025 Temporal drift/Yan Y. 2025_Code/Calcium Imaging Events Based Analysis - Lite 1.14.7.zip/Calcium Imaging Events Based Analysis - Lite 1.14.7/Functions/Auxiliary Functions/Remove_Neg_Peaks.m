function trace_clean = Remove_Neg_Peaks (trace_unclean, Neg_Peaks, FLAG_display)
% This function substitutes segments of NaNs to the negative peaks, in the
% selected trace.

n_peaks = numel(Neg_Peaks);

trace_clean = trace_unclean;

if (~isfield(Neg_Peaks, 'Start') && ~isfield(Neg_Peaks, 'End')) || n_peaks == 0
    Neg_Peaks = [];
    return
end

for i_peak = 1:n_peaks
    NegStart = Neg_Peaks(i_peak).Start;
    NegEnd = Neg_Peaks(i_peak).End;
    trace_clean(NegStart:NegEnd) = NaN(NegEnd-NegStart+1, 1);
end

if FLAG_display == 1
    figure(); hold on;
    plot(trace_unclean, '--r', 'LineWidth', 1);
    plot(trace_clean, 'b', 'LineWidth', 1);
    axis tight; box on; grid on;
    xlabel('Frames'); ylabel('\DeltaF/F');
    legend({'Unclean Trace', 'Clean Trace'});
end