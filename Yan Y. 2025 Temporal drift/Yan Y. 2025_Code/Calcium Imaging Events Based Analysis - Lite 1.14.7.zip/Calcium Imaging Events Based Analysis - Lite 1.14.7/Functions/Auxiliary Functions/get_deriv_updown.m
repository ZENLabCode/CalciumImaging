function diff_binary = get_deriv_updown(trace_interp, trace_diff, Opts)

% This function does the following:
% 1) estimates the noise from the signal derivative.
% 2) sets to zero the points that are under +- the noise level.
% 3) gets the limits (start/end points) of the positive and negative areas.
%   3a) for an event to end, a rise fase must be accompanied by a decay.
%   3b) if an event ends before the raw trace goes back to baseline value,
%       it is a complex event

min_length = (0.2*Opts.FrameRate)/Opts.Interp_step;
min_length_zero = (0.1*Opts.FrameRate)/Opts.Interp_step;

% Estimate Noise.
Opts.noise_estimation_steps = 1;
[noise_estimate, ~, ~] = estimate_noise (trace_diff, Opts.noise_estimation_steps);
noise_estimate = noise_estimate/2;

% Set Noise to flat zero
trace_diff_flattened = trace_diff;
trace_diff_flattened(abs(trace_diff) < noise_estimate) = 0;

% Make signal binary
diff_binary = (trace_diff_flattened);
diff_binary(diff_binary ~= 0) = 1;
diff_binary(isnan(trace_diff_flattened)) = NaN;

%% Improve detection signal continuity
% Remove rises/decays that are too short 
% (short = 0.2 seconds = 0.2*FrameRate/interpolation)
i_1 = 1;
% Scroll values
while i_1 < numel(diff_binary)
    if isnan(diff_binary(i_1)) || diff_binary(i_1) == 0
       i_1 = i_1 + 1;
       continue
    end
    % Till you find a 1: then
    if diff_binary(i_1) == 1
        RD_start = i_1; % RD stands for Rise/Decay
        % Start counting
        i_length = 1;
        while i_length < numel(diff_binary) - i_1
            if diff_binary(i_1 + i_length) == 1
                i_length = i_length + 1;
                continue
            else
                break
            end
        end
        RD_end = i_1 + i_length;
        i_1 = RD_end + 1;
    end
    % Check if the rise/decay is long enough
    if i_length < min_length
        diff_binary(RD_start:RD_end) = 0;
    end
end
diff_binary(trace_diff_flattened < 0) = diff_binary(trace_diff_flattened < 0)*(-1);

% Include very short derivative = 0 areas into contiguous +1 or -1 segments
i_1 = 1;
% Scroll values
while i_1 < numel(diff_binary)
    if isnan(diff_binary(i_1)) || diff_binary(i_1) ~= 0
       i_1 = i_1 + 1;
       continue
    end
    % Till you find a 0: then
    if diff_binary(i_1) == 0
        zero_start = i_1; % RD stands for Rise/Decay
        % Start counting
        i_length = 1;
        while i_length < numel(diff_binary) - i_1
            if diff_binary(i_1 + i_length) == 0
                i_length = i_length + 1;
                continue
            else
                break
            end
        end
        zero_end = i_1 + i_length;
        i_1 = zero_end + 1;
    end
    % Check if the rise/decay is long enough AND if what comes before and
    % after has the same sign
    if i_length < min_length_zero
        if zero_start - 1 > 0 && zero_end + 1 < numel(diff_binary)
            if (diff_binary(zero_start - 1) == 1 && diff_binary(zero_end + 1) == 1) || (diff_binary(zero_start - 1) == -1 && diff_binary(zero_end + 1) == -1)
                diff_binary(zero_start:zero_end) = diff_binary(zero_start - 1);
            end
        end
    end
end

