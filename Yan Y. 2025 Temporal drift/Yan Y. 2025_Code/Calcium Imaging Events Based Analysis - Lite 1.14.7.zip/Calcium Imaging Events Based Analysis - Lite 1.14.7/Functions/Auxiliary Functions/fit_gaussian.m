function [gauss_plot, gauss_fit_results, gauss_fit] = fit_gaussian (Data, bins_edges, FLAGs, options, fit_options)
% Fits a gaussian model to the data and plots it.
% FLAGs is a struct with 3 fields used to select the fit + plot needed: 
%   FLAGs.gaussian_model ('gauss2' or 'gauss1')
%   FLAGs.fit_G1 (1 or 2)
%   FLAGs.fit_G2 (1 or 2)

if isfield(options, 'FLAG_normalize') == 0
    options.FLAG_normalize = 0;
    options.normalization_k = 1;
end

[bin_counts, ~] = histcounts(Data, bins_edges);

if strcmpi(FLAGs.gaussian_model, 'gauss2')  % Fit 2 Gaussians.
    gauss_fit = fit((bins_edges(1:end-1))', bin_counts', 'gauss2');
    
    % Extract readable coefficients.
    gauss_fit_results.G1_mean = gauss_fit.b1;
    gauss_fit_results.G1_std = gauss_fit.c1;
    gauss_fit_results.G1_height = gauss_fit.a1;
    gauss_fit_results.G2_mean = gauss_fit.b2;
    gauss_fit_results.G2_std = gauss_fit.c2;
    gauss_fit_results.G2_height = gauss_fit.a2;
    
    % Add to plot
    hold on;
    % Plot G1
    if FLAGs.fit_G1 == 1
        G1 = exp( -((bins_edges(1:end-1) - gauss_fit_results.G1_mean).^2)./(2.*sqrt(2.*pi)) ) .* gauss_fit_results.G1_height;
        
        G1_plot = plot(bins_edges(1:end-1), G1, '--');
        G1_plot.LineWidth = 1; G1_plot.Color = [0.5, 0.5, 1];
    end
    % Plot G2
    if FLAGs.fit_G2 == 1
        G2 = exp( -((bins_edges(1:end-1) - gauss_fit_results.G2_mean).^2)./(2.*sqrt(2.*pi)) ) .* gauss_fit_results.G2_height;
        G2_plot = plot(bins_edges(1:end-1), G2, '--');
        G2_plot.LineWidth = 1; G2_plot.Color = [0.25, 0.25, 1];
    end
   
elseif strcmpi(FLAGs.gaussian_model, 'gauss1') || strcmpi(FLAGs.gaussian_model, 'gauss') % Fit 1 Gaussian.
    if nargin < 5
        gauss_fit = fit((bins_edges(1:end-1))', bin_counts', 'gauss1');
    else
        gauss_fit = fit((bins_edges(1:end-1))', bin_counts', 'gauss1', fit_options);
    end
    
    if options.FLAG_normalize == 1 % Normalize?
        gauss_fit.a1 = gauss_fit.a1 / options.normalization_k;
    end
    
    % Extract readable coefficients.
    gauss_fit_results.G1_mean = gauss_fit.b1;
    gauss_fit_results.G1_std = gauss_fit.c1;
    gauss_fit_results.G1_height = gauss_fit.a1;
    
% elseif strcmpi (FLAGs.gaussian_model, 'HalfNormal') % Fit a HalfNormal distribution
% %     % Gets the mean of the HalfNormal distribution to fit
% %     tmp_first_count = bin_counts'; 
% %     tmp_first_count(tmp_first_count == 0) = [];
% %     tmp_first_count = tmp_first_count(1);
%     % Fits the Distribution
%     bin_counts_clean = bin_counts(bin_counts ~= 0);
%     gauss_fit = fitdist(bin_counts_clean', 'HalfNormal');
%     gauss_fit_results.G1half_mean = 0;
%     gauss_fit_results.G1half_std = gauss_fit.sigma;
%     gauss_fit2 = pdf(gauss_fit, bins_edges(1:end-1)');
%     gauss_fit2 = (gauss_fit2./nanmax(gauss_fit2)).*nanmax(bin_counts);
end

% Plot G total
hold on;


gauss_plot = plot(gauss_fit, bins_edges(1:end-1)', bin_counts);
delete(gauss_plot(1))
gauss_plot = gauss_plot(2);
gauss_plot.LineWidth = 1.5;
gauss_plot.Color = options.Color;
