function trace_restored = Restore_NaNs_InterpSmooth (trace_interp, trace_nanless, interp_step)
% This function restores the NaNs lost in any interpolation or smoothing
% operation, present in the original input trace.
% The 3rd input is to be used in case the interpolation changed the
% sampling. In other words, "interp_step" is the ratio 
% original datapoints / interpolated datapoints .
% In case of simple smoothing, either set interp_step = 1;, or leave it
% blank

if nargin < 3 
   interp_step = 1; % Default, in case of smoothing.
end

n_datapoints = numel(trace_interp);

i_t = 1;
while i_t < n_datapoints
    if isnan(trace_interp(i_t))
        nanstart = i_t;
        for i_t2 = i_t:n_datapoints
            if ~isnan(trace_interp(i_t2))
                nanend = i_t2;
                break
            end
        end
%         fprintf('Segment from %d to %d\n', nanstart, nanend);
        trace_nanless(nanstart/interp_step:nanend/interp_step) = NaN(1, numel(nanstart/interp_step:nanend/interp_step));
        i_t = i_t2;
    end
    i_t = i_t + 1;
end

trace_restored = trace_nanless';