function save_ROIs(CalciumDataStruct, MouseFolder)
% This function saves the ROIs present in the DataParam type of variable,
% that is given as output from the data preprocessing, as an external file
% named "ROIs.mat", in the corresponding Mouse folder.

[dim1, dim2, n_cells] = size(CalciumDataStruct.neuronShapes);
ROIs = cell(1, n_cells);

for i_cell = 1:n_cells
    current_ROI = CalciumDataStruct.neuronShapes(:, :, i_cell);
    current_ROI(current_ROI > 0) = 1;
    ROIs{1, i_cell} = current_ROI;
end

% Save in file in current mouse folder.
FileFullPath = sprintf('%s\\ROIs.mat', MouseFolder);
save(FileFullPath, 'ROIs');

