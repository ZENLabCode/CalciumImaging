function plot_pie_v2(EventsSinglets, EventsComposite, HypnoState, Dir_Figures)
% This function plots the pie charts of the events distributions across the
% states.
% This version of the function plots Tonic and Complex events separately.

n_rows = 2;
n_columns = 3;

n_mice = numel(HypnoState);

% Get the total duration of sleep states.
for i_mouse = 1:numel(HypnoState)
    Duration_ToT_Awake(i_mouse) = HypnoState(i_mouse).Duration.Awake;
    Duration_ToT_NREM(i_mouse) = HypnoState(i_mouse).Duration.NoNREM;
    Duration_ToT_REM(i_mouse) = HypnoState(i_mouse).Duration.REM;
end
Duration_ToT_Awake = nansum(Duration_ToT_Awake);
Duration_ToT_NREM = nansum(Duration_ToT_NREM);
Duration_ToT_REM = nansum(Duration_ToT_REM);
DurationsNorm100 = Duration_ToT_Awake + Duration_ToT_NREM + Duration_ToT_REM;

% Get the number of events per sleep state.
StateTags_Singlets = [EventsSinglets.StateTag];
n_EventsSinglets_Awake = numel(StateTags_Singlets(StateTags_Singlets == 1));
n_EventsSinglets_NREM = numel(StateTags_Singlets(StateTags_Singlets == 2));
n_EventsSinglets_REM = numel(StateTags_Singlets(StateTags_Singlets == 4));

StateTags_Composites = [EventsComposite.StateTag];
n_EventsComposites_Awake = numel(StateTags_Composites(StateTags_Composites == 1));
n_EventsComposites_NREM = numel(StateTags_Composites(StateTags_Composites == 2));
n_EventsComposites_REM = numel(StateTags_Composites(StateTags_Composites == 4));


figure(); set(gcf,'position', get(0,'screensize'));

tmp_txt1 = sprintf('Awake:\n');
tmp_txt2 = sprintf('NREM:\n');
tmp_txt3 = sprintf('REM:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};


%% Plots - Singlet events
i_subplot = 1;
% SUBPLOT 1
subplot(n_rows, n_columns, i_subplot)
h_piechart = pie([Duration_ToT_Awake, Duration_ToT_NREM, Duration_ToT_REM]);
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
if numel(tmp_percentValues) < 3
    tmp_percentValues{3} = '0%'; % REM 0%
end
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues);

tmp_pText(1).String = sprintf('%s\n(%.f Seconds)', tmp_combinedtxt{1}, Duration_ToT_Awake);% tmp_combinedtxt(1);
tmp_pText(2).String = sprintf('%s\n(%.f Seconds)', tmp_combinedtxt{2}, Duration_ToT_NREM); % tmp_combinedtxt(2);
% keyboard
if numel(tmp_pText) >= 3
    tmp_pText(3).String = sprintf('%s\n(%.f Seconds)', tmp_combinedtxt{3}, Duration_ToT_REM); % tmp_combinedtxt(3);
end
h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
if numel(tmp_pText) >= 3
    h_piechart(5).FaceColor = [0, 1, 0];
end

title_str = sprintf('Composition of recordings\n(States cumulative duration)\nN = %d mice', n_mice);
title(title_str)
i_subplot = i_subplot + 1;

% SUBPLOT 2
subplot(n_rows, n_columns, i_subplot);
h_piechart = pie([n_EventsSinglets_Awake, n_EventsSinglets_NREM, n_EventsSinglets_REM]);
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
if numel(tmp_percentValues) < 3
    tmp_percentValues{3} = '0%'; % REM 0%
end
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{1}, n_EventsSinglets_Awake);% tmp_combinedtxt(1);
tmp_pText(2).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{2}, n_EventsSinglets_NREM); % tmp_combinedtxt(2);
if numel(tmp_pText) >= 3
    tmp_pText(3).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{3}, n_EventsSinglets_REM); % tmp_combinedtxt(3);
end
h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
if numel(tmp_pText) >= 3
    h_piechart(5).FaceColor = [0, 1, 0];
end

title_str = sprintf('Ca2+ Events in Sleep States\nSinglets');
title(title_str)
i_subplot = i_subplot + 1;

% SUBPLOT 3
subplot(n_rows, n_columns, i_subplot)
if Duration_ToT_REM == 0
    tmp_REM = 0;
else
    tmp_REM = n_EventsSinglets_REM/(Duration_ToT_REM/DurationsNorm100);
end
h_piechart = pie([n_EventsSinglets_Awake/(Duration_ToT_Awake/DurationsNorm100), n_EventsSinglets_NREM/(Duration_ToT_NREM/DurationsNorm100), tmp_REM]);
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
if numel(tmp_percentValues) < 3
    tmp_percentValues{3} = '0%'; % REM 0%
end
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
if numel(tmp_pText) >= 3
    tmp_pText(3).String = tmp_combinedtxt(3);
end
h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
if numel(tmp_pText) >= 3
    h_piechart(5).FaceColor = [0, 1, 0];
end

title_str = sprintf('Frequency of Ca2+ Events in Sleep States\nSinglets');
title(title_str)
i_subplot = i_subplot + 1;


%% Plots - Composite events
i_subplot = i_subplot + 1;
% SUBPLOT 5
subplot(n_rows, n_columns, i_subplot);
h_piechart = pie([n_EventsComposites_Awake, n_EventsComposites_NREM, n_EventsComposites_REM]);
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
if numel(tmp_percentValues) < 3
    tmp_percentValues{3} = '0%'; % REM 0%
end
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{1}, n_EventsComposites_Awake);% tmp_combinedtxt(1);
tmp_pText(2).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{2}, n_EventsComposites_NREM); % tmp_combinedtxt(2);
if numel(tmp_pText) >= 3
    tmp_pText(3).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{3}, n_EventsComposites_REM); % tmp_combinedtxt(3);
end
h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
if numel(tmp_pText) >= 3
    h_piechart(5).FaceColor = [0, 1, 0];
end

title_str = sprintf('Ca2+ Events in Sleep States\nComposites');
title(title_str)
i_subplot = i_subplot + 1;

% SUBPLOT 6
subplot(n_rows, n_columns, i_subplot)
if Duration_ToT_REM == 0
    tmp_REM = 0;
else
    tmp_REM = n_EventsComposites_REM/(Duration_ToT_REM/DurationsNorm100);
end
h_piechart = pie([n_EventsComposites_Awake/(Duration_ToT_Awake/DurationsNorm100), n_EventsComposites_NREM/(Duration_ToT_NREM/DurationsNorm100), tmp_REM]);
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
if numel(tmp_percentValues) < 3
    tmp_percentValues{3} = '0%'; % REM 0%
end
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
if numel(tmp_pText) >= 3
    tmp_pText(3).String = tmp_combinedtxt(3);
end
h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
if numel(tmp_pText) >= 3
    h_piechart(5).FaceColor = [0, 1, 0];
end

title_str = sprintf('Frequency of Ca2+ Events in Sleep States\nComposites');
title(title_str)
i_subplot = i_subplot + 1;

% Suptitle
h_suptitle = suptitle('States Duration and Events Distribution');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';


%% Save
FileName = 'Figure Events per State - Pie Plot';
FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))
close gcf 

