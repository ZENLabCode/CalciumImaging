function Hist_Results = plot_histogram_single(Data_Awake, Data_NREM, Data_REM, Duration_ToT, Opts_Hist)
% This function plots histograms for a single data variable. Calls to this
% function are made in the "plot_histograms" function

% Options
FLAGs = Opts_Hist.FLAGs;
options.FLAG_normalize = 0;
Title_FontSize = 14;
i_subplot = 1;
LabelStr = Opts_Hist.LabelStr;

% Control
if Opts_Hist.FLAG_PreDefinedBins == 1 && ~isfield(Opts_Hist, 'Bins_Edges')
   error('Requested to plot an histogram with predefined bins edges, without defining Opts_Hist.Bins_Edges variable.\n') 
end

figure();
set(gcf,'position', get(0,'screensize'));


%% Plot All.
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
if isempty(Data_REM)
    if Opts_Hist.FLAG_PreDefinedBins == 1
        h = histogram([Data_Awake, Data_NREM], Opts_Hist.Bins_Edges, 'FaceColor', 'c');
    else
        h = histogram([Data_Awake, Data_NREM], Opts_Hist.n_bins, 'FaceColor', 'c');
    end
    
else
    if Opts_Hist.FLAG_PreDefinedBins == 1
        h = histogram([Data_Awake, Data_NREM, Data_REM], Opts_Hist.Bins_Edges, 'FaceColor', 'c');
    else
        h = histogram([Data_Awake, Data_NREM, Data_REM], Opts_Hist.n_bins, 'FaceColor', 'c');
    end
end
ylabel('Count')
xlabel(LabelStr)
box on; grid on;
axis ([-inf, inf, 0, nanmax(h.BinCounts)+5]);
title('All Data', 'FontSize', Title_FontSize)
i_subplot = i_subplot + 1;

Bin_Edges = h.BinEdges;


%% Plot Awake
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
if Opts_Hist.FLAG_PreDefinedBins == 1
    h = histogram(Data_Awake, Opts_Hist.Bins_Edges, 'FaceColor', 'b');
else
    h = histogram(Data_Awake, Opts_Hist.n_bins, 'FaceColor', 'b');
end
ylabel('Count')
xlabel(LabelStr)
box on; grid on;
axis ([-inf, inf, 0, nanmax(h.BinCounts)+5]);
title('Awake', 'FontSize', Title_FontSize)
i_subplot = i_subplot + 1;


%% Plot Non-REM
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
if Opts_Hist.FLAG_PreDefinedBins == 1
    h = histogram(Data_NREM, Opts_Hist.Bins_Edges, 'FaceColor', 'r');
else
    h = histogram(Data_NREM, Opts_Hist.n_bins, 'FaceColor', 'r');
end
ylabel('Count')
xlabel(LabelStr)
box on; grid on;
axis ([-inf, inf, 0, nanmax(h.BinCounts)+5]);
title('NoN-REM', 'FontSize', Title_FontSize)
i_subplot = i_subplot + 1;


%% Plot REM
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
if Opts_Hist.FLAG_PreDefinedBins == 1
    h = histogram(Data_REM, Opts_Hist.Bins_Edges, 'FaceColor', 'g');
else
    h = histogram(Data_REM, Opts_Hist.n_bins, 'FaceColor', 'g');
end
ylabel('Count')
xlabel(LabelStr)
box on; grid on;
axis ([-inf, inf, 0, nanmax(h.BinCounts)+5]);
title('REM', 'FontSize', Title_FontSize)
i_subplot = i_subplot + 1;


%% Plot Overlapping.
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
hold on;
if Opts_Hist.FLAG_PreDefinedBins == 1
    h1 = histogram(Data_Awake, Opts_Hist.Bins_Edges, 'FaceColor', 'b');
    h2 = histogram(Data_NREM, Opts_Hist.Bins_Edges, 'FaceColor', 'r');
    h3 = histogram(Data_REM, Opts_Hist.Bins_Edges, 'FaceColor', 'g');
else
    h1 = histogram(Data_Awake, Opts_Hist.n_bins, 'FaceColor', 'b');
    h2 = histogram(Data_NREM, Opts_Hist.n_bins, 'FaceColor', 'r');
    h3 = histogram(Data_REM, Opts_Hist.n_bins, 'FaceColor', 'g');
end

% Awake
options.Color = 'b';
try
    Bin_Edges = h1.BinEdges;
    [gauss_plot_Awake, fit_results_Awake] = fit_gaussian (Data_Awake, Bin_Edges, FLAGs, options);
catch
    warning('Gauss Fit did not work for Awake Data, trying to tighten the parameters choice.')
    fit_options = fitoptions('gauss1', 'Lower', [nanmin(Data_Awake) nanmin(Bin_Edges) 0], 'Upper', [nanmax(Data_Awake), nanmax(Bin_Edges), nanmax(Bin_Edges)]);
    [gauss_plot_Awake, fit_results_Awake, fit_Awake] = fit_gaussian (Data_Awake, Bin_Edges, FLAGs, options, fit_options);
end

% Non-REM
options.Color = 'r';
try
    [gauss_plot_NoNREM, fit_results_NoNREM] = fit_gaussian (Data_NREM, Bin_Edges, FLAGs, options);
catch
    warning('Gauss Fit did not work for Non-REM data, trying to tighten the parameters choice.')
    fit_options = fitoptions('gauss1', 'Lower', [nanmin(Data_NREM) nanmin(Bin_Edges) 0], 'Upper', [nanmax(Data_NREM), nanmax(Bin_Edges), nanmax(Bin_Edges)]);
    [gauss_plot_NoNREM, fit_results_NoNREM, fit_NoNREM] = fit_gaussian (Data_NREM, Bin_Edges, FLAGs, options, fit_options);
end

% REM
options.Color = 'g';
try
    [gauss_plot_REM, fit_results_REM] = fit_gaussian (Data_REM, Bin_Edges, FLAGs, options);
catch
    warning('Gauss Fit did not work for REM data, trying to tighten the parameters choice.')
    fit_options = fitoptions('gauss1', 'Lower', [nanmin(Data_REM) nanmin(Bin_Edges) 0], 'Upper', [nanmax(Data_REM), nanmax(Bin_Edges), nanmax(Bin_Edges)]);
    [gauss_plot_REM, fit_results_REM, fit_REM] = fit_gaussian (Data_REM, Bin_Edges, FLAGs, options, fit_options);
end
ylabel('Count')
xlabel(LabelStr)
box on; grid on;
axis ([-inf, inf, 0, nanmax([h1.BinCounts, h2.BinCounts, h3.BinCounts])+5]);
title('Comparison', 'FontSize', Title_FontSize)
hold off;
legend([h1, h2, h3], {'Awake', 'NoN-REM Sleep', 'REM Sleep'}, 'Location', 'NorthEast');
i_subplot = i_subplot + 1;


Hist_Results.Fit_Results.Awake = fit_results_Awake;
Hist_Results.Fit_Results.NoNREM = fit_results_NoNREM;
Hist_Results.Fit_Results.REM = fit_results_REM;
[Hist_Results.HistCount.Awake, Hist_Results.Edges.Awake] = histcounts(Data_Awake, Opts_Hist.Bins_Edges);
[Hist_Results.HistCount.NoNREM, Hist_Results.Edges.NoNREM] = histcounts(Data_NREM, Opts_Hist.Bins_Edges);
[Hist_Results.HistCount.REM, Hist_Results.Edges.REM] = histcounts(Data_REM, Opts_Hist.Bins_Edges);


%% Plot Overlapping Normalized.
subplot(Opts_Hist.subplots_rows, Opts_Hist.subplots_columns, i_subplot);
hold on;
% values1 = h1.Values/Duration_ToT.Awake;
% values2 = h2.Values/Duration_ToT.NoNREM;
% values3 = h3.Values/Duration_ToT.REM;
values1 = h1.Values/numel(Data_Awake);
values2 = h2.Values/numel(Data_NREM);
if numel(Data_REM) == 0
    values3 = 0;
else
values3 = h3.Values/numel(Data_REM);
end
h1 = histogram('BinEdges', Bin_Edges, 'BinCounts', values1, 'FaceColor', 'b');
h2 = histogram('BinEdges', Bin_Edges, 'BinCounts', values2, 'FaceColor', 'r');
if numel(Data_REM) > 0
    h3 = histogram('BinEdges', Bin_Edges, 'BinCounts', values3, 'FaceColor', 'g');
end
% Interpolate for Gaussian fit.
fit_options = fitoptions('gauss1', 'Lower', [nanmax(values1) fit_results_Awake.G1_mean fit_results_Awake.G1_std], 'Upper', [nanmax(values1), fit_results_Awake.G1_mean, fit_results_Awake.G1_std]);
options.Color = 'b';
[gauss_plot, gauss_fit_results, gauss_fit] = fit_gaussian (values1, Bin_Edges, FLAGs, options, fit_options);
fit_options = fitoptions('gauss1', 'Lower', [nanmax(values2) fit_results_NoNREM.G1_mean fit_results_NoNREM.G1_std], 'Upper', [nanmax(values2), fit_results_NoNREM.G1_mean, fit_results_NoNREM.G1_std]);
options.Color = 'r';
[gauss_plot, gauss_fit_results, gauss_fit] = fit_gaussian (values2, Bin_Edges, FLAGs, options, fit_options);
fit_options = fitoptions('gauss1', 'Lower', [nanmax(values3) fit_results_REM.G1_mean fit_results_REM.G1_std], 'Upper', [nanmax(values3), fit_results_REM.G1_mean, fit_results_REM.G1_std]);
options.Color = 'g';
[gauss_plot, gauss_fit_results, gauss_fit] = fit_gaussian (values3, Bin_Edges, FLAGs, options, fit_options);

ylabel('Count')
xlabel(LabelStr)
box on; grid on;
% axis ([-inf, inf, 0, nanmax([values1, values2, values3]) + nanmax([values1, values2, values3])*0.1]);
strtitle = sprintf('Comparison\n(Conditions normalized by #Events)');
title(strtitle, 'FontSize', Title_FontSize);
hold off;
if numel(Data_REM) > 0
    legend([h1, h2], {'Awake', 'NoN-REM Sleep'}, 'Location', 'NorthEast');
else
    legend([h1, h2, h3], {'Awake', 'NoN-REM Sleep', 'REM Sleep'}, 'Location', 'NorthEast');
end
i_subplot = i_subplot + 1;

h_suptitle = suptitle(Opts_Hist.SupTitleStr);
h_suptitle.FontSize = 18;
h_suptitle.FontWeight = 'bold';


%% Save
FilePath = sprintf('%s\\%s', Opts_Hist.Dir_Figures, Opts_Hist.FileName);

print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))
close gcf 

