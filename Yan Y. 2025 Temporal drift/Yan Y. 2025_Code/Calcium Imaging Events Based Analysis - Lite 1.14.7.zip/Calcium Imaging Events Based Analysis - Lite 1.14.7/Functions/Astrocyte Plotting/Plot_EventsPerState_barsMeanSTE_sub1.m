function Plot_EventsPerState_barsMeanSTE_sub1 (Events_QT_ACC, Events_QT_BRC, MouseMeans_QT_ACC, MouseMeans_QT_BRC, AstroStatsQT, Opts)




%% Options
Color_Awake = Opts.AstroPlot.Color_Awake;
Color_NONREM = Opts.AstroPlot.Color_NONREM;
Color_REM = Opts.AstroPlot.Color_REM;
Color_Baseline_ACC = Opts.AstroPlot.Color_Baseline_ACC;
Color_SD1_ACC = Opts.AstroPlot.Color_SD1_ACC;
Color_SD2_ACC = Opts.AstroPlot.Color_SD2_ACC;
Color_SD3_ACC = Opts.AstroPlot.Color_SD3_ACC;
Color_Baseline_BRC = Opts.AstroPlot.Color_Baseline_BRC;
Color_SD1_BRC = Opts.AstroPlot.Color_SD1_BRC;
Color_SD2_BRC = Opts.AstroPlot.Color_SD2_BRC;
Color_SD3_BRC = Opts.AstroPlot.Color_SD3_BRC;

FLAG_Show_MouseMeans = Opts.AstroPlot.FLAG_Show_MouseMeans;

n_colors = 8;
legend_labels = {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'};


%% Initialize Data
% ACC
tmp_Data1_Base_Awake_ACC = [Events_QT_ACC(1).Awake];
tmp_Data2_Base_Awake_ACC = [Events_QT_ACC(2).Awake];
tmp_Data3_Base_Awake_ACC = [Events_QT_ACC(3).Awake];
tmp_Data4_Base_Awake_ACC = [Events_QT_ACC(4).Awake];
tmp_Data5_Base_Awake_ACC = [Events_QT_ACC(5).Awake];
tmp_Data6_Base_Awake_ACC = [Events_QT_ACC(6).Awake];
tmp_Data1_SD_Awake_ACC = [Events_QT_ACC(8).Awake];
tmp_Data2_SD_Awake_ACC = [Events_QT_ACC(9).Awake];
tmp_Data3_SD_Awake_ACC = [Events_QT_ACC(10).Awake];
tmp_Data4_SD_Awake_ACC = [Events_QT_ACC(11).Awake];
tmp_Data5_SD_Awake_ACC = [Events_QT_ACC(12).Awake];
tmp_Data6_SD_Awake_ACC = [Events_QT_ACC(13).Awake];
data_Day_Base_Awake_ACC = [tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC];
data_Night_Base_Awake_ACC = [tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC];

tmp_Data1_Base_NoNREM_ACC = [Events_QT_ACC(1).NoNREM];
tmp_Data2_Base_NoNREM_ACC = [Events_QT_ACC(2).NoNREM];
tmp_Data3_Base_NoNREM_ACC = [Events_QT_ACC(3).NoNREM];
tmp_Data4_Base_NoNREM_ACC = [Events_QT_ACC(4).NoNREM];
tmp_Data5_Base_NoNREM_ACC = [Events_QT_ACC(5).NoNREM];
tmp_Data6_Base_NoNREM_ACC = [Events_QT_ACC(6).NoNREM];
tmp_Data1_SD_NoNREM_ACC = [Events_QT_ACC(8).NoNREM];
tmp_Data2_SD_NoNREM_ACC = [Events_QT_ACC(9).NoNREM];
tmp_Data3_SD_NoNREM_ACC = [Events_QT_ACC(10).NoNREM];
tmp_Data4_SD_NoNREM_ACC = [Events_QT_ACC(11).NoNREM];
tmp_Data5_SD_NoNREM_ACC = [Events_QT_ACC(12).NoNREM];
tmp_Data6_SD_NoNREM_ACC = [Events_QT_ACC(13).NoNREM];
data_Day_Base_NoNREM_ACC = [tmp_Data1_Base_NoNREM_ACC, tmp_Data3_Base_NoNREM_ACC, tmp_Data5_Base_NoNREM_ACC];
data_Night_Base_NoNREM_ACC = [tmp_Data2_Base_NoNREM_ACC, tmp_Data4_Base_NoNREM_ACC, tmp_Data6_Base_NoNREM_ACC];

tmp_Data1_Base_REM_ACC = [Events_QT_ACC(1).REM];
tmp_Data2_Base_REM_ACC = [Events_QT_ACC(2).REM];
tmp_Data3_Base_REM_ACC = [Events_QT_ACC(3).REM];
tmp_Data4_Base_REM_ACC = [Events_QT_ACC(4).REM];
tmp_Data5_Base_REM_ACC = [Events_QT_ACC(5).REM];
tmp_Data6_Base_REM_ACC = [Events_QT_ACC(6).REM];
tmp_Data1_SD_REM_ACC = [Events_QT_ACC(8).REM];
tmp_Data2_SD_REM_ACC = [Events_QT_ACC(9).REM];
tmp_Data3_SD_REM_ACC = [Events_QT_ACC(10).REM];
tmp_Data4_SD_REM_ACC = [Events_QT_ACC(11).REM];
tmp_Data5_SD_REM_ACC = [Events_QT_ACC(12).REM];
tmp_Data6_SD_REM_ACC = [Events_QT_ACC(13).REM];
data_Day_Base_REM_ACC = [tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC];
data_Night_Base_REM_ACC = [tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC];

% Barrel Cortex
tmp_Data1_Base_Awake_BRC = [Events_QT_BRC(1).Awake];
tmp_Data2_Base_Awake_BRC = [Events_QT_BRC(2).Awake];
tmp_Data3_Base_Awake_BRC = [Events_QT_BRC(3).Awake];
tmp_Data4_Base_Awake_BRC = [Events_QT_BRC(4).Awake];
tmp_Data5_Base_Awake_BRC = [Events_QT_BRC(5).Awake];
tmp_Data6_Base_Awake_BRC = [Events_QT_BRC(6).Awake];
tmp_Data1_SD_Awake_BRC = [Events_QT_BRC(8).Awake];
tmp_Data2_SD_Awake_BRC = [Events_QT_BRC(9).Awake];
tmp_Data3_SD_Awake_BRC = [Events_QT_BRC(10).Awake];
tmp_Data4_SD_Awake_BRC = [Events_QT_BRC(11).Awake];
tmp_Data5_SD_Awake_BRC = [Events_QT_BRC(12).Awake];
tmp_Data6_SD_Awake_BRC = [Events_QT_BRC(13).Awake];
data_Day_Base_Awake_BRC = [tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC];
data_Night_Base_Awake_BRC = [tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC];

tmp_Data1_Base_NoNREM_BRC = [Events_QT_BRC(1).NoNREM];
tmp_Data2_Base_NoNREM_BRC = [Events_QT_BRC(2).NoNREM];
tmp_Data3_Base_NoNREM_BRC = [Events_QT_BRC(3).NoNREM];
tmp_Data4_Base_NoNREM_BRC = [Events_QT_BRC(4).NoNREM];
tmp_Data5_Base_NoNREM_BRC = [Events_QT_BRC(5).NoNREM];
tmp_Data6_Base_NoNREM_BRC = [Events_QT_BRC(6).NoNREM];
tmp_Data1_SD_NoNREM_BRC = [Events_QT_BRC(8).NoNREM];
tmp_Data2_SD_NoNREM_BRC = [Events_QT_BRC(9).NoNREM];
tmp_Data3_SD_NoNREM_BRC = [Events_QT_BRC(10).NoNREM];
tmp_Data4_SD_NoNREM_BRC = [Events_QT_BRC(11).NoNREM];
tmp_Data5_SD_NoNREM_BRC = [Events_QT_BRC(12).NoNREM];
tmp_Data6_SD_NoNREM_BRC = [Events_QT_BRC(13).NoNREM];
data_Day_Base_NoNREM_BRC = [tmp_Data1_Base_NoNREM_BRC, tmp_Data3_Base_NoNREM_BRC, tmp_Data5_Base_NoNREM_BRC];
data_Night_Base_NoNREM_BRC = [tmp_Data2_Base_NoNREM_BRC, tmp_Data4_Base_NoNREM_BRC, tmp_Data6_Base_NoNREM_BRC];

tmp_Data1_Base_REM_BRC = [Events_QT_BRC(1).REM];
tmp_Data2_Base_REM_BRC = [Events_QT_BRC(2).REM];
tmp_Data3_Base_REM_BRC = [Events_QT_BRC(3).REM];
tmp_Data4_Base_REM_BRC = [Events_QT_BRC(4).REM];
tmp_Data5_Base_REM_BRC = [Events_QT_BRC(5).REM];
tmp_Data6_Base_REM_BRC = [Events_QT_BRC(6).REM];
tmp_Data1_SD_REM_BRC = [Events_QT_BRC(8).REM];
tmp_Data2_SD_REM_BRC = [Events_QT_BRC(9).REM];
tmp_Data3_SD_REM_BRC = [Events_QT_BRC(10).REM];
tmp_Data4_SD_REM_BRC = [Events_QT_BRC(11).REM];
tmp_Data5_SD_REM_BRC = [Events_QT_BRC(12).REM];
tmp_Data6_SD_REM_BRC = [Events_QT_BRC(13).REM];
data_Day_Base_REM_BRC = [tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC];
data_Night_Base_REM_BRC = [tmp_Data2_Base_REM_BRC, tmp_Data4_Base_REM_BRC, tmp_Data6_Base_REM_BRC];

% Plot bars positions and comparisons between bars
Plot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];

% The comparisons between columns to show in the significance of. Each
% value is the position of the corresponding boxplot
if Opts.AstroPlot.FLAG_all_comparisons == 1
    Comparisons = {[Plot_Positions(1),Plot_Positions(2)], [Plot_Positions(1),Plot_Positions(3)], [Plot_Positions(1),Plot_Positions(4)], [Plot_Positions(2),Plot_Positions(3)], [Plot_Positions(2),Plot_Positions(4)], [Plot_Positions(3),Plot_Positions(4)],...
        [Plot_Positions(5),Plot_Positions(6)], [Plot_Positions(5),Plot_Positions(7)], [Plot_Positions(5),Plot_Positions(8)], [Plot_Positions(6),Plot_Positions(7)], [Plot_Positions(6),Plot_Positions(8)], [Plot_Positions(7),Plot_Positions(8)],...
        [Plot_Positions(9),Plot_Positions(10)], [Plot_Positions(9),Plot_Positions(11)], [Plot_Positions(9),Plot_Positions(12)], [Plot_Positions(10),Plot_Positions(11)], [Plot_Positions(10),Plot_Positions(12)], [Plot_Positions(11),Plot_Positions(12)],...
        [Plot_Positions(13),Plot_Positions(14)], [Plot_Positions(13),Plot_Positions(15)], [Plot_Positions(13),Plot_Positions(16)], [Plot_Positions(14),Plot_Positions(15)], [Plot_Positions(14),Plot_Positions(16)], [Plot_Positions(15),Plot_Positions(16)],...
        [Plot_Positions(17),Plot_Positions(18)], [Plot_Positions(17),Plot_Positions(19)], [Plot_Positions(17),Plot_Positions(20)], [Plot_Positions(18),Plot_Positions(19)], [Plot_Positions(18),Plot_Positions(20)], [Plot_Positions(19),Plot_Positions(20)],...
        [Plot_Positions(21),Plot_Positions(22)], [Plot_Positions(21),Plot_Positions(23)], [Plot_Positions(21),Plot_Positions(24)], [Plot_Positions(22),Plot_Positions(23)], [Plot_Positions(22),Plot_Positions(24)], [Plot_Positions(23),Plot_Positions(24)]};
else
    Comparisons = {[Plot_Positions(1),Plot_Positions(2)], [Plot_Positions(1),Plot_Positions(3)], [Plot_Positions(1),Plot_Positions(4)],...
        [Plot_Positions(5),Plot_Positions(6)], [Plot_Positions(5),Plot_Positions(7)], [Plot_Positions(5),Plot_Positions(8)],...
        [Plot_Positions(9),Plot_Positions(10)], [Plot_Positions(9),Plot_Positions(11)], [Plot_Positions(9),Plot_Positions(12)],...
        [Plot_Positions(13),Plot_Positions(14)], [Plot_Positions(13),Plot_Positions(15)], [Plot_Positions(13),Plot_Positions(16)],...
        [Plot_Positions(17),Plot_Positions(18)], [Plot_Positions(17),Plot_Positions(19)], [Plot_Positions(17),Plot_Positions(20)],...
        [Plot_Positions(21),Plot_Positions(22)], [Plot_Positions(21),Plot_Positions(23)], [Plot_Positions(21),Plot_Positions(24)]};
end




%% Plot 1: Day
figure(); set(gcf,'position', get(0,'screensize'));

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
GroupMeans = [nanmean(data_Day_Base_Awake_ACC), nanmean(tmp_Data1_SD_Awake_ACC), nanmean(tmp_Data3_SD_Awake_ACC), nanmean(tmp_Data5_SD_Awake_ACC), ...
    nanmean(data_Day_Base_Awake_BRC), nanmean(tmp_Data1_SD_Awake_BRC), nanmean(tmp_Data3_SD_Awake_BRC), nanmean(tmp_Data5_SD_Awake_BRC), ...
    nanmean(data_Day_Base_NoNREM_ACC), nanmean(tmp_Data1_SD_NoNREM_ACC), nanmean(tmp_Data3_SD_NoNREM_ACC), nanmean(tmp_Data5_SD_NoNREM_ACC), ...
    nanmean(data_Day_Base_NoNREM_BRC), nanmean(tmp_Data1_SD_NoNREM_BRC), nanmean(tmp_Data3_SD_NoNREM_BRC), nanmean(tmp_Data5_SD_NoNREM_BRC), ...
    nanmean(data_Day_Base_REM_ACC), nanmean(tmp_Data1_SD_REM_ACC), nanmean(tmp_Data3_SD_REM_ACC), nanmean(tmp_Data5_SD_REM_ACC), ...
    nanmean(data_Day_Base_REM_BRC), nanmean(tmp_Data1_SD_REM_BRC), nanmean(tmp_Data3_SD_REM_BRC), nanmean(tmp_Data5_SD_REM_BRC)];

GroupSTE = [nanstd(data_Day_Base_Awake_ACC)./(sqrt(numel(data_Day_Base_Awake_ACC))), nanstd(tmp_Data1_SD_Awake_ACC)./(sqrt(numel(tmp_Data1_SD_Awake_ACC))), nanstd(tmp_Data3_SD_Awake_ACC)./(sqrt(numel(tmp_Data3_SD_Awake_ACC))), nanstd(tmp_Data5_SD_Awake_ACC)./(sqrt(numel(tmp_Data5_SD_Awake_ACC))), ...
    nanstd(data_Day_Base_Awake_BRC)./(sqrt(numel(data_Day_Base_Awake_BRC))), nanstd(tmp_Data1_SD_Awake_BRC)./(sqrt(numel(tmp_Data1_SD_Awake_BRC))), nanstd(tmp_Data3_SD_Awake_BRC)./(sqrt(numel(tmp_Data3_SD_Awake_BRC))), nanstd(tmp_Data5_SD_Awake_BRC)./(sqrt(numel(tmp_Data5_SD_Awake_BRC))), ...
    nanstd(data_Day_Base_NoNREM_ACC)./(sqrt(numel(data_Day_Base_NoNREM_ACC))), nanstd(tmp_Data1_SD_NoNREM_ACC)./(sqrt(numel(data_Day_Base_NoNREM_ACC))), nanstd(tmp_Data3_SD_NoNREM_ACC)./(sqrt(numel(tmp_Data3_SD_NoNREM_ACC))), nanstd(tmp_Data5_SD_NoNREM_ACC)./(sqrt(numel(tmp_Data5_SD_NoNREM_ACC))), ...
    nanstd(data_Day_Base_NoNREM_BRC)./(sqrt(numel(data_Day_Base_NoNREM_BRC))), nanstd(tmp_Data1_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data1_SD_NoNREM_BRC))), nanstd(tmp_Data3_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data3_SD_NoNREM_BRC))), nanstd(tmp_Data5_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data5_SD_NoNREM_BRC))), ...
    nanstd(data_Day_Base_REM_ACC)./(sqrt(numel(data_Day_Base_REM_ACC))), nanstd(tmp_Data1_SD_REM_ACC)./(sqrt(numel(tmp_Data1_SD_REM_ACC))), nanstd(tmp_Data3_SD_REM_ACC)./(sqrt(numel(tmp_Data3_SD_REM_ACC))), nanstd(tmp_Data5_SD_REM_ACC)./(sqrt(numel(tmp_Data5_SD_REM_ACC))), ...
    nanstd(data_Day_Base_REM_BRC)./(sqrt(numel(data_Day_Base_REM_BRC))), nanstd(tmp_Data1_SD_REM_BRC)./(sqrt(numel(tmp_Data1_SD_REM_BRC))), nanstd(tmp_Data3_SD_REM_BRC)./(sqrt(numel(tmp_Data3_SD_REM_BRC))), nanstd(tmp_Data5_SD_REM_BRC)./(sqrt(numel(tmp_Data5_SD_REM_BRC)))];

n_groups = numel(GroupMeans);

% Array of P-values, 1 for each comparison
if Opts.AstroPlot.FLAG_all_comparisons == 1
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue];
end

hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');

% Plot
h_barplots = bar(Plot_Positions, GroupMeans);
errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:8:n_groups, :) = repmat(Color_Baseline_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(2:8:n_groups, :) = repmat(Color_SD1_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(3:8:n_groups, :) = repmat(Color_SD2_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(4:8:n_groups, :) = repmat(Color_SD3_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(5:8:n_groups, :) = repmat(Color_Baseline_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(6:8:n_groups, :) = repmat(Color_SD1_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(8:8:n_groups, :) = repmat(Color_SD2_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(8:8:n_groups, :) = repmat(Color_SD3_BRC, numel(1:8:n_groups), 1);

% Scatter Plot of Mouse Means
if FLAG_Show_MouseMeans == 1
    MouseMeans_QT_ACC_Awake = [MouseMeans_QT_ACC.Awake];
    MouseMeans_QT_ACC_NREM = [MouseMeans_QT_ACC.NREM];
    MouseMeans_QT_ACC_REM = [MouseMeans_QT_ACC.REM];
    MouseMeans_QT_BRC_Awake = [MouseMeans_QT_BRC.Awake];
    MouseMeans_QT_BRC_NREM = [MouseMeans_QT_BRC.NREM];
    MouseMeans_QT_BRC_REM = [MouseMeans_QT_BRC.REM];
    
    tmp_n = numel(MouseMeans_QT_ACC_Awake([1, 3, 5], :));
    tmp_n1 = numel(MouseMeans_QT_ACC_Awake(1, :));
    
    h_scatter_Base_1 = scatter(ones(1, tmp_n).*Plot_Positions(1), reshape(MouseMeans_QT_ACC_Awake([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_1 = scatter(ones(1, tmp_n1).*Plot_Positions(2), reshape(MouseMeans_QT_ACC_Awake(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_1 = scatter(ones(1, tmp_n1).*Plot_Positions(3), reshape(MouseMeans_QT_ACC_Awake(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_1 = scatter(ones(1, tmp_n1).*Plot_Positions(4), reshape(MouseMeans_QT_ACC_Awake(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_2 = scatter(ones(1, tmp_n).*Plot_Positions(5), reshape(MouseMeans_QT_BRC_Awake([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_2 = scatter(ones(1, tmp_n1).*Plot_Positions(6), reshape(MouseMeans_QT_BRC_Awake(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_2 = scatter(ones(1, tmp_n1).*Plot_Positions(7), reshape(MouseMeans_QT_BRC_Awake(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_2 = scatter(ones(1, tmp_n1).*Plot_Positions(8), reshape(MouseMeans_QT_BRC_Awake(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_3 = scatter(ones(1, tmp_n).*Plot_Positions(9), reshape(MouseMeans_QT_ACC_NREM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_3 = scatter(ones(1, tmp_n1).*Plot_Positions(10), reshape(MouseMeans_QT_ACC_NREM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_3 = scatter(ones(1, tmp_n1).*Plot_Positions(11), reshape(MouseMeans_QT_ACC_NREM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_3 = scatter(ones(1, tmp_n1).*Plot_Positions(12), reshape(MouseMeans_QT_ACC_NREM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_4 = scatter(ones(1, tmp_n).*Plot_Positions(13), reshape(MouseMeans_QT_BRC_NREM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_4 = scatter(ones(1, tmp_n1).*Plot_Positions(14), reshape(MouseMeans_QT_BRC_NREM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_4 = scatter(ones(1, tmp_n1).*Plot_Positions(15), reshape(MouseMeans_QT_BRC_NREM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_4 = scatter(ones(1, tmp_n1).*Plot_Positions(16), reshape(MouseMeans_QT_BRC_NREM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_5 = scatter(ones(1, tmp_n).*Plot_Positions(17), reshape(MouseMeans_QT_ACC_REM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_5 = scatter(ones(1, tmp_n1).*Plot_Positions(18), reshape(MouseMeans_QT_ACC_REM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_5 = scatter(ones(1, tmp_n1).*Plot_Positions(19), reshape(MouseMeans_QT_ACC_REM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_5 = scatter(ones(1, tmp_n1).*Plot_Positions(20), reshape(MouseMeans_QT_ACC_REM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_6 = scatter(ones(1, tmp_n).*Plot_Positions(21), reshape(MouseMeans_QT_BRC_REM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_6 = scatter(ones(1, tmp_n1).*Plot_Positions(22), reshape(MouseMeans_QT_BRC_REM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_6 = scatter(ones(1, tmp_n1).*Plot_Positions(23), reshape(MouseMeans_QT_BRC_REM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_6 = scatter(ones(1, tmp_n1).*Plot_Positions(24), reshape(MouseMeans_QT_BRC_REM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
end

ylim([0, Opts.AstroPlot.Plot_YMax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

% Ticks
set(gca, 'xTick', Plot_Positions(2:4:end) + Opts.AstroPlot.BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});

% Labels & title
ylabel(Opts.AstroPlot.str_ylabel)
title(Opts.AstroPlot.str_title_Day)

% Legend
h_placeholder = bar(nan(2, n_colors));  % invisible placeholder
tmp_colors = [Color_Baseline_ACC; Color_SD1_ACC; Color_SD2_ACC; Color_SD3_ACC;...
    Color_Baseline_BRC; Color_SD1_BRC; Color_SD2_BRC; Color_SD3_BRC];
for i=1:n_colors
    h_placeholder(i).FaceColor = tmp_colors(i,:);
end
hLG = legend(h_placeholder, legend_labels, 'location', 'northeast');

% Save
if Opts.AstroPlot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(Opts.AstroPlot.FilePath_Day, '.eps'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.jpg'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.fig'))
    close gcf
end


%% Plot 2: Night
figure(); set(gcf,'position', get(0,'screensize'));

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM

GroupMeans = [nanmean(data_Night_Base_Awake_ACC), nanmean(tmp_Data2_SD_Awake_ACC), nanmean(tmp_Data4_SD_Awake_ACC), nanmean(tmp_Data6_SD_Awake_ACC), ...
    nanmean(data_Night_Base_Awake_BRC), nanmean(tmp_Data2_SD_Awake_BRC), nanmean(tmp_Data4_SD_Awake_BRC), nanmean(tmp_Data6_SD_Awake_BRC), ...
    nanmean(data_Night_Base_NoNREM_ACC), nanmean(tmp_Data2_SD_NoNREM_ACC), nanmean(tmp_Data4_SD_NoNREM_ACC), nanmean(tmp_Data6_SD_NoNREM_ACC), ...
    nanmean(data_Night_Base_NoNREM_BRC), nanmean(tmp_Data2_SD_NoNREM_BRC), nanmean(tmp_Data4_SD_NoNREM_BRC), nanmean(tmp_Data6_SD_NoNREM_BRC), ...
    nanmean(data_Night_Base_REM_ACC), nanmean(tmp_Data2_SD_REM_ACC), nanmean(tmp_Data4_SD_REM_ACC), nanmean(tmp_Data6_SD_REM_ACC), ...
    nanmean(data_Night_Base_REM_BRC), nanmean(tmp_Data2_SD_REM_BRC), nanmean(tmp_Data4_SD_REM_BRC), nanmean(tmp_Data6_SD_REM_BRC)];

GroupSTE = [nanstd(data_Night_Base_Awake_ACC)./(sqrt(numel(data_Night_Base_Awake_ACC))), nanstd(tmp_Data2_SD_Awake_ACC)./(sqrt(numel(tmp_Data2_SD_Awake_ACC))), nanstd(tmp_Data4_SD_Awake_ACC)./(sqrt(numel(tmp_Data4_SD_Awake_ACC))), nanstd(tmp_Data6_SD_Awake_ACC)./(sqrt(numel(tmp_Data6_SD_Awake_ACC))), ...
    nanstd(data_Night_Base_Awake_BRC)./(sqrt(numel(data_Night_Base_Awake_BRC))), nanstd(tmp_Data2_SD_Awake_BRC)./(sqrt(numel(tmp_Data2_SD_Awake_BRC))), nanstd(tmp_Data4_SD_Awake_BRC)./(sqrt(numel(tmp_Data4_SD_Awake_BRC))), nanstd(tmp_Data6_SD_Awake_BRC)./(sqrt(numel(tmp_Data6_SD_Awake_BRC))), ...
    nanstd(data_Night_Base_NoNREM_ACC)./(sqrt(numel(data_Night_Base_NoNREM_ACC))), nanstd(tmp_Data2_SD_NoNREM_ACC)./(sqrt(numel(data_Night_Base_NoNREM_ACC))), nanstd(tmp_Data4_SD_NoNREM_ACC)./(sqrt(numel(tmp_Data4_SD_NoNREM_ACC))), nanstd(tmp_Data6_SD_NoNREM_ACC)./(sqrt(numel(tmp_Data6_SD_NoNREM_ACC))), ...
    nanstd(data_Night_Base_NoNREM_BRC)./(sqrt(numel(data_Night_Base_NoNREM_BRC))), nanstd(tmp_Data2_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data2_SD_NoNREM_BRC))), nanstd(tmp_Data4_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data4_SD_NoNREM_BRC))), nanstd(tmp_Data6_SD_NoNREM_BRC)./(sqrt(numel(tmp_Data6_SD_NoNREM_BRC))), ...
    nanstd(data_Night_Base_REM_ACC)./(sqrt(numel(data_Night_Base_REM_ACC))), nanstd(tmp_Data2_SD_REM_ACC)./(sqrt(numel(tmp_Data2_SD_REM_ACC))), nanstd(tmp_Data4_SD_REM_ACC)./(sqrt(numel(tmp_Data4_SD_REM_ACC))), nanstd(tmp_Data6_SD_REM_ACC)./(sqrt(numel(tmp_Data6_SD_REM_ACC))), ...
    nanstd(data_Night_Base_REM_BRC)./(sqrt(numel(data_Night_Base_REM_BRC))), nanstd(tmp_Data2_SD_REM_BRC)./(sqrt(numel(tmp_Data2_SD_REM_BRC))), nanstd(tmp_Data4_SD_REM_BRC)./(sqrt(numel(tmp_Data4_SD_REM_BRC))), nanstd(tmp_Data6_SD_REM_BRC)./(sqrt(numel(tmp_Data6_SD_REM_BRC)))];

n_groups = numel(GroupMeans);

% Array of P-values, 1 for each comparison
if Opts.AstroPlot.FLAG_all_comparisons == 1
    PVal_Array = [AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD72h.Pvalue];
end

hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
h_barplots = bar(Plot_Positions, GroupMeans);

errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:8:n_groups, :) = repmat(Color_Baseline_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(2:8:n_groups, :) = repmat(Color_SD1_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(3:8:n_groups, :) = repmat(Color_SD2_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(4:8:n_groups, :) = repmat(Color_SD3_ACC, numel(1:8:n_groups), 1);
h_barplots.CData(5:8:n_groups, :) = repmat(Color_Baseline_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(6:8:n_groups, :) = repmat(Color_SD1_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(8:8:n_groups, :) = repmat(Color_SD2_BRC, numel(1:8:n_groups), 1);
h_barplots.CData(8:8:n_groups, :) = repmat(Color_SD3_BRC, numel(1:8:n_groups), 1);

% Scatter Plot of Mouse Means
if FLAG_Show_MouseMeans == 1
    MouseMeans_QT_ACC_Awake = [MouseMeans_QT_ACC.Awake];
    MouseMeans_QT_ACC_NREM = [MouseMeans_QT_ACC.NREM];
    MouseMeans_QT_ACC_REM = [MouseMeans_QT_ACC.REM];
    MouseMeans_QT_BRC_Awake = [MouseMeans_QT_BRC.Awake];
    MouseMeans_QT_BRC_NREM = [MouseMeans_QT_BRC.NREM];
    MouseMeans_QT_BRC_REM = [MouseMeans_QT_BRC.REM];
    
    tmp_n = numel(MouseMeans_QT_ACC_Awake([2, 4, 6], :));
    tmp_n1 = numel(MouseMeans_QT_ACC_Awake(2, :));
    h_scatter_Base_1 = scatter(ones(1, tmp_n).*Plot_Positions(1), reshape(MouseMeans_QT_ACC_Awake([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_1 = scatter(ones(1, tmp_n1).*Plot_Positions(2), reshape(MouseMeans_QT_ACC_Awake(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_1 = scatter(ones(1, tmp_n1).*Plot_Positions(3), reshape(MouseMeans_QT_ACC_Awake(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_1 = scatter(ones(1, tmp_n1).*Plot_Positions(4), reshape(MouseMeans_QT_ACC_Awake(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_2 = scatter(ones(1, tmp_n).*Plot_Positions(5), reshape(MouseMeans_QT_BRC_Awake([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_2 = scatter(ones(1, tmp_n1).*Plot_Positions(6), reshape(MouseMeans_QT_BRC_Awake(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_2 = scatter(ones(1, tmp_n1).*Plot_Positions(7), reshape(MouseMeans_QT_BRC_Awake(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_2 = scatter(ones(1, tmp_n1).*Plot_Positions(8), reshape(MouseMeans_QT_BRC_Awake(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_3 = scatter(ones(1, tmp_n).*Plot_Positions(9), reshape(MouseMeans_QT_ACC_NREM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_3 = scatter(ones(1, tmp_n1).*Plot_Positions(10), reshape(MouseMeans_QT_ACC_NREM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_3 = scatter(ones(1, tmp_n1).*Plot_Positions(11), reshape(MouseMeans_QT_ACC_NREM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_3 = scatter(ones(1, tmp_n1).*Plot_Positions(12), reshape(MouseMeans_QT_ACC_NREM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_4 = scatter(ones(1, tmp_n).*Plot_Positions(13), reshape(MouseMeans_QT_BRC_NREM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_4 = scatter(ones(1, tmp_n1).*Plot_Positions(14), reshape(MouseMeans_QT_BRC_NREM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_4 = scatter(ones(1, tmp_n1).*Plot_Positions(15), reshape(MouseMeans_QT_BRC_NREM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_4 = scatter(ones(1, tmp_n1).*Plot_Positions(16), reshape(MouseMeans_QT_BRC_NREM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_5 = scatter(ones(1, tmp_n).*Plot_Positions(17), reshape(MouseMeans_QT_ACC_REM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_5 = scatter(ones(1, tmp_n1).*Plot_Positions(18), reshape(MouseMeans_QT_ACC_REM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_5 = scatter(ones(1, tmp_n1).*Plot_Positions(19), reshape(MouseMeans_QT_ACC_REM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_5 = scatter(ones(1, tmp_n1).*Plot_Positions(20), reshape(MouseMeans_QT_ACC_REM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_Base_6 = scatter(ones(1, tmp_n).*Plot_Positions(21), reshape(MouseMeans_QT_BRC_REM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % Baseline
    h_scatter_SD1_6 = scatter(ones(1, tmp_n1).*Plot_Positions(22), reshape(MouseMeans_QT_BRC_REM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_6 = scatter(ones(1, tmp_n1).*Plot_Positions(23), reshape(MouseMeans_QT_BRC_REM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_6 = scatter(ones(1, tmp_n1).*Plot_Positions(24), reshape(MouseMeans_QT_BRC_REM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
end
ylim([0, Opts.AstroPlot.Plot_YMax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', Plot_Positions(2:4:end) + Opts.AstroPlot.BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});

ylabel(Opts.AstroPlot.str_ylabel)
title(Opts.AstroPlot.str_title_Night)

% Legend
h_placeholder = bar(nan(2, n_colors));  % invisible placeholder
tmp_colors = [Color_Baseline_ACC; Color_SD1_ACC; Color_SD2_ACC; Color_SD3_ACC;...
    Color_Baseline_BRC; Color_SD1_BRC; Color_SD2_BRC; Color_SD3_BRC];
for i=1:n_colors
    h_placeholder(i).FaceColor = tmp_colors(i,:);
end
hLG = legend(h_placeholder, legend_labels, 'location', 'northeast');

% Save
if Opts.AstroPlot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(Opts.AstroPlot.FilePath_Night, '.eps'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Night, '.jpg'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Night, '.fig'))
    close gcf
end
