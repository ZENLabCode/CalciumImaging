function [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type)
% This function computes the statistics for Astrocyte data.


%% Get Data
% EventRate
n_sessions = numel(Events_Data_ACC);

Events_ERate_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventRate;
    Events_ERate_ACC(i_session).Awake = [tmp.Awake];
    Events_ERate_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_ERate_ACC(i_session).REM = [tmp.REM];
end
clear tmp

Events_ERate_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventRate;
    Events_ERate_BRC(i_session).Awake = [tmp.Awake];
    Events_ERate_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_ERate_BRC(i_session).REM = [tmp.REM];
end
clear tmp

% Integrals
Events_Integrals_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventIntegral_Mean;
    Events_Integrals_ACC(i_session).Awake = [tmp.Awake];
    Events_Integrals_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_Integrals_ACC(i_session).REM = [tmp.REM];
end
clear tmp

Events_Integrals_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventIntegral_Mean;
    Events_Integrals_BRC(i_session).Awake = [tmp.Awake];
    Events_Integrals_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_Integrals_BRC(i_session).REM = [tmp.REM];
end
clear tmp

% Amplitude
Events_Amplitude_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventAmplitude_Mean;
    Events_Amplitude_ACC(i_session).Awake = [tmp.Awake];
    Events_Amplitude_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_Amplitude_ACC(i_session).REM = [tmp.REM];
end
clear tmp

Events_Amplitude_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventAmplitude_Mean;
    Events_Amplitude_BRC(i_session).Awake = [tmp.Awake];
    Events_Amplitude_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_Amplitude_BRC(i_session).REM = [tmp.REM];
end
clear tmp


%% N Events
N_Events_ACC = struct('Awake', [], 'NREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventIntegral_Mean;
    tmp_Awake = [tmp.Awake];
    tmp_NREM = [tmp.NoNREM];
    tmp_REM = [tmp.REM];
    N_Events_ACC(i_session).Awake = numel(tmp_Awake(~isnan(tmp_Awake)));
    N_Events_ACC(i_session).NREM = numel(tmp_NREM(~isnan(tmp_NREM)));
    N_Events_ACC(i_session).REM = numel(tmp_REM(~isnan(tmp_REM)));
end
N_Events_BRC = struct('Awake', [], 'NREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventIntegral_Mean;
    tmp_Awake = [tmp.Awake];
    tmp_NREM = [tmp.NoNREM];
    tmp_REM = [tmp.REM];
    N_Events_BRC(i_session).Awake = numel(tmp_Awake(~isnan(tmp_Awake)));
    N_Events_BRC(i_session).NREM = numel(tmp_NREM(~isnan(tmp_NREM)));
    N_Events_BRC(i_session).REM = numel(tmp_REM(~isnan(tmp_REM)));
end

N_Events.ACC = N_Events_ACC;
N_Events.BRC = N_Events_BRC;

%% Statistics
fprintf('\nComputing Statistics...\n')
if strcmpi(Stats_Type, 'ranksum') == 1
    fprintf('Events Rates...\n')
    AstroStats.ERate = Astrocyte_Stats_Ranksum_sub1 (Events_ERate_ACC, Events_ERate_BRC);
    fprintf('Integrals...\n')
    AstroStats.Integrals = Astrocyte_Stats_Ranksum_sub1 (Events_Integrals_ACC, Events_Integrals_BRC);
    fprintf('Amplitudes...\n')
    AstroStats.Amplitude = Astrocyte_Stats_Ranksum_sub1 (Events_Amplitude_ACC, Events_Amplitude_BRC);
elseif strcmpi(Stats_Type, 'ttest2') == 1
    fprintf('Events Rates...\n')
    AstroStats.ERate = Astrocyte_Stats_Ttest2_sub1 (Events_ERate_ACC, Events_ERate_BRC);
    fprintf('Integrals...\n')
    AstroStats.Integrals = Astrocyte_Stats_Ttest2_sub1 (Events_Integrals_ACC, Events_Integrals_BRC);
    fprintf('Amplitudes...\n')
    AstroStats.Amplitude = Astrocyte_Stats_Ttest2_sub1 (Events_Amplitude_ACC, Events_Amplitude_BRC);
else
    error ('Unidentified statistics requested.')
end
fprintf('Done!\n')

