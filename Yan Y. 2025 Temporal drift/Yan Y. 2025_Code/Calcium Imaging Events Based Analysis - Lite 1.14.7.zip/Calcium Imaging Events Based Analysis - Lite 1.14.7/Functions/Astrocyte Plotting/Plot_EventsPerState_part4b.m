function Plot_EventsPerState_part4b (Events_Data_ACC, Events_Data_BrC, AstroStats)
% This function plots the results for Christina Astrocytes Analysis.
% The plot is Events Rate / Integrals / Amplitude: 
% Baseline vs SD Recovery, ACC and BRC together, 2
% separate plots for day and night


Stats_Type = 'ttest2'; % 'ranksum' or 'ttest2'
if exist('AstroStats', 'var') == 0
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end
if isempty(AstroStats)
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end

PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';
if exist(PlotPath, 'dir') == 0
    PlotPath = pwd;
end

n_sessions = numel(Events_Data_ACC);
n_mice = numel(Events_Data_ACC(1).MouseMeans);


%% Options
Opts.AstroPlot.FLAG_Save = 1;

Opts.AstroPlot.PlotsTransparency = 0.5;
Opts.AstroPlot.MarkerSize_Significance = 80;
Opts.AstroPlot.ScatterDotLineWidth = 0.25;
Opts.AstroPlot.ScatterDotArea = 18;
Opts.AstroPlot.BP_Width = 0.5; % Boxplots Width

Opts.AstroPlot.Color_Awake = [0,0,0.5];
Opts.AstroPlot.Color_NONREM = [0.5,0,0];
Opts.AstroPlot.Color_REM = [0,0.5,0];
Opts.AstroPlot.Color_Baseline_ACC = [0.5,0,0];
Opts.AstroPlot.Color_SD1_ACC = [1,0.66,0.66];
Opts.AstroPlot.Color_SD2_ACC = [1,0.33,0.33];
Opts.AstroPlot.Color_SD3_ACC = [1,0,0];
Opts.AstroPlot.Color_Baseline_BRC = [0,0,0.5];
Opts.AstroPlot.Color_SD1_BRC = [0.66,0.66,1];
Opts.AstroPlot.Color_SD2_BRC = [0.33,0.33,1];
Opts.AstroPlot.Color_SD3_BRC = [0,0,1];

Opts.AstroPlot.FLAG_all_comparisons = 0; % Display all the comparisons (set = 1), or just with baseline values?
Opts.AstroPlot.FLAG_SortPValue = 0;


%% Events Rate
AstroStatsQT = AstroStats.ERate;

% ACC
Events_ERate_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventRate;
    Events_ERate_ACC(i_session).Awake = [tmp.Awake];
    Events_ERate_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_ERate_ACC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_ERate_ACC.Awake = NaN(n_sessions, n_mice);
MouseMeans_ERate_ACC.NREM = NaN(n_sessions, n_mice);
MouseMeans_ERate_ACC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_ACC(i_session).MouseMeans.EventRate];
    MouseMeans_ERate_ACC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_ERate_ACC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_ERate_ACC.REM(i_session, :) = [tmp.REM];
end
clear tmp

% BRC
Events_ERate_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventRate;
    Events_ERate_BRC(i_session).Awake = [tmp.Awake];
    Events_ERate_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_ERate_BRC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_ERate_BRC.Awake = NaN(n_sessions, n_mice);
MouseMeans_ERate_BRC.NREM = NaN(n_sessions, n_mice);
MouseMeans_ERate_BRC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_BrC(i_session).MouseMeans.EventRate];
    MouseMeans_ERate_BRC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_ERate_BRC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_ERate_BRC.REM(i_session, :) = [tmp.REM];
end
clear tmp

Opts.AstroPlot.Plot_YMax = 0.16;

Opts.AstroPlot.str_title_Day = 'Events Rate [Hz] - Day - Baseline vs SD Recovery';
Opts.AstroPlot.str_title_Night = 'Events Rate [Hz] - Night - Baseline vs SD Recovery';
Opts.AstroPlot.str_ylabel = 'Ca2+ Events Rate [Hz]';

Opts.AstroPlot.FileName_Day = sprintf('Events Rate - Baselines vs SD - Day');
Opts.AstroPlot.FileName_Night = sprintf('Events Rate - Baselines vs SD - Night');

Opts.AstroPlot.FilePath_Day = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Day);
Opts.AstroPlot.FilePath_Night = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Night);

Plot_EventsPerState_part4b_sub1 (Events_ERate_ACC, Events_ERate_BRC, MouseMeans_ERate_ACC, MouseMeans_ERate_BRC, AstroStatsQT, Opts);


%% Integrals
AstroStatsQT = AstroStats.Integrals;

% ACC
Events_Integrals_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventIntegral_Mean;
    Events_Integrals_ACC(i_session).Awake = [tmp.Awake];
    Events_Integrals_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_Integrals_ACC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_Integrals_ACC.Awake = NaN(n_sessions, n_mice);
MouseMeans_Integrals_ACC.NREM = NaN(n_sessions, n_mice);
MouseMeans_Integrals_ACC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_ACC(i_session).MouseMeans.EventIntegral_Mean];
    MouseMeans_Integrals_ACC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_Integrals_ACC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_Integrals_ACC.REM(i_session, :) = [tmp.REM];
end
clear tmp

% BRC
Events_Integrals_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventIntegral_Mean;
    Events_Integrals_BRC(i_session).Awake = [tmp.Awake];
    Events_Integrals_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_Integrals_BRC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_Integrals_BRC.Awake = NaN(n_sessions, n_mice);
MouseMeans_Integrals_BRC.NREM = NaN(n_sessions, n_mice);
MouseMeans_Integrals_BRC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_BrC(i_session).MouseMeans.EventIntegral_Mean];
    MouseMeans_Integrals_BRC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_Integrals_BRC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_Integrals_BRC.REM(i_session, :) = [tmp.REM];
end
clear tmp

Opts.AstroPlot.Plot_YMax = 140;

Opts.AstroPlot.str_title_Day = 'Integrals - Day - Baseline vs SD Recovery';
Opts.AstroPlot.str_title_Night = 'Integrals - Night - Baseline vs SD Recovery';
Opts.AstroPlot.str_ylabel = 'Ca2+ Integral';

Opts.AstroPlot.FileName_Day = sprintf('Integrals - Baselines vs SD - Day');
Opts.AstroPlot.FileName_Night = sprintf('Integrals - Baselines vs SD - Night');
Opts.AstroPlot.FilePath_Day = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Day);
Opts.AstroPlot.FilePath_Night = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Night);

Plot_EventsPerState_part4b_sub1 (Events_Integrals_ACC, Events_Integrals_BRC, MouseMeans_Integrals_ACC, MouseMeans_Integrals_BRC, AstroStatsQT, Opts);



%% Amplitudes
AstroStatsQT = AstroStats.Amplitude;

% ACC
Events_Amplitude_ACC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_ACC(i_session).EventAmplitude_Mean;
    Events_Amplitude_ACC(i_session).Awake = [tmp.Awake];
    Events_Amplitude_ACC(i_session).NoNREM = [tmp.NoNREM];
    Events_Amplitude_ACC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_Amplitude_ACC.Awake = NaN(n_sessions, n_mice);
MouseMeans_Amplitude_ACC.NREM = NaN(n_sessions, n_mice);
MouseMeans_Amplitude_ACC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_ACC(i_session).MouseMeans.EventAmplitude_Mean];
    MouseMeans_Amplitude_ACC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_Amplitude_ACC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_Amplitude_ACC.REM(i_session, :) = [tmp.REM];
end
clear tmp

% BRC
Events_Amplitude_BRC = struct('Awake', [], 'NoNREM', [], 'REM', []);
for i_session = 1:n_sessions
    tmp = Events_Data_BrC(i_session).EventAmplitude_Mean;
    Events_Amplitude_BRC(i_session).Awake = [tmp.Awake];
    Events_Amplitude_BRC(i_session).NoNREM = [tmp.NoNREM];
    Events_Amplitude_BRC(i_session).REM = [tmp.REM];
end
clear tmp

MouseMeans_Amplitude_BRC.Awake = NaN(n_sessions, n_mice);
MouseMeans_Amplitude_BRC.NREM = NaN(n_sessions, n_mice);
MouseMeans_Amplitude_BRC.REM = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_BrC(i_session).MouseMeans.EventAmplitude_Mean];
    MouseMeans_Amplitude_BRC.Awake(i_session, :) = [tmp.Awake];
    MouseMeans_Amplitude_BRC.NREM(i_session, :) = [tmp.NoNREM];
    MouseMeans_Amplitude_BRC.REM(i_session, :) = [tmp.REM];
end
clear tmp

Opts.AstroPlot.Plot_YMax = 50;

Opts.AstroPlot.str_title_Day = 'Amplitude - Day - Baseline vs SD Recovery';
Opts.AstroPlot.str_title_Night = 'Amplitude - Night - Baseline vs SD Recovery';
Opts.AstroPlot.str_ylabel = 'Ca2+ Amplitude';

Opts.AstroPlot.FileName_Day = sprintf('Amplitude - Baselines vs SD - Day');
Opts.AstroPlot.FileName_Night = sprintf('Amplitude - Baselines vs SD - Night');
Opts.AstroPlot.FilePath_Day = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Day);
Opts.AstroPlot.FilePath_Night = sprintf('%s\\%s', PlotPath, Opts.AstroPlot.FileName_Night);

Plot_EventsPerState_part4b_sub1 (Events_Amplitude_ACC, Events_Amplitude_BRC, MouseMeans_Amplitude_ACC, MouseMeans_Amplitude_BRC, AstroStatsQT, Opts);