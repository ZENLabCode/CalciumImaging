function Plot_EventsPerState_Baselines_barsMeanSTE (Events_Data_ACC, Events_Data_BrC, AstroStats)
% This function plots the results for Christina Astrocytes Analysis.
% The plot made is baselines ACC vs baselines BRC


Stats_Type = 'ttest2'; % 'ranksum' or 'ttest2'
if exist('AstroStats', 'var') == 0
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end
if isempty(AstroStats)
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end
PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';
if exist(PlotPath, 'dir') == 0
    PlotPath = pwd;
end

% Options
FLAG_Save = 1;
BP_Width = 0.5;

Opts.AstroPlot.FLAG_SortPValue = 0;
Plot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];

Comparisons = {[Plot_Positions(1),Plot_Positions(2)], [Plot_Positions(3),Plot_Positions(4)], [Plot_Positions(5),Plot_Positions(6)],...
    [Plot_Positions(7),Plot_Positions(8)], [Plot_Positions(9),Plot_Positions(10)], [Plot_Positions(11),Plot_Positions(12)]};

n_colors = 2;
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
Color_ACC = [1, 1, 0];
Color_BRC = [0, 0, 1];
PlotsTransparency = 0.5;
legend_labels = {'ACC', 'BRC'};


figure(); set(gcf,'position', get(0,'screensize'));


%% Event Rate
Plot_ymax = 0.1;

subplot(1, 3, 1);

AstroStatsQT = AstroStats.ERate;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*

GroupMeans = [nanmean(data_Day_ACC_Awake), nanmean(data_Day_BrC_Awake), ...
    nanmean(data_Night_ACC_Awake), nanmean(data_Night_BrC_Awake), ...
    nanmean(data_Day_ACC_NoNREM), nanmean(data_Day_BrC_NoNREM), ...
    nanmean(data_Night_ACC_NoNREM), nanmean(data_Night_BrC_NoNREM), ...
    nanmean(data_Day_ACC_REM), nanmean(data_Day_BrC_REM), ...
    nanmean(data_Night_ACC_REM), nanmean(data_Night_BrC_REM)];
GroupSTE = [nanstd(data_Day_ACC_Awake)./(sqrt(numel(data_Day_ACC_Awake))), nanstd(data_Day_BrC_Awake)./(sqrt(numel(data_Day_BrC_Awake))), ...
    nanstd(data_Night_ACC_Awake)./(sqrt(numel(data_Night_ACC_Awake))), nanstd(data_Night_BrC_Awake)./(sqrt(numel(data_Night_BrC_Awake))), ...
    nanstd(data_Day_ACC_NoNREM)./(sqrt(numel(data_Day_ACC_NoNREM))), nanstd(data_Day_BrC_NoNREM)./(sqrt(numel(data_Day_BrC_NoNREM))), ...
    nanstd(data_Night_ACC_NoNREM)./(sqrt(numel(data_Night_ACC_NoNREM))), nanstd(data_Night_BrC_NoNREM)./(sqrt(numel(data_Night_BrC_NoNREM))), ...
    nanstd(data_Day_ACC_REM)./(sqrt(numel(data_Day_ACC_REM))), nanstd(data_Day_BrC_REM)./(sqrt(numel(data_Day_BrC_REM))), ...
    nanstd(data_Night_ACC_REM)./(sqrt(numel(data_Night_ACC_REM))), nanstd(data_Night_BrC_REM)./(sqrt(numel(data_Night_BrC_REM)))];
n_groups = numel(GroupMeans);
    
hold on; box on; grid on;

% Plot
h_barplots = bar(Plot_Positions, GroupMeans);
errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:2:n_groups, :) = repmat(Color_ACC, numel(1:2:n_groups), 1);
h_barplots.CData(2:2:n_groups, :) = repmat(Color_BRC, numel(1:2:n_groups), 1);

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', Plot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz]')

% Legend
h_placeholder = bar(nan(2, n_colors));  % invisible placeholder
tmp_colors = [Color_ACC; Color_BRC];
for i=1:n_colors
    h_placeholder(i).FaceColor = tmp_colors(i,:);
end
hLG = legend(h_placeholder, legend_labels, 'location', 'northeast');

axis square;


%% Integrals
Plot_ymax = 140;

subplot(1, 3, 2);

AstroStatsQT = AstroStats.Integrals;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*

GroupMeans = [nanmean(data_Day_ACC_Awake), nanmean(data_Day_BrC_Awake), ...
    nanmean(data_Night_ACC_Awake), nanmean(data_Night_BrC_Awake), ...
    nanmean(data_Day_ACC_NoNREM), nanmean(data_Day_BrC_NoNREM), ...
    nanmean(data_Night_ACC_NoNREM), nanmean(data_Night_BrC_NoNREM), ...
    nanmean(data_Day_ACC_REM), nanmean(data_Day_BrC_REM), ...
    nanmean(data_Night_ACC_REM), nanmean(data_Night_BrC_REM)];
GroupSTE = [nanstd(data_Day_ACC_Awake)./(sqrt(numel(data_Day_ACC_Awake))), nanstd(data_Day_BrC_Awake)./(sqrt(numel(data_Day_BrC_Awake))), ...
    nanstd(data_Night_ACC_Awake)./(sqrt(numel(data_Night_ACC_Awake))), nanstd(data_Night_BrC_Awake)./(sqrt(numel(data_Night_BrC_Awake))), ...
    nanstd(data_Day_ACC_NoNREM)./(sqrt(numel(data_Day_ACC_NoNREM))), nanstd(data_Day_BrC_NoNREM)./(sqrt(numel(data_Day_BrC_NoNREM))), ...
    nanstd(data_Night_ACC_NoNREM)./(sqrt(numel(data_Night_ACC_NoNREM))), nanstd(data_Night_BrC_NoNREM)./(sqrt(numel(data_Night_BrC_NoNREM))), ...
    nanstd(data_Day_ACC_REM)./(sqrt(numel(data_Day_ACC_REM))), nanstd(data_Day_BrC_REM)./(sqrt(numel(data_Day_BrC_REM))), ...
    nanstd(data_Night_ACC_REM)./(sqrt(numel(data_Night_ACC_REM))), nanstd(data_Night_BrC_REM)./(sqrt(numel(data_Night_BrC_REM)))];
n_groups = numel(GroupMeans);

hold on; box on; grid on;

% Plot
h_barplots = bar(Plot_Positions, GroupMeans);
errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:2:n_groups, :) = repmat(Color_ACC, numel(1:2:n_groups), 1);
h_barplots.CData(2:2:n_groups, :) = repmat(Color_BRC, numel(1:2:n_groups), 1);

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', Plot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Integral')
title('Events Integrals')

axis square;

%% Amplitude
Plot_ymax = 60;

subplot(1, 3, 3);

AstroStatsQT = AstroStats.Amplitude;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*

GroupMeans = [nanmean(data_Day_ACC_Awake), nanmean(data_Day_BrC_Awake), ...
    nanmean(data_Night_ACC_Awake), nanmean(data_Night_BrC_Awake), ...
    nanmean(data_Day_ACC_NoNREM), nanmean(data_Day_BrC_NoNREM), ...
    nanmean(data_Night_ACC_NoNREM), nanmean(data_Night_BrC_NoNREM), ...
    nanmean(data_Day_ACC_REM), nanmean(data_Day_BrC_REM), ...
    nanmean(data_Night_ACC_REM), nanmean(data_Night_BrC_REM)];
GroupSTE = [nanstd(data_Day_ACC_Awake)./(sqrt(numel(data_Day_ACC_Awake))), nanstd(data_Day_BrC_Awake)./(sqrt(numel(data_Day_BrC_Awake))), ...
    nanstd(data_Night_ACC_Awake)./(sqrt(numel(data_Night_ACC_Awake))), nanstd(data_Night_BrC_Awake)./(sqrt(numel(data_Night_BrC_Awake))), ...
    nanstd(data_Day_ACC_NoNREM)./(sqrt(numel(data_Day_ACC_NoNREM))), nanstd(data_Day_BrC_NoNREM)./(sqrt(numel(data_Day_BrC_NoNREM))), ...
    nanstd(data_Night_ACC_NoNREM)./(sqrt(numel(data_Night_ACC_NoNREM))), nanstd(data_Night_BrC_NoNREM)./(sqrt(numel(data_Night_BrC_NoNREM))), ...
    nanstd(data_Day_ACC_REM)./(sqrt(numel(data_Day_ACC_REM))), nanstd(data_Day_BrC_REM)./(sqrt(numel(data_Day_BrC_REM))), ...
    nanstd(data_Night_ACC_REM)./(sqrt(numel(data_Night_ACC_REM))), nanstd(data_Night_BrC_REM)./(sqrt(numel(data_Night_BrC_REM)))];
n_groups = numel(GroupMeans);

hold on; box on; grid on;

% Plot
h_barplots = bar(Plot_Positions, GroupMeans);
errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:2:n_groups, :) = repmat(Color_ACC, numel(1:2:n_groups), 1);
h_barplots.CData(2:2:n_groups, :) = repmat(Color_BRC, numel(1:2:n_groups), 1);

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', Plot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Amplitude (dF/F)')
title('Events Amplitude')

axis square; 

%% Save Figure
FileName = sprintf('ACC vs BrC - Baselines Barplots');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    fprintf('Saving "%s" in %s.\n\n', FileName, PlotPath);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


