function Plot_EventsPerState_barsMeanSTE_sub2 (Events_QT_ACC, Events_QT_BRC, MouseMeans_QT_ACC, MouseMeans_QT_BRC, AstroStatsQT, Opts)
% This function - a sub-function to Plot_EventsPerState_barsMeanSTE - 
% plots the barplots of the Post-SleepDeprivation condition values,
% relative to the baselines values.


%% Options
Color_Awake = Opts.AstroPlot.Color_Awake;
Color_NONREM = Opts.AstroPlot.Color_NONREM;
Color_REM = Opts.AstroPlot.Color_REM;
Color_Baseline_ACC = Opts.AstroPlot.Color_Baseline_ACC;
Color_SD1_ACC = Opts.AstroPlot.Color_SD1_ACC;
Color_SD2_ACC = Opts.AstroPlot.Color_SD2_ACC;
Color_SD3_ACC = Opts.AstroPlot.Color_SD3_ACC;
Color_Baseline_BRC = Opts.AstroPlot.Color_Baseline_BRC;
Color_SD1_BRC = Opts.AstroPlot.Color_SD1_BRC;
Color_SD2_BRC = Opts.AstroPlot.Color_SD2_BRC;
Color_SD3_BRC = Opts.AstroPlot.Color_SD3_BRC;

FLAG_Show_MouseMeans = Opts.AstroPlot.FLAG_Show_MouseMeans;

n_colors = 2;
% legend_labels = {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'};
legend_labels = {'ACC Baseline', 'BRC Baseline'};


%% Initialize Data
MouseMeans_QT_ACC_Awake = [MouseMeans_QT_ACC.Awake];
MouseMeans_QT_ACC_NREM = [MouseMeans_QT_ACC.NREM];
MouseMeans_QT_ACC_REM = [MouseMeans_QT_ACC.REM];
MouseMeans_QT_BRC_Awake = [MouseMeans_QT_BRC.Awake];
MouseMeans_QT_BRC_NREM = [MouseMeans_QT_BRC.NREM];
MouseMeans_QT_BRC_REM = [MouseMeans_QT_BRC.REM];

keyboard

% Compute Means of the Sleep Deprivation, relative to the Baselines
[SD_Mean_ACC_Awake, BaselineMeanDay_ACC_Awake, BaselineSTE_ACC_Awake] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_ACC_Awake);
[SD_Mean_ACC_NREM, BaselineMeanDay_ACC_NREM, BaselineSTE_ACC_NREM] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_ACC_NREM);
[SD_Mean_ACC_REM, BaselineMeanDay_ACC_REM, BaselineSTE_ACC_REM] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_ACC_REM);
[SD_Mean_BRC_Awake, BaselineMeanDay_BRC_Awake, BaselineSTE_BRC_Awake] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_BRC_Awake);
[SD_Mean_BRC_NREM, BaselineMeanDay_BRC_NREM, BaselineSTE_BRC_NREM] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_BRC_NREM);
[SD_Mean_BRC_REM, BaselineMeanDay_BRC_REM, BaselineSTE_BRC_REM] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT_BRC_REM);


% Plot bars positions and comparisons between bars
Plot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];

% The comparisons between columns to show in the significance of. Each
% value is the position of the corresponding boxplot
if Opts.AstroPlot.FLAG_all_comparisons == 1
    Comparisons = {[Plot_Positions(1),Plot_Positions(2)], [Plot_Positions(1),Plot_Positions(3)], [Plot_Positions(1),Plot_Positions(4)], [Plot_Positions(2),Plot_Positions(3)], [Plot_Positions(2),Plot_Positions(4)], [Plot_Positions(3),Plot_Positions(4)],...
        [Plot_Positions(5),Plot_Positions(6)], [Plot_Positions(5),Plot_Positions(7)], [Plot_Positions(5),Plot_Positions(8)], [Plot_Positions(6),Plot_Positions(7)], [Plot_Positions(6),Plot_Positions(8)], [Plot_Positions(7),Plot_Positions(8)],...
        [Plot_Positions(9),Plot_Positions(10)], [Plot_Positions(9),Plot_Positions(11)], [Plot_Positions(9),Plot_Positions(12)], [Plot_Positions(10),Plot_Positions(11)], [Plot_Positions(10),Plot_Positions(12)], [Plot_Positions(11),Plot_Positions(12)],...
        [Plot_Positions(13),Plot_Positions(14)], [Plot_Positions(13),Plot_Positions(15)], [Plot_Positions(13),Plot_Positions(16)], [Plot_Positions(14),Plot_Positions(15)], [Plot_Positions(14),Plot_Positions(16)], [Plot_Positions(15),Plot_Positions(16)],...
        [Plot_Positions(17),Plot_Positions(18)], [Plot_Positions(17),Plot_Positions(19)], [Plot_Positions(17),Plot_Positions(20)], [Plot_Positions(18),Plot_Positions(19)], [Plot_Positions(18),Plot_Positions(20)], [Plot_Positions(19),Plot_Positions(20)],...
        [Plot_Positions(21),Plot_Positions(22)], [Plot_Positions(21),Plot_Positions(23)], [Plot_Positions(21),Plot_Positions(24)], [Plot_Positions(22),Plot_Positions(23)], [Plot_Positions(22),Plot_Positions(24)], [Plot_Positions(23),Plot_Positions(24)]};
else
    Comparisons = {[Plot_Positions(1),Plot_Positions(2)], [Plot_Positions(1),Plot_Positions(3)], [Plot_Positions(1),Plot_Positions(4)],...
        [Plot_Positions(5),Plot_Positions(6)], [Plot_Positions(5),Plot_Positions(7)], [Plot_Positions(5),Plot_Positions(8)],...
        [Plot_Positions(9),Plot_Positions(10)], [Plot_Positions(9),Plot_Positions(11)], [Plot_Positions(9),Plot_Positions(12)],...
        [Plot_Positions(13),Plot_Positions(14)], [Plot_Positions(13),Plot_Positions(15)], [Plot_Positions(13),Plot_Positions(16)],...
        [Plot_Positions(17),Plot_Positions(18)], [Plot_Positions(17),Plot_Positions(19)], [Plot_Positions(17),Plot_Positions(20)],...
        [Plot_Positions(21),Plot_Positions(22)], [Plot_Positions(21),Plot_Positions(23)], [Plot_Positions(21),Plot_Positions(24)]};
end

GroupMeans = [nanmean(SD_Mean_ACC_Awake.Day_1), nanmean(SD_Mean_ACC_Awake.Day_2), nanmean(SD_Mean_ACC_Awake.Day_3), ...
    nanmean(SD_Mean_ACC_Awake.Night_1), nanmean(SD_Mean_ACC_Awake.Night_2), nanmean(SD_Mean_ACC_Awake.Night_3), ...
    nanmean(SD_Mean_BRC_Awake.Day_1), nanmean(SD_Mean_BRC_Awake.Day_2), nanmean(SD_Mean_BRC_Awake.Day_3), ...
    nanmean(SD_Mean_BRC_Awake.Night_1), nanmean(SD_Mean_BRC_Awake.Night_2), nanmean(SD_Mean_BRC_Awake.Night_3)];

GroupSTE = [nanstd(SD_Mean_ACC_Awake.Day_1)./(sqrt(numel(SD_Mean_ACC_Awake.Day_1))), nanstd(SD_Mean_ACC_Awake.Day_2)./(sqrt(numel(SD_Mean_ACC_Awake.Day_2))), nanstd(SD_Mean_ACC_Awake.Day_3)./(sqrt(numel(SD_Mean_ACC_Awake.Day_3))), ...
    nanstd(SD_Mean_ACC_Awake.Night_1)./(sqrt(numel(SD_Mean_ACC_Awake.Night_1))), nanstd(SD_Mean_ACC_Awake.Night_2)./(sqrt(numel(SD_Mean_ACC_Awake.Night_2))), nanstd(SD_Mean_ACC_Awake.Night_3)./(sqrt(numel(SD_Mean_ACC_Awake.Night_3))), ...
    nanstd(SD_Mean_BRC_Awake.Day_1)./(sqrt(numel(SD_Mean_BRC_Awake.Day_1))), nanstd(SD_Mean_BRC_Awake.Day_2)./(sqrt(numel(SD_Mean_BRC_Awake.Day_2))), nanstd(SD_Mean_BRC_Awake.Day_3)./(sqrt(numel(SD_Mean_BRC_Awake.Day_3))), ...
    nanstd(SD_Mean_BRC_Awake.Night_1)./(sqrt(numel(SD_Mean_BRC_Awake.Night_1))), nanstd(SD_Mean_BRC_Awake.Night_2)./(sqrt(numel(SD_Mean_BRC_Awake.Night_2))), nanstd(SD_Mean_BRC_Awake.Night_3)./(sqrt(numel(SD_Mean_BRC_Awake.Night_3)))];

Plot_Positions = [1, 1.5, 2, 3.5, 4, 4.5, 6, 6.5, 7, 8.5, 9, 9.5];


%% Plot 1: Day
figure(); set(gcf,'position', get(0,'screensize'));
n_groups = numel(GroupMeans);

% Array of P-values, 1 for each comparison
if Opts.AstroPlot.FLAG_all_comparisons == 1
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue];
end

hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');

% Plot
h_barplots = bar(Plot_Positions, GroupMeans);
errorbar(Plot_Positions,  GroupMeans,  GroupSTE, '.k', 'LineWidth', 1)

% Color Bars
h_barplots.FaceColor = 'flat';
h_barplots.CData(1:1:(n_groups/2), :) = repmat(Color_Baseline_ACC, n_groups/2, 1);
h_barplots.CData((n_groups/2)+1:1:(n_groups), :) = repmat(Color_Baseline_BRC, n_groups/2, 1);

% Scatter Plot of Mouse Means
if FLAG_Show_MouseMeans == 1

    tmp_n = numel(MouseMeans_QT_ACC_Awake([1, 2, 3], :));
    tmp_n1 = numel(MouseMeans_QT_ACC_Awake(1, :));
    
    h_scatter_SD1_Day_ACC_Awake = scatter(ones(1, tmp_n1).*Plot_Positions(1), [SD_Mean_ACC_Awake.Day_1], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_Day_ACC_NREM = scatter(ones(1, tmp_n1).*Plot_Positions(2), [SD_Mean_ACC_Awake.Day_2], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_Day_ACC_REM = scatter(ones(1, tmp_n1).*Plot_Positions(3), [SD_Mean_ACC_Awake.Day_3], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_SD1_Night_ACC_Awake = scatter(ones(1, tmp_n1).*Plot_Positions(4), [SD_Mean_ACC_Awake.Night_1], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_Night_ACC_NREM = scatter(ones(1, tmp_n1).*Plot_Positions(5), [SD_Mean_ACC_Awake.Night_2], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_Night_ACC_REM = scatter(ones(1, tmp_n1).*Plot_Positions(6), [SD_Mean_ACC_Awake.Night_3], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_SD1_Day_BRC_Awake = scatter(ones(1, tmp_n1).*Plot_Positions(7), [SD_Mean_BRC_Awake.Day_1], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_Day_BRC_NREM = scatter(ones(1, tmp_n1).*Plot_Positions(8), [SD_Mean_BRC_Awake.Day_2], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_Day_BRC_REM = scatter(ones(1, tmp_n1).*Plot_Positions(9), [SD_Mean_BRC_Awake.Day_3], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3
    
    h_scatter_SD1_Night_BRC_Awake = scatter(ones(1, tmp_n1).*Plot_Positions(10), [SD_Mean_BRC_Awake.Night_1], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD1
    h_scatter_SD2_Night_BRC_NREM = scatter(ones(1, tmp_n1).*Plot_Positions(11), [SD_Mean_BRC_Awake.Night_2], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD2
    h_scatter_SD3_Night_BRC_REM = scatter(ones(1, tmp_n1).*Plot_Positions(12), [SD_Mean_BRC_Awake.Night_3], Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', 'k'); % SD3

end

ylim([0, Opts.AstroPlot.Plot_YMax])

% Add significancy markers
% h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

% Ticks
set(gca, 'xTick', Plot_Positions(2:3:end));
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});

% Labels & title
ylabel(Opts.AstroPlot.str_ylabel)
title(Opts.AstroPlot.str_title_Day)

% Legend
n_colors = 2;
h_placeholder = bar(nan(2, n_colors));  % invisible placeholder
% tmp_colors = [Color_Baseline_ACC; Color_SD1_ACC; Color_SD2_ACC; Color_SD3_ACC;...
%     Color_Baseline_BRC; Color_SD1_BRC; Color_SD2_BRC; Color_SD3_BRC];
tmp_colors  = [Color_Baseline_ACC; Color_Baseline_BRC];
for i=1:n_colors
    h_placeholder(i).FaceColor = tmp_colors(i,:);
end
hLG = legend(h_placeholder, legend_labels, 'location', 'northeast');

% Save
if Opts.AstroPlot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(Opts.AstroPlot.FilePath_Day, '.eps'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.jpg'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.fig'))
    close gcf
end
