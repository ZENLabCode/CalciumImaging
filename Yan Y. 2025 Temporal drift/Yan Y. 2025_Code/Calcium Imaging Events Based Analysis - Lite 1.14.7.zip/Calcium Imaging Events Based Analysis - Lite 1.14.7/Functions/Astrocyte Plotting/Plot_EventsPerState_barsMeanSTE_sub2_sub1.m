function [SD_Mean, BaselineMeanDay, BaselineSTE] = Plot_EventsPerState_barsMeanSTE_sub2_sub1 (MouseMeans_QT)
% This function is a sub-sub function to Plot_EventsPerState_barsMeanSTE.
% It serves to compute the means of the Sleep Deprivation, respect to the
% baseline values..

BaselineMeanDay = (MouseMeans_QT(1, :) + MouseMeans_QT(3, :) + MouseMeans_QT(5, :))./3;
BaselineSTE = sqrt(( abs(BaselineMeanDay - MouseMeans_QT(1, :)) + abs(BaselineMeanDay - MouseMeans_QT(3, :)) + abs(BaselineMeanDay - MouseMeans_QT(5, :)) )./3)./sqrt(3);

SD_Mean.Day_1 = MouseMeans_QT(8, :)./BaselineMeanDay;
SD_Mean.Day_2 = MouseMeans_QT(10, :)./BaselineMeanDay;
SD_Mean.Day_3 = MouseMeans_QT(12, :)./BaselineMeanDay;
SD_Mean.Night_1 = MouseMeans_QT(9, :)./BaselineMeanDay;
SD_Mean.Night_2 = MouseMeans_QT(11, :)./BaselineMeanDay;
SD_Mean.Night_3 = MouseMeans_QT(13, :)./BaselineMeanDay;



