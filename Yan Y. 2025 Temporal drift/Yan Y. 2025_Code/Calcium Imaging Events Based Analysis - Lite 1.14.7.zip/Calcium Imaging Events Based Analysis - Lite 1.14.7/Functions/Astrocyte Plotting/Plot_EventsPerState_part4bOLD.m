function Plot_EventsPerState_part4b (Events_Data_ACC, Events_Data_BrC, AstroStats)
% This function plots the results for Christina Astrocytes Analysis.
% The plot is Events Rate: Baseline vs SD Recovery, ACC and BRC together, 2
% separate plots for day and night

if exist('AstroStats', 'var') == 0
    AstroStats = Astrocyte_Stats_Ranksum (Events_Data_ACC, Events_Data_BrC);
%      AstroStats = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC);
end
if isempty(AstroStats)
    AstroStats = Astrocyte_Stats_Ranksum (Events_Data_ACC, Events_Data_BrC);
%     AstroStats = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC);
end

PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';
if exist(PlotPath, 'dir') == 0
    PlotPath = pwd;
end

FLAG_Save = 1;

PlotsTransparency = 0.5;
MarkerSize_Significance = 80;
ScatterDotLineWidth = 0.25;
ScatterDotArea = 18;

Color_Awake = [0,0,0.5];
Color_NONREM = [0.5,0,0];
Color_REM = [0,0.5,0];
Color_Baseline_ACC = [0.5,0,0];
Color_SD1_ACC = [1,0.66,0.66];
Color_SD2_ACC = [1,0.33,0.33];
Color_SD3_ACC = [1,0,0];
Color_Baseline_BRC = [0,0,0.5];
Color_SD1_BRC = [0.66,0.66,1];
Color_SD2_BRC = [0.33,0.33,1];
Color_SD3_BRC = [0,0,1];

FLAG_all_comparisons = 0; % Display all the comparisons (set = 1), or just with baseline values?

FLAG_SortPValue = 0;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%   EVENTS RATE     %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% GET DATA


% ACC
tmp_Data1_Base_Awake_ACC = [Events_Data_ACC(1).EventRate.Awake];
tmp_Data2_Base_Awake_ACC = [Events_Data_ACC(2).EventRate.Awake];
tmp_Data3_Base_Awake_ACC = [Events_Data_ACC(3).EventRate.Awake];
tmp_Data4_Base_Awake_ACC = [Events_Data_ACC(4).EventRate.Awake];
tmp_Data5_Base_Awake_ACC = [Events_Data_ACC(5).EventRate.Awake];
tmp_Data6_Base_Awake_ACC = [Events_Data_ACC(6).EventRate.Awake];
tmp_Data1_SD_Awake_ACC = [Events_Data_ACC(8).EventRate.Awake];
tmp_Data2_SD_Awake_ACC = [Events_Data_ACC(9).EventRate.Awake];
tmp_Data3_SD_Awake_ACC = [Events_Data_ACC(10).EventRate.Awake];
tmp_Data4_SD_Awake_ACC = [Events_Data_ACC(11).EventRate.Awake];
tmp_Data5_SD_Awake_ACC = [Events_Data_ACC(12).EventRate.Awake];
tmp_Data6_SD_Awake_ACC = [Events_Data_ACC(13).EventRate.Awake];
data_Day_Base_Awake_ACC = [tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC];
data_Night_Base_Awake_ACC = [tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC];

tmp_Data1_Base_NoNREM_ACC = [Events_Data_ACC(1).EventRate.NoNREM];
tmp_Data2_Base_NoNREM_ACC = [Events_Data_ACC(2).EventRate.NoNREM];
tmp_Data3_Base_NoNREM_ACC = [Events_Data_ACC(3).EventRate.NoNREM];
tmp_Data4_Base_NoNREM_ACC = [Events_Data_ACC(4).EventRate.NoNREM];
tmp_Data5_Base_NoNREM_ACC = [Events_Data_ACC(5).EventRate.NoNREM];
tmp_Data6_Base_NoNREM_ACC = [Events_Data_ACC(6).EventRate.NoNREM];
tmp_Data1_SD_NoNREM_ACC = [Events_Data_ACC(8).EventRate.NoNREM];
tmp_Data2_SD_NoNREM_ACC = [Events_Data_ACC(9).EventRate.NoNREM];
tmp_Data3_SD_NoNREM_ACC = [Events_Data_ACC(10).EventRate.NoNREM];
tmp_Data4_SD_NoNREM_ACC = [Events_Data_ACC(11).EventRate.NoNREM];
tmp_Data5_SD_NoNREM_ACC = [Events_Data_ACC(12).EventRate.NoNREM];
tmp_Data6_SD_NoNREM_ACC = [Events_Data_ACC(13).EventRate.NoNREM];
data_Day_Base_NoNREM_ACC = [tmp_Data1_Base_NoNREM_ACC, tmp_Data3_Base_NoNREM_ACC, tmp_Data5_Base_NoNREM_ACC];
data_Night_Base_NoNREM_ACC = [tmp_Data2_Base_NoNREM_ACC, tmp_Data4_Base_NoNREM_ACC, tmp_Data6_Base_NoNREM_ACC];

tmp_Data1_Base_REM_ACC = [Events_Data_ACC(1).EventRate.REM];
tmp_Data2_Base_REM_ACC = [Events_Data_ACC(2).EventRate.REM];
tmp_Data3_Base_REM_ACC = [Events_Data_ACC(3).EventRate.REM];
tmp_Data4_Base_REM_ACC = [Events_Data_ACC(4).EventRate.REM];
tmp_Data5_Base_REM_ACC = [Events_Data_ACC(5).EventRate.REM];
tmp_Data6_Base_REM_ACC = [Events_Data_ACC(6).EventRate.REM];
tmp_Data1_SD_REM_ACC = [Events_Data_ACC(8).EventRate.REM];
tmp_Data2_SD_REM_ACC = [Events_Data_ACC(9).EventRate.REM];
tmp_Data3_SD_REM_ACC = [Events_Data_ACC(10).EventRate.REM];
tmp_Data4_SD_REM_ACC = [Events_Data_ACC(11).EventRate.REM];
tmp_Data5_SD_REM_ACC = [Events_Data_ACC(12).EventRate.REM];
tmp_Data6_SD_REM_ACC = [Events_Data_ACC(13).EventRate.REM];
data_Day_Base_REM_ACC = [tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC];
data_Night_Base_REM_ACC = [tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC];

MouseMeans_Awake_ACC = NaN(n_sessions, n_mice);
MouseMeans_NREM_ACC = NaN(n_sessions, n_mice);
MouseMeans_REM_ACC = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_ACC(i_session).MouseMeans.EventRate];
    MouseMeans_Awake_ACC(i_session, :) = [tmp.Awake];
    MouseMeans_NREM_ACC(i_session, :) = [tmp.NoNREM];
    MouseMeans_REM_ACC(i_session, :) = [tmp.REM];
end

% Barrel Cortex
tmp_Data1_Base_Awake_BRC = [Events_Data_BrC(1).EventRate.Awake];
tmp_Data2_Base_Awake_BRC = [Events_Data_BrC(2).EventRate.Awake];
tmp_Data3_Base_Awake_BRC = [Events_Data_BrC(3).EventRate.Awake];
tmp_Data4_Base_Awake_BRC = [Events_Data_BrC(4).EventRate.Awake];
tmp_Data5_Base_Awake_BRC = [Events_Data_BrC(5).EventRate.Awake];
tmp_Data6_Base_Awake_BRC = [Events_Data_BrC(6).EventRate.Awake];
tmp_Data1_SD_Awake_BRC = [Events_Data_BrC(8).EventRate.Awake];
tmp_Data2_SD_Awake_BRC = [Events_Data_BrC(9).EventRate.Awake];
tmp_Data3_SD_Awake_BRC = [Events_Data_BrC(10).EventRate.Awake];
tmp_Data4_SD_Awake_BRC = [Events_Data_BrC(11).EventRate.Awake];
tmp_Data5_SD_Awake_BRC = [Events_Data_BrC(12).EventRate.Awake];
tmp_Data6_SD_Awake_BRC = [Events_Data_BrC(13).EventRate.Awake];
data_Day_Base_Awake_BRC = [tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC];
data_Night_Base_Awake_BRC = [tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC];

tmp_Data1_Base_NoNREM_BRC = [Events_Data_BrC(1).EventRate.NoNREM];
tmp_Data2_Base_NoNREM_BRC = [Events_Data_BrC(2).EventRate.NoNREM];
tmp_Data3_Base_NoNREM_BRC = [Events_Data_BrC(3).EventRate.NoNREM];
tmp_Data4_Base_NoNREM_BRC = [Events_Data_BrC(4).EventRate.NoNREM];
tmp_Data5_Base_NoNREM_BRC = [Events_Data_BrC(5).EventRate.NoNREM];
tmp_Data6_Base_NoNREM_BRC = [Events_Data_BrC(6).EventRate.NoNREM];
tmp_Data1_SD_NoNREM_BRC = [Events_Data_BrC(8).EventRate.NoNREM];
tmp_Data2_SD_NoNREM_BRC = [Events_Data_BrC(9).EventRate.NoNREM];
tmp_Data3_SD_NoNREM_BRC = [Events_Data_BrC(10).EventRate.NoNREM];
tmp_Data4_SD_NoNREM_BRC = [Events_Data_BrC(11).EventRate.NoNREM];
tmp_Data5_SD_NoNREM_BRC = [Events_Data_BrC(12).EventRate.NoNREM];
tmp_Data6_SD_NoNREM_BRC = [Events_Data_BrC(13).EventRate.NoNREM];
data_Day_Base_NoNREM_BRC = [tmp_Data1_Base_NoNREM_BRC, tmp_Data3_Base_NoNREM_BRC, tmp_Data5_Base_NoNREM_BRC];
data_Night_Base_NoNREM_BRC = [tmp_Data2_Base_NoNREM_BRC, tmp_Data4_Base_NoNREM_BRC, tmp_Data6_Base_NoNREM_BRC];

tmp_Data1_Base_REM_BRC = [Events_Data_BrC(1).EventRate.REM];
tmp_Data2_Base_REM_BRC = [Events_Data_BrC(2).EventRate.REM];
tmp_Data3_Base_REM_BRC = [Events_Data_BrC(3).EventRate.REM];
tmp_Data4_Base_REM_BRC = [Events_Data_BrC(4).EventRate.REM];
tmp_Data5_Base_REM_BRC = [Events_Data_BrC(5).EventRate.REM];
tmp_Data6_Base_REM_BRC = [Events_Data_BrC(6).EventRate.REM];
tmp_Data1_SD_REM_BRC = [Events_Data_BrC(8).EventRate.REM];
tmp_Data2_SD_REM_BRC = [Events_Data_BrC(9).EventRate.REM];
tmp_Data3_SD_REM_BRC = [Events_Data_BrC(10).EventRate.REM];
tmp_Data4_SD_REM_BRC = [Events_Data_BrC(11).EventRate.REM];
tmp_Data5_SD_REM_BRC = [Events_Data_BrC(12).EventRate.REM];
tmp_Data6_SD_REM_BRC = [Events_Data_BrC(13).EventRate.REM];
data_Day_Base_REM_BRC = [tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC];
data_Night_Base_REM_BRC = [tmp_Data2_Base_REM_BRC, tmp_Data4_Base_REM_BRC, tmp_Data6_Base_REM_BRC];

MouseMeans_Awake_BRC = NaN(n_sessions, n_mice);
MouseMeans_NREM_BRC = NaN(n_sessions, n_mice);
MouseMeans_REM_BRC = NaN(n_sessions, n_mice);
for i_session = 1:n_sessions
    tmp = [Events_Data_BrC(i_session).MouseMeans.EventRate];
    MouseMeans_Awake_BRC(i_session, :) = [tmp.Awake];
    MouseMeans_NREM_BRC(i_session, :) = [tmp.NoNREM];
    MouseMeans_REM_BRC(i_session, :) = [tmp.REM];
end


% Plot bars positions and comparisons between bars
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];

% The comparisons between columns to show in the significance of. Each
% value is the position of the corresponding boxplot
if FLAG_all_comparisons == 1
    Comparisons = {[BoxPlot_Positions(1),BoxPlot_Positions(2)], [BoxPlot_Positions(1),BoxPlot_Positions(3)], [BoxPlot_Positions(1),BoxPlot_Positions(4)], [BoxPlot_Positions(2),BoxPlot_Positions(3)], [BoxPlot_Positions(2),BoxPlot_Positions(4)], [BoxPlot_Positions(3),BoxPlot_Positions(4)],...
        [BoxPlot_Positions(5),BoxPlot_Positions(6)], [BoxPlot_Positions(5),BoxPlot_Positions(7)], [BoxPlot_Positions(5),BoxPlot_Positions(8)], [BoxPlot_Positions(6),BoxPlot_Positions(7)], [BoxPlot_Positions(6),BoxPlot_Positions(8)], [BoxPlot_Positions(7),BoxPlot_Positions(8)],...
        [BoxPlot_Positions(9),BoxPlot_Positions(10)], [BoxPlot_Positions(9),BoxPlot_Positions(11)], [BoxPlot_Positions(9),BoxPlot_Positions(12)], [BoxPlot_Positions(10),BoxPlot_Positions(11)], [BoxPlot_Positions(10),BoxPlot_Positions(12)], [BoxPlot_Positions(11),BoxPlot_Positions(12)],...
        [BoxPlot_Positions(13),BoxPlot_Positions(14)], [BoxPlot_Positions(13),BoxPlot_Positions(15)], [BoxPlot_Positions(13),BoxPlot_Positions(16)], [BoxPlot_Positions(14),BoxPlot_Positions(15)], [BoxPlot_Positions(14),BoxPlot_Positions(16)], [BoxPlot_Positions(15),BoxPlot_Positions(16)],...
        [BoxPlot_Positions(17),BoxPlot_Positions(18)], [BoxPlot_Positions(17),BoxPlot_Positions(19)], [BoxPlot_Positions(17),BoxPlot_Positions(20)], [BoxPlot_Positions(18),BoxPlot_Positions(19)], [BoxPlot_Positions(18),BoxPlot_Positions(20)], [BoxPlot_Positions(19),BoxPlot_Positions(20)],...
        [BoxPlot_Positions(21),BoxPlot_Positions(22)], [BoxPlot_Positions(21),BoxPlot_Positions(23)], [BoxPlot_Positions(21),BoxPlot_Positions(24)], [BoxPlot_Positions(22),BoxPlot_Positions(23)], [BoxPlot_Positions(22),BoxPlot_Positions(24)], [BoxPlot_Positions(23),BoxPlot_Positions(24)]};
else
    Comparisons = {[BoxPlot_Positions(1),BoxPlot_Positions(2)], [BoxPlot_Positions(1),BoxPlot_Positions(3)], [BoxPlot_Positions(1),BoxPlot_Positions(4)],...
        [BoxPlot_Positions(5),BoxPlot_Positions(6)], [BoxPlot_Positions(5),BoxPlot_Positions(7)], [BoxPlot_Positions(5),BoxPlot_Positions(8)],...
        [BoxPlot_Positions(9),BoxPlot_Positions(10)], [BoxPlot_Positions(9),BoxPlot_Positions(11)], [BoxPlot_Positions(9),BoxPlot_Positions(12)],...
        [BoxPlot_Positions(13),BoxPlot_Positions(14)], [BoxPlot_Positions(13),BoxPlot_Positions(15)], [BoxPlot_Positions(13),BoxPlot_Positions(16)],...
        [BoxPlot_Positions(17),BoxPlot_Positions(18)], [BoxPlot_Positions(17),BoxPlot_Positions(19)], [BoxPlot_Positions(17),BoxPlot_Positions(20)],...
        [BoxPlot_Positions(21),BoxPlot_Positions(22)], [BoxPlot_Positions(21),BoxPlot_Positions(23)], [BoxPlot_Positions(21),BoxPlot_Positions(24)]};
end


%% Plot 1: Events Rate - Day
figure(); set(gcf,'position', get(0,'screensize'));
Plot_YMax = 0.16;

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM

BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data1_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data3_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data5_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Day_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data1_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data3_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data5_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Day_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data1_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data3_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data5_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Day_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data1_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data3_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data5_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Day_Base_REM_ACC)), 18*ones(1, numel(tmp_Data1_SD_REM_ACC)), 19*ones(1, numel(tmp_Data3_SD_REM_ACC)), 20*ones(1, numel(tmp_Data5_SD_REM_ACC)), ...
    21*ones(1, numel(data_Day_Base_REM_BRC)), 22*ones(1, numel(tmp_Data1_SD_REM_BRC)), 23*ones(1, numel(tmp_Data3_SD_REM_BRC)), 24*ones(1, numel(tmp_Data5_SD_REM_BRC))];

% The actual data distributions
EventsRate_BoxPlot = [data_Day_Base_Awake_ACC, tmp_Data1_SD_Awake_ACC, tmp_Data3_SD_Awake_ACC, tmp_Data5_SD_Awake_ACC, ...
    data_Day_Base_Awake_BRC, tmp_Data1_SD_Awake_BRC, tmp_Data3_SD_Awake_BRC, tmp_Data5_SD_Awake_BRC, ...
    data_Day_Base_NoNREM_ACC, tmp_Data1_SD_NoNREM_ACC, tmp_Data3_SD_NoNREM_ACC, tmp_Data5_SD_NoNREM_ACC, ...
    data_Day_Base_NoNREM_BRC, tmp_Data1_SD_NoNREM_BRC, tmp_Data3_SD_NoNREM_BRC, tmp_Data5_SD_NoNREM_BRC, ...
    data_Day_Base_REM_ACC, tmp_Data1_SD_REM_ACC, tmp_Data3_SD_REM_ACC, tmp_Data5_SD_REM_ACC, ...
    data_Day_Base_REM_BRC, tmp_Data1_SD_REM_BRC, tmp_Data3_SD_REM_BRC, tmp_Data5_SD_REM_BRC];

% Array of P-values, 1 for each comparison
if FLAG_all_comparisons == 1
    PVal_Array = [AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.ACC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.BRC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.ACC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.BRC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.ACC.Day.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStats.ERate.BRC.Day.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStats.ERate.BRC.Day.REM.Baseline_vs_SD72h.Pvalue];
end
hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');

% Scatter Plot of Mouse Means
tmp_n = numel(MouseMeans_Awake_ACC(1:3, :));
tmp_n1 = numel(MouseMeans_Awake_ACC(1, :));
h_scatter_Base_1 = scatter(ones(1, tmp_n).*BoxPlot_Positions(1), reshape(MouseMeans_Awake_ACC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(2), reshape(MouseMeans_Awake_ACC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD1
h_scatter_SD2_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(3), reshape(MouseMeans_Awake_ACC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(4), reshape(MouseMeans_Awake_ACC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD3

h_scatter_Base_2 = scatter(ones(1, tmp_n).*BoxPlot_Positions(5), reshape(MouseMeans_Awake_BRC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(6), reshape(MouseMeans_Awake_BRC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD1
h_scatter_SD2_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(7), reshape(MouseMeans_Awake_BRC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(8), reshape(MouseMeans_Awake_BRC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD3

h_scatter_Base_3 = scatter(ones(1, tmp_n).*BoxPlot_Positions(9), reshape(MouseMeans_NREM_ACC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(10), reshape(MouseMeans_NREM_ACC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD1
h_scatter_SD2_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(11), reshape(MouseMeans_NREM_ACC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(12), reshape(MouseMeans_NREM_ACC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD3

h_scatter_Base_4 = scatter(ones(1, tmp_n).*BoxPlot_Positions(13), reshape(MouseMeans_NREM_BRC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(14), reshape(MouseMeans_NREM_BRC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD1
h_scatter_SD2_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(15), reshape(MouseMeans_NREM_BRC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(16), reshape(MouseMeans_NREM_BRC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD3

h_scatter_Base_5 = scatter(ones(1, tmp_n).*BoxPlot_Positions(17), reshape(MouseMeans_REM_ACC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(18), reshape(MouseMeans_REM_ACC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD1
h_scatter_SD2_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(19), reshape(MouseMeans_REM_ACC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(20), reshape(MouseMeans_REM_ACC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD3

h_scatter_Base_6 = scatter(ones(1, tmp_n).*BoxPlot_Positions(21), reshape(MouseMeans_REM_BRC([1, 3, 5], :), [1, tmp_n]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(22), reshape(MouseMeans_REM_BRC(8, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD1
h_scatter_SD2_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(23), reshape(MouseMeans_REM_BRC(10, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(24), reshape(MouseMeans_REM_BRC(12, :), [1, tmp_n1]), ScatterDotArea, 'filled', 'LineWidth', ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD3



% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', PlotsTransparency);
end

% Add distribution of each mouse mean value.


ylim([0, Plot_YMax])
% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz] - Day - Baseline vs SD Recovery')

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

FileName = sprintf('Day - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);

if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


%% Plot 2: Events Rate - Night
figure(); set(gcf,'position', get(0,'screensize'));
Plot_YMax = 0.12;

% Plot first Awake, Night, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
BoxPlot_Groups = [1*ones(1, numel(data_Night_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data2_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data4_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data6_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Night_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data2_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data4_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data6_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Night_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data2_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data4_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data6_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Night_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data2_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data4_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data6_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Night_Base_REM_ACC)), 18*ones(1, numel(tmp_Data2_SD_REM_ACC)), 19*ones(1, numel(tmp_Data4_SD_REM_ACC)), 20*ones(1, numel(tmp_Data6_SD_REM_ACC)), ...
    21*ones(1, numel(data_Night_Base_REM_BRC)), 22*ones(1, numel(tmp_Data2_SD_REM_BRC)), 23*ones(1, numel(tmp_Data4_SD_REM_BRC)), 24*ones(1, numel(tmp_Data6_SD_REM_BRC))];

EventsRate_BoxPlot = [data_Night_Base_Awake_ACC, tmp_Data2_SD_Awake_ACC, tmp_Data4_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC, ...
    data_Night_Base_Awake_BRC, tmp_Data2_SD_Awake_BRC, tmp_Data4_SD_Awake_BRC, tmp_Data6_SD_Awake_BRC, ...
    data_Night_Base_NoNREM_ACC, tmp_Data2_SD_NoNREM_ACC, tmp_Data4_SD_NoNREM_ACC, tmp_Data6_SD_NoNREM_ACC, ...
    data_Night_Base_NoNREM_BRC, tmp_Data2_SD_NoNREM_BRC, tmp_Data4_SD_NoNREM_BRC, tmp_Data6_SD_NoNREM_BRC, ...
    data_Night_Base_REM_ACC, tmp_Data2_SD_REM_ACC, tmp_Data4_SD_REM_ACC, tmp_Data6_SD_REM_ACC, ...
    data_Night_Base_REM_BRC, tmp_Data2_SD_REM_BRC, tmp_Data4_SD_REM_BRC, tmp_Data6_SD_REM_BRC];
hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_YMax])


set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz] - Night - Baseline vs SD Recovery')

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

FileName = sprintf('Night - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);

if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%    INTEGRALS      %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% GET DATA
% ACC
tmp_Data1_Base_Awake_ACC = [Events_Data_ACC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base_Awake_ACC = [Events_Data_ACC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base_Awake_ACC = [Events_Data_ACC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base_Awake_ACC = [Events_Data_ACC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base_Awake_ACC = [Events_Data_ACC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base_Awake_ACC = [Events_Data_ACC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD_Awake_ACC = [Events_Data_ACC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD_Awake_ACC = [Events_Data_ACC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD_Awake_ACC = [Events_Data_ACC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD_Awake_ACC = [Events_Data_ACC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD_Awake_ACC = [Events_Data_ACC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD_Awake_ACC = [Events_Data_ACC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake_ACC = [tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC];
data_Night_Base_Awake_ACC = [tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC];

tmp_Data1_Base_NoNREM_ACC = [Events_Data_ACC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base_NoNREM_ACC = [Events_Data_ACC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base_NoNREM_ACC = [Events_Data_ACC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base_NoNREM_ACC = [Events_Data_ACC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base_NoNREM_ACC = [Events_Data_ACC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base_NoNREM_ACC = [Events_Data_ACC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD_NoNREM_ACC = [Events_Data_ACC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD_NoNREM_ACC = [Events_Data_ACC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD_NoNREM_ACC = [Events_Data_ACC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD_NoNREM_ACC = [Events_Data_ACC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD_NoNREM_ACC = [Events_Data_ACC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD_NoNREM_ACC = [Events_Data_ACC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM_ACC = [tmp_Data1_Base_NoNREM_ACC, tmp_Data3_Base_NoNREM_ACC, tmp_Data5_Base_NoNREM_ACC];
data_Night_Base_NoNREM_ACC = [tmp_Data2_Base_NoNREM_ACC, tmp_Data4_Base_NoNREM_ACC, tmp_Data6_Base_NoNREM_ACC];

tmp_Data1_Base_REM_ACC = [Events_Data_ACC(1).EventIntegral_Mean.REM];
tmp_Data2_Base_REM_ACC = [Events_Data_ACC(2).EventIntegral_Mean.REM];
tmp_Data3_Base_REM_ACC = [Events_Data_ACC(3).EventIntegral_Mean.REM];
tmp_Data4_Base_REM_ACC = [Events_Data_ACC(4).EventIntegral_Mean.REM];
tmp_Data5_Base_REM_ACC = [Events_Data_ACC(5).EventIntegral_Mean.REM];
tmp_Data6_Base_REM_ACC = [Events_Data_ACC(6).EventIntegral_Mean.REM];
tmp_Data1_SD_REM_ACC = [Events_Data_ACC(8).EventIntegral_Mean.REM];
tmp_Data2_SD_REM_ACC = [Events_Data_ACC(9).EventIntegral_Mean.REM];
tmp_Data3_SD_REM_ACC = [Events_Data_ACC(10).EventIntegral_Mean.REM];
tmp_Data4_SD_REM_ACC = [Events_Data_ACC(11).EventIntegral_Mean.REM];
tmp_Data5_SD_REM_ACC = [Events_Data_ACC(12).EventIntegral_Mean.REM];
tmp_Data6_SD_REM_ACC = [Events_Data_ACC(13).EventIntegral_Mean.REM];
data_Day_Base_REM_ACC = [tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC];
data_Night_Base_REM_ACC = [tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC];

% Barrel Cortex
tmp_Data1_Base_Awake_BRC = [Events_Data_BrC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base_Awake_BRC = [Events_Data_BrC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base_Awake_BRC = [Events_Data_BrC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base_Awake_BRC = [Events_Data_BrC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base_Awake_BRC = [Events_Data_BrC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base_Awake_BRC = [Events_Data_BrC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD_Awake_BRC = [Events_Data_BrC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD_Awake_BRC = [Events_Data_BrC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD_Awake_BRC = [Events_Data_BrC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD_Awake_BRC = [Events_Data_BrC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD_Awake_BRC = [Events_Data_BrC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD_Awake_BRC = [Events_Data_BrC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake_BRC = [tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC];
data_Night_Base_Awake_BRC = [tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC];

tmp_Data1_Base_NoNREM_BRC = [Events_Data_BrC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base_NoNREM_BRC = [Events_Data_BrC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base_NoNREM_BRC = [Events_Data_BrC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base_NoNREM_BRC = [Events_Data_BrC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base_NoNREM_BRC = [Events_Data_BrC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base_NoNREM_BRC = [Events_Data_BrC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD_NoNREM_BRC = [Events_Data_BrC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD_NoNREM_BRC = [Events_Data_BrC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD_NoNREM_BRC = [Events_Data_BrC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD_NoNREM_BRC = [Events_Data_BrC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD_NoNREM_BRC = [Events_Data_BrC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD_NoNREM_BRC = [Events_Data_BrC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM_BRC = [tmp_Data1_Base_NoNREM_BRC, tmp_Data3_Base_NoNREM_BRC, tmp_Data5_Base_NoNREM_BRC];
data_Night_Base_NoNREM_BRC = [tmp_Data2_Base_NoNREM_BRC, tmp_Data4_Base_NoNREM_BRC, tmp_Data6_Base_NoNREM_BRC];

tmp_Data1_Base_REM_BRC = [Events_Data_BrC(1).EventIntegral_Mean.REM];
tmp_Data2_Base_REM_BRC = [Events_Data_BrC(2).EventIntegral_Mean.REM];
tmp_Data3_Base_REM_BRC = [Events_Data_BrC(3).EventIntegral_Mean.REM];
tmp_Data4_Base_REM_BRC = [Events_Data_BrC(4).EventIntegral_Mean.REM];
tmp_Data5_Base_REM_BRC = [Events_Data_BrC(5).EventIntegral_Mean.REM];
tmp_Data6_Base_REM_BRC = [Events_Data_BrC(6).EventIntegral_Mean.REM];
tmp_Data1_SD_REM_BRC = [Events_Data_BrC(8).EventIntegral_Mean.REM];
tmp_Data2_SD_REM_BRC = [Events_Data_BrC(9).EventIntegral_Mean.REM];
tmp_Data3_SD_REM_BRC = [Events_Data_BrC(10).EventIntegral_Mean.REM];
tmp_Data4_SD_REM_BRC = [Events_Data_BrC(11).EventIntegral_Mean.REM];
tmp_Data5_SD_REM_BRC = [Events_Data_BrC(12).EventIntegral_Mean.REM];
tmp_Data6_SD_REM_BRC = [Events_Data_BrC(13).EventIntegral_Mean.REM];
data_Day_Base_REM_BRC = [tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC];
data_Night_Base_REM_BRC = [tmp_Data2_Base_REM_BRC, tmp_Data4_Base_REM_BRC, tmp_Data6_Base_REM_BRC];


%% Plot 1: Events Rate - Day
figure(); set(gcf,'position', get(0,'screensize'));
Plot_YMax = 100;

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data1_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data3_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data5_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Day_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data1_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data3_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data5_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Day_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data1_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data3_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data5_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Day_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data1_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data3_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data5_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Day_Base_REM_ACC)), 18*ones(1, numel(tmp_Data1_SD_REM_ACC)), 19*ones(1, numel(tmp_Data3_SD_REM_ACC)), 20*ones(1, numel(tmp_Data5_SD_REM_ACC)), ...
    21*ones(1, numel(data_Day_Base_REM_BRC)), 22*ones(1, numel(tmp_Data1_SD_REM_BRC)), 23*ones(1, numel(tmp_Data3_SD_REM_BRC)), 24*ones(1, numel(tmp_Data5_SD_REM_BRC))];

Integral_BoxPlot = [data_Day_Base_Awake_ACC, tmp_Data1_SD_Awake_ACC, tmp_Data3_SD_Awake_ACC, tmp_Data5_SD_Awake_ACC, ...
    data_Day_Base_Awake_BRC, tmp_Data1_SD_Awake_BRC, tmp_Data3_SD_Awake_BRC, tmp_Data5_SD_Awake_BRC, ...
    data_Day_Base_NoNREM_ACC, tmp_Data1_SD_NoNREM_ACC, tmp_Data3_SD_NoNREM_ACC, tmp_Data5_SD_NoNREM_ACC, ...
    data_Day_Base_NoNREM_BRC, tmp_Data1_SD_NoNREM_BRC, tmp_Data3_SD_NoNREM_BRC, tmp_Data5_SD_NoNREM_BRC, ...
    data_Day_Base_REM_ACC, tmp_Data1_SD_REM_ACC, tmp_Data3_SD_REM_ACC, tmp_Data5_SD_REM_ACC, ...
    data_Day_Base_REM_BRC, tmp_Data1_SD_REM_BRC, tmp_Data3_SD_REM_BRC, tmp_Data5_SD_REM_BRC];
hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(Integral_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_YMax])

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});
ylabel('Ca2+ Integrals ')
title('Integrals [Hz] - Day - Baseline vs SD Recovery')

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

FileName = sprintf('Day - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);

if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


%% Plot 2: Events Rate - Night
figure(); set(gcf,'position', get(0,'screensize'));
Plot_YMax = 0.12;

% Plot first Awake, Night, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
BoxPlot_Groups = [1*ones(1, numel(data_Night_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data2_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data4_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data6_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Night_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data2_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data4_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data6_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Night_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data2_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data4_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data6_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Night_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data2_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data4_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data6_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Night_Base_REM_ACC)), 18*ones(1, numel(tmp_Data2_SD_REM_ACC)), 19*ones(1, numel(tmp_Data4_SD_REM_ACC)), 20*ones(1, numel(tmp_Data6_SD_REM_ACC)), ...
    21*ones(1, numel(data_Night_Base_REM_BRC)), 22*ones(1, numel(tmp_Data2_SD_REM_BRC)), 23*ones(1, numel(tmp_Data4_SD_REM_BRC)), 24*ones(1, numel(tmp_Data6_SD_REM_BRC))];

Integral_BoxPlot = [data_Night_Base_Awake_ACC, tmp_Data2_SD_Awake_ACC, tmp_Data4_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC, ...
    data_Night_Base_Awake_BRC, tmp_Data2_SD_Awake_BRC, tmp_Data4_SD_Awake_BRC, tmp_Data6_SD_Awake_BRC, ...
    data_Night_Base_NoNREM_ACC, tmp_Data2_SD_NoNREM_ACC, tmp_Data4_SD_NoNREM_ACC, tmp_Data6_SD_NoNREM_ACC, ...
    data_Night_Base_NoNREM_BRC, tmp_Data2_SD_NoNREM_BRC, tmp_Data4_SD_NoNREM_BRC, tmp_Data6_SD_NoNREM_BRC, ...
    data_Night_Base_REM_ACC, tmp_Data2_SD_REM_ACC, tmp_Data4_SD_REM_ACC, tmp_Data6_SD_REM_ACC, ...
    data_Night_Base_REM_BRC, tmp_Data2_SD_REM_BRC, tmp_Data4_SD_REM_BRC, tmp_Data6_SD_REM_BRC];
hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(Integral_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_YMax])

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz] - Night - Baseline vs SD Recovery')

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

FileName = sprintf('Night - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);

if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
