function Plot_EventsPerState_part5 (Events_Data_ACC, Events_Data_BrC)
% This function plots the results for Christina Astrocytes Analysis

PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';
if exist(PlotPath) == 0
    PlotPath = pwd;
end

FLAG_Save = 1;


% Integral
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 140;

tmp_Data1_Base_Awake = [Events_Data_ACC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base_Awake = [Events_Data_ACC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base_Awake = [Events_Data_ACC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base_Awake = [Events_Data_ACC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base_Awake = [Events_Data_ACC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base_Awake = [Events_Data_ACC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD_Awake = [Events_Data_ACC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD_Awake = [Events_Data_ACC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD_Awake = [Events_Data_ACC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD_Awake = [Events_Data_ACC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD_Awake = [Events_Data_ACC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD_Awake = [Events_Data_ACC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base_Awake, tmp_Data3_Base_Awake, tmp_Data5_Base_Awake];
data_Night_Base_Awake = [tmp_Data2_Base_Awake, tmp_Data4_Base_Awake, tmp_Data6_Base_Awake];

tmp_Data1_Base_NoNREM = [Events_Data_ACC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base_NoNREM = [Events_Data_ACC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base_NoNREM = [Events_Data_ACC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base_NoNREM = [Events_Data_ACC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base_NoNREM = [Events_Data_ACC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base_NoNREM = [Events_Data_ACC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD_NoNREM = [Events_Data_ACC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD_NoNREM = [Events_Data_ACC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD_NoNREM = [Events_Data_ACC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD_NoNREM = [Events_Data_ACC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD_NoNREM = [Events_Data_ACC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD_NoNREM = [Events_Data_ACC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base_NoNREM, tmp_Data3_Base_NoNREM, tmp_Data5_Base_NoNREM];
data_Night_Base_NoNREM = [tmp_Data2_Base_NoNREM, tmp_Data4_Base_NoNREM, tmp_Data6_Base_NoNREM];

tmp_Data1_Base_REM = [Events_Data_ACC(1).EventIntegral_Mean.REM];
tmp_Data2_Base_REM = [Events_Data_ACC(2).EventIntegral_Mean.REM];
tmp_Data3_Base_REM = [Events_Data_ACC(3).EventIntegral_Mean.REM];
tmp_Data4_Base_REM = [Events_Data_ACC(4).EventIntegral_Mean.REM];
tmp_Data5_Base_REM = [Events_Data_ACC(5).EventIntegral_Mean.REM];
tmp_Data6_Base_REM = [Events_Data_ACC(6).EventIntegral_Mean.REM];
tmp_Data1_SD_REM = [Events_Data_ACC(8).EventIntegral_Mean.REM];
tmp_Data2_SD_REM = [Events_Data_ACC(9).EventIntegral_Mean.REM];
tmp_Data3_SD_REM = [Events_Data_ACC(10).EventIntegral_Mean.REM];
tmp_Data4_SD_REM = [Events_Data_ACC(11).EventIntegral_Mean.REM];
tmp_Data5_SD_REM = [Events_Data_ACC(12).EventIntegral_Mean.REM];
tmp_Data6_SD_REM = [Events_Data_ACC(13).EventIntegral_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base_REM, tmp_Data3_Base_REM, tmp_Data5_Base_REM];
data_Night_Base_REM = [tmp_Data2_Base_REM, tmp_Data4_Base_REM, tmp_Data6_Base_REM];
% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(tmp_Data1_SD_Awake)), 3*ones(1, numel(tmp_Data3_SD_Awake)), 4*ones(1, numel(tmp_Data5_SD_Awake)), ...
    5*ones(1, numel(data_Night_Base_Awake)), 6*ones(1, numel(tmp_Data2_SD_Awake)), 7*ones(1, numel(tmp_Data4_SD_Awake)), 8*ones(1, numel(tmp_Data6_SD_Awake)), ...
    9*ones(1, numel(data_Day_Base_NoNREM)), 10*ones(1, numel(tmp_Data1_SD_NoNREM)), 11*ones(1, numel(tmp_Data3_SD_NoNREM)), 12*ones(1, numel(tmp_Data5_SD_NoNREM)), ...
    13*ones(1, numel(data_Night_Base_NoNREM)), 14*ones(1, numel(tmp_Data2_SD_NoNREM)), 15*ones(1, numel(tmp_Data4_SD_NoNREM)), 16*ones(1, numel(tmp_Data6_SD_NoNREM)), ...
    17*ones(1, numel(data_Day_Base_REM)), 18*ones(1, numel(tmp_Data1_SD_REM)), 19*ones(1, numel(tmp_Data3_SD_REM)), 20*ones(1, numel(tmp_Data5_SD_REM)), ...
    21*ones(1, numel(data_Night_Base_REM)), 22*ones(1, numel(tmp_Data2_SD_REM)), 23*ones(1, numel(tmp_Data4_SD_REM)), 24*ones(1, numel(tmp_Data6_SD_REM))];

EventsRate_BoxPlot = [data_Day_Base_Awake, tmp_Data1_SD_Awake, tmp_Data3_SD_Awake, tmp_Data5_SD_Awake, ...
    data_Night_Base_Awake, tmp_Data2_SD_Awake, tmp_Data4_SD_Awake, tmp_Data6_SD_Awake, ...
    data_Day_Base_NoNREM, tmp_Data1_SD_NoNREM, tmp_Data3_SD_NoNREM, tmp_Data5_SD_NoNREM, ...
    data_Night_Base_NoNREM, tmp_Data2_SD_NoNREM, tmp_Data4_SD_NoNREM, tmp_Data6_SD_NoNREM, ...
    data_Day_Base_REM, tmp_Data1_SD_REM, tmp_Data3_SD_REM, tmp_Data5_SD_REM, ...
    data_Night_Base_REM, tmp_Data2_SD_REM, tmp_Data4_SD_REM, tmp_Data6_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=4:4:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:4:length(h)
    h_patch_grey1 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0.66,0.66], 'FaceAlpha', PlotsTransparency);
end
for j=2:4:length(h)
    h_patch_grey2 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0.33,0.33], 'FaceAlpha', PlotsTransparency);
end
for j=3:4:length(h)
    h_patch_grey3 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0,0], 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
ylabel('Ca2+ Integral')
title('Integral - ACC - Baseline vs SD Recovery')

legend([h_patch_blue, h_patch_grey3, h_patch_grey2, h_patch_grey1], {'Baseline', 'SD Rec - 24h', 'SD Rec - 48h', 'SD Rec - 72h'}, 'location', 'northeast');


FileName = sprintf('ACC - Baselines vs SD - Integral');
FilePath = sprintf('%s\\%s', PlotPath, FileName);

if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



















% Integral
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

figure(); set(gcf,'position', get(0,'screensize'));

tmp_Data1_Base_Awake = [Events_Data_BrC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base_Awake = [Events_Data_BrC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base_Awake = [Events_Data_BrC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base_Awake = [Events_Data_BrC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base_Awake = [Events_Data_BrC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base_Awake = [Events_Data_BrC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD_Awake = [Events_Data_BrC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD_Awake = [Events_Data_BrC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD_Awake = [Events_Data_BrC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD_Awake = [Events_Data_BrC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD_Awake = [Events_Data_BrC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD_Awake = [Events_Data_BrC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base_Awake, tmp_Data3_Base_Awake, tmp_Data5_Base_Awake];
data_Night_Base_Awake = [tmp_Data2_Base_Awake, tmp_Data4_Base_Awake, tmp_Data6_Base_Awake];

tmp_Data1_Base_NoNREM = [Events_Data_BrC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base_NoNREM = [Events_Data_BrC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base_NoNREM = [Events_Data_BrC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base_NoNREM = [Events_Data_BrC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base_NoNREM = [Events_Data_BrC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base_NoNREM = [Events_Data_BrC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD_NoNREM = [Events_Data_BrC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD_NoNREM = [Events_Data_BrC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD_NoNREM = [Events_Data_BrC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD_NoNREM = [Events_Data_BrC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD_NoNREM = [Events_Data_BrC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD_NoNREM = [Events_Data_BrC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base_NoNREM, tmp_Data3_Base_NoNREM, tmp_Data5_Base_NoNREM];
data_Night_Base_NoNREM = [tmp_Data2_Base_NoNREM, tmp_Data4_Base_NoNREM, tmp_Data6_Base_NoNREM];

tmp_Data1_Base_REM = [Events_Data_BrC(1).EventIntegral_Mean.REM];
tmp_Data2_Base_REM = [Events_Data_BrC(2).EventIntegral_Mean.REM];
tmp_Data3_Base_REM = [Events_Data_BrC(3).EventIntegral_Mean.REM];
tmp_Data4_Base_REM = [Events_Data_BrC(4).EventIntegral_Mean.REM];
tmp_Data5_Base_REM = [Events_Data_BrC(5).EventIntegral_Mean.REM];
tmp_Data6_Base_REM = [Events_Data_BrC(6).EventIntegral_Mean.REM];
tmp_Data1_SD_REM = [Events_Data_BrC(8).EventIntegral_Mean.REM];
tmp_Data2_SD_REM = [Events_Data_BrC(9).EventIntegral_Mean.REM];
tmp_Data3_SD_REM = [Events_Data_BrC(10).EventIntegral_Mean.REM];
tmp_Data4_SD_REM = [Events_Data_BrC(11).EventIntegral_Mean.REM];
tmp_Data5_SD_REM = [Events_Data_BrC(12).EventIntegral_Mean.REM];
tmp_Data6_SD_REM = [Events_Data_BrC(13).EventIntegral_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base_REM, tmp_Data3_Base_REM, tmp_Data5_Base_REM];
data_Night_Base_REM = [tmp_Data2_Base_REM, tmp_Data4_Base_REM, tmp_Data6_Base_REM];
% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(tmp_Data1_SD_Awake)), 3*ones(1, numel(tmp_Data3_SD_Awake)), 4*ones(1, numel(tmp_Data5_SD_Awake)), ...
    5*ones(1, numel(data_Night_Base_Awake)), 6*ones(1, numel(tmp_Data2_SD_Awake)), 7*ones(1, numel(tmp_Data4_SD_Awake)), 8*ones(1, numel(tmp_Data6_SD_Awake)), ...
    9*ones(1, numel(data_Day_Base_NoNREM)), 10*ones(1, numel(tmp_Data1_SD_NoNREM)), 11*ones(1, numel(tmp_Data3_SD_NoNREM)), 12*ones(1, numel(tmp_Data5_SD_NoNREM)), ...
    13*ones(1, numel(data_Night_Base_NoNREM)), 14*ones(1, numel(tmp_Data2_SD_NoNREM)), 15*ones(1, numel(tmp_Data4_SD_NoNREM)), 16*ones(1, numel(tmp_Data6_SD_NoNREM)), ...
    17*ones(1, numel(data_Day_Base_REM)), 18*ones(1, numel(tmp_Data1_SD_REM)), 19*ones(1, numel(tmp_Data3_SD_REM)), 20*ones(1, numel(tmp_Data5_SD_REM)), ...
    21*ones(1, numel(data_Night_Base_REM)), 22*ones(1, numel(tmp_Data2_SD_REM)), 23*ones(1, numel(tmp_Data4_SD_REM)), 24*ones(1, numel(tmp_Data6_SD_REM))];

EventsRate_BoxPlot = [data_Day_Base_Awake, tmp_Data1_SD_Awake, tmp_Data3_SD_Awake, tmp_Data5_SD_Awake, ...
    data_Night_Base_Awake, tmp_Data2_SD_Awake, tmp_Data4_SD_Awake, tmp_Data6_SD_Awake, ...
    data_Day_Base_NoNREM, tmp_Data1_SD_NoNREM, tmp_Data3_SD_NoNREM, tmp_Data5_SD_NoNREM, ...
    data_Night_Base_NoNREM, tmp_Data2_SD_NoNREM, tmp_Data4_SD_NoNREM, tmp_Data6_SD_NoNREM, ...
    data_Day_Base_REM, tmp_Data1_SD_REM, tmp_Data3_SD_REM, tmp_Data5_SD_REM, ...
    data_Night_Base_REM, tmp_Data2_SD_REM, tmp_Data4_SD_REM, tmp_Data6_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];
BP_Width = 0.5;
BoxPlot_Widths = BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=4:4:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:4:length(h)
    h_patch_grey1 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0.66,0.66], 'FaceAlpha', PlotsTransparency);
end
for j=2:4:length(h)
    h_patch_grey2 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0.33,0.33], 'FaceAlpha', PlotsTransparency);
end
for j=3:4:length(h)
    h_patch_grey3 = patch(get(h(j),'XData'),get(h(j),'YData'), [1,0,0], 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
ylabel('Ca2+ Integral')
title('Integral - BrC - Baseline vs SD Recovery')

legend([h_patch_blue, h_patch_grey3, h_patch_grey2, h_patch_grey1], {'Baseline', 'SD Rec - 24h', 'SD Rec - 48h', 'SD Rec - 72h'}, 'location', 'northeast');


FileName = sprintf('BrC - Baselines vs SD - Integral');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
