function OutputStats = Astrocyte_Stats_Ranksum_sub1 (Events_Data_ACC, Events_Data_BRC)
% This function computes the statistics for Astrocyte data.

min_n_events = 3;

% ACC
tmp_Data1_Base_Awake_ACC = [Events_Data_ACC(1).Awake];
tmp_Data2_Base_Awake_ACC = [Events_Data_ACC(2).Awake];
tmp_Data3_Base_Awake_ACC = [Events_Data_ACC(3).Awake];
tmp_Data4_Base_Awake_ACC = [Events_Data_ACC(4).Awake];
tmp_Data5_Base_Awake_ACC = [Events_Data_ACC(5).Awake];
tmp_Data6_Base_Awake_ACC = [Events_Data_ACC(6).Awake];
tmp_Data1_SD_Awake_ACC = [Events_Data_ACC(8).Awake];
tmp_Data2_SD_Awake_ACC = [Events_Data_ACC(9).Awake];
tmp_Data3_SD_Awake_ACC = [Events_Data_ACC(10).Awake];
tmp_Data4_SD_Awake_ACC = [Events_Data_ACC(11).Awake];
tmp_Data5_SD_Awake_ACC = [Events_Data_ACC(12).Awake];
tmp_Data6_SD_Awake_ACC = [Events_Data_ACC(13).Awake];
data_Day_Base_Awake_ACC = [tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC];
data_Night_Base_Awake_ACC = [tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC];

tmp_Data1_Base_NREM_ACC = [Events_Data_ACC(1).NoNREM];
tmp_Data2_Base_NREM_ACC = [Events_Data_ACC(2).NoNREM];
tmp_Data3_Base_NREM_ACC = [Events_Data_ACC(3).NoNREM];
tmp_Data4_Base_NREM_ACC = [Events_Data_ACC(4).NoNREM];
tmp_Data5_Base_NREM_ACC = [Events_Data_ACC(5).NoNREM];
tmp_Data6_Base_NREM_ACC = [Events_Data_ACC(6).NoNREM];
tmp_Data1_SD_NREM_ACC = [Events_Data_ACC(8).NoNREM];
tmp_Data2_SD_NREM_ACC = [Events_Data_ACC(9).NoNREM];
tmp_Data3_SD_NREM_ACC = [Events_Data_ACC(10).NoNREM];
tmp_Data4_SD_NREM_ACC = [Events_Data_ACC(11).NoNREM];
tmp_Data5_SD_NREM_ACC = [Events_Data_ACC(12).NoNREM];
tmp_Data6_SD_NREM_ACC = [Events_Data_ACC(13).NoNREM];
data_Day_Base_NREM_ACC = [tmp_Data1_Base_NREM_ACC, tmp_Data3_Base_NREM_ACC, tmp_Data5_Base_NREM_ACC];
data_Night_Base_NREM_ACC = [tmp_Data2_Base_NREM_ACC, tmp_Data4_Base_NREM_ACC, tmp_Data6_Base_NREM_ACC];

tmp_Data1_Base_REM_ACC = [Events_Data_ACC(1).REM];
tmp_Data2_Base_REM_ACC = [Events_Data_ACC(2).REM];
tmp_Data3_Base_REM_ACC = [Events_Data_ACC(3).REM];
tmp_Data4_Base_REM_ACC = [Events_Data_ACC(4).REM];
tmp_Data5_Base_REM_ACC = [Events_Data_ACC(5).REM];
tmp_Data6_Base_REM_ACC = [Events_Data_ACC(6).REM];
tmp_Data1_SD_REM_ACC = [Events_Data_ACC(8).REM];
tmp_Data2_SD_REM_ACC = [Events_Data_ACC(9).REM];
tmp_Data3_SD_REM_ACC = [Events_Data_ACC(10).REM];
tmp_Data4_SD_REM_ACC = [Events_Data_ACC(11).REM];
tmp_Data5_SD_REM_ACC = [Events_Data_ACC(12).REM];
tmp_Data6_SD_REM_ACC = [Events_Data_ACC(13).REM];
data_Day_Base_REM_ACC = [tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC];
data_Night_Base_REM_ACC = [tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC];

% Barrel Cortex
tmp_Data1_Base_Awake_BRC = [Events_Data_BRC(1).Awake];
tmp_Data2_Base_Awake_BRC = [Events_Data_BRC(2).Awake];
tmp_Data3_Base_Awake_BRC = [Events_Data_BRC(3).Awake];
tmp_Data4_Base_Awake_BRC = [Events_Data_BRC(4).Awake];
tmp_Data5_Base_Awake_BRC = [Events_Data_BRC(5).Awake];
tmp_Data6_Base_Awake_BRC = [Events_Data_BRC(6).Awake];
tmp_Data1_SD_Awake_BRC = [Events_Data_BRC(8).Awake];
tmp_Data2_SD_Awake_BRC = [Events_Data_BRC(9).Awake];
tmp_Data3_SD_Awake_BRC = [Events_Data_BRC(10).Awake];
tmp_Data4_SD_Awake_BRC = [Events_Data_BRC(11).Awake];
tmp_Data5_SD_Awake_BRC = [Events_Data_BRC(12).Awake];
tmp_Data6_SD_Awake_BRC = [Events_Data_BRC(13).Awake];
data_Day_Base_Awake_BRC = [tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC];
data_Night_Base_Awake_BRC = [tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC];

tmp_Data1_Base_NREM_BRC = [Events_Data_BRC(1).NoNREM];
tmp_Data2_Base_NREM_BRC = [Events_Data_BRC(2).NoNREM];
tmp_Data3_Base_NREM_BRC = [Events_Data_BRC(3).NoNREM];
tmp_Data4_Base_NREM_BRC = [Events_Data_BRC(4).NoNREM];
tmp_Data5_Base_NREM_BRC = [Events_Data_BRC(5).NoNREM];
tmp_Data6_Base_NREM_BRC = [Events_Data_BRC(6).NoNREM];
tmp_Data1_SD_NREM_BRC = [Events_Data_BRC(8).NoNREM];
tmp_Data2_SD_NREM_BRC = [Events_Data_BRC(9).NoNREM];
tmp_Data3_SD_NREM_BRC = [Events_Data_BRC(10).NoNREM];
tmp_Data4_SD_NREM_BRC = [Events_Data_BRC(11).NoNREM];
tmp_Data5_SD_NREM_BRC = [Events_Data_BRC(12).NoNREM];
tmp_Data6_SD_NREM_BRC = [Events_Data_BRC(13).NoNREM];
data_Day_Base_NREM_BRC = [tmp_Data1_Base_NREM_BRC, tmp_Data3_Base_NREM_BRC, tmp_Data5_Base_NREM_BRC];
data_Night_Base_NREM_BRC = [tmp_Data2_Base_NREM_BRC, tmp_Data4_Base_NREM_BRC, tmp_Data6_Base_NREM_BRC];

tmp_Data1_Base_REM_BRC = [Events_Data_BRC(1).REM];
tmp_Data2_Base_REM_BRC = [Events_Data_BRC(2).REM];
tmp_Data3_Base_REM_BRC = [Events_Data_BRC(3).REM];
tmp_Data4_Base_REM_BRC = [Events_Data_BRC(4).REM];
tmp_Data5_Base_REM_BRC = [Events_Data_BRC(5).REM];
tmp_Data6_Base_REM_BRC = [Events_Data_BRC(6).REM];
tmp_Data1_SD_REM_BRC = [Events_Data_BRC(8).REM];
tmp_Data2_SD_REM_BRC = [Events_Data_BRC(9).REM];
tmp_Data3_SD_REM_BRC = [Events_Data_BRC(10).REM];
tmp_Data4_SD_REM_BRC = [Events_Data_BRC(11).REM];
tmp_Data5_SD_REM_BRC = [Events_Data_BRC(12).REM];
tmp_Data6_SD_REM_BRC = [Events_Data_BRC(13).REM];
data_Day_Base_REM_BRC = [tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC];
data_Night_Base_REM_BRC = [tmp_Data2_Base_REM_BRC, tmp_Data4_Base_REM_BRC, tmp_Data6_Base_REM_BRC];

%% Statistics ACC - Day
% Baseline Comparisons
[Day.Awake.Baseline1_vs_Baseline2.Pvalue, Day.Awake.Baseline1_vs_Baseline2.h, Day.Awake.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC);
[Day.Awake.Baseline1_vs_Baseline3.Pvalue, Day.Awake.Baseline1_vs_Baseline3.h, Day.Awake.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC);
[Day.Awake.Baseline2_vs_Baseline3.Pvalue, Day.Awake.Baseline2_vs_Baseline3.h, Day.Awake.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC);

[Day.NREM.Baseline1_vs_Baseline2.Pvalue, Day.NREM.Baseline1_vs_Baseline2.h, Day.NREM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_NREM_ACC, tmp_Data3_Base_NREM_ACC);
[Day.NREM.Baseline1_vs_Baseline3.Pvalue, Day.NREM.Baseline1_vs_Baseline3.h, Day.NREM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_NREM_ACC, tmp_Data5_Base_NREM_ACC);
[Day.NREM.Baseline2_vs_Baseline3.Pvalue, Day.NREM.Baseline2_vs_Baseline3.h, Day.NREM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_NREM_ACC, tmp_Data5_Base_NREM_ACC);

[Day.REM.Baseline1_vs_Baseline2.Pvalue, Day.REM.Baseline1_vs_Baseline2.h, Day.REM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC);
[Day.REM.Baseline1_vs_Baseline3.Pvalue, Day.REM.Baseline1_vs_Baseline3.h, Day.REM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_REM_ACC, tmp_Data5_Base_REM_ACC);
[Day.REM.Baseline2_vs_Baseline3.Pvalue, Day.REM.Baseline2_vs_Baseline3.h, Day.REM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC);

% Awake vs NREM vs REM
[Day.Awake_vsNREM.Baseline.Pvalue, Day.Awake_vsNREM.Baseline.h, Day.Awake_vsNREM.Baseline.Stats] = ranksum(data_Day_Base_Awake_ACC, data_Day_Base_NREM_ACC);
[Day.Awake_vsREM.Baseline.Pvalue, Day.Awake_vsREM.Baseline.h, Day.Awake_vsREM.Baseline.Stats] = ranksum(data_Day_Base_Awake_ACC, data_Day_Base_REM_ACC);
[Day.NREM_vsREM.Baseline.Pvalue, Day.NREM_vsREM.Baseline.h, Day.NREM_vsREM.Baseline.Stats] = ranksum(data_Day_Base_NREM_ACC, data_Day_Base_REM_ACC);

[Day.Awake_vsNREM.SD24h.Pvalue, Day.Awake_vsNREM.SD24h.h, Day.Awake_vsNREM.SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data1_SD_NREM_ACC);
[Day.Awake_vsREM.SD24h.Pvalue, Day.Awake_vsREM.SD24h.h, Day.Awake_vsREM.SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data1_SD_REM_ACC);
[Day.NREM_vsREM.SD24h.Pvalue, Day.NREM_vsREM.SD24h.h, Day.NREM_vsREM.SD24h.Stats] = ranksum(tmp_Data1_SD_NREM_ACC, tmp_Data1_SD_REM_ACC);

[Day.Awake_vsNREM.SD48h.Pvalue, Day.Awake_vsNREM.SD48h.h, Day.Awake_vsNREM.SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_ACC, tmp_Data3_SD_NREM_ACC);
[Day.Awake_vsREM.SD48h.Pvalue, Day.Awake_vsREM.SD48h.h, Day.Awake_vsREM.SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_ACC, tmp_Data3_SD_REM_ACC);
[Day.NREM_vsREM.SD48h.Pvalue, Day.NREM_vsREM.SD48h.h, Day.NREM_vsREM.SD48h.Stats] = ranksum(tmp_Data3_SD_NREM_ACC, tmp_Data3_SD_REM_ACC);

[Day.Awake_vsNREM.SD72h.Pvalue, Day.Awake_vsNREM.SD72h.h, Day.Awake_vsNREM.SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_ACC, tmp_Data5_SD_NREM_ACC);
[Day.Awake_vsREM.SD72h.Pvalue, Day.Awake_vsREM.SD72h.h, Day.Awake_vsREM.SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_ACC, tmp_Data5_SD_REM_ACC);
[Day.NREM_vsREM.SD72h.Pvalue, Day.NREM_vsREM.SD72h.h, Day.NREM_vsREM.SD72h.Stats] = ranksum(tmp_Data5_SD_NREM_ACC, tmp_Data5_SD_REM_ACC);

% Baseline vs SD 24-48-72
[Day.Awake.Baseline_vs_SD24h.Pvalue, Day.Awake.Baseline_vs_SD24h.h, Day.Awake.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_Awake_ACC, tmp_Data1_SD_Awake_ACC);
[Day.Awake.Baseline_vs_SD48h.Pvalue, Day.Awake.Baseline_vs_SD48h.h, Day.Awake.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_Awake_ACC, tmp_Data3_SD_Awake_ACC);
[Day.Awake.Baseline_vs_SD72h.Pvalue, Day.Awake.Baseline_vs_SD72h.h, Day.Awake.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_Awake_ACC, tmp_Data5_SD_Awake_ACC);

[Day.Awake.SD24h_vs_SD48h.Pvalue, Day.Awake.SD24h_vs_SD48h.h, Day.Awake.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data3_SD_Awake_ACC);
[Day.Awake.SD24h_vs_SD72h.Pvalue, Day.Awake.SD24h_vs_SD72h.h, Day.Awake.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data5_SD_Awake_ACC);
[Day.Awake.SD48h_vs_SD72h.Pvalue, Day.Awake.SD48h_vs_SD72h.h, Day.Awake.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_Awake_ACC, tmp_Data5_SD_Awake_ACC);

[Day.NREM.Baseline_vs_SD24h.Pvalue, Day.NREM.Baseline_vs_SD24h.h, Day.NREM.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_NREM_ACC, tmp_Data1_SD_NREM_ACC);
[Day.NREM.Baseline_vs_SD48h.Pvalue, Day.NREM.Baseline_vs_SD48h.h, Day.NREM.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_NREM_ACC, tmp_Data3_SD_NREM_ACC);
[Day.NREM.Baseline_vs_SD72h.Pvalue, Day.NREM.Baseline_vs_SD72h.h, Day.NREM.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_NREM_ACC, tmp_Data5_SD_NREM_ACC);

[Day.NREM.SD24h_vs_SD48h.Pvalue, Day.NREM.SD24h_vs_SD48h.h, Day.NREM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_NREM_ACC, tmp_Data3_SD_NREM_ACC);
[Day.NREM.SD24h_vs_SD72h.Pvalue, Day.NREM.SD24h_vs_SD72h.h, Day.NREM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_NREM_ACC, tmp_Data5_SD_NREM_ACC);
[Day.NREM.SD48h_vs_SD72h.Pvalue, Day.NREM.SD48h_vs_SD72h.h, Day.NREM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_NREM_ACC, tmp_Data5_SD_NREM_ACC);

[Day.REM.Baseline_vs_SD24h.Pvalue, Day.REM.Baseline_vs_SD24h.h, Day.REM.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_REM_ACC, tmp_Data1_SD_REM_ACC);
[Day.REM.Baseline_vs_SD48h.Pvalue, Day.REM.Baseline_vs_SD48h.h, Day.REM.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_REM_ACC, tmp_Data3_SD_REM_ACC);
[Day.REM.Baseline_vs_SD72h.Pvalue, Day.REM.Baseline_vs_SD72h.h, Day.REM.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_REM_ACC, tmp_Data5_SD_REM_ACC);

[Day.REM.SD24h_vs_SD48h.Pvalue, Day.REM.SD24h_vs_SD48h.h, Day.REM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_REM_ACC, tmp_Data3_SD_REM_ACC);
[Day.REM.SD24h_vs_SD72h.Pvalue, Day.REM.SD24h_vs_SD72h.h, Day.REM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_REM_ACC, tmp_Data5_SD_REM_ACC);
[Day.REM.SD48h_vs_SD72h.Pvalue, Day.REM.SD48h_vs_SD72h.h, Day.REM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_REM_ACC, tmp_Data5_SD_REM_ACC);


%% Statistics ACC - Night
% Baseline Comparisons
if numel(find(~isnan(tmp_Data2_Base_Awake_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_Base_Awake_ACC))) > min_n_events
    [Night.Awake.Baseline1_vs_Baseline2.Pvalue, Night.Awake.Baseline1_vs_Baseline2.h, Night.Awake.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC);
else
    Night.Awake.Baseline1_vs_Baseline2.Pvalue = NaN; Night.Awake.Baseline1_vs_Baseline2.h = NaN; Night.Awake.Baseline1_vs_Baseline2.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_Base_Awake_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_Base_Awake_ACC))) > min_n_events
    [Night.Awake.Baseline1_vs_Baseline3.Pvalue, Night.Awake.Baseline1_vs_Baseline3.h, Night.Awake.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data2_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC);
else
    Night.Awake.Baseline1_vs_Baseline3.Pvalue = NaN; Night.Awake.Baseline1_vs_Baseline3.h = NaN; Night.Awake.Baseline1_vs_Baseline3.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_Base_Awake_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_Base_Awake_ACC))) > min_n_events
    [Night.Awake.Baseline2_vs_Baseline3.Pvalue, Night.Awake.Baseline2_vs_Baseline3.h, Night.Awake.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC);
else
    Night.Awake.Baseline2_vs_Baseline3.Pvalue = NaN; Night.Awake.Baseline2_vs_Baseline3.h = NaN; Night.Awake.Baseline2_vs_Baseline3.Stats = NaN;
end

if numel(find(~isnan(tmp_Data2_Base_NREM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_Base_NREM_ACC))) > min_n_events
    [Night.NREM.Baseline1_vs_Baseline2.Pvalue, Night.NREM.Baseline1_vs_Baseline2.h, Night.NREM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data2_Base_NREM_ACC, tmp_Data4_Base_NREM_ACC);
else
    Night.NREM.Baseline1_vs_Baseline2.Pvalue = NaN; Night.NREM.Baseline1_vs_Baseline2.h = NaN; Night.NREM.Baseline1_vs_Baseline2.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_Base_NREM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_Base_NREM_ACC))) > min_n_events
    [Night.NREM.Baseline1_vs_Baseline3.Pvalue, Night.NREM.Baseline1_vs_Baseline3.h, Night.NREM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data2_Base_NREM_ACC, tmp_Data6_Base_NREM_ACC);
else
    Night.NREM.Baseline1_vs_Baseline3.Pvalue = NaN; Night.NREM.Baseline1_vs_Baseline3.h = NaN; Night.NREM.Baseline1_vs_Baseline3.Stats = NaN;
end
if numel(find(~isnan(tmp_Data4_Base_NREM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_Base_NREM_ACC))) > min_n_events
    [Night.NREM.Baseline2_vs_Baseline3.Pvalue, Night.NREM.Baseline2_vs_Baseline3.h, Night.NREM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data4_Base_NREM_ACC, tmp_Data6_Base_NREM_ACC);
else
    Night.NREM.Baseline2_vs_Baseline3.Pvalue = NaN; Night.NREM.Baseline2_vs_Baseline3.h = NaN; Night.NREM.Baseline2_vs_Baseline3.Stats = NaN;
end

if numel(find(~isnan(tmp_Data2_Base_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_Base_REM_ACC))) > min_n_events
    [Night.REM.Baseline1_vs_Baseline2.Pvalue, Night.REM.Baseline1_vs_Baseline2.h, Night.REM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC);
else
    Night.REM.Baseline1_vs_Baseline2.Pvalue = NaN; Night.REM.Baseline1_vs_Baseline2.h = NaN; Night.REM.Baseline1_vs_Baseline2.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_Base_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_Base_REM_ACC))) > min_n_events
    [Night.REM.Baseline1_vs_Baseline3.Pvalue, Night.REM.Baseline1_vs_Baseline3.h, Night.REM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data2_Base_REM_ACC, tmp_Data6_Base_REM_ACC);
else
    Night.REM.Baseline1_vs_Baseline3.Pvalue = NaN; Night.REM.Baseline1_vs_Baseline3.h = NaN; Night.REM.Baseline1_vs_Baseline3.Stats = NaN;
end
if numel(find(~isnan(tmp_Data4_Base_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_Base_REM_ACC))) > min_n_events
    [Night.REM.Baseline2_vs_Baseline3.Pvalue, Night.REM.Baseline2_vs_Baseline3.h, Night.REM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC);
else
    Night.REM.Baseline2_vs_Baseline3.Pvalue = NaN; Night.REM.Baseline2_vs_Baseline3.h = NaN; Night.REM.Baseline2_vs_Baseline3.Stats = NaN;
end

% Awake vs NREM vs REM
[Night.Awake_vsNREM.Baseline.Pvalue, Night.Awake_vsNREM.Baseline.h, Night.Awake_vsNREM.Baseline.Stats] = ranksum(data_Night_Base_Awake_ACC, data_Night_Base_NREM_ACC);
[Night.Awake_vsREM.Baseline.Pvalue, Night.Awake_vsREM.Baseline.h, Night.Awake_vsREM.Baseline.Stats] = ranksum(data_Night_Base_Awake_ACC, data_Night_Base_REM_ACC);
[Night.NREM_vsREM.Baseline.Pvalue, Night.NREM_vsREM.Baseline.h, Night.NREM_vsREM.Baseline.Stats] = ranksum(data_Night_Base_NREM_ACC, data_Night_Base_REM_ACC);

[Night.Awake_vsNREM.SD24h.Pvalue, Night.Awake_vsNREM.SD24h.h, Night.Awake_vsNREM.SD24h.Stats] = ranksum(tmp_Data2_SD_Awake_ACC, tmp_Data2_SD_NREM_ACC);
[Night.Awake_vsREM.SD24h.Pvalue, Night.Awake_vsREM.SD24h.h, Night.Awake_vsREM.SD24h.Stats] = ranksum(tmp_Data2_SD_Awake_ACC, tmp_Data2_SD_REM_ACC);
[Night.NREM_vsREM.SD24h.Pvalue, Night.NREM_vsREM.SD24h.h, Night.NREM_vsREM.SD24h.Stats] = ranksum(tmp_Data2_SD_NREM_ACC, tmp_Data2_SD_REM_ACC);

[Night.Awake_vsNREM.SD48h.Pvalue, Night.Awake_vsNREM.SD48h.h, Night.Awake_vsNREM.SD48h.Stats] = ranksum(tmp_Data4_SD_Awake_ACC, tmp_Data4_SD_NREM_ACC);
[Night.Awake_vsREM.SD48h.Pvalue, Night.Awake_vsREM.SD48h.h, Night.Awake_vsREM.SD48h.Stats] = ranksum(tmp_Data4_SD_Awake_ACC, tmp_Data4_SD_REM_ACC);
[Night.NREM_vsREM.SD48h.Pvalue, Night.NREM_vsREM.SD48h.h, Night.NREM_vsREM.SD48h.Stats] = ranksum(tmp_Data4_SD_NREM_ACC, tmp_Data4_SD_REM_ACC);

if numel(find(~isnan(tmp_Data6_SD_Awake_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_NREM_ACC))) > min_n_events
    [Night.Awake_vsNREM.SD72h.Pvalue, Night.Awake_vsNREM.SD72h.h, Night.Awake_vsNREM.SD72h.Stats] = ranksum(tmp_Data6_SD_Awake_ACC, tmp_Data6_SD_NREM_ACC);
else
    Night.Awake_vsNREM.SD72h.Pvalue = NaN; Night.Awake_vsNREM.SD72h.h = NaN; Night.Awake_vsNREM.SD72h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data6_SD_Awake_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Night.Awake_vsREM.SD72h.Pvalue, Night.Awake_vsREM.SD72h.h, Night.Awake_vsREM.SD72h.Stats] = ranksum(tmp_Data6_SD_Awake_ACC, tmp_Data6_SD_REM_ACC);
else
    Night.Awake_vsREM.SD72h.Pvalue = NaN; Night.Awake_vsREM.SD72h.h = NaN; Night.Awake_vsREM.SD72h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data6_SD_NREM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Night.NREM_vsREM.SD72h.Pvalue, Night.NREM_vsREM.SD72h.h, Night.NREM_vsREM.SD72h.Stats] = ranksum(tmp_Data6_SD_NREM_ACC, tmp_Data6_SD_REM_ACC);
else
    Night.NREM_vsREM.SD72h.Pvalue = NaN; Night.NREM_vsREM.SD72h.h = NaN; Night.NREM_vsREM.SD72h.Stats = NaN;
end

% Baseline vs SD 24-48-72
[Night.Awake.Baseline_vs_SD24h.Pvalue, Night.Awake.Baseline_vs_SD24h.h, Night.Awake.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_Awake_ACC, tmp_Data2_SD_Awake_ACC);
[Night.Awake.Baseline_vs_SD48h.Pvalue, Night.Awake.Baseline_vs_SD48h.h, Night.Awake.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_Awake_ACC, tmp_Data4_SD_Awake_ACC);
[Night.Awake.Baseline_vs_SD72h.Pvalue, Night.Awake.Baseline_vs_SD72h.h, Night.Awake.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_Awake_ACC, tmp_Data6_SD_Awake_ACC);

[Night.Awake.SD24h_vs_SD48h.Pvalue, Night.Awake.SD24h_vs_SD48h.h, Night.Awake.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data2_SD_Awake_ACC, tmp_Data4_SD_Awake_ACC);
[Night.Awake.SD24h_vs_SD72h.Pvalue, Night.Awake.SD24h_vs_SD72h.h, Night.Awake.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data2_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC);
[Night.Awake.SD48h_vs_SD72h.Pvalue, Night.Awake.SD48h_vs_SD72h.h, Night.Awake.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data4_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC);

[Night.NREM.Baseline_vs_SD24h.Pvalue, Night.NREM.Baseline_vs_SD24h.h, Night.NREM.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_NREM_ACC, tmp_Data2_SD_NREM_ACC);
[Night.NREM.Baseline_vs_SD48h.Pvalue, Night.NREM.Baseline_vs_SD48h.h, Night.NREM.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_NREM_ACC, tmp_Data4_SD_NREM_ACC);
[Night.NREM.Baseline_vs_SD72h.Pvalue, Night.NREM.Baseline_vs_SD72h.h, Night.NREM.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_NREM_ACC, tmp_Data6_SD_NREM_ACC);

[Night.NREM.SD24h_vs_SD48h.Pvalue, Night.NREM.SD24h_vs_SD48h.h, Night.NREM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data2_SD_NREM_ACC, tmp_Data4_SD_NREM_ACC);
[Night.NREM.SD24h_vs_SD72h.Pvalue, Night.NREM.SD24h_vs_SD72h.h, Night.NREM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data2_SD_NREM_ACC, tmp_Data6_SD_NREM_ACC);
[Night.NREM.SD48h_vs_SD72h.Pvalue, Night.NREM.SD48h_vs_SD72h.h, Night.NREM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data4_SD_NREM_ACC, tmp_Data6_SD_NREM_ACC);

[Night.REM.Baseline_vs_SD24h.Pvalue, Night.REM.Baseline_vs_SD24h.h, Night.REM.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_REM_ACC, tmp_Data2_SD_REM_ACC);
[Night.REM.Baseline_vs_SD48h.Pvalue, Night.REM.Baseline_vs_SD48h.h, Night.REM.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_REM_ACC, tmp_Data4_SD_REM_ACC);
if numel(find(~isnan(data_Night_Base_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Night.REM.Baseline_vs_SD72h.Pvalue, Night.REM.Baseline_vs_SD72h.h, Night.REM.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_REM_ACC, tmp_Data6_SD_REM_ACC);
else
    Night.REM.Baseline_vs_SD72h.Pvalue = NaN; Night.REM.Baseline_vs_SD72h.h = NaN; Night.REM.Baseline_vs_SD72h.Stats = NaN;
end

if numel(find(~isnan(tmp_Data2_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_ACC))) > min_n_events
    [Night.REM.SD24h_vs_SD48h.Pvalue, Night.REM.SD24h_vs_SD48h.h, Night.REM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data2_SD_REM_ACC, tmp_Data4_SD_REM_ACC);
else
    Night.REM.SD24h_vs_SD48h.Pvalue = NaN; Night.REM.SD24h_vs_SD48h.h = NaN; Night.REM.SD24h_vs_SD48h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Night.REM.SD24h_vs_SD72h.Pvalue, Night.REM.SD24h_vs_SD72h.h, Night.REM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data2_SD_REM_ACC, tmp_Data6_SD_REM_ACC);
else
    Night.REM.SD24h_vs_SD72h.Pvalue = NaN; Night.REM.SD24h_vs_SD72h.h = NaN; Night.REM.SD24h_vs_SD72h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data4_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Night.REM.SD48h_vs_SD72h.Pvalue, Night.REM.SD48h_vs_SD72h.h, Night.REM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data4_SD_REM_ACC, tmp_Data6_SD_REM_ACC);
else
    Night.REM.SD48h_vs_SD72h.Pvalue = NaN; Night.REM.SD48h_vs_SD72h.h = NaN; Night.REM.SD48h_vs_SD72h.Stats = NaN;
end

%% Statistics ACC - Day vs Night
[Day_vs_Night.Awake.Baseline_vs_Baseline.Pvalue, Day_vs_Night.Awake.Baseline_vs_Baseline.h, Day_vs_Night.Awake.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_Awake_ACC, data_Night_Base_Awake_ACC);
[Day_vs_Night.Awake.SD24h_vs_SD24h.Pvalue, Day_vs_Night.Awake.SD24h_vs_SD24h.h, Day_vs_Night.Awake.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data2_SD_Awake_ACC);
[Day_vs_Night.Awake.SD48h_vs_SD48h.Pvalue, Day_vs_Night.Awake.SD48h_vs_SD48h.h, Day_vs_Night.Awake.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_ACC, tmp_Data4_SD_Awake_ACC);
[Day_vs_Night.Awake.SD72h_vs_SD72h.Pvalue, Day_vs_Night.Awake.SD72h_vs_SD72h.h, Day_vs_Night.Awake.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC);

[Day_vs_Night.NREM.Baseline_vs_Baseline.Pvalue, Day_vs_Night.NREM.Baseline_vs_Baseline.h, Day_vs_Night.NREM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_NREM_ACC, data_Night_Base_NREM_ACC);
[Day_vs_Night.NREM.SD24h_vs_SD24h.Pvalue, Day_vs_Night.NREM.SD24h_vs_SD24h.h, Day_vs_Night.NREM.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_NREM_ACC, tmp_Data2_SD_NREM_ACC);
[Day_vs_Night.NREM.SD48h_vs_SD48h.Pvalue, Day_vs_Night.NREM.SD48h_vs_SD48h.h, Day_vs_Night.NREM.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_NREM_ACC, tmp_Data4_SD_NREM_ACC);
[Day_vs_Night.NREM.SD72h_vs_SD72h.Pvalue, Day_vs_Night.NREM.SD72h_vs_SD72h.h, Day_vs_Night.NREM.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_NREM_ACC, tmp_Data6_SD_NREM_ACC);

[Day_vs_Night.REM.Baseline_vs_Baseline.Pvalue, Day_vs_Night.REM.Baseline_vs_Baseline.h, Day_vs_Night.REM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_REM_ACC, data_Night_Base_REM_ACC);
[Day_vs_Night.REM.SD24h_vs_SD24h.Pvalue, Day_vs_Night.REM.SD24h_vs_SD24h.h, Day_vs_Night.REM.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_REM_ACC, tmp_Data2_SD_REM_ACC);
[Day_vs_Night.REM.SD48h_vs_SD48h.Pvalue, Day_vs_Night.REM.SD48h_vs_SD48h.h, Day_vs_Night.REM.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_REM_ACC, tmp_Data4_SD_REM_ACC);

if numel(find(~isnan(tmp_Data5_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events
    [Day_vs_Night.REM.SD72h_vs_SD72h.Pvalue, Day_vs_Night.REM.SD72h_vs_SD72h.h, Day_vs_Night.REM.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_REM_ACC, tmp_Data6_SD_REM_ACC);
else
    Day_vs_Night.REM.SD72h_vs_SD72h.Pvalue = NaN; Day_vs_Night.REM.SD72h_vs_SD72h.h = NaN; Day_vs_Night.REM.SD72h_vs_SD72h.Stats = NaN;
end

ACC.Day = Day;
ACC.Night = Night;
ACC.Day_vs_Night = Day_vs_Night;

%% Statistics BRC - Day
% Baseline Comparisons
[Day.Awake.Baseline1_vs_Baseline2.Pvalue, Day.Awake.Baseline1_vs_Baseline2.h, Day.Awake.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC);
[Day.Awake.Baseline1_vs_Baseline3.Pvalue, Day.Awake.Baseline1_vs_Baseline3.h, Day.Awake.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC);
[Day.Awake.Baseline2_vs_Baseline3.Pvalue, Day.Awake.Baseline2_vs_Baseline3.h, Day.Awake.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC);

[Day.NREM.Baseline1_vs_Baseline2.Pvalue, Day.NREM.Baseline1_vs_Baseline2.h, Day.NREM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_NREM_BRC, tmp_Data3_Base_NREM_BRC);
[Day.NREM.Baseline1_vs_Baseline3.Pvalue, Day.NREM.Baseline1_vs_Baseline3.h, Day.NREM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_NREM_BRC, tmp_Data5_Base_NREM_BRC);
[Day.NREM.Baseline2_vs_Baseline3.Pvalue, Day.NREM.Baseline2_vs_Baseline3.h, Day.NREM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_NREM_BRC, tmp_Data5_Base_NREM_BRC);

[Day.REM.Baseline1_vs_Baseline2.Pvalue, Day.REM.Baseline1_vs_Baseline2.h, Day.REM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC);
[Day.REM.Baseline1_vs_Baseline3.Pvalue, Day.REM.Baseline1_vs_Baseline3.h, Day.REM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_REM_BRC, tmp_Data5_Base_REM_BRC);
[Day.REM.Baseline2_vs_Baseline3.Pvalue, Day.REM.Baseline2_vs_Baseline3.h, Day.REM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC);

% Awake vs NREM vs REM
[Day.Awake_vsNREM.Baseline.Pvalue, Day.Awake_vsNREM.Baseline.h, Day.Awake_vsNREM.Baseline.Stats] = ranksum(data_Day_Base_Awake_BRC, data_Day_Base_NREM_BRC);
[Day.Awake_vsREM.Baseline.Pvalue, Day.Awake_vsREM.Baseline.h, Day.Awake_vsREM.Baseline.Stats] = ranksum(data_Day_Base_Awake_BRC, data_Day_Base_REM_BRC);
[Day.NREM_vsREM.Baseline.Pvalue, Day.NREM_vsREM.Baseline.h, Day.NREM_vsREM.Baseline.Stats] = ranksum(data_Day_Base_NREM_BRC, data_Day_Base_REM_BRC);

[Day.Awake_vsNREM.SD24h.Pvalue, Day.Awake_vsNREM.SD24h.h, Day.Awake_vsNREM.SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_BRC, tmp_Data1_SD_NREM_BRC);
[Day.Awake_vsREM.SD24h.Pvalue, Day.Awake_vsREM.SD24h.h, Day.Awake_vsREM.SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_BRC, tmp_Data1_SD_REM_BRC);
[Day.NREM_vsREM.SD24h.Pvalue, Day.NREM_vsREM.SD24h.h, Day.NREM_vsREM.SD24h.Stats] = ranksum(tmp_Data1_SD_NREM_BRC, tmp_Data1_SD_REM_BRC);

[Day.Awake_vsNREM.SD48h.Pvalue, Day.Awake_vsNREM.SD48h.h, Day.Awake_vsNREM.SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_BRC, tmp_Data3_SD_NREM_BRC);
[Day.Awake_vsREM.SD48h.Pvalue, Day.Awake_vsREM.SD48h.h, Day.Awake_vsREM.SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_BRC, tmp_Data3_SD_REM_BRC);
[Day.NREM_vsREM.SD48h.Pvalue, Day.NREM_vsREM.SD48h.h, Day.NREM_vsREM.SD48h.Stats] = ranksum(tmp_Data3_SD_NREM_BRC, tmp_Data3_SD_REM_BRC);

[Day.Awake_vsNREM.SD72h.Pvalue, Day.Awake_vsNREM.SD72h.h, Day.Awake_vsNREM.SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_BRC, tmp_Data5_SD_NREM_BRC);
[Day.Awake_vsREM.SD72h.Pvalue, Day.Awake_vsREM.SD72h.h, Day.Awake_vsREM.SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_BRC, tmp_Data5_SD_REM_BRC);
[Day.NREM_vsREM.SD72h.Pvalue, Day.NREM_vsREM.SD72h.h, Day.NREM_vsREM.SD72h.Stats] = ranksum(tmp_Data5_SD_NREM_BRC, tmp_Data5_SD_REM_BRC);

% Baseline vs SD 24-48-72
[Day.Awake.Baseline_vs_SD24h.Pvalue, Day.Awake.Baseline_vs_SD24h.h, Day.Awake.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_Awake_BRC, tmp_Data1_SD_Awake_BRC);
[Day.Awake.Baseline_vs_SD48h.Pvalue, Day.Awake.Baseline_vs_SD48h.h, Day.Awake.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_Awake_BRC, tmp_Data3_SD_Awake_BRC);
[Day.Awake.Baseline_vs_SD72h.Pvalue, Day.Awake.Baseline_vs_SD72h.h, Day.Awake.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_Awake_BRC, tmp_Data5_SD_Awake_BRC);

[Day.Awake.SD24h_vs_SD48h.Pvalue, Day.Awake.SD24h_vs_SD48h.h, Day.Awake.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_Awake_BRC, tmp_Data3_SD_Awake_BRC);
[Day.Awake.SD24h_vs_SD72h.Pvalue, Day.Awake.SD24h_vs_SD72h.h, Day.Awake.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_Awake_BRC, tmp_Data5_SD_Awake_BRC);
[Day.Awake.SD48h_vs_SD72h.Pvalue, Day.Awake.SD48h_vs_SD72h.h, Day.Awake.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_Awake_BRC, tmp_Data5_SD_Awake_BRC);

[Day.NREM.Baseline_vs_SD24h.Pvalue, Day.NREM.Baseline_vs_SD24h.h, Day.NREM.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_NREM_BRC, tmp_Data1_SD_NREM_BRC);
[Day.NREM.Baseline_vs_SD48h.Pvalue, Day.NREM.Baseline_vs_SD48h.h, Day.NREM.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_NREM_BRC, tmp_Data3_SD_NREM_BRC);
[Day.NREM.Baseline_vs_SD72h.Pvalue, Day.NREM.Baseline_vs_SD72h.h, Day.NREM.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_NREM_BRC, tmp_Data5_SD_NREM_BRC);

[Day.NREM.SD24h_vs_SD48h.Pvalue, Day.NREM.SD24h_vs_SD48h.h, Day.NREM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_NREM_BRC, tmp_Data3_SD_NREM_BRC);
[Day.NREM.SD24h_vs_SD72h.Pvalue, Day.NREM.SD24h_vs_SD72h.h, Day.NREM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_NREM_BRC, tmp_Data5_SD_NREM_BRC);
[Day.NREM.SD48h_vs_SD72h.Pvalue, Day.NREM.SD48h_vs_SD72h.h, Day.NREM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_NREM_BRC, tmp_Data5_SD_NREM_BRC);
% keyboard
[Day.REM.Baseline_vs_SD24h.Pvalue, Day.REM.Baseline_vs_SD24h.h, Day.REM.Baseline_vs_SD24h.Stats] = ranksum(data_Day_Base_REM_BRC, tmp_Data1_SD_REM_BRC);
[Day.REM.Baseline_vs_SD48h.Pvalue, Day.REM.Baseline_vs_SD48h.h, Day.REM.Baseline_vs_SD48h.Stats] = ranksum(data_Day_Base_REM_BRC, tmp_Data3_SD_REM_BRC);
[Day.REM.Baseline_vs_SD72h.Pvalue, Day.REM.Baseline_vs_SD72h.h, Day.REM.Baseline_vs_SD72h.Stats] = ranksum(data_Day_Base_REM_BRC, tmp_Data5_SD_REM_BRC);

[Day.REM.SD24h_vs_SD48h.Pvalue, Day.REM.SD24h_vs_SD48h.h, Day.REM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data1_SD_REM_BRC, tmp_Data3_SD_REM_BRC);
[Day.REM.SD24h_vs_SD72h.Pvalue, Day.REM.SD24h_vs_SD72h.h, Day.REM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data1_SD_REM_BRC, tmp_Data5_SD_REM_BRC);
[Day.REM.SD48h_vs_SD72h.Pvalue, Day.REM.SD48h_vs_SD72h.h, Day.REM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data3_SD_REM_BRC, tmp_Data5_SD_REM_BRC);


%% Statistics BRC - Night
% Baseline Comparisons
[Night.Awake.Baseline1_vs_Baseline2.Pvalue, Night.Awake.Baseline1_vs_Baseline2.h, Night.Awake.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC);
[Night.Awake.Baseline1_vs_Baseline3.Pvalue, Night.Awake.Baseline1_vs_Baseline3.h, Night.Awake.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data2_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC);
[Night.Awake.Baseline2_vs_Baseline3.Pvalue, Night.Awake.Baseline2_vs_Baseline3.h, Night.Awake.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC);

[Night.NREM.Baseline1_vs_Baseline2.Pvalue, Night.NREM.Baseline1_vs_Baseline2.h, Night.NREM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_NREM_BRC, tmp_Data3_Base_NREM_BRC);
[Night.NREM.Baseline1_vs_Baseline3.Pvalue, Night.NREM.Baseline1_vs_Baseline3.h, Night.NREM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_NREM_BRC, tmp_Data5_Base_NREM_BRC);
[Night.NREM.Baseline2_vs_Baseline3.Pvalue, Night.NREM.Baseline2_vs_Baseline3.h, Night.NREM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_NREM_BRC, tmp_Data5_Base_NREM_BRC);

[Night.REM.Baseline1_vs_Baseline2.Pvalue, Night.REM.Baseline1_vs_Baseline2.h, Night.REM.Baseline1_vs_Baseline2.Stats] = ranksum(tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC);
[Night.REM.Baseline1_vs_Baseline3.Pvalue, Night.REM.Baseline1_vs_Baseline3.h, Night.REM.Baseline1_vs_Baseline3.Stats] = ranksum(tmp_Data1_Base_REM_BRC, tmp_Data5_Base_REM_BRC);
[Night.REM.Baseline2_vs_Baseline3.Pvalue, Night.REM.Baseline2_vs_Baseline3.h, Night.REM.Baseline2_vs_Baseline3.Stats] = ranksum(tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC);

% Awake vs NREM vs REM
[Night.Awake_vsNREM.Baseline.Pvalue, Night.Awake_vsNREM.Baseline.h, Night.Awake_vsNREM.Baseline.Stats] = ranksum(data_Night_Base_Awake_BRC, data_Night_Base_NREM_BRC);
if numel(find(~isnan(data_Night_Base_Awake_BRC))) > min_n_events && numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events
    [Night.Awake_vsREM.Baseline.Pvalue, Night.Awake_vsREM.Baseline.h, Night.Awake_vsREM.Baseline.Stats] = ranksum(data_Night_Base_Awake_BRC, data_Night_Base_REM_BRC);
else
    Night.Awake_vsREM.Baseline.Pvalue = NaN; Night.Awake_vsREM.Baseline.h = NaN; Night.Awake_vsREM.Baseline.Stats = NaN;
end
if numel(find(~isnan(data_Night_Base_NREM_BRC))) > min_n_events && numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events
    [Night.NREM_vsREM.Baseline.Pvalue, Night.NREM_vsREM.Baseline.h, Night.NREM_vsREM.Baseline.Stats] = ranksum(data_Night_Base_NREM_BRC, data_Night_Base_REM_BRC);
else
    Night.NREM_vsREM.Baseline.Pvalue = NaN; Night.NREM_vsREM.Baseline.h = NaN; Night.NREM_vsREM.Baseline.Stats = NaN;
end

[Night.Awake_vsNREM.SD24h.Pvalue, Night.Awake_vsNREM.SD24h.h, Night.Awake_vsNREM.SD24h.Stats] = ranksum(tmp_Data2_SD_Awake_BRC, tmp_Data2_SD_NREM_BRC);
[Night.Awake_vsREM.SD24h.Pvalue, Night.Awake_vsREM.SD24h.h, Night.Awake_vsREM.SD24h.Stats] = ranksum(tmp_Data2_SD_Awake_BRC, tmp_Data2_SD_REM_BRC);
[Night.NREM_vsREM.SD24h.Pvalue, Night.NREM_vsREM.SD24h.h, Night.NREM_vsREM.SD24h.Stats] = ranksum(tmp_Data2_SD_NREM_BRC, tmp_Data2_SD_REM_BRC);

[Night.Awake_vsNREM.SD48h.Pvalue, Night.Awake_vsNREM.SD48h.h, Night.Awake_vsNREM.SD48h.Stats] = ranksum(tmp_Data4_SD_Awake_BRC, tmp_Data4_SD_NREM_BRC);
if numel(find(~isnan(tmp_Data4_SD_Awake_BRC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Night.Awake_vsREM.SD48h.Pvalue, Night.Awake_vsREM.SD48h.h, Night.Awake_vsREM.SD48h.Stats] = ranksum(tmp_Data4_SD_Awake_BRC, tmp_Data4_SD_REM_BRC);
else
    Night.Awake_vsREM.SD48h.Pvalue = NaN; Night.Awake_vsREM.SD48h.h = NaN; Night.Awake_vsREM.SD48h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data4_SD_NREM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Night.NREM_vsREM.SD48h.Pvalue, Night.NREM_vsREM.SD48h.h, Night.NREM_vsREM.SD48h.Stats] = ranksum(tmp_Data4_SD_NREM_BRC, tmp_Data4_SD_REM_BRC);
else
    Night.NREM_vsREM.SD48h.Pvalue = NaN; Night.NREM_vsREM.SD48h.h = NaN; Night.NREM_vsREM.SD48h.Stats = NaN;
end

[Night.Awake_vsNREM.SD72h.Pvalue, Night.Awake_vsNREM.SD72h.h, Night.Awake_vsNREM.SD72h.Stats] = ranksum(tmp_Data6_SD_Awake_BRC, tmp_Data6_SD_NREM_BRC);
if numel(find(~isnan(tmp_Data6_SD_Awake_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.Awake_vsREM.SD72h.Pvalue, Night.Awake_vsREM.SD72h.h, Night.Awake_vsREM.SD72h.Stats] = ranksum(tmp_Data6_SD_Awake_BRC, tmp_Data6_SD_REM_BRC);
else
    Night.Awake_vsREM.SD72h.Pvalue = NaN; Night.Awake_vsREM.SD72h.h = NaN; Night.Awake_vsREM.SD72h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data6_SD_NREM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.NREM_vsREM.SD72h.Pvalue, Night.NREM_vsREM.SD72h.h, Night.NREM_vsREM.SD72h.Stats] = ranksum(tmp_Data6_SD_NREM_BRC, tmp_Data6_SD_REM_BRC);
else
    Night.NREM_vsREM.SD72h.Pvalue = NaN; Night.NREM_vsREM.SD72h.h = NaN; Night.NREM_vsREM.SD72h.Stats = NaN;
end

% Baseline vs SD 24-48-72
[Night.Awake.Baseline_vs_SD24h.Pvalue, Night.Awake.Baseline_vs_SD24h.h, Night.Awake.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data2_SD_Awake_BRC);
[Night.Awake.Baseline_vs_SD48h.Pvalue, Night.Awake.Baseline_vs_SD48h.h, Night.Awake.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data4_SD_Awake_BRC);
[Night.Awake.Baseline_vs_SD72h.Pvalue, Night.Awake.Baseline_vs_SD72h.h, Night.Awake.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data6_SD_Awake_BRC);

[Night.Awake.Baseline_vs_SD24h.Pvalue, Night.Awake.Baseline_vs_SD24h.h, Night.Awake.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data2_SD_Awake_BRC);
[Night.Awake.Baseline_vs_SD48h.Pvalue, Night.Awake.Baseline_vs_SD48h.h, Night.Awake.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data4_SD_Awake_BRC);
[Night.Awake.Baseline_vs_SD72h.Pvalue, Night.Awake.Baseline_vs_SD72h.h, Night.Awake.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_Awake_BRC, tmp_Data6_SD_Awake_BRC);

[Night.NREM.Baseline_vs_SD24h.Pvalue, Night.NREM.Baseline_vs_SD24h.h, Night.NREM.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_NREM_BRC, tmp_Data2_SD_NREM_BRC);
[Night.NREM.Baseline_vs_SD48h.Pvalue, Night.NREM.Baseline_vs_SD48h.h, Night.NREM.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_NREM_BRC, tmp_Data4_SD_NREM_BRC);
[Night.NREM.Baseline_vs_SD72h.Pvalue, Night.NREM.Baseline_vs_SD72h.h, Night.NREM.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_NREM_BRC, tmp_Data6_SD_NREM_BRC);

[Night.NREM.SD24h_vs_SD48h.Pvalue, Night.NREM.SD24h_vs_SD48h.h, Night.NREM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data2_SD_NREM_BRC, tmp_Data4_SD_NREM_BRC);
[Night.NREM.SD24h_vs_SD72h.Pvalue, Night.NREM.SD24h_vs_SD72h.h, Night.NREM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data2_SD_NREM_BRC, tmp_Data6_SD_NREM_BRC);
[Night.NREM.SD48h_vs_SD72h.Pvalue, Night.NREM.SD48h_vs_SD72h.h, Night.NREM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data4_SD_NREM_BRC, tmp_Data6_SD_NREM_BRC);

if numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data2_SD_REM_BRC))) > min_n_events
    [Night.REM.Baseline_vs_SD24h.Pvalue, Night.REM.Baseline_vs_SD24h.h, Night.REM.Baseline_vs_SD24h.Stats] = ranksum(data_Night_Base_REM_BRC, tmp_Data2_SD_REM_BRC);
else
    Night.REM.Baseline_vs_SD24h.Pvalue = NaN; Night.REM.Baseline_vs_SD24h.h = NaN; Night.REM.Baseline_vs_SD24h.Stats = NaN;
end
if numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Night.REM.Baseline_vs_SD48h.Pvalue, Night.REM.Baseline_vs_SD48h.h, Night.REM.Baseline_vs_SD48h.Stats] = ranksum(data_Night_Base_REM_BRC, tmp_Data4_SD_REM_BRC);
else
    Night.REM.Baseline_vs_SD48h.Pvalue = NaN; Night.REM.Baseline_vs_SD48h.h = NaN; Night.REM.Baseline_vs_SD48h.Stats = NaN;
end
if numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.REM.Baseline_vs_SD72h.Pvalue, Night.REM.Baseline_vs_SD72h.h, Night.REM.Baseline_vs_SD72h.Stats] = ranksum(data_Night_Base_REM_BRC, tmp_Data6_SD_REM_BRC);
else
    Night.REM.Baseline_vs_SD72h.Pvalue = NaN; Night.REM.Baseline_vs_SD72h.h = NaN; Night.REM.Baseline_vs_SD72h.Stats = NaN;
end

if numel(find(~isnan(tmp_Data2_SD_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Night.REM.SD24h_vs_SD48h.Pvalue, Night.REM.SD24h_vs_SD48h.h, Night.REM.SD24h_vs_SD48h.Stats] = ranksum(tmp_Data2_SD_REM_BRC, tmp_Data4_SD_REM_BRC);
else
    Night.REM.SD24h_vs_SD48h.Pvalue = NaN; Night.REM.SD24h_vs_SD48h.h = NaN; Night.REM.SD24h_vs_SD48h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data2_SD_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.REM.SD24h_vs_SD72h.Pvalue, Night.REM.SD24h_vs_SD72h.h, Night.REM.SD24h_vs_SD72h.Stats] = ranksum(tmp_Data2_SD_REM_BRC, tmp_Data6_SD_REM_BRC);
else
    Night.REM.SD24h_vs_SD72h.Pvalue = NaN; Night.REM.SD24h_vs_SD72h.h = NaN; Night.REM.SD24h_vs_SD72h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.REM.SD48h_vs_SD72h.Pvalue, Night.REM.SD48h_vs_SD72h.h, Night.REM.SD48h_vs_SD72h.Stats] = ranksum(tmp_Data4_SD_REM_BRC, tmp_Data6_SD_REM_BRC);
else
    Night.REM.SD48h_vs_SD72h.Pvalue = NaN; Night.REM.SD48h_vs_SD72h.h = NaN; Night.REM.SD48h_vs_SD72h.Stats = NaN;
end


%% Statistics BRC - Day vs Night
[Day_vs_Night.Awake.Baseline_vs_Baseline.Pvalue, Day_vs_Night.Awake.Baseline_vs_Baseline.h, Day_vs_Night.Awake.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_Awake_BRC, data_Night_Base_Awake_BRC);
[Day_vs_Night.Awake.SD24h_vs_SD24h.Pvalue, Day_vs_Night.Awake.SD24h_vs_SD24h.h, Day_vs_Night.Awake.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_BRC, tmp_Data2_SD_Awake_BRC);
[Day_vs_Night.Awake.SD48h_vs_SD48h.Pvalue, Day_vs_Night.Awake.SD48h_vs_SD48h.h, Day_vs_Night.Awake.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_BRC, tmp_Data4_SD_Awake_BRC);
[Day_vs_Night.Awake.SD72h_vs_SD72h.Pvalue, Day_vs_Night.Awake.SD72h_vs_SD72h.h, Day_vs_Night.Awake.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_BRC, tmp_Data6_SD_Awake_BRC);

[Day_vs_Night.NREM.Baseline_vs_Baseline.Pvalue, Day_vs_Night.NREM.Baseline_vs_Baseline.h, Day_vs_Night.NREM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_NREM_BRC, data_Night_Base_NREM_BRC);
[Day_vs_Night.NREM.SD24h_vs_SD24h.Pvalue, Day_vs_Night.NREM.SD24h_vs_SD24h.h, Day_vs_Night.NREM.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_NREM_BRC, tmp_Data2_SD_NREM_BRC);
[Day_vs_Night.NREM.SD48h_vs_SD48h.Pvalue, Day_vs_Night.NREM.SD48h_vs_SD48h.h, Day_vs_Night.NREM.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_NREM_BRC, tmp_Data4_SD_NREM_BRC);
[Day_vs_Night.NREM.SD72h_vs_SD72h.Pvalue, Day_vs_Night.NREM.SD72h_vs_SD72h.h, Day_vs_Night.NREM.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_NREM_BRC, tmp_Data6_SD_NREM_BRC);

if numel(find(~isnan(data_Day_Base_REM_BRC))) > min_n_events && numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events
    [Day_vs_Night.REM.Baseline_vs_Baseline.Pvalue, Day_vs_Night.REM.Baseline_vs_Baseline.h, Day_vs_Night.REM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_REM_BRC, data_Night_Base_REM_BRC);
else
    Day_vs_Night.REM.Baseline_vs_Baseline.Pvalue = NaN; Day_vs_Night.REM.Baseline_vs_Baseline.h = NaN; Day_vs_Night.REM.Baseline_vs_Baseline.Stats = NaN;
end
[Day_vs_Night.REM.SD24h_vs_SD24h.Pvalue, Day_vs_Night.REM.SD24h_vs_SD24h.h, Day_vs_Night.REM.SD24h_vs_SD24h.Stats] = ranksum(tmp_Data1_SD_REM_BRC, tmp_Data2_SD_REM_BRC);
if numel(find(~isnan(tmp_Data3_SD_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Day_vs_Night.REM.SD48h_vs_SD48h.Pvalue, Day_vs_Night.REM.SD48h_vs_SD48h.h, Day_vs_Night.REM.SD48h_vs_SD48h.Stats] = ranksum(tmp_Data3_SD_REM_BRC, tmp_Data4_SD_REM_BRC);
else
    Day_vs_Night.REM.SD48h_vs_SD48h.Pvalue = NaN; Day_vs_Night.REM.SD48h_vs_SD48h.h = NaN; Day_vs_Night.REM.SD48h_vs_SD48h.Stats = NaN;
end
if numel(find(~isnan(tmp_Data5_SD_REM_BRC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Day_vs_Night.REM.SD72h_vs_SD72h.Pvalue, Day_vs_Night.REM.SD72h_vs_SD72h.h, Day_vs_Night.REM.SD72h_vs_SD72h.Stats] = ranksum(tmp_Data5_SD_REM_BRC, tmp_Data6_SD_REM_BRC);
else
    Day_vs_Night.REM.SD72h_vs_SD72h.Pvalue = NaN; Day_vs_Night.REM.SD72h_vs_SD72h.h = NaN; Day_vs_Night.REM.SD72h_vs_SD72h.Stats = NaN;
end
BRC.Day = Day;
BRC.Night = Night;
BRC.Day_vs_Night = Day_vs_Night;

%% Statistics ACC vs BRC
% Baseline Comparisons
[Day.Awake.Baseline_vs_Baseline.Pvalue, Day.Awake.Baseline_vs_Baseline.h, Day.Awake.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_Awake_ACC, data_Day_Base_Awake_BRC);
[Day.NREM.Baseline_vs_Baseline.Pvalue, Day.NREM.Baseline_vs_Baseline.h, Day.NREM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_NREM_ACC, data_Day_Base_NREM_BRC);
[Day.REM.Baseline_vs_Baseline.Pvalue, Day.REM.Baseline_vs_Baseline.h, Day.REM.Baseline_vs_Baseline.Stats] = ranksum(data_Day_Base_REM_ACC, data_Day_Base_REM_BRC);

[Night.Awake.Baseline_vs_Baseline.Pvalue, Night.Awake.Baseline_vs_Baseline.h, Night.Awake.Baseline_vs_Baseline.Stats] = ranksum(data_Night_Base_Awake_ACC, data_Night_Base_Awake_BRC);
[Night.NREM.Baseline_vs_Baseline.Pvalue, Night.NREM.Baseline_vs_Baseline.h, Night.NREM.Baseline_vs_Baseline.Stats] = ranksum(data_Night_Base_NREM_ACC, data_Night_Base_NREM_BRC);
if numel(find(~isnan(data_Night_Base_REM_ACC))) > min_n_events && numel(find(~isnan(data_Night_Base_REM_BRC))) > min_n_events
    [Night.REM.Baseline_vs_Baseline.Pvalue, Night.REM.Baseline_vs_Baseline.h, Night.REM.Baseline_vs_Baseline.Stats] = ranksum(data_Night_Base_REM_ACC, data_Night_Base_REM_BRC);
else
    Night.REM.Baseline_vs_Baseline.Pvalue = NaN; Night.REM.Baseline_vs_Baseline.h = NaN; Night.REM.Baseline_vs_Baseline.Stats = NaN;
end
% SD
[Day.Awake.SD24h.Pvalue, Day.Awake.SD24h.h, Day.Awake.SD24h.Stats] = ranksum(tmp_Data1_SD_Awake_ACC, tmp_Data1_SD_Awake_BRC);
[Day.NREM.SD24h.Pvalue, Day.NREM.SD24h.h, Day.NREM.SD24h.Stats] = ranksum(tmp_Data1_SD_NREM_ACC, tmp_Data1_SD_NREM_BRC);
[Day.REM.SD24h.Pvalue, Day.REM.SD24h.h, Day.REM.SD24h.Stats] = ranksum(tmp_Data1_SD_REM_ACC, tmp_Data1_SD_REM_BRC);

[Day.Awake.SD48h.Pvalue, Day.Awake.SD48h.h, Day.Awake.SD48h.Stats] = ranksum(tmp_Data3_SD_Awake_ACC, tmp_Data3_SD_Awake_BRC);
[Day.NREM.SD48h.Pvalue, Day.NREM.SD48h.h, Day.NREM.SD48h.Stats] = ranksum(tmp_Data3_SD_NREM_ACC, tmp_Data3_SD_NREM_BRC);
[Day.REM.SD48h.Pvalue, Day.REM.SD48h.h, Day.REM.SD48h.Stats] = ranksum(tmp_Data3_SD_REM_ACC, tmp_Data3_SD_REM_BRC);

[Day.Awake.SD72h.Pvalue, Day.Awake.SD72h.h, Day.Awake.SD72h.Stats] = ranksum(tmp_Data5_SD_Awake_ACC, tmp_Data5_SD_Awake_BRC);
[Day.NREM.SD72h.Pvalue, Day.NREM.SD72h.h, Day.NREM.SD72h.Stats] = ranksum(tmp_Data5_SD_NREM_ACC, tmp_Data5_SD_NREM_BRC);
[Day.REM.SD72h.Pvalue, Day.REM.SD72h.h, Day.REM.SD72h.Stats] = ranksum(tmp_Data5_SD_REM_ACC, tmp_Data5_SD_REM_BRC);

[Night.Awake.SD24h.Pvalue, Night.Awake.SD24h.h, Night.Awake.SD24h.Stats] = ranksum(tmp_Data2_SD_Awake_ACC, tmp_Data2_SD_Awake_BRC);
[Night.NREM.SD24h.Pvalue, Night.NREM.SD24h.h, Night.NREM.SD24h.Stats] = ranksum(tmp_Data2_SD_NREM_ACC, tmp_Data2_SD_NREM_BRC);
[Night.REM.SD24h.Pvalue, Night.REM.SD24h.h, Night.REM.SD24h.Stats] = ranksum(tmp_Data2_SD_REM_ACC, tmp_Data2_SD_REM_BRC);

[Night.Awake.SD48h.Pvalue, Night.Awake.SD48h.h, Night.Awake.SD48h.Stats] = ranksum(tmp_Data4_SD_Awake_ACC, tmp_Data4_SD_Awake_BRC);
[Night.NREM.SD48h.Pvalue, Night.NREM.SD48h.h, Night.NREM.SD48h.Stats] = ranksum(tmp_Data4_SD_NREM_ACC, tmp_Data4_SD_NREM_BRC);
if numel(find(~isnan(tmp_Data4_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data4_SD_REM_BRC))) > min_n_events
    [Night.REM.SD48h.Pvalue, Night.REM.SD48h.h, Night.REM.SD48h.Stats] = ranksum(tmp_Data4_SD_REM_ACC, tmp_Data4_SD_REM_BRC);
else
    Night.REM.SD48h.Pvalue = NaN; Night.REM.SD48h.h = NaN; Night.REM.SD48h.Stats = NaN;
end

[Night.Awake.SD72h.Pvalue, Night.Awake.SD72h.h, Night.Awake.SD72h.Stats] = ranksum(tmp_Data6_SD_Awake_ACC, tmp_Data6_SD_Awake_BRC);
[Night.NREM.SD72h.Pvalue, Night.NREM.SD72h.h, Night.NREM.SD72h.Stats] = ranksum(tmp_Data6_SD_NREM_ACC, tmp_Data6_SD_NREM_BRC);
if numel(find(~isnan(tmp_Data6_SD_REM_ACC))) > min_n_events && numel(find(~isnan(tmp_Data6_SD_REM_BRC))) > min_n_events
    [Night.REM.SD72h.Pvalue, Night.REM.SD72h.h, Night.REM.SD72h.Stats] = ranksum(tmp_Data6_SD_REM_ACC, tmp_Data6_SD_REM_BRC);
else
    Night.REM.SD72h.Pvalue = NaN; Night.REM.SD72h.h = NaN; Night.REM.SD72h.Stats = NaN;
end

ACCvsBRC.Day = Day;
ACCvsBRC.Night = Night;

% Save Output 
OutputStats.ACC = ACC;
OutputStats.BRC = BRC;
OutputStats.ACCvsBRC = ACCvsBRC;
