function Plot_EventsPerState_part4b_sub1 (Events_QT_ACC, Events_QT_BRC, MouseMeans_QT_ACC, MouseMeans_QT_BRC, AstroStatsQT, Opts)


%% Options
Color_Awake = Opts.AstroPlot.Color_Awake;
Color_NONREM = Opts.AstroPlot.Color_NONREM;
Color_REM = Opts.AstroPlot.Color_REM;
Color_Baseline_ACC = Opts.AstroPlot.Color_Baseline_ACC;
Color_SD1_ACC = Opts.AstroPlot.Color_SD1_ACC;
Color_SD2_ACC = Opts.AstroPlot.Color_SD2_ACC;
Color_SD3_ACC = Opts.AstroPlot.Color_SD3_ACC;
Color_Baseline_BRC = Opts.AstroPlot.Color_Baseline_BRC;
Color_SD1_BRC = Opts.AstroPlot.Color_SD1_BRC;
Color_SD2_BRC = Opts.AstroPlot.Color_SD2_BRC;
Color_SD3_BRC = Opts.AstroPlot.Color_SD3_BRC;


%% Initialize Data
% ACC
tmp_Data1_Base_Awake_ACC = [Events_QT_ACC(1).Awake];
tmp_Data2_Base_Awake_ACC = [Events_QT_ACC(2).Awake];
tmp_Data3_Base_Awake_ACC = [Events_QT_ACC(3).Awake];
tmp_Data4_Base_Awake_ACC = [Events_QT_ACC(4).Awake];
tmp_Data5_Base_Awake_ACC = [Events_QT_ACC(5).Awake];
tmp_Data6_Base_Awake_ACC = [Events_QT_ACC(6).Awake];
tmp_Data1_SD_Awake_ACC = [Events_QT_ACC(8).Awake];
tmp_Data2_SD_Awake_ACC = [Events_QT_ACC(9).Awake];
tmp_Data3_SD_Awake_ACC = [Events_QT_ACC(10).Awake];
tmp_Data4_SD_Awake_ACC = [Events_QT_ACC(11).Awake];
tmp_Data5_SD_Awake_ACC = [Events_QT_ACC(12).Awake];
tmp_Data6_SD_Awake_ACC = [Events_QT_ACC(13).Awake];
data_Day_Base_Awake_ACC = [tmp_Data1_Base_Awake_ACC, tmp_Data3_Base_Awake_ACC, tmp_Data5_Base_Awake_ACC];
data_Night_Base_Awake_ACC = [tmp_Data2_Base_Awake_ACC, tmp_Data4_Base_Awake_ACC, tmp_Data6_Base_Awake_ACC];

tmp_Data1_Base_NoNREM_ACC = [Events_QT_ACC(1).NoNREM];
tmp_Data2_Base_NoNREM_ACC = [Events_QT_ACC(2).NoNREM];
tmp_Data3_Base_NoNREM_ACC = [Events_QT_ACC(3).NoNREM];
tmp_Data4_Base_NoNREM_ACC = [Events_QT_ACC(4).NoNREM];
tmp_Data5_Base_NoNREM_ACC = [Events_QT_ACC(5).NoNREM];
tmp_Data6_Base_NoNREM_ACC = [Events_QT_ACC(6).NoNREM];
tmp_Data1_SD_NoNREM_ACC = [Events_QT_ACC(8).NoNREM];
tmp_Data2_SD_NoNREM_ACC = [Events_QT_ACC(9).NoNREM];
tmp_Data3_SD_NoNREM_ACC = [Events_QT_ACC(10).NoNREM];
tmp_Data4_SD_NoNREM_ACC = [Events_QT_ACC(11).NoNREM];
tmp_Data5_SD_NoNREM_ACC = [Events_QT_ACC(12).NoNREM];
tmp_Data6_SD_NoNREM_ACC = [Events_QT_ACC(13).NoNREM];
data_Day_Base_NoNREM_ACC = [tmp_Data1_Base_NoNREM_ACC, tmp_Data3_Base_NoNREM_ACC, tmp_Data5_Base_NoNREM_ACC];
data_Night_Base_NoNREM_ACC = [tmp_Data2_Base_NoNREM_ACC, tmp_Data4_Base_NoNREM_ACC, tmp_Data6_Base_NoNREM_ACC];

tmp_Data1_Base_REM_ACC = [Events_QT_ACC(1).REM];
tmp_Data2_Base_REM_ACC = [Events_QT_ACC(2).REM];
tmp_Data3_Base_REM_ACC = [Events_QT_ACC(3).REM];
tmp_Data4_Base_REM_ACC = [Events_QT_ACC(4).REM];
tmp_Data5_Base_REM_ACC = [Events_QT_ACC(5).REM];
tmp_Data6_Base_REM_ACC = [Events_QT_ACC(6).REM];
tmp_Data1_SD_REM_ACC = [Events_QT_ACC(8).REM];
tmp_Data2_SD_REM_ACC = [Events_QT_ACC(9).REM];
tmp_Data3_SD_REM_ACC = [Events_QT_ACC(10).REM];
tmp_Data4_SD_REM_ACC = [Events_QT_ACC(11).REM];
tmp_Data5_SD_REM_ACC = [Events_QT_ACC(12).REM];
tmp_Data6_SD_REM_ACC = [Events_QT_ACC(13).REM];
data_Day_Base_REM_ACC = [tmp_Data1_Base_REM_ACC, tmp_Data3_Base_REM_ACC, tmp_Data5_Base_REM_ACC];
data_Night_Base_REM_ACC = [tmp_Data2_Base_REM_ACC, tmp_Data4_Base_REM_ACC, tmp_Data6_Base_REM_ACC];

% Barrel Cortex
tmp_Data1_Base_Awake_BRC = [Events_QT_BRC(1).Awake];
tmp_Data2_Base_Awake_BRC = [Events_QT_BRC(2).Awake];
tmp_Data3_Base_Awake_BRC = [Events_QT_BRC(3).Awake];
tmp_Data4_Base_Awake_BRC = [Events_QT_BRC(4).Awake];
tmp_Data5_Base_Awake_BRC = [Events_QT_BRC(5).Awake];
tmp_Data6_Base_Awake_BRC = [Events_QT_BRC(6).Awake];
tmp_Data1_SD_Awake_BRC = [Events_QT_BRC(8).Awake];
tmp_Data2_SD_Awake_BRC = [Events_QT_BRC(9).Awake];
tmp_Data3_SD_Awake_BRC = [Events_QT_BRC(10).Awake];
tmp_Data4_SD_Awake_BRC = [Events_QT_BRC(11).Awake];
tmp_Data5_SD_Awake_BRC = [Events_QT_BRC(12).Awake];
tmp_Data6_SD_Awake_BRC = [Events_QT_BRC(13).Awake];
data_Day_Base_Awake_BRC = [tmp_Data1_Base_Awake_BRC, tmp_Data3_Base_Awake_BRC, tmp_Data5_Base_Awake_BRC];
data_Night_Base_Awake_BRC = [tmp_Data2_Base_Awake_BRC, tmp_Data4_Base_Awake_BRC, tmp_Data6_Base_Awake_BRC];

tmp_Data1_Base_NoNREM_BRC = [Events_QT_BRC(1).NoNREM];
tmp_Data2_Base_NoNREM_BRC = [Events_QT_BRC(2).NoNREM];
tmp_Data3_Base_NoNREM_BRC = [Events_QT_BRC(3).NoNREM];
tmp_Data4_Base_NoNREM_BRC = [Events_QT_BRC(4).NoNREM];
tmp_Data5_Base_NoNREM_BRC = [Events_QT_BRC(5).NoNREM];
tmp_Data6_Base_NoNREM_BRC = [Events_QT_BRC(6).NoNREM];
tmp_Data1_SD_NoNREM_BRC = [Events_QT_BRC(8).NoNREM];
tmp_Data2_SD_NoNREM_BRC = [Events_QT_BRC(9).NoNREM];
tmp_Data3_SD_NoNREM_BRC = [Events_QT_BRC(10).NoNREM];
tmp_Data4_SD_NoNREM_BRC = [Events_QT_BRC(11).NoNREM];
tmp_Data5_SD_NoNREM_BRC = [Events_QT_BRC(12).NoNREM];
tmp_Data6_SD_NoNREM_BRC = [Events_QT_BRC(13).NoNREM];
data_Day_Base_NoNREM_BRC = [tmp_Data1_Base_NoNREM_BRC, tmp_Data3_Base_NoNREM_BRC, tmp_Data5_Base_NoNREM_BRC];
data_Night_Base_NoNREM_BRC = [tmp_Data2_Base_NoNREM_BRC, tmp_Data4_Base_NoNREM_BRC, tmp_Data6_Base_NoNREM_BRC];

tmp_Data1_Base_REM_BRC = [Events_QT_BRC(1).REM];
tmp_Data2_Base_REM_BRC = [Events_QT_BRC(2).REM];
tmp_Data3_Base_REM_BRC = [Events_QT_BRC(3).REM];
tmp_Data4_Base_REM_BRC = [Events_QT_BRC(4).REM];
tmp_Data5_Base_REM_BRC = [Events_QT_BRC(5).REM];
tmp_Data6_Base_REM_BRC = [Events_QT_BRC(6).REM];
tmp_Data1_SD_REM_BRC = [Events_QT_BRC(8).REM];
tmp_Data2_SD_REM_BRC = [Events_QT_BRC(9).REM];
tmp_Data3_SD_REM_BRC = [Events_QT_BRC(10).REM];
tmp_Data4_SD_REM_BRC = [Events_QT_BRC(11).REM];
tmp_Data5_SD_REM_BRC = [Events_QT_BRC(12).REM];
tmp_Data6_SD_REM_BRC = [Events_QT_BRC(13).REM];
data_Day_Base_REM_BRC = [tmp_Data1_Base_REM_BRC, tmp_Data3_Base_REM_BRC, tmp_Data5_Base_REM_BRC];
data_Night_Base_REM_BRC = [tmp_Data2_Base_REM_BRC, tmp_Data4_Base_REM_BRC, tmp_Data6_Base_REM_BRC];

% Plot bars positions and comparisons between bars
BoxPlot_Positions = [1, 1.5, 2, 2.5, 4, 4.5, 5, 5.5, 7, 7.5, 8, 8.5, 10, 10.5, 11, 11.5, 13, 13.5, 14, 14.5, 16, 16.5, 17, 17.5];

% The comparisons between columns to show in the significance of. Each
% value is the position of the corresponding boxplot
if Opts.AstroPlot.FLAG_all_comparisons == 1
    Comparisons = {[BoxPlot_Positions(1),BoxPlot_Positions(2)], [BoxPlot_Positions(1),BoxPlot_Positions(3)], [BoxPlot_Positions(1),BoxPlot_Positions(4)], [BoxPlot_Positions(2),BoxPlot_Positions(3)], [BoxPlot_Positions(2),BoxPlot_Positions(4)], [BoxPlot_Positions(3),BoxPlot_Positions(4)],...
        [BoxPlot_Positions(5),BoxPlot_Positions(6)], [BoxPlot_Positions(5),BoxPlot_Positions(7)], [BoxPlot_Positions(5),BoxPlot_Positions(8)], [BoxPlot_Positions(6),BoxPlot_Positions(7)], [BoxPlot_Positions(6),BoxPlot_Positions(8)], [BoxPlot_Positions(7),BoxPlot_Positions(8)],...
        [BoxPlot_Positions(9),BoxPlot_Positions(10)], [BoxPlot_Positions(9),BoxPlot_Positions(11)], [BoxPlot_Positions(9),BoxPlot_Positions(12)], [BoxPlot_Positions(10),BoxPlot_Positions(11)], [BoxPlot_Positions(10),BoxPlot_Positions(12)], [BoxPlot_Positions(11),BoxPlot_Positions(12)],...
        [BoxPlot_Positions(13),BoxPlot_Positions(14)], [BoxPlot_Positions(13),BoxPlot_Positions(15)], [BoxPlot_Positions(13),BoxPlot_Positions(16)], [BoxPlot_Positions(14),BoxPlot_Positions(15)], [BoxPlot_Positions(14),BoxPlot_Positions(16)], [BoxPlot_Positions(15),BoxPlot_Positions(16)],...
        [BoxPlot_Positions(17),BoxPlot_Positions(18)], [BoxPlot_Positions(17),BoxPlot_Positions(19)], [BoxPlot_Positions(17),BoxPlot_Positions(20)], [BoxPlot_Positions(18),BoxPlot_Positions(19)], [BoxPlot_Positions(18),BoxPlot_Positions(20)], [BoxPlot_Positions(19),BoxPlot_Positions(20)],...
        [BoxPlot_Positions(21),BoxPlot_Positions(22)], [BoxPlot_Positions(21),BoxPlot_Positions(23)], [BoxPlot_Positions(21),BoxPlot_Positions(24)], [BoxPlot_Positions(22),BoxPlot_Positions(23)], [BoxPlot_Positions(22),BoxPlot_Positions(24)], [BoxPlot_Positions(23),BoxPlot_Positions(24)]};
else
    Comparisons = {[BoxPlot_Positions(1),BoxPlot_Positions(2)], [BoxPlot_Positions(1),BoxPlot_Positions(3)], [BoxPlot_Positions(1),BoxPlot_Positions(4)],...
        [BoxPlot_Positions(5),BoxPlot_Positions(6)], [BoxPlot_Positions(5),BoxPlot_Positions(7)], [BoxPlot_Positions(5),BoxPlot_Positions(8)],...
        [BoxPlot_Positions(9),BoxPlot_Positions(10)], [BoxPlot_Positions(9),BoxPlot_Positions(11)], [BoxPlot_Positions(9),BoxPlot_Positions(12)],...
        [BoxPlot_Positions(13),BoxPlot_Positions(14)], [BoxPlot_Positions(13),BoxPlot_Positions(15)], [BoxPlot_Positions(13),BoxPlot_Positions(16)],...
        [BoxPlot_Positions(17),BoxPlot_Positions(18)], [BoxPlot_Positions(17),BoxPlot_Positions(19)], [BoxPlot_Positions(17),BoxPlot_Positions(20)],...
        [BoxPlot_Positions(21),BoxPlot_Positions(22)], [BoxPlot_Positions(21),BoxPlot_Positions(23)], [BoxPlot_Positions(21),BoxPlot_Positions(24)]};
end


%% Plot 1: Day
figure(); set(gcf,'position', get(0,'screensize'));

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM

BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data1_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data3_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data5_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Day_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data1_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data3_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data5_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Day_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data1_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data3_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data5_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Day_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data1_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data3_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data5_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Day_Base_REM_ACC)), 18*ones(1, numel(tmp_Data1_SD_REM_ACC)), 19*ones(1, numel(tmp_Data3_SD_REM_ACC)), 20*ones(1, numel(tmp_Data5_SD_REM_ACC)), ...
    21*ones(1, numel(data_Day_Base_REM_BRC)), 22*ones(1, numel(tmp_Data1_SD_REM_BRC)), 23*ones(1, numel(tmp_Data3_SD_REM_BRC)), 24*ones(1, numel(tmp_Data5_SD_REM_BRC))];

% The actual data distributions
Data_BoxPlot = [data_Day_Base_Awake_ACC, tmp_Data1_SD_Awake_ACC, tmp_Data3_SD_Awake_ACC, tmp_Data5_SD_Awake_ACC, ...
    data_Day_Base_Awake_BRC, tmp_Data1_SD_Awake_BRC, tmp_Data3_SD_Awake_BRC, tmp_Data5_SD_Awake_BRC, ...
    data_Day_Base_NoNREM_ACC, tmp_Data1_SD_NoNREM_ACC, tmp_Data3_SD_NoNREM_ACC, tmp_Data5_SD_NoNREM_ACC, ...
    data_Day_Base_NoNREM_BRC, tmp_Data1_SD_NoNREM_BRC, tmp_Data3_SD_NoNREM_BRC, tmp_Data5_SD_NoNREM_BRC, ...
    data_Day_Base_REM_ACC, tmp_Data1_SD_REM_ACC, tmp_Data3_SD_REM_ACC, tmp_Data5_SD_REM_ACC, ...
    data_Day_Base_REM_BRC, tmp_Data1_SD_REM_BRC, tmp_Data3_SD_REM_BRC, tmp_Data5_SD_REM_BRC];

% Array of P-values, 1 for each comparison
if Opts.AstroPlot.FLAG_all_comparisons == 1
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Day.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Day.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Day.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Day.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Day.REM.Baseline_vs_SD72h.Pvalue];
end

hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BoxPlot_Widths = Opts.AstroPlot.BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(Data_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');

% Scatter Plot of Mouse Means
MouseMeans_QT_ACC_Awake = [MouseMeans_QT_ACC.Awake];
MouseMeans_QT_ACC_NREM = [MouseMeans_QT_ACC.NREM];
MouseMeans_QT_ACC_REM = [MouseMeans_QT_ACC.REM];
MouseMeans_QT_BRC_Awake = [MouseMeans_QT_BRC.Awake];
MouseMeans_QT_BRC_NREM = [MouseMeans_QT_BRC.NREM];
MouseMeans_QT_BRC_REM = [MouseMeans_QT_BRC.REM];

tmp_n = numel(MouseMeans_QT_ACC_Awake([1, 3, 5], :));
tmp_n1 = numel(MouseMeans_QT_ACC_Awake(1, :));
h_scatter_Base_1 = scatter(ones(1, tmp_n).*BoxPlot_Positions(1), reshape(MouseMeans_QT_ACC_Awake([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(2), reshape(MouseMeans_QT_ACC_Awake(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD1
h_scatter_SD2_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(3), reshape(MouseMeans_QT_ACC_Awake(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(4), reshape(MouseMeans_QT_ACC_Awake(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD3

h_scatter_Base_2 = scatter(ones(1, tmp_n).*BoxPlot_Positions(5), reshape(MouseMeans_QT_BRC_Awake([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(6), reshape(MouseMeans_QT_BRC_Awake(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD1
h_scatter_SD2_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(7), reshape(MouseMeans_QT_BRC_Awake(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(8), reshape(MouseMeans_QT_BRC_Awake(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD3

h_scatter_Base_3 = scatter(ones(1, tmp_n).*BoxPlot_Positions(9), reshape(MouseMeans_QT_ACC_NREM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(10), reshape(MouseMeans_QT_ACC_NREM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD1
h_scatter_SD2_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(11), reshape(MouseMeans_QT_ACC_NREM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(12), reshape(MouseMeans_QT_ACC_NREM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD3

h_scatter_Base_4 = scatter(ones(1, tmp_n).*BoxPlot_Positions(13), reshape(MouseMeans_QT_BRC_NREM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(14), reshape(MouseMeans_QT_BRC_NREM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD1
h_scatter_SD2_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(15), reshape(MouseMeans_QT_BRC_NREM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(16), reshape(MouseMeans_QT_BRC_NREM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD3

h_scatter_Base_5 = scatter(ones(1, tmp_n).*BoxPlot_Positions(17), reshape(MouseMeans_QT_ACC_REM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(18), reshape(MouseMeans_QT_ACC_REM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD1
h_scatter_SD2_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(19), reshape(MouseMeans_QT_ACC_REM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(20), reshape(MouseMeans_QT_ACC_REM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD3

h_scatter_Base_6 = scatter(ones(1, tmp_n).*BoxPlot_Positions(21), reshape(MouseMeans_QT_BRC_REM([1, 3, 5], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(22), reshape(MouseMeans_QT_BRC_REM(8, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD1
h_scatter_SD2_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(23), reshape(MouseMeans_QT_BRC_REM(10, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(24), reshape(MouseMeans_QT_BRC_REM(12, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD3



% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end

ylim([0, Opts.AstroPlot.Plot_YMax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + Opts.AstroPlot.BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});

ylabel(Opts.AstroPlot.str_ylabel)
title(Opts.AstroPlot.str_title_Day)

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

% Save
if Opts.AstroPlot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(Opts.AstroPlot.FilePath_Day, '.eps'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.jpg'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Day, '.fig'))
    close gcf
end


%% Plot 2: Night
figure(); set(gcf,'position', get(0,'screensize'));

% Plot first Awake, Day, Baseline vs Rec 1, 2, 3, then switch to night,
% then repeat for NREM and REM

BoxPlot_Groups = [1*ones(1, numel(data_Night_Base_Awake_ACC)), 2*ones(1, numel(tmp_Data2_SD_Awake_ACC)), 3*ones(1, numel(tmp_Data4_SD_Awake_ACC)), 4*ones(1, numel(tmp_Data6_SD_Awake_ACC)), ...
    5*ones(1, numel(data_Night_Base_Awake_BRC)), 6*ones(1, numel(tmp_Data2_SD_Awake_BRC)), 7*ones(1, numel(tmp_Data4_SD_Awake_BRC)), 8*ones(1, numel(tmp_Data6_SD_Awake_BRC)), ...
    9*ones(1, numel(data_Night_Base_NoNREM_ACC)), 10*ones(1, numel(tmp_Data2_SD_NoNREM_ACC)), 11*ones(1, numel(tmp_Data4_SD_NoNREM_ACC)), 12*ones(1, numel(tmp_Data6_SD_NoNREM_ACC)), ...
    13*ones(1, numel(data_Night_Base_NoNREM_BRC)), 14*ones(1, numel(tmp_Data2_SD_NoNREM_BRC)), 15*ones(1, numel(tmp_Data4_SD_NoNREM_BRC)), 16*ones(1, numel(tmp_Data6_SD_NoNREM_BRC)), ...
    17*ones(1, numel(data_Night_Base_REM_ACC)), 18*ones(1, numel(tmp_Data2_SD_REM_ACC)), 19*ones(1, numel(tmp_Data4_SD_REM_ACC)), 20*ones(1, numel(tmp_Data6_SD_REM_ACC)), ...
    21*ones(1, numel(data_Night_Base_REM_BRC)), 22*ones(1, numel(tmp_Data2_SD_REM_BRC)), 23*ones(1, numel(tmp_Data4_SD_REM_BRC)), 24*ones(1, numel(tmp_Data6_SD_REM_BRC))];

% The actual data distributions
Data_BoxPlot = [data_Night_Base_Awake_ACC, tmp_Data2_SD_Awake_ACC, tmp_Data4_SD_Awake_ACC, tmp_Data6_SD_Awake_ACC, ...
    data_Night_Base_Awake_BRC, tmp_Data2_SD_Awake_BRC, tmp_Data4_SD_Awake_BRC, tmp_Data6_SD_Awake_BRC, ...
    data_Night_Base_NoNREM_ACC, tmp_Data2_SD_NoNREM_ACC, tmp_Data4_SD_NoNREM_ACC, tmp_Data6_SD_NoNREM_ACC, ...
    data_Night_Base_NoNREM_BRC, tmp_Data2_SD_NoNREM_BRC, tmp_Data4_SD_NoNREM_BRC, tmp_Data6_SD_NoNREM_BRC, ...
    data_Night_Base_REM_ACC, tmp_Data2_SD_REM_ACC, tmp_Data4_SD_REM_ACC, tmp_Data6_SD_REM_ACC, ...
    data_Night_Base_REM_BRC, tmp_Data2_SD_REM_BRC, tmp_Data4_SD_REM_BRC, tmp_Data6_SD_REM_BRC];

% Array of P-values, 1 for each comparison
if Opts.AstroPlot.FLAG_all_comparisons == 1
    PVal_Array = [AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.Awake.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.NREM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.ACC.Night.REM.SD48h_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.SD24h_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.SD24h_vs_SD72h.Pvalue, AstroStatsQT.BRC.Night.REM.SD48h_vs_SD72h.Pvalue];
else
    PVal_Array = [AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.Awake.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.NREM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.ACC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.ACC.Night.REM.Baseline_vs_SD72h.Pvalue, ...
        AstroStatsQT.BRC.Night.REM.Baseline_vs_SD24h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD48h.Pvalue, AstroStatsQT.BRC.Night.REM.Baseline_vs_SD72h.Pvalue];
end

hold on; box on; axis square;
set(gca, 'YGrid', 'on', 'XGrid', 'off');
BoxPlot_Widths = Opts.AstroPlot.BP_Width*ones(1, numel(BoxPlot_Positions));
h_boxplot = boxplot(Data_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');

% Scatter Plot of Mouse Means
MouseMeans_QT_ACC_Awake = [MouseMeans_QT_ACC.Awake];
MouseMeans_QT_ACC_NREM = [MouseMeans_QT_ACC.NREM];
MouseMeans_QT_ACC_REM = [MouseMeans_QT_ACC.REM];
MouseMeans_QT_BRC_Awake = [MouseMeans_QT_BRC.Awake];
MouseMeans_QT_BRC_NREM = [MouseMeans_QT_BRC.NREM];
MouseMeans_QT_BRC_REM = [MouseMeans_QT_BRC.REM];

tmp_n = numel(MouseMeans_QT_ACC_Awake([2, 4, 6], :));
tmp_n1 = numel(MouseMeans_QT_ACC_Awake(2, :));
h_scatter_Base_1 = scatter(ones(1, tmp_n).*BoxPlot_Positions(1), reshape(MouseMeans_QT_ACC_Awake([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(2), reshape(MouseMeans_QT_ACC_Awake(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD1
h_scatter_SD2_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(3), reshape(MouseMeans_QT_ACC_Awake(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_1 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(4), reshape(MouseMeans_QT_ACC_Awake(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD3

h_scatter_Base_2 = scatter(ones(1, tmp_n).*BoxPlot_Positions(5), reshape(MouseMeans_QT_BRC_Awake([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(6), reshape(MouseMeans_QT_BRC_Awake(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD1
h_scatter_SD2_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(7), reshape(MouseMeans_QT_BRC_Awake(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_2 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(8), reshape(MouseMeans_QT_BRC_Awake(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD3

h_scatter_Base_3 = scatter(ones(1, tmp_n).*BoxPlot_Positions(9), reshape(MouseMeans_QT_ACC_NREM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(10), reshape(MouseMeans_QT_ACC_NREM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD1
h_scatter_SD2_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(11), reshape(MouseMeans_QT_ACC_NREM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_3 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(12), reshape(MouseMeans_QT_ACC_NREM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD3

h_scatter_Base_4 = scatter(ones(1, tmp_n).*BoxPlot_Positions(13), reshape(MouseMeans_QT_BRC_NREM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(14), reshape(MouseMeans_QT_BRC_NREM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD1
h_scatter_SD2_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(15), reshape(MouseMeans_QT_BRC_NREM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_4 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(16), reshape(MouseMeans_QT_BRC_NREM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD3

h_scatter_Base_5 = scatter(ones(1, tmp_n).*BoxPlot_Positions(17), reshape(MouseMeans_QT_ACC_REM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_ACC); % Baseline
h_scatter_SD1_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(18), reshape(MouseMeans_QT_ACC_REM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_ACC); % SD1
h_scatter_SD2_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(19), reshape(MouseMeans_QT_ACC_REM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_ACC); % SD2
h_scatter_SD3_5 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(20), reshape(MouseMeans_QT_ACC_REM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_ACC); % SD3

h_scatter_Base_6 = scatter(ones(1, tmp_n).*BoxPlot_Positions(21), reshape(MouseMeans_QT_BRC_REM([2, 4, 6], :), [1, tmp_n]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_Baseline_BRC); % Baseline
h_scatter_SD1_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(22), reshape(MouseMeans_QT_BRC_REM(9, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD3_BRC); % SD1
h_scatter_SD2_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(23), reshape(MouseMeans_QT_BRC_REM(11, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD2_BRC); % SD2
h_scatter_SD3_6 = scatter(ones(1, tmp_n1).*BoxPlot_Positions(24), reshape(MouseMeans_QT_BRC_REM(13, :), [1, tmp_n1]), Opts.AstroPlot.ScatterDotArea, 'filled', 'LineWidth', Opts.AstroPlot.ScatterDotLineWidth, 'MarkerFaceColor', Color_SD1_BRC); % SD3

% Color ACC
for j=8:8:length(h)
    h_patch_baseACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=5:8:length(h)
    h_patch_grey1ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=6:8:length(h)
    h_patch_grey2ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=7:8:length(h)
    h_patch_grey3ACC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_ACC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end

% Color BRC
for j=4:8:length(h)
    h_patch_baseBRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_Baseline_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=1:8:length(h)
    h_patch_grey1BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD1_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=2:8:length(h)
    h_patch_grey2BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD2_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end
for j=3:8:length(h)
    h_patch_grey3BRC = patch(get(h(j),'XData'),get(h(j),'YData'), Color_SD3_BRC, 'FaceAlpha', Opts.AstroPlot.PlotsTransparency);
end

ylim([0, Opts.AstroPlot.Plot_YMax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(2:4:end) + Opts.AstroPlot.BP_Width/2);
set(gca,'XTickLabel',{'ACC', 'BRC', 'ACC', 'BRC', 'ACC', 'BRC'});

ylabel(Opts.AstroPlot.str_ylabel)
title(Opts.AstroPlot.str_title_Night)

legend([h_patch_baseACC, h_patch_grey3ACC, h_patch_grey2ACC, h_patch_grey1ACC, h_patch_baseBRC, h_patch_grey3BRC, h_patch_grey2BRC, h_patch_grey1BRC], ...
    {'ACC Baseline', 'ACC SD Rec - 24h', 'ACC SD Rec - 48h', 'ACC SD Rec - 72h', 'BRC Baseline', 'BRC SD Rec - 24h', 'BRC SD Rec - 48h', 'BRC SD Rec - 72h'}, 'location', 'northeast');

% Save
if Opts.AstroPlot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(Opts.AstroPlot.FilePath_Night, '.eps'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Night, '.jpg'))
    saveas(gcf, strcat(Opts.AstroPlot.FilePath_Night, '.fig'))
    close gcf
end
