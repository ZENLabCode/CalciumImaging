function Plot_EventsPerState_part3 (Events_Data_ACC, Events_Data_BrC)
% This function plots the results for Christina Astrocytes Analysis

PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';

FLAG_Save = 1;


% Event Rate
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 0.1;
subplot(1, 3, 1);

tmp_Data1_Base = [Events_Data_ACC(1).EventRate.Awake];
tmp_Data2_Base = [Events_Data_ACC(2).EventRate.Awake];
tmp_Data3_Base = [Events_Data_ACC(3).EventRate.Awake];
tmp_Data4_Base = [Events_Data_ACC(4).EventRate.Awake];
tmp_Data5_Base = [Events_Data_ACC(5).EventRate.Awake];
tmp_Data6_Base = [Events_Data_ACC(6).EventRate.Awake];
tmp_Data1_SD = [Events_Data_ACC(8).EventRate.Awake];
tmp_Data2_SD = [Events_Data_ACC(9).EventRate.Awake];
tmp_Data3_SD = [Events_Data_ACC(10).EventRate.Awake];
tmp_Data4_SD = [Events_Data_ACC(11).EventRate.Awake];
tmp_Data5_SD = [Events_Data_ACC(12).EventRate.Awake];
tmp_Data6_SD = [Events_Data_ACC(13).EventRate.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventRate.NoNREM];
tmp_Data2_Base = [Events_Data_ACC(2).EventRate.NoNREM];
tmp_Data3_Base = [Events_Data_ACC(3).EventRate.NoNREM];
tmp_Data4_Base = [Events_Data_ACC(4).EventRate.NoNREM];
tmp_Data5_Base = [Events_Data_ACC(5).EventRate.NoNREM];
tmp_Data6_Base = [Events_Data_ACC(6).EventRate.NoNREM];
tmp_Data1_SD = [Events_Data_ACC(8).EventRate.NoNREM];
tmp_Data2_SD = [Events_Data_ACC(9).EventRate.NoNREM];
tmp_Data3_SD = [Events_Data_ACC(10).EventRate.NoNREM];
tmp_Data4_SD = [Events_Data_ACC(11).EventRate.NoNREM];
tmp_Data5_SD = [Events_Data_ACC(12).EventRate.NoNREM];
tmp_Data6_SD = [Events_Data_ACC(13).EventRate.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventRate.REM];
tmp_Data2_Base = [Events_Data_ACC(2).EventRate.REM];
tmp_Data3_Base = [Events_Data_ACC(3).EventRate.REM];
tmp_Data4_Base = [Events_Data_ACC(4).EventRate.REM];
tmp_Data5_Base = [Events_Data_ACC(5).EventRate.REM];
tmp_Data6_Base = [Events_Data_ACC(6).EventRate.REM];
tmp_Data1_SD = [Events_Data_ACC(8).EventRate.REM];
tmp_Data2_SD = [Events_Data_ACC(9).EventRate.REM];
tmp_Data3_SD = [Events_Data_ACC(10).EventRate.REM];
tmp_Data4_SD = [Events_Data_ACC(11).EventRate.REM];
tmp_Data5_SD = [Events_Data_ACC(12).EventRate.REM];
tmp_Data6_SD = [Events_Data_ACC(13).EventRate.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz] - ACC - Baseline vs SD')

legend([h_patch_blue, h_patch_yellow], {'SD Recovery', 'Baseline'}, 'location', 'northeast');

% Integrals
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

Plot_ymax = 140;
subplot(1, 3, 2);
tmp_Data1_Base = [Events_Data_ACC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base = [Events_Data_ACC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base = [Events_Data_ACC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base = [Events_Data_ACC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base = [Events_Data_ACC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base = [Events_Data_ACC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD = [Events_Data_ACC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD = [Events_Data_ACC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD = [Events_Data_ACC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD = [Events_Data_ACC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD = [Events_Data_ACC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD = [Events_Data_ACC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base = [Events_Data_ACC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base = [Events_Data_ACC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base = [Events_Data_ACC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base = [Events_Data_ACC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base = [Events_Data_ACC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD = [Events_Data_ACC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD = [Events_Data_ACC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD = [Events_Data_ACC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD = [Events_Data_ACC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD = [Events_Data_ACC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD = [Events_Data_ACC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventIntegral_Mean.REM];
tmp_Data2_Base = [Events_Data_ACC(2).EventIntegral_Mean.REM];
tmp_Data3_Base = [Events_Data_ACC(3).EventIntegral_Mean.REM];
tmp_Data4_Base = [Events_Data_ACC(4).EventIntegral_Mean.REM];
tmp_Data5_Base = [Events_Data_ACC(5).EventIntegral_Mean.REM];
tmp_Data6_Base = [Events_Data_ACC(6).EventIntegral_Mean.REM];
tmp_Data1_SD = [Events_Data_ACC(8).EventIntegral_Mean.REM];
tmp_Data2_SD = [Events_Data_ACC(9).EventIntegral_Mean.REM];
tmp_Data3_SD = [Events_Data_ACC(10).EventIntegral_Mean.REM];
tmp_Data4_SD = [Events_Data_ACC(11).EventIntegral_Mean.REM];
tmp_Data5_SD = [Events_Data_ACC(12).EventIntegral_Mean.REM];
tmp_Data6_SD = [Events_Data_ACC(13).EventIntegral_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Integral')
title('Events Integrals - ACC - Baseline vs SD')


% Amplitude
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

Plot_ymax = 60;
subplot(1, 3, 3);
tmp_Data1_Base = [Events_Data_ACC(1).EventAmplitude_Mean.Awake];
tmp_Data2_Base = [Events_Data_ACC(2).EventAmplitude_Mean.Awake];
tmp_Data3_Base = [Events_Data_ACC(3).EventAmplitude_Mean.Awake];
tmp_Data4_Base = [Events_Data_ACC(4).EventAmplitude_Mean.Awake];
tmp_Data5_Base = [Events_Data_ACC(5).EventAmplitude_Mean.Awake];
tmp_Data6_Base = [Events_Data_ACC(6).EventAmplitude_Mean.Awake];
tmp_Data1_SD = [Events_Data_ACC(8).EventAmplitude_Mean.Awake];
tmp_Data2_SD = [Events_Data_ACC(9).EventAmplitude_Mean.Awake];
tmp_Data3_SD = [Events_Data_ACC(10).EventAmplitude_Mean.Awake];
tmp_Data4_SD = [Events_Data_ACC(11).EventAmplitude_Mean.Awake];
tmp_Data5_SD = [Events_Data_ACC(12).EventAmplitude_Mean.Awake];
tmp_Data6_SD = [Events_Data_ACC(13).EventAmplitude_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_Base = [Events_Data_ACC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_Base = [Events_Data_ACC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_Base = [Events_Data_ACC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_Base = [Events_Data_ACC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_Base = [Events_Data_ACC(6).EventAmplitude_Mean.NoNREM];
tmp_Data1_SD = [Events_Data_ACC(8).EventAmplitude_Mean.NoNREM];
tmp_Data2_SD = [Events_Data_ACC(9).EventAmplitude_Mean.NoNREM];
tmp_Data3_SD = [Events_Data_ACC(10).EventAmplitude_Mean.NoNREM];
tmp_Data4_SD = [Events_Data_ACC(11).EventAmplitude_Mean.NoNREM];
tmp_Data5_SD = [Events_Data_ACC(12).EventAmplitude_Mean.NoNREM];
tmp_Data6_SD = [Events_Data_ACC(13).EventAmplitude_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_ACC(1).EventAmplitude_Mean.REM];
tmp_Data2_Base = [Events_Data_ACC(2).EventAmplitude_Mean.REM];
tmp_Data3_Base = [Events_Data_ACC(3).EventAmplitude_Mean.REM];
tmp_Data4_Base = [Events_Data_ACC(4).EventAmplitude_Mean.REM];
tmp_Data5_Base = [Events_Data_ACC(5).EventAmplitude_Mean.REM];
tmp_Data6_Base = [Events_Data_ACC(6).EventAmplitude_Mean.REM];
tmp_Data1_SD = [Events_Data_ACC(8).EventAmplitude_Mean.REM];
tmp_Data2_SD = [Events_Data_ACC(9).EventAmplitude_Mean.REM];
tmp_Data3_SD = [Events_Data_ACC(10).EventAmplitude_Mean.REM];
tmp_Data4_SD = [Events_Data_ACC(11).EventAmplitude_Mean.REM];
tmp_Data5_SD = [Events_Data_ACC(12).EventAmplitude_Mean.REM];
tmp_Data6_SD = [Events_Data_ACC(13).EventAmplitude_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Amplitude (dF/F)')
title('Events Amplitude - ACC - Baseline vs SD')


FileName = sprintf('ACC - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



















% Event Rate
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 0.1;
subplot(1, 3, 1);

tmp_Data1_Base = [Events_Data_BrC(1).EventRate.Awake];
tmp_Data2_Base = [Events_Data_BrC(2).EventRate.Awake];
tmp_Data3_Base = [Events_Data_BrC(3).EventRate.Awake];
tmp_Data4_Base = [Events_Data_BrC(4).EventRate.Awake];
tmp_Data5_Base = [Events_Data_BrC(5).EventRate.Awake];
tmp_Data6_Base = [Events_Data_BrC(6).EventRate.Awake];
tmp_Data1_SD = [Events_Data_BrC(8).EventRate.Awake];
tmp_Data2_SD = [Events_Data_BrC(9).EventRate.Awake];
tmp_Data3_SD = [Events_Data_BrC(10).EventRate.Awake];
tmp_Data4_SD = [Events_Data_BrC(11).EventRate.Awake];
tmp_Data5_SD = [Events_Data_BrC(12).EventRate.Awake];
tmp_Data6_SD = [Events_Data_BrC(13).EventRate.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventRate.NoNREM];
tmp_Data2_Base = [Events_Data_BrC(2).EventRate.NoNREM];
tmp_Data3_Base = [Events_Data_BrC(3).EventRate.NoNREM];
tmp_Data4_Base = [Events_Data_BrC(4).EventRate.NoNREM];
tmp_Data5_Base = [Events_Data_BrC(5).EventRate.NoNREM];
tmp_Data6_Base = [Events_Data_BrC(6).EventRate.NoNREM];
tmp_Data1_SD = [Events_Data_BrC(8).EventRate.NoNREM];
tmp_Data2_SD = [Events_Data_BrC(9).EventRate.NoNREM];
tmp_Data3_SD = [Events_Data_BrC(10).EventRate.NoNREM];
tmp_Data4_SD = [Events_Data_BrC(11).EventRate.NoNREM];
tmp_Data5_SD = [Events_Data_BrC(12).EventRate.NoNREM];
tmp_Data6_SD = [Events_Data_BrC(13).EventRate.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventRate.REM];
tmp_Data2_Base = [Events_Data_BrC(2).EventRate.REM];
tmp_Data3_Base = [Events_Data_BrC(3).EventRate.REM];
tmp_Data4_Base = [Events_Data_BrC(4).EventRate.REM];
tmp_Data5_Base = [Events_Data_BrC(5).EventRate.REM];
tmp_Data6_Base = [Events_Data_BrC(6).EventRate.REM];
tmp_Data1_SD = [Events_Data_BrC(8).EventRate.REM];
tmp_Data2_SD = [Events_Data_BrC(9).EventRate.REM];
tmp_Data3_SD = [Events_Data_BrC(10).EventRate.REM];
tmp_Data4_SD = [Events_Data_BrC(11).EventRate.REM];
tmp_Data5_SD = [Events_Data_BrC(12).EventRate.REM];
tmp_Data6_SD = [Events_Data_BrC(13).EventRate.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz] - BrC - Baseline vs SD')

legend([h_patch_blue, h_patch_yellow], {'SD Recovery', 'Baseline'}, 'location', 'northeast');

% Integrals
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

Plot_ymax = 140;
subplot(1, 3, 2);
tmp_Data1_Base = [Events_Data_BrC(1).EventIntegral_Mean.Awake];
tmp_Data2_Base = [Events_Data_BrC(2).EventIntegral_Mean.Awake];
tmp_Data3_Base = [Events_Data_BrC(3).EventIntegral_Mean.Awake];
tmp_Data4_Base = [Events_Data_BrC(4).EventIntegral_Mean.Awake];
tmp_Data5_Base = [Events_Data_BrC(5).EventIntegral_Mean.Awake];
tmp_Data6_Base = [Events_Data_BrC(6).EventIntegral_Mean.Awake];
tmp_Data1_SD = [Events_Data_BrC(8).EventIntegral_Mean.Awake];
tmp_Data2_SD = [Events_Data_BrC(9).EventIntegral_Mean.Awake];
tmp_Data3_SD = [Events_Data_BrC(10).EventIntegral_Mean.Awake];
tmp_Data4_SD = [Events_Data_BrC(11).EventIntegral_Mean.Awake];
tmp_Data5_SD = [Events_Data_BrC(12).EventIntegral_Mean.Awake];
tmp_Data6_SD = [Events_Data_BrC(13).EventIntegral_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_Base = [Events_Data_BrC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_Base = [Events_Data_BrC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_Base = [Events_Data_BrC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_Base = [Events_Data_BrC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_Base = [Events_Data_BrC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_SD = [Events_Data_BrC(8).EventIntegral_Mean.NoNREM];
tmp_Data2_SD = [Events_Data_BrC(9).EventIntegral_Mean.NoNREM];
tmp_Data3_SD = [Events_Data_BrC(10).EventIntegral_Mean.NoNREM];
tmp_Data4_SD = [Events_Data_BrC(11).EventIntegral_Mean.NoNREM];
tmp_Data5_SD = [Events_Data_BrC(12).EventIntegral_Mean.NoNREM];
tmp_Data6_SD = [Events_Data_BrC(13).EventIntegral_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventIntegral_Mean.REM];
tmp_Data2_Base = [Events_Data_BrC(2).EventIntegral_Mean.REM];
tmp_Data3_Base = [Events_Data_BrC(3).EventIntegral_Mean.REM];
tmp_Data4_Base = [Events_Data_BrC(4).EventIntegral_Mean.REM];
tmp_Data5_Base = [Events_Data_BrC(5).EventIntegral_Mean.REM];
tmp_Data6_Base = [Events_Data_BrC(6).EventIntegral_Mean.REM];
tmp_Data1_SD = [Events_Data_BrC(8).EventIntegral_Mean.REM];
tmp_Data2_SD = [Events_Data_BrC(9).EventIntegral_Mean.REM];
tmp_Data3_SD = [Events_Data_BrC(10).EventIntegral_Mean.REM];
tmp_Data4_SD = [Events_Data_BrC(11).EventIntegral_Mean.REM];
tmp_Data5_SD = [Events_Data_BrC(12).EventIntegral_Mean.REM];
tmp_Data6_SD = [Events_Data_BrC(13).EventIntegral_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Integral')
title('Events Integrals - BrC - Baseline vs SD')


% Amplitude
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;

Plot_ymax = 60;
subplot(1, 3, 3);
tmp_Data1_Base = [Events_Data_BrC(1).EventAmplitude_Mean.Awake];
tmp_Data2_Base = [Events_Data_BrC(2).EventAmplitude_Mean.Awake];
tmp_Data3_Base = [Events_Data_BrC(3).EventAmplitude_Mean.Awake];
tmp_Data4_Base = [Events_Data_BrC(4).EventAmplitude_Mean.Awake];
tmp_Data5_Base = [Events_Data_BrC(5).EventAmplitude_Mean.Awake];
tmp_Data6_Base = [Events_Data_BrC(6).EventAmplitude_Mean.Awake];
tmp_Data1_SD = [Events_Data_BrC(8).EventAmplitude_Mean.Awake];
tmp_Data2_SD = [Events_Data_BrC(9).EventAmplitude_Mean.Awake];
tmp_Data3_SD = [Events_Data_BrC(10).EventAmplitude_Mean.Awake];
tmp_Data4_SD = [Events_Data_BrC(11).EventAmplitude_Mean.Awake];
tmp_Data5_SD = [Events_Data_BrC(12).EventAmplitude_Mean.Awake];
tmp_Data6_SD = [Events_Data_BrC(13).EventAmplitude_Mean.Awake];
data_Day_Base_Awake = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_Awake = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_Awake = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_Awake = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_Base = [Events_Data_BrC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_Base = [Events_Data_BrC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_Base = [Events_Data_BrC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_Base = [Events_Data_BrC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_Base = [Events_Data_BrC(6).EventAmplitude_Mean.NoNREM];
tmp_Data1_SD = [Events_Data_BrC(8).EventAmplitude_Mean.NoNREM];
tmp_Data2_SD = [Events_Data_BrC(9).EventAmplitude_Mean.NoNREM];
tmp_Data3_SD = [Events_Data_BrC(10).EventAmplitude_Mean.NoNREM];
tmp_Data4_SD = [Events_Data_BrC(11).EventAmplitude_Mean.NoNREM];
tmp_Data5_SD = [Events_Data_BrC(12).EventAmplitude_Mean.NoNREM];
tmp_Data6_SD = [Events_Data_BrC(13).EventAmplitude_Mean.NoNREM];
data_Day_Base_NoNREM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_NoNREM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_NoNREM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_NoNREM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
tmp_Data1_Base = [Events_Data_BrC(1).EventAmplitude_Mean.REM];
tmp_Data2_Base = [Events_Data_BrC(2).EventAmplitude_Mean.REM];
tmp_Data3_Base = [Events_Data_BrC(3).EventAmplitude_Mean.REM];
tmp_Data4_Base = [Events_Data_BrC(4).EventAmplitude_Mean.REM];
tmp_Data5_Base = [Events_Data_BrC(5).EventAmplitude_Mean.REM];
tmp_Data6_Base = [Events_Data_BrC(6).EventAmplitude_Mean.REM];
tmp_Data1_SD = [Events_Data_BrC(8).EventAmplitude_Mean.REM];
tmp_Data2_SD = [Events_Data_BrC(9).EventAmplitude_Mean.REM];
tmp_Data3_SD = [Events_Data_BrC(10).EventAmplitude_Mean.REM];
tmp_Data4_SD = [Events_Data_BrC(11).EventAmplitude_Mean.REM];
tmp_Data5_SD = [Events_Data_BrC(12).EventAmplitude_Mean.REM];
tmp_Data6_SD = [Events_Data_BrC(13).EventAmplitude_Mean.REM];
data_Day_Base_REM = [tmp_Data1_Base, tmp_Data3_Base, tmp_Data5_Base];
data_Day_SD_REM = [tmp_Data1_SD, tmp_Data3_SD, tmp_Data5_SD];
data_Night_Base_REM = [tmp_Data2_Base, tmp_Data4_Base, tmp_Data6_Base];
data_Night_SD_REM = [tmp_Data2_SD, tmp_Data4_SD, tmp_Data6_SD];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_Base_Awake)), 2*ones(1, numel(data_Day_SD_Awake)), 3*ones(1, numel(data_Night_Base_Awake)), 4*ones(1, numel(data_Night_SD_Awake)), 5*ones(1, numel(data_Day_Base_NoNREM)), 6*ones(1, numel(data_Day_SD_NoNREM)), 7*ones(1, numel(data_Night_Base_NoNREM)), 8*ones(1, numel(data_Night_SD_NoNREM)), 9*ones(1, numel(data_Day_Base_REM)), 10*ones(1, numel(data_Day_SD_REM)), 11*ones(1, numel(data_Night_Base_REM)), 12*ones(1, numel(data_Night_SD_REM))];
EventsRate_BoxPlot = [data_Day_Base_Awake, data_Day_SD_Awake, data_Night_Base_Awake, data_Night_SD_Awake, data_Day_Base_NoNREM, data_Day_SD_NoNREM, data_Night_Base_NoNREM, data_Night_SD_NoNREM, data_Day_Base_REM, data_Day_SD_REM, data_Night_Base_REM, data_Night_SD_REM];
hold on; box on; axis square; grid on;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'r', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'k', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Amplitude (dF/F)')
title('Events Amplitude - BrC - Baseline vs SD')


FileName = sprintf('BrC - Baselines vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
