function Plot_EventsPerState_part2 (Events_Data_ACC, Events_Data_BrC, AstroStats)
% This function plots the results for Christina Astrocytes Analysis.
% The plot made is baselines ACC vs baselines BRC


Stats_Type = 'ttest2'; % 'ranksum' or 'ttest2'
if exist('AstroStats', 'var') == 0
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end
if isempty(AstroStats)
    [AstroStats, N_Events] = Astrocyte_Stats (Events_Data_ACC, Events_Data_BrC, Stats_Type);
end
PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';
if exist(PlotPath, 'dir') == 0
    PlotPath = pwd;
end

% Options
FLAG_Save = 1;

Opts.AstroPlot.FLAG_SortPValue = 0;
BoxPlot_Positions = [1, 1.5, 3, 3.5, 5, 5.5, 7, 7.5, 9, 9.5, 11, 11.5];

Comparisons = {[BoxPlot_Positions(1),BoxPlot_Positions(2)], [BoxPlot_Positions(3),BoxPlot_Positions(4)], [BoxPlot_Positions(5),BoxPlot_Positions(6)],...
    [BoxPlot_Positions(7),BoxPlot_Positions(8)], [BoxPlot_Positions(9),BoxPlot_Positions(10)], [BoxPlot_Positions(11),BoxPlot_Positions(12)]};

Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.5;


figure(); set(gcf,'position', get(0,'screensize'));


%% Event Rate
Plot_ymax = 0.1;

subplot(1, 3, 1);

AstroStatsQT = AstroStats.ERate;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventRate.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventRate.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventRate.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventRate.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventRate.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventRate.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventRate.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventRate.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventRate.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventRate.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventRate.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventRate.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_ACC_Awake)), 2*ones(1, numel(data_Day_BrC_Awake)), 3*ones(1, numel(data_Night_ACC_Awake)), 4*ones(1, numel(data_Night_BrC_Awake)), 5*ones(1, numel(data_Day_ACC_NoNREM)), 6*ones(1, numel(data_Day_BrC_NoNREM)), 7*ones(1, numel(data_Night_ACC_NoNREM)), 8*ones(1, numel(data_Night_BrC_NoNREM)), 9*ones(1, numel(data_Day_ACC_REM)), 10*ones(1, numel(data_Day_BrC_REM)), 11*ones(1, numel(data_Night_ACC_REM)), 12*ones(1, numel(data_Night_BrC_REM))];
EventsRate_BoxPlot = [data_Day_ACC_Awake, data_Day_BrC_Awake, data_Night_ACC_Awake, data_Night_BrC_Awake, data_Day_ACC_NoNREM, data_Day_BrC_NoNREM, data_Night_ACC_NoNREM, data_Night_BrC_NoNREM, data_Day_ACC_REM, data_Day_BrC_REM, data_Night_ACC_REM, data_Night_BrC_REM];
hold on; box on; axis square; grid on;
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');

% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'b', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'y', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Ca2+ Events Rate [Hz]')
title('Events Rate [Hz]')

legend([h_patch_blue, h_patch_yellow], {'BrC', 'ACC'}, 'location', 'northeast');



%% Integrals
Plot_ymax = 140;

subplot(1, 3, 2);

AstroStatsQT = AstroStats.Integrals;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventIntegral_Mean.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventIntegral_Mean.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventIntegral_Mean.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventIntegral_Mean.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventIntegral_Mean.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventIntegral_Mean.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventIntegral_Mean.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventIntegral_Mean.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventIntegral_Mean.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventIntegral_Mean.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventIntegral_Mean.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventIntegral_Mean.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_ACC_Awake)), 2*ones(1, numel(data_Day_BrC_Awake)), 3*ones(1, numel(data_Night_ACC_Awake)), 4*ones(1, numel(data_Night_BrC_Awake)), 5*ones(1, numel(data_Day_ACC_NoNREM)), 6*ones(1, numel(data_Day_BrC_NoNREM)), 7*ones(1, numel(data_Night_ACC_NoNREM)), 8*ones(1, numel(data_Night_BrC_NoNREM)), 9*ones(1, numel(data_Day_ACC_REM)), 10*ones(1, numel(data_Day_BrC_REM)), 11*ones(1, numel(data_Night_ACC_REM)), 12*ones(1, numel(data_Night_BrC_REM))];
EventsRate_BoxPlot = [data_Day_ACC_Awake, data_Day_BrC_Awake, data_Night_ACC_Awake, data_Night_BrC_Awake, data_Day_ACC_NoNREM, data_Day_BrC_NoNREM, data_Night_ACC_NoNREM, data_Night_BrC_NoNREM, data_Day_ACC_REM, data_Day_BrC_REM, data_Night_ACC_REM, data_Night_BrC_REM];
hold on; box on; axis square; grid on;
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'b', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'y', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Integral')
title('Events Integrals')


%% Amplitude
Plot_ymax = 60;

subplot(1, 3, 3);

AstroStatsQT = AstroStats.Amplitude;
AstroStatsQT = AstroStatsQT.ACCvsBRC;

PVal_Array = [AstroStatsQT.Day.Awake.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.Awake.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.NREM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.NREM.Baseline_vs_Baseline.Pvalue, ...
    AstroStatsQT.Day.REM.Baseline_vs_Baseline.Pvalue, AstroStatsQT.Night.REM.Baseline_vs_Baseline.Pvalue];

tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.Awake];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.Awake];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.Awake];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.Awake];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.Awake];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.Awake];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.Awake];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.Awake];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.Awake];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.Awake];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.Awake];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.Awake];
data_Day_ACC_Awake = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_Awake = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_Awake = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_Awake = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.NoNREM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.NoNREM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.NoNREM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.NoNREM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.NoNREM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.NoNREM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.NoNREM];
data_Day_ACC_NoNREM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_NoNREM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_NoNREM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_NoNREM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
tmp_Data1_ACC = [Events_Data_ACC(1).EventAmplitude_Mean.REM];
tmp_Data2_ACC = [Events_Data_ACC(2).EventAmplitude_Mean.REM];
tmp_Data3_ACC = [Events_Data_ACC(3).EventAmplitude_Mean.REM];
tmp_Data4_ACC = [Events_Data_ACC(4).EventAmplitude_Mean.REM];
tmp_Data5_ACC = [Events_Data_ACC(5).EventAmplitude_Mean.REM];
tmp_Data6_ACC = [Events_Data_ACC(6).EventAmplitude_Mean.REM];
tmp_Data1_BrC = [Events_Data_BrC(1).EventAmplitude_Mean.REM];
tmp_Data2_BrC = [Events_Data_BrC(2).EventAmplitude_Mean.REM];
tmp_Data3_BrC = [Events_Data_BrC(3).EventAmplitude_Mean.REM];
tmp_Data4_BrC = [Events_Data_BrC(4).EventAmplitude_Mean.REM];
tmp_Data5_BrC = [Events_Data_BrC(5).EventAmplitude_Mean.REM];
tmp_Data6_BrC = [Events_Data_BrC(6).EventAmplitude_Mean.REM];
data_Day_ACC_REM = [tmp_Data1_ACC, tmp_Data3_ACC, tmp_Data5_ACC];
data_Day_BrC_REM = [tmp_Data1_BrC, tmp_Data3_BrC, tmp_Data5_BrC];
data_Night_ACC_REM = [tmp_Data2_ACC, tmp_Data4_ACC, tmp_Data6_ACC];
data_Night_BrC_REM = [tmp_Data2_BrC, tmp_Data4_BrC, tmp_Data6_BrC];
clear tmp*
BoxPlot_Groups = [1*ones(1, numel(data_Day_ACC_Awake)), 2*ones(1, numel(data_Day_BrC_Awake)), 3*ones(1, numel(data_Night_ACC_Awake)), 4*ones(1, numel(data_Night_BrC_Awake)), 5*ones(1, numel(data_Day_ACC_NoNREM)), 6*ones(1, numel(data_Day_BrC_NoNREM)), 7*ones(1, numel(data_Night_ACC_NoNREM)), 8*ones(1, numel(data_Night_BrC_NoNREM)), 9*ones(1, numel(data_Day_ACC_REM)), 10*ones(1, numel(data_Day_BrC_REM)), 11*ones(1, numel(data_Night_ACC_REM)), 12*ones(1, numel(data_Night_BrC_REM))];
EventsRate_BoxPlot = [data_Day_ACC_Awake, data_Day_BrC_Awake, data_Night_ACC_Awake, data_Night_BrC_Awake, data_Day_ACC_NoNREM, data_Day_BrC_NoNREM, data_Night_ACC_NoNREM, data_Night_BrC_NoNREM, data_Day_ACC_REM, data_Day_BrC_REM, data_Night_ACC_REM, data_Night_BrC_REM];
hold on; box on; axis square; grid on;
BP_Width = 0.5;
BoxPlot_Widths = [BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width, BP_Width];
h_boxplot = boxplot(EventsRate_BoxPlot, BoxPlot_Groups, 'positions', BoxPlot_Positions, 'Widths', BoxPlot_Widths);
set(h_boxplot(7,:), 'Visible', 'off');
% Face Colors
h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    h_patch_blue = patch(get(h(j),'XData'),get(h(j),'YData'), 'b', 'FaceAlpha', PlotsTransparency);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    h_patch_yellow = patch(get(h(j),'XData'),get(h(j),'YData'), 'y', 'FaceAlpha', PlotsTransparency);
end

ylim([0, Plot_ymax])

% Add significancy markers
h_significance = sigstar(Comparisons, PVal_Array, Opts.AstroPlot.FLAG_SortPValue);

set(gca, 'xTick', BoxPlot_Positions(1:2:end) + BP_Width/2);
set(gca,'XTickLabel',{'Day', 'Night', 'Day', 'Night', 'Day', 'Night'});
xtickangle(0)
ylabel('Amplitude (dF/F)')
title('Events Amplitude')



%% Save Figure
FileName = sprintf('ACC vs BrC - Baselines');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    fprintf('Saving "%s" in %s.\n\n', FileName, PlotPath);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


