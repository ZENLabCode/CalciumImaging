function Plot_EventsPerState (Events_Data)
% This function plots the results for Christina Astrocytes Analysis


PlotPath = 'C:\Users\I0328159\Desktop\Data Astrocytes\Figures';

FLAG_Save = 1;

% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %
% ------------------------- EVENTS RATE -------------------------------- %
% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %

%% Plot Comparisons - Daytime Baseline - Events Rate
% Baselines Comparisons - Day
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventRate.Awake];
tmp_Data2 = [Events_Data(3).EventRate.Awake];
tmp_Data3 = [Events_Data(5).EventRate.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Daytime 1', 'Daytime 2', 'Daytime 3'});
ylabel('Ca2+ Events Rate [Hz]')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventRate.NoNREM];
tmp_Data2 = [Events_Data(3).EventRate.NoNREM];
tmp_Data3 = [Events_Data(5).EventRate.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Daytime 1', 'Daytime 2', 'Daytime 3'});
title('NonREM')
xlabel('Daytime vs Daytime')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventRate.REM];
tmp_Data2 = [Events_Data(3).EventRate.REM];
tmp_Data3 = [Events_Data(5).EventRate.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Daytime 1', 'Daytime 2', 'Daytime 3'});
title('REM')

h_suptitle = suptitle('Baseline Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';








%% Baseline - Daytime & Nighttime  - Events Rate
% Baselines Comparisons - Day
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 0.10;
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventRate.Awake];
tmp_Data2 = [Events_Data(2).EventRate.Awake];
tmp_Data3 = [Events_Data(3).EventRate.Awake];
tmp_Data4 = [Events_Data(4).EventRate.Awake];
tmp_Data5 = [Events_Data(5).EventRate.Awake];
tmp_Data6 = [Events_Data(6).EventRate.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);

h = findobj(gca,'Tag','Box');
for j=1:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'b', 'FaceAlpha', 0.75);
end
h = findobj(gca,'Tag','Box');
for j=2:2:length(h)
    patch(get(h(j),'XData'),get(h(j),'YData'), 'y', 'FaceAlpha', 0.75);
end

ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Rate [Hz]')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventRate.NoNREM];
tmp_Data2 = [Events_Data(2).EventRate.NoNREM];
tmp_Data3 = [Events_Data(3).EventRate.NoNREM];
tmp_Data4 = [Events_Data(4).EventRate.NoNREM];
tmp_Data5 = [Events_Data(5).EventRate.NoNREM];
tmp_Data6 = [Events_Data(6).EventRate.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventRate.REM];
tmp_Data2 = [Events_Data(2).EventRate.REM];
tmp_Data3 = [Events_Data(3).EventRate.REM];
tmp_Data4 = [Events_Data(4).EventRate.REM];
tmp_Data5 = [Events_Data(5).EventRate.REM];
tmp_Data6 = [Events_Data(6).EventRate.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Baseline Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Events Rates - Baseline Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



%% SleepDep Recovery - Daytime & Nighttime   - Events Rate
% Baselines Comparisons - Day
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(8).EventRate.Awake];
tmp_Data2 = [Events_Data(9).EventRate.Awake];
tmp_Data3 = [Events_Data(10).EventRate.Awake];
tmp_Data4 = [Events_Data(11).EventRate.Awake];
tmp_Data5 = [Events_Data(12).EventRate.Awake];
tmp_Data6 = [Events_Data(13).EventRate.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Rate [Hz]')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(8).EventRate.NoNREM];
tmp_Data2 = [Events_Data(9).EventRate.NoNREM];
tmp_Data3 = [Events_Data(10).EventRate.NoNREM];
tmp_Data4 = [Events_Data(11).EventRate.NoNREM];
tmp_Data5 = [Events_Data(12).EventRate.NoNREM];
tmp_Data6 = [Events_Data(13).EventRate.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(8).EventRate.REM];
tmp_Data2 = [Events_Data(9).EventRate.REM];
tmp_Data3 = [Events_Data(10).EventRate.REM];
tmp_Data4 = [Events_Data(11).EventRate.REM];
tmp_Data5 = [Events_Data(12).EventRate.REM];
tmp_Data6 = [Events_Data(13).EventRate.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Sleep Deprivation Recovery Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Events Rates - SD Recovery Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Baseline vs Recovery - Daytime   - Events Rate
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventRate.Awake];
tmp_Data2 = [Events_Data(8).EventRate.Awake];
tmp_Data3 = [Events_Data(3).EventRate.Awake];
tmp_Data4 = [Events_Data(10).EventRate.Awake];
tmp_Data5 = [Events_Data(5).EventRate.Awake];
tmp_Data6 = [Events_Data(12).EventRate.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Rate [Hz]')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventRate.NoNREM];
tmp_Data2 = [Events_Data(8).EventRate.NoNREM];
tmp_Data3 = [Events_Data(3).EventRate.NoNREM];
tmp_Data4 = [Events_Data(10).EventRate.NoNREM];
tmp_Data5 = [Events_Data(5).EventRate.NoNREM];
tmp_Data6 = [Events_Data(12).EventRate.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventRate.REM];
tmp_Data2 = [Events_Data(8).EventRate.REM];
tmp_Data3 = [Events_Data(3).EventRate.REM];
tmp_Data4 = [Events_Data(10).EventRate.REM];
tmp_Data5 = [Events_Data(5).EventRate.REM];
tmp_Data6 = [Events_Data(12).EventRate.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Daytime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Events Rates - Daytime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Baseline vs Recovery - Nighttime - Events Rate
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(2).EventRate.Awake];
tmp_Data2 = [Events_Data(9).EventRate.Awake];
tmp_Data3 = [Events_Data(4).EventRate.Awake];
tmp_Data4 = [Events_Data(11).EventRate.Awake];
tmp_Data5 = [Events_Data(6).EventRate.Awake];
tmp_Data6 = [Events_Data(13).EventRate.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Rate [Hz]')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(2).EventRate.NoNREM];
tmp_Data2 = [Events_Data(9).EventRate.NoNREM];
tmp_Data3 = [Events_Data(4).EventRate.NoNREM];
tmp_Data4 = [Events_Data(11).EventRate.NoNREM];
tmp_Data5 = [Events_Data(6).EventRate.NoNREM];
tmp_Data6 = [Events_Data(13).EventRate.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(2).EventRate.REM];
tmp_Data2 = [Events_Data(9).EventRate.REM];
tmp_Data3 = [Events_Data(4).EventRate.REM];
tmp_Data4 = [Events_Data(11).EventRate.REM];
tmp_Data5 = [Events_Data(6).EventRate.REM];
tmp_Data6 = [Events_Data(13).EventRate.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Nighttime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Events Rates - Nighttime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %
% ----------------------------- INTEGRALS ------------------------------ %
% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %



%% Integrals - Baseline Comparisons - Daytime & Nighttime
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 400;
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.Awake];
tmp_Data2 = [Events_Data(2).EventIntegral_Mean.Awake];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.Awake];
tmp_Data4 = [Events_Data(4).EventIntegral_Mean.Awake];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.Awake];
tmp_Data6 = [Events_Data(6).EventIntegral_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Integrals')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.NoNREM];
tmp_Data2 = [Events_Data(2).EventIntegral_Mean.NoNREM];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.NoNREM];
tmp_Data4 = [Events_Data(4).EventIntegral_Mean.NoNREM];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.NoNREM];
tmp_Data6 = [Events_Data(6).EventIntegral_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.REM];
tmp_Data2 = [Events_Data(2).EventIntegral_Mean.REM];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.REM];
tmp_Data4 = [Events_Data(4).EventIntegral_Mean.REM];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.REM];
tmp_Data6 = [Events_Data(6).EventIntegral_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Baseline Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Integrals - Baseline Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



%% Integrals - SD Recovery Comparisons
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(8).EventIntegral_Mean.Awake];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.Awake];
tmp_Data3 = [Events_Data(10).EventIntegral_Mean.Awake];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.Awake];
tmp_Data5 = [Events_Data(12).EventIntegral_Mean.Awake];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Integrals')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(8).EventIntegral_Mean.NoNREM];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.NoNREM];
tmp_Data3 = [Events_Data(10).EventIntegral_Mean.NoNREM];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.NoNREM];
tmp_Data5 = [Events_Data(12).EventIntegral_Mean.NoNREM];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(8).EventIntegral_Mean.REM];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.REM];
tmp_Data3 = [Events_Data(10).EventIntegral_Mean.REM];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.REM];
tmp_Data5 = [Events_Data(12).EventIntegral_Mean.REM];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Sleep Deprivation Recovery Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Integrals - SD Recovery Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Integrals - Daytime - Baseline vs Recovery
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.Awake];
tmp_Data2 = [Events_Data(8).EventIntegral_Mean.Awake];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.Awake];
tmp_Data4 = [Events_Data(10).EventIntegral_Mean.Awake];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.Awake];
tmp_Data6 = [Events_Data(12).EventIntegral_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Integrals')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.NoNREM];
tmp_Data2 = [Events_Data(8).EventIntegral_Mean.NoNREM];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.NoNREM];
tmp_Data4 = [Events_Data(10).EventIntegral_Mean.NoNREM];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.NoNREM];
tmp_Data6 = [Events_Data(12).EventIntegral_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventIntegral_Mean.REM];
tmp_Data2 = [Events_Data(8).EventIntegral_Mean.REM];
tmp_Data3 = [Events_Data(3).EventIntegral_Mean.REM];
tmp_Data4 = [Events_Data(10).EventIntegral_Mean.REM];
tmp_Data5 = [Events_Data(5).EventIntegral_Mean.REM];
tmp_Data6 = [Events_Data(12).EventIntegral_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Daytime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Integrals - Daytime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Integrals - Nighttime - Baseline vs Recovery
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(2).EventIntegral_Mean.Awake];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.Awake];
tmp_Data3 = [Events_Data(4).EventIntegral_Mean.Awake];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.Awake];
tmp_Data5 = [Events_Data(6).EventIntegral_Mean.Awake];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Integrals')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(2).EventIntegral_Mean.NoNREM];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.NoNREM];
tmp_Data3 = [Events_Data(4).EventIntegral_Mean.NoNREM];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.NoNREM];
tmp_Data5 = [Events_Data(6).EventIntegral_Mean.NoNREM];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(2).EventIntegral_Mean.REM];
tmp_Data2 = [Events_Data(9).EventIntegral_Mean.REM];
tmp_Data3 = [Events_Data(4).EventIntegral_Mean.REM];
tmp_Data4 = [Events_Data(11).EventIntegral_Mean.REM];
tmp_Data5 = [Events_Data(6).EventIntegral_Mean.REM];
tmp_Data6 = [Events_Data(13).EventIntegral_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Nighttime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Integrals - Nighttime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end





% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %
% ----------------------------- AMPLITUDE ------------------------------ %
% ---------------------------------------------------------------------- %
% ---------------------------------------------------------------------- %



%% Amplitude - Baseline Comparisons - Daytime & Nighttime
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
Plot_ymax = 120;
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.Awake];
tmp_Data2 = [Events_Data(2).EventAmplitude_Mean.Awake];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.Awake];
tmp_Data4 = [Events_Data(4).EventAmplitude_Mean.Awake];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.Awake];
tmp_Data6 = [Events_Data(6).EventAmplitude_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Amplitude')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.NoNREM];
tmp_Data2 = [Events_Data(2).EventAmplitude_Mean.NoNREM];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.NoNREM];
tmp_Data4 = [Events_Data(4).EventAmplitude_Mean.NoNREM];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.NoNREM];
tmp_Data6 = [Events_Data(6).EventAmplitude_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.REM];
tmp_Data2 = [Events_Data(2).EventAmplitude_Mean.REM];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.REM];
tmp_Data4 = [Events_Data(4).EventAmplitude_Mean.REM];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.REM];
tmp_Data6 = [Events_Data(6).EventAmplitude_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Baseline Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Amplitude - Baseline Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



%% Amplitude - SD Recovery Comparisons
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(8).EventAmplitude_Mean.Awake];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.Awake];
tmp_Data3 = [Events_Data(10).EventAmplitude_Mean.Awake];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.Awake];
tmp_Data5 = [Events_Data(12).EventAmplitude_Mean.Awake];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
ylabel('Ca2+ Events Amplitude')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(8).EventAmplitude_Mean.NoNREM];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.NoNREM];
tmp_Data3 = [Events_Data(10).EventAmplitude_Mean.NoNREM];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.NoNREM];
tmp_Data5 = [Events_Data(12).EventAmplitude_Mean.NoNREM];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(8).EventAmplitude_Mean.REM];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.REM];
tmp_Data3 = [Events_Data(10).EventAmplitude_Mean.REM];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.REM];
tmp_Data5 = [Events_Data(12).EventAmplitude_Mean.REM];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Daytime 1', 'Nighttime 1', 'Daytime 2', 'Nighttime 2', 'Daytime 3', 'Nighttime 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Sleep Deprivation Recovery Comparisons');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Amplitude - SD Recovery Comparisons');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Amplitude - Daytime - Baseline vs Recovery
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.Awake];
tmp_Data2 = [Events_Data(8).EventAmplitude_Mean.Awake];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.Awake];
tmp_Data4 = [Events_Data(10).EventAmplitude_Mean.Awake];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.Awake];
tmp_Data6 = [Events_Data(12).EventAmplitude_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Amplitude')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.NoNREM];
tmp_Data2 = [Events_Data(8).EventAmplitude_Mean.NoNREM];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.NoNREM];
tmp_Data4 = [Events_Data(10).EventAmplitude_Mean.NoNREM];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.NoNREM];
tmp_Data6 = [Events_Data(12).EventAmplitude_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(1).EventAmplitude_Mean.REM];
tmp_Data2 = [Events_Data(8).EventAmplitude_Mean.REM];
tmp_Data3 = [Events_Data(3).EventAmplitude_Mean.REM];
tmp_Data4 = [Events_Data(10).EventAmplitude_Mean.REM];
tmp_Data5 = [Events_Data(5).EventAmplitude_Mean.REM];
tmp_Data6 = [Events_Data(12).EventAmplitude_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Day - Baseline 1', 'Day - Recovery 1', 'Day - Baseline 2', 'Day - Recovery 2', 'Day - Baseline 3', 'Day - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Daytime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Amplitude - Daytime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




%% Amplitude - Nighttime - Baseline vs Recovery
Color_Awake = [0, 0, 0.5];
Color_NONREM = [0.5, 0, 0];
Color_REM = [0, 0.5, 0];
PlotsTransparency = 0.4;

figure(); set(gcf,'position', get(0,'screensize'));
% Baseline: Awake
subplot(1, 3, 1);
tmp_Data1 = [Events_Data(2).EventAmplitude_Mean.Awake];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.Awake];
tmp_Data3 = [Events_Data(4).EventAmplitude_Mean.Awake];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.Awake];
tmp_Data5 = [Events_Data(6).EventAmplitude_Mean.Awake];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.Awake];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
ylabel('Ca2+ Events Amplitude')
title('Awake')
% Baseline: NonREM
subplot(1, 3, 2);
tmp_Data1 = [Events_Data(2).EventAmplitude_Mean.NoNREM];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.NoNREM];
tmp_Data3 = [Events_Data(4).EventAmplitude_Mean.NoNREM];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.NoNREM];
tmp_Data5 = [Events_Data(6).EventAmplitude_Mean.NoNREM];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.NoNREM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('NonREM')
% Recovery: REM
subplot(1, 3, 3);
tmp_Data1 = [Events_Data(2).EventAmplitude_Mean.REM];
tmp_Data2 = [Events_Data(9).EventAmplitude_Mean.REM];
tmp_Data3 = [Events_Data(4).EventAmplitude_Mean.REM];
tmp_Data4 = [Events_Data(11).EventAmplitude_Mean.REM];
tmp_Data5 = [Events_Data(6).EventAmplitude_Mean.REM];
tmp_Data6 = [Events_Data(13).EventAmplitude_Mean.REM];
BoxPlot_Groups = [1*ones(1, numel(tmp_Data1)), 2*ones(1, numel(tmp_Data2)), 3*ones(1, numel(tmp_Data3)), 4*ones(1, numel(tmp_Data4)), 5*ones(1, numel(tmp_Data5)), 6*ones(1, numel(tmp_Data6))];
EventsRate_BoxPlot = [tmp_Data1, tmp_Data2, tmp_Data3, tmp_Data4, tmp_Data5, tmp_Data6];
hold on; box on; axis square; grid on;
boxplot(EventsRate_BoxPlot, BoxPlot_Groups);
ylim([0, Plot_ymax])
set(gca,'XTickLabel',{'Night - Baseline 1', 'Night - Recovery 1', 'Night - Baseline 2', 'Night - Recovery 2', 'Night - Baseline 3', 'Night - Recovery 3'});
xtickangle(45)
title('REM')

h_suptitle = suptitle('Nighttime Baseline vs Sleep Deprivation Recovery');
h_suptitle.FontSize = 20;
h_suptitle.FontWeight = 'bold';

FileName = sprintf('Amplitude - Nighttime - Baseline vs SD');
FilePath = sprintf('%s\\%s', PlotPath, FileName);
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

