function plot_pie(Events, HypnoState, Dir_Figures)
% This function plots the pie charts of the events distributions across the
% states.

n_rows = 1;
n_columns = 3;

% Get the total duration of sleep states.
for i_mouse = 1:numel(HypnoState)
    Duration_ToT_Awake = HypnoState(i_mouse).Duration.Awake;
    Duration_ToT_NoNREM = HypnoState(i_mouse).Duration.NoNREM;
    Duration_ToT_REM = HypnoState(i_mouse).Duration.REM;
end

% Get the number of events per sleep state.
StateTags = [Events.StateTag];
n_Events_Awake = numel(StateTags(StateTags == 1));
n_Events_NoNREM = numel(StateTags(StateTags == 2));
n_Events_REM = numel(StateTags(StateTags == 4));


figure(); set(gcf,'position', get(0,'screensize'));

% SUBPLOT 1
subplot(n_rows, n_columns, 1)
h_piechart = pie([Duration_ToT_Awake, Duration_ToT_NoNREM, Duration_ToT_REM]);

tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
tmp_pText(3).String = tmp_combinedtxt(3);

h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
h_piechart(5).FaceColor = [0, 1, 0];

title('Composition of recordings (States cumulative duration)')

% SUBPLOT 2
subplot(n_rows, n_columns, 2);
h_piechart = pie([n_Events_Awake, n_Events_NoNREM, n_Events_REM]);

h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
h_piechart(5).FaceColor = [0, 1, 0];

tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
tmp_pText(3).String = tmp_combinedtxt(3);

title_str = sprintf('Ca2+ Events in Sleep States\n');
title(title_str)

% SUBPLOT 3
subplot(n_rows, n_columns, 3)
h_piechart = pie([n_Events_Awake/Duration_ToT_Awake, n_Events_NoNREM/Duration_ToT_NoNREM, n_Events_REM/Duration_ToT_REM]);

tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_percentValues = get(tmp_pText, 'String');
tmp_txt1 = sprintf('Awake\nState:\n');
tmp_txt2 = sprintf('Non-REM\nState:\n');
tmp_txt3 = sprintf('REM\nState:\n');
tmp_txt = {tmp_txt1; tmp_txt2; tmp_txt3};
tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
tmp_pText(1).String = tmp_combinedtxt(1);
tmp_pText(2).String = tmp_combinedtxt(2);
tmp_pText(3).String = tmp_combinedtxt(3);

h_piechart(1).FaceColor = [0, 0, 1];
h_piechart(3).FaceColor = [1, 0, 0];
h_piechart(5).FaceColor = [0, 1, 0];

title('Frequency of Ca2+ Events in Sleep States')

% print(gcf,'-depsc','-painters', 'Figure_Events_Pie.eps')
% print(gcf, '-depsc', '-painters', 'Figure_Events_Pie.jpg')
% print(gcf, '-depsc', '-painters', 'Figure_Events_Pie.pdf')

FileName = 'Figure Events per State - Pie Plot';
FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))
close gcf 

