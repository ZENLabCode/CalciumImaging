function Hist_Results = plot_histograms(Events_AllMice, HypnoState, Dir_Figures)
% Plots the pie plot of the states and events distribution, and the events
% characteristics histograms.
% The output is the fit of a gaussian over each of the events
% characteristics distributions.

% Get Composite Events Only.
Events_Complex = get_composite_info(Events_AllMice);


%% Split events between states.
Events = Events_Complex;
Events_Awake = Events([Events.StateTag] == 1);
Events_NonREM = Events([Events.StateTag] == 2);
Events_REM = Events([Events.StateTag] == 4);
% Get the total duration of sleep states.
for i_mouse = 1:numel(HypnoState)
    Duration_ToT.Awake = HypnoState(i_mouse).Duration.Awake;
    Duration_ToT.NoNREM = HypnoState(i_mouse).Duration.NoNREM;
    Duration_ToT.REM = HypnoState(i_mouse).Duration.REM;
end

n_Awake = numel(Events_Awake);
n_NonREM = numel(Events_NonREM);
n_REM = numel(Events_REM);

% Correction for Amplitude
tmp = [Events_Awake.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_Awake.Amp_Baseline])
   Events_Awake(i).Amp_Baseline = tmp(i);
end
tmp = [Events_NonREM.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_NonREM.Amp_Baseline])
   Events_NonREM(i).Amp_Baseline = tmp(i);
end
tmp = [Events_REM.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_REM.Amp_Baseline])
   Events_REM(i).Amp_Baseline = tmp(i);
end
clear tmp

% Get Inter-Events-Interval
Events_Awake_IEI = NaN(1, numel(Events_Awake));
Events_NonREM_IEI = NaN(1, numel(Events_NonREM));
Events_REM_IEI = NaN(1, numel(Events_REM));
Events_IEI = NaN(1, numel(Events));
for i_event = 1:numel(Events_Awake)
    Events_Awake_IEI(i_event) = Events_Awake(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events_NonREM)
    Events_NonREM_IEI(i_event) = Events_NonREM(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events_REM)
    Events_REM_IEI(i_event) = Events_REM(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events)
    Events_IEI(i_event) = Events(i_event).InterEventInterval;    
end

% Histograms Options.
Opts_Hist.subplots_rows = 2;
Opts_Hist.subplots_columns = 3;
Opts_Hist.n_bins_large = double(idivide(numel(Events), int32(12)));
Opts_Hist.n_bins = double(idivide(min([n_Awake, n_NonREM, n_REM]), int32(8)));
Opts_Hist.hist_alpha = 0.5;
Opts_Hist.FLAG_PreDefinedBins = 0;
Opts_Hist.Dir_Figures = Dir_Figures;


%% Pie plot.
plot_pie(Events_Complex, HypnoState, Dir_Figures);
close gcf 


%% --------------- Histograms of all Events together. --------------- %%

Opts.FLAG_Tonic = 1;
Opts_Hist.FLAGs.gaussian_model = 'gauss1';
Opts_Hist.FLAGs.fit_G1 = 1;
Opts_Hist.FLAGs.fit_G2 = 0;

Opts_Hist.SupTitleStr = 'Duration of Events';
Opts_Hist.LabelStr = 'Duration [s]';
Opts_Hist.FileName = 'Figure Duration';
Opts_Hist.FLAG_PreDefinedBins = 1;
max_bin = 25;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Duration = plot_histogram_single([Events_Awake.Duration], [Events_NonREM.Duration], [Events_REM.Duration], Duration_ToT, Opts_Hist);
% FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
% print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
% saveas(gcf, strcat(FilePath, '.jpg'))
% saveas(gcf, strcat(FilePath, '.fig'))
% close gcf 

Opts_Hist.SupTitleStr = 'Integral of Events';
Opts_Hist.LabelStr = 'Integral [DFoF * s]';
Opts_Hist.FileName = 'Figure Integral';
Opts_Hist.FLAG_PreDefinedBins = 1;
max_bin = 25;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Integral = plot_histogram_single([Events_Awake.Integral], [Events_NonREM.Integral], [Events_REM.Integral], Duration_ToT, Opts_Hist);
% FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
% print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
% saveas(gcf, strcat(FilePath, '.jpg'))
% saveas(gcf, strcat(FilePath, '.fig'))
% close gcf 

Opts_Hist.SupTitleStr = 'Amplitude of Events';
Opts_Hist.LabelStr = sprintf('Amplitude [\\DeltaFoF]');
Opts_Hist.FileName = 'Figure Amplitude';
Opts_Hist.FLAG_PreDefinedBins = 1;
max_bin = 80;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Amplitude = plot_histogram_single([Events_Awake.Amp_Baseline], [Events_NonREM.Amp_Baseline], [Events_REM.Amp_Baseline], Duration_ToT, Opts_Hist);
% FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
% 
% saveas(gcf, strcat(FilePath, '.jpg'))
% saveas(gcf, strcat(FilePath, '.fig'))
% close gcf 

Opts_Hist.SupTitleStr = 'Inter Events Interval';
Opts_Hist.LabelStr = sprintf('IEI [s]');
Opts_Hist.FileName = 'Figure IEI';
Opts_Hist.FLAG_PreDefinedBins = 1;
max_bin = 100;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.IEI = plot_histogram_single(Events_Awake_IEI, Events_NonREM_IEI, Events_REM_IEI, Events_IEI, Opts_Hist);

% FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
% print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
% saveas(gcf, strcat(FilePath, '.jpg'))
% saveas(gcf, strcat(FilePath, '.fig'))
% close gcf 
