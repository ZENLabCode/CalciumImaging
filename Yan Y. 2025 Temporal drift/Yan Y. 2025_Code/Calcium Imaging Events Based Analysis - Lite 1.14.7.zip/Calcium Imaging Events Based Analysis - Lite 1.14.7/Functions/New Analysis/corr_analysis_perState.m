function corr_analysis_perState (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, HypnoState, Mouse_Names, Opts)


DistanceType = 'cosine'; % 'euclidean'

n_sessions = numel(HypnoState);
n_mice = numel(Mouse_Names);

StableStateMinDuration = Opts.General.MinStableStateDuration*Opts.General.FrameRate;

% Separate Traces and Hypnogram per mouse
CalciumTraces_perMouse = cell(n_mice, 1);
Hypnogram_perMouse = cell(n_mice, 1);
HypnogramDuration_perMouse = cell(n_mice, 1);
StateType_perMouse = cell(n_mice, 1);
StateDuration_perMouse = cell(n_mice, 1);
StateChanges_perMouse = cell(n_mice, 1);
for i_mouse = 1:n_mice
    Current_Mouse = Mouse_Names{i_mouse};
    CalciumTraces = cell(0);
    Hypnogram = cell(0);
    Hypnogram_Duration = cell(0);
    StateType_Array = cell(0);
    StateDuration_Array = cell(0);
    StateChanges_Array = cell(0);
    for i_session  = 1:n_sessions
        if strcmpi(HypnoState(i_session).MouseName, Current_Mouse) == 1
            CurrentHypno = Hypnogram_AllSessions(i_session).Hypnogram;
            CurrentHypno_Duration = Hypnogram_AllSessions(i_session).StateDuration_Array;
            CurrentStateType = Hypnogram_AllSessions(i_session).StateType;
            CurrentStateDuration = Hypnogram_AllSessions(i_session).StateDuration;
            CurrentStateChanges = Hypnogram_AllSessions(i_session).StateChanges;
            
            CalciumTraces = [CalciumTraces; CalciumTraces_Clean_AllSessions{i_session}];
            Hypnogram = [Hypnogram; CurrentHypno];
            StateType_Array = [StateType_Array; CurrentStateType];
            StateDuration_Array = [StateDuration_Array; CurrentStateDuration];
            StateChanges_Array = [StateChanges_Array; CurrentStateChanges];
        end
    end
    CalciumTraces_perMouse{i_mouse} = CalciumTraces;
    Hypnogram_perMouse{i_mouse} = Hypnogram;
    HypnogramDuration_perMouse{i_mouse} = Hypnogram_Duration;
    StateType_perMouse{i_mouse} = StateType_Array;
    StateDuration_perMouse{i_mouse} = StateDuration_Array;
    StateChanges_perMouse{i_mouse} = StateChanges_Array;
end
clear CalciumTraces; clear Hypnogram; clear CurrentHypno; clear Hypnogram_Duration; clear CurrentHypno_Duration;

% keyboard

Distance_Matrices = cell(n_mice, 1);
for i_mouse = 1:n_mice
    CurrentTraces_Sessions = CalciumTraces_perMouse{i_mouse};
    tmp_n_sessions = numel(CurrentTraces_Sessions);
    CorrMatrices = cell(tmp_n_sessions, 4);
    
    % CM = CurrentMouse
    CM_StateDuration = StateDuration_perMouse{i_mouse};
    CM_StateArray = StateType_perMouse{i_mouse};
    CM_StateChanges = StateChanges_perMouse{i_mouse};
    CM_CalciumTraces = CalciumTraces_perMouse{i_mouse};
    
    tmp_n_sessions = numel(CM_CalciumTraces);
    for i_session = 1:tmp_n_sessions
        % CS = CurrentSession
        CS_StateDuration = CM_StateDuration{i_session};
        CS_StateArray = CM_StateArray{i_session};
        CS_StateChanges = CM_StateChanges{i_session};
        CS_CalciumTraces = CM_CalciumTraces{i_session};
        [~, n_cells] = size(CS_CalciumTraces);
        n_states = numel(CS_StateArray);
        
        % Scroll each sleep state, glue together the traces of each
        % stable state
        CalciumTracesGlued_AllStates = cell(4, 1);
        for i_SleepState = 1:4
            if i_SleepState == 3
                continue
            end
            CalciumTracesGlued = [];
            for i_state = 1:n_states
                if CS_StateArray(i_state) == i_SleepState
                    if CS_StateDuration(i_state) >= StableStateMinDuration
                        StateStart = CS_StateChanges(i_state);
                        if i_state == n_states
                            [StateEnd, ~] = size(CS_CalciumTraces);
                        else
                            StateEnd = CS_StateChanges(i_state + 1);
                        end
                        % Take the traces as indicated by StateStart & StateEnd
                        CurrentState = CS_CalciumTraces(StateStart:StateEnd, :);
                        
                        % Cut the first and last 5% seconds of the stable
                        % state.
                        CutTime = ((1/20).*Opts.General.MinStableStateDuration)*Opts.General.FrameRate;
                        CurrentState = CurrentState(CutTime:end - CutTime, :);
                        CalciumTracesGlued = [CalciumTracesGlued; CurrentState];
                        
                    else
                        continue
                    end
                else
                    continue
                end
                clear CurrentState
            end
            % Compute the correlation between the whole traces.
            % Obtain a n_cells x n_cells correlation matrix for each session
            if isempty(CalciumTracesGlued)
                fprintf('\nNo states %d in Session %d, Mouse %s\n\n', i_SleepState, i_session, Mouse_Names{i_mouse});
                CorrWholeState = NaN(n_cells, n_cells);
            else
                [CorrWholeState, CorrWholeState_p] = corr(CalciumTracesGlued, 'rows', 'complete');
            end
            CorrMatrices{i_session, i_SleepState} = CorrWholeState;
            CalciumTracesGlued_AllStates{i_SleepState} = CalciumTracesGlued;
        end
    end

    % Compute the pairwise distance between these correlation matrices
    % Take then the average of each, showing in the end the
    % n_sessions x n_sessions matrix of average distances between the
    % various correlation maps
    D = NaN(tmp_n_sessions, tmp_n_sessions, 4);
    for i_session = 1:tmp_n_sessions
        for j_session = 1:tmp_n_sessions
            for i_SleepState = 1:4
                if i_SleepState == 3
                    continue
                end
                tmp = pdist2(CorrMatrices{i_session, i_SleepState},CorrMatrices{j_session, i_SleepState}, DistanceType);
                D(i_session, j_session, i_SleepState) = nanmean(nanmean(tmp));
            end
        end
    end
    % Normalize D
    D_norm = rescale(D);
    % Save for each mouse
    Distance_Matrices{i_mouse} = D_norm;
end


% pcolor(CorrMatrices{i_session})
% set(gca, 'YDir','reverse')
% ax = gca;
% ax.FontSize = AxisFontSize;
% ylabel('Cell ID', 'FontSize', 18)
% xlabel('Cell ID', 'FontSize', 18)
% title('Example Correlation Matrix for a single session', 'FontSize', FontSizeTitles)
% keyboard

n_rows = 6;
n_columns = 3;

keyboard

figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

Ticks_Array = ([1, 4, 7, 10, 13, 16, 19]);
Ticks_Array = Ticks_Array + 0.5;
Ticks_Labels = ({'Day 1','Day 2','Day 3', 'SD', 'Rec 1', 'Rec 2', 'Rec 3'});

i_subplot = 0;
for i_mouse = 1:n_mice
    %     imagesc(Distance_Matrices{i_mouse})
    for i_state = 1:4
        if i_state == 3
            continue
        end
        i_subplot = i_subplot + 1;
        subplot(n_rows, n_columns, i_subplot)
        switch i_state
            case 1
                Text_Title = sprintf('Mouse #%d Awake', i_mouse);
            case 2
                Text_Title = sprintf('Mouse #%d NREM', i_mouse);
            case 4
                Text_Title = sprintf('Mouse #%d REM', i_mouse);
        end
        tmp_DistanceMatrix = Distance_Matrices{i_mouse};
        pcolor((tmp_DistanceMatrix(:, :, i_state))')
        set(gca, 'YDir','reverse')
        ax = gca;
        ax.FontSize = AxisFontSize;
        axis square
        if i_state == 1
            ylabel('Recording Session', 'FontSize', 18)
        end
        yticks(Ticks_Array)
        yticklabels(Ticks_Labels)
        if i_mouse == n_mice
            xticks(Ticks_Array)
            xticklabels(Ticks_Labels)
            xtickangle(45)
        else
            set(gca,'xtick',[])
        end
        
        title(Text_Title, 'FontSize', FontSizeTitles)
        h_colorbar = colorbar;
    end
end
Text_Suptitle = sprintf('Distance Between Cell Correlation Maps');
h_suptitle = suptitle(Text_Suptitle);
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';