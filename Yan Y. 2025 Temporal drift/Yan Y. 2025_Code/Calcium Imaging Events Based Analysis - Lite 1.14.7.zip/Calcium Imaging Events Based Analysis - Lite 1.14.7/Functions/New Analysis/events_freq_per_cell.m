function Events_Freq_Matrix = events_freq_per_cell(Events, TotalDuration, Mouse_Cells)

% This function is thought to work in the framework of the Session_Analysis
% for VGlut and Vgat
% This function computes the number of events of a certain cell, per each
% state (all states counted together), divided by the total duration of
% that state. Repeated for each cell.

n_cells = Mouse_Cells(1).n_cells;
cell_num_array = [Events.TraceNumber];
% trace_i_max = nanmax(cell_num_array);
Events_Freq_Matrix = NaN(3, n_cells);
for i_cell = 1:n_cells
    Events_CurrentCell = Events(cell_num_array == i_cell);
    CurrentCell_state_array = [Events_CurrentCell.StateTag];
    
    % Separate per State
    Events_CurrentCell_Awake = Events_CurrentCell(CurrentCell_state_array == 1);
    Events_CurrentCell_NREM = Events_CurrentCell(CurrentCell_state_array == 2);
    Events_CurrentCell_REM = Events_CurrentCell(CurrentCell_state_array == 4);
    
    Events_Number_Awake(i_cell) = numel(Events_CurrentCell_Awake);
    Events_Number_NREM(i_cell) = numel(Events_CurrentCell_NREM);
    Events_Number_REM(i_cell) = numel(Events_CurrentCell_REM);
    
    Events_Freq_Awake(i_cell) = Events_Number_Awake(i_cell)./TotalDuration.Awake;
    Events_Freq_NREM(i_cell) = Events_Number_NREM(i_cell)./TotalDuration.NREM;
    Events_Freq_REM(i_cell) = Events_Number_REM(i_cell)./TotalDuration.REM;
    
    Events_Freq_Matrix(1, i_cell) = Events_Freq_Awake(i_cell);
    Events_Freq_Matrix(2, i_cell) = Events_Freq_NREM(i_cell);
    Events_Freq_Matrix(3, i_cell) = Events_Freq_REM(i_cell);
end

Events_Freq_Matrix = Events_Freq_Matrix';