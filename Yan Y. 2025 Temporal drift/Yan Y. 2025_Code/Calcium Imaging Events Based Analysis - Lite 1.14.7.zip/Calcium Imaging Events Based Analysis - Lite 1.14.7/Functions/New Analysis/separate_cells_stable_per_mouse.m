function Cell_Stable_perMouse = separate_cells_stable_per_mouse (Cell_Stable, MouseCellsRecorded)


n_mice = numel(MouseCellsRecorded);

tmp = Cell_Stable.Awake;
Cell_Stable_perMouse = cell(1, n_mice);
Cell_Stable_perMouse{1} = tmp(1:MouseCellsRecorded(1));
for i_mouse = 2:n_mice
   Cell_Stable_perMouse{i_mouse} = tmp(MouseCellsRecorded(i_mouse - 1) + 1:MouseCellsRecorded(i_mouse - 1) + MouseCellsRecorded(i_mouse));    
end

