

n_baselines = 3;
n_sessions_per_day = 3;
n_comparisons_per_day = 6;

% Patchwork WIP
[n_cells, ~] = size(Events_Freq_Matrix_allMice_SD_11);
if n_cells ~= 509 && n_cells ~= 257
    Events_Freq_Matrix_allMice_SD_11(end+1, :) = NaN(1, 3);
end
[n_cells, ~] = size(Events_Freq_Matrix_allMice_SD_3pm);
if n_cells ~= 509 && n_cells ~= 257
    Events_Freq_Matrix_allMice_SD_3pm(end+1, :) = NaN(1, 3);
end
[n_cells, ~] = size(Events_Freq_Matrix_allMice_Recovery_20);
if n_cells ~= 509 && n_cells ~= 257
    Events_Freq_Matrix_allMice_Recovery_20(end+1, :) = NaN(1, 3);
end
[n_cells, ~] = size(Events_Freq_Matrix_allMice_Recovery_14);
if n_cells ~= 509 && n_cells ~= 257
    Events_Freq_Matrix_allMice_Recovery_14(end+1, :) = NaN(1, 3);
end



%% Stability computation (simple difference between arrays)
% Stability During Baseline Day
Stability.s1vs2 = abs(Events_Freq_Matrix_allMice_Baseline_1 - Events_Freq_Matrix_allMice_Baseline_2);
Stability.s2vs3 = abs(Events_Freq_Matrix_allMice_Baseline_2 - Events_Freq_Matrix_allMice_Baseline_3);

Stability.s4vs5 = abs(Events_Freq_Matrix_allMice_Baseline_4 - Events_Freq_Matrix_allMice_Baseline_5);
Stability.s5vs6 = abs(Events_Freq_Matrix_allMice_Baseline_5 - Events_Freq_Matrix_allMice_Baseline_6);

Stability.s7vs8 = abs(Events_Freq_Matrix_allMice_Baseline_7 - Events_Freq_Matrix_allMice_Baseline_8);
Stability.s8vs9 = abs(Events_Freq_Matrix_allMice_Baseline_8 - Events_Freq_Matrix_allMice_Baseline_9);

% Stability During Recovery Day
Stability.s13vs14 = abs(Events_Freq_Matrix_allMice_Recovery_13 - Events_Freq_Matrix_allMice_Recovery_14);
Stability.s14vs15 = abs(Events_Freq_Matrix_allMice_Recovery_14 - Events_Freq_Matrix_allMice_Recovery_15);

Stability.s16vs17 = abs(Events_Freq_Matrix_allMice_Recovery_16 - Events_Freq_Matrix_allMice_Recovery_17);
Stability.s17vs18 = abs(Events_Freq_Matrix_allMice_Recovery_17 - Events_Freq_Matrix_allMice_Recovery_18);

Stability.s19vs20 = abs(Events_Freq_Matrix_allMice_Recovery_19 - Events_Freq_Matrix_allMice_Recovery_20);
try
    Stability.s20vs21 = abs(Events_Freq_Matrix_allMice_Recovery_20 - Events_Freq_Matrix_allMice_Recovery_21);
catch
    warning('Last session had 1 less mouse, that mouse has been skipped for the purpose of the Events Freq comparison')
    tmp = [Events_Freq_Matrix_allMice_Recovery_20(1:166, :); Events_Freq_Matrix_allMice_Recovery_20(208:end, :)];
    Stability.s20vs21 = abs(tmp - Events_Freq_Matrix_allMice_Recovery_21);
end

% Stability Across SD
Stability_AcrossSD.s7vs10 = abs(Events_Freq_Matrix_allMice_Baseline_7 - Events_Freq_Matrix_allMice_SD_10);
Stability_AcrossSD.s8vs11 = abs(Events_Freq_Matrix_allMice_Baseline_8 - Events_Freq_Matrix_allMice_SD_11);
Stability_AcrossSD.s9vs12 = abs(Events_Freq_Matrix_allMice_Baseline_9 - Events_Freq_Matrix_allMice_SD_12);

Stability_AcrossSD.s7vs13 = abs(Events_Freq_Matrix_allMice_Baseline_7 - Events_Freq_Matrix_allMice_Recovery_13);
Stability_AcrossSD.s8vs14 = abs(Events_Freq_Matrix_allMice_Baseline_8 - Events_Freq_Matrix_allMice_Recovery_14);
Stability_AcrossSD.s9vs15 = abs(Events_Freq_Matrix_allMice_Baseline_9 - Events_Freq_Matrix_allMice_Recovery_15);


%% Stability Average
[n_cells, ~] = size(Stability.s1vs2(:, 1));

% Awake
DUMMY = 1;
while DUMMY == 1
    % Mean - Baseline Day
    Stability_Avg.Base1vs2.Awake = nanmean(Stability.s1vs2(:, 1));
    Stability_Avg.Base2vs3.Awake = nanmean(Stability.s2vs3(:, 1));
    Stability_Avg.Base4vs5.Awake = nanmean(Stability.s4vs5(:, 1));
    Stability_Avg.Base5vs6.Awake = nanmean(Stability.s5vs6(:, 1));
    Stability_Avg.Base7vs8.Awake = nanmean(Stability.s7vs8(:, 1));
    Stability_Avg.Base8vs9.Awake = nanmean(Stability.s8vs9(:, 1));
    % StE - Baseline Day
    Stability_StE.Base1vs2.Awake = (nanstd(Stability.s1vs2(:, 1)))./sqrt(n_cells);
    Stability_StE.Base2vs3.Awake = (nanstd(Stability.s2vs3(:, 1)))./sqrt(n_cells);
    Stability_StE.Base4vs5.Awake = (nanstd(Stability.s4vs5(:, 1)))./sqrt(n_cells);
    Stability_StE.Base5vs6.Awake = (nanstd(Stability.s5vs6(:, 1)))./sqrt(n_cells);
    Stability_StE.Base7vs8.Awake = (nanstd(Stability.s7vs8(:, 1)))./sqrt(n_cells);
    Stability_StE.Base8vs9.Awake = (nanstd(Stability.s8vs9(:, 1)))./sqrt(n_cells);
    
    % Mean - Recovery Day
    Stability_Avg.Rec13vs14.Awake = nanmean(Stability.s13vs14(:, 1));
    Stability_Avg.Rec14vs15.Awake = nanmean(Stability.s14vs15(:, 1));
    Stability_Avg.Rec16vs17.Awake = nanmean(Stability.s16vs17(:, 1));
    Stability_Avg.Rec17vs18.Awake = nanmean(Stability.s17vs18(:, 1));
    Stability_Avg.Rec19vs20.Awake = nanmean(Stability.s19vs20(:, 1));
    Stability_Avg.Rec20vs21.Awake = nanmean(Stability.s20vs21(:, 1));
    % StE - Recovery Day
    Stability_StE.Rec13vs14.Awake = (nanstd(Stability.s13vs14(:, 1)))./sqrt(n_cells);
    Stability_StE.Rec14vs15.Awake = (nanstd(Stability.s14vs15(:, 1)))./sqrt(n_cells);
    Stability_StE.Rec16vs17.Awake = (nanstd(Stability.s16vs17(:, 1)))./sqrt(n_cells);
    Stability_StE.Rec17vs18.Awake = (nanstd(Stability.s17vs18(:, 1)))./sqrt(n_cells);
    Stability_StE.Rec19vs20.Awake = (nanstd(Stability.s19vs20(:, 1)))./sqrt(n_cells);
    Stability_StE.Rec20vs21.Awake = (nanstd(Stability.s20vs21(:, 1)))./sqrt(n_cells);
    
    % Stability Across SD
    % Mean - Baseline Day
    Stability_Avg.SD7vs10.Awake = nanmean(Stability_AcrossSD.s7vs10(:, 1));
    Stability_Avg.SD8vs11.Awake = nanmean(Stability_AcrossSD.s8vs11(:, 1));
    Stability_Avg.SD9vs12.Awake = nanmean(Stability_AcrossSD.s9vs12(:, 1));
    Stability_Avg.SD8vs14.Awake = nanmean(Stability_AcrossSD.s8vs14(:, 1));
    Stability_Avg.SD9vs15.Awake = nanmean(Stability_AcrossSD.s9vs15(:, 1));
    % StE - Baseline Day
    Stability_StE.SD7vs10.Awake = (nanstd(Stability_AcrossSD.s7vs10(:, 1)))./sqrt(n_cells);
    Stability_StE.SD8vs11.Awake = (nanstd(Stability_AcrossSD.s8vs11(:, 1)))./sqrt(n_cells);
    Stability_StE.SD9vs12.Awake = (nanstd(Stability_AcrossSD.s9vs12(:, 1)))./sqrt(n_cells);
    Stability_StE.SD8vs14.Awake = (nanstd(Stability_AcrossSD.s8vs14(:, 1)))./sqrt(n_cells);
    Stability_StE.SD9vs15.Awake = (nanstd(Stability_AcrossSD.s9vs15(:, 1)))./sqrt(n_cells);
    DUMMY = 0;
end


% NREM
DUMMY = 1;
while DUMMY == 1
    % Mean - Baseline Day
    Stability_Avg.Base1vs2.NREM = nanmean(Stability.s1vs2(:, 2));
    Stability_Avg.Base2vs3.NREM = nanmean(Stability.s2vs3(:, 2));
    Stability_Avg.Base4vs5.NREM = nanmean(Stability.s4vs5(:, 2));
    Stability_Avg.Base5vs6.NREM = nanmean(Stability.s5vs6(:, 2));
    Stability_Avg.Base7vs8.NREM = nanmean(Stability.s7vs8(:, 2));
    Stability_Avg.Base8vs9.NREM = nanmean(Stability.s8vs9(:, 2));
    % StE - Baseline Day
    Stability_StE.Base1vs2.NREM = (nanstd(Stability.s1vs2(:, 2)))./sqrt(n_cells);
    Stability_StE.Base2vs3.NREM = (nanstd(Stability.s2vs3(:, 2)))./sqrt(n_cells);
    Stability_StE.Base4vs5.NREM = (nanstd(Stability.s4vs5(:, 2)))./sqrt(n_cells);
    Stability_StE.Base5vs6.NREM = (nanstd(Stability.s5vs6(:, 2)))./sqrt(n_cells);
    Stability_StE.Base7vs8.NREM = (nanstd(Stability.s7vs8(:, 2)))./sqrt(n_cells);
    Stability_StE.Base8vs9.NREM = (nanstd(Stability.s8vs9(:, 2)))./sqrt(n_cells);
    
    % Mean - Recovery Day
    Stability_Avg.Rec13vs14.NREM = nanmean(Stability.s13vs14(:, 2));
    Stability_Avg.Rec14vs15.NREM = nanmean(Stability.s14vs15(:, 2));
    Stability_Avg.Rec16vs17.NREM = nanmean(Stability.s16vs17(:, 2));
    Stability_Avg.Rec17vs18.NREM = nanmean(Stability.s17vs18(:, 2));
    Stability_Avg.Rec19vs20.NREM = nanmean(Stability.s19vs20(:, 2));
    Stability_Avg.Rec20vs21.NREM = nanmean(Stability.s20vs21(:, 2));
    % StE - Recovery Day
    Stability_StE.Rec13vs14.NREM = (nanstd(Stability.s13vs14(:, 2)))./sqrt(n_cells);
    Stability_StE.Rec14vs15.NREM = (nanstd(Stability.s14vs15(:, 2)))./sqrt(n_cells);
    Stability_StE.Rec16vs17.NREM = (nanstd(Stability.s16vs17(:, 2)))./sqrt(n_cells);
    Stability_StE.Rec17vs18.NREM = (nanstd(Stability.s17vs18(:, 2)))./sqrt(n_cells);
    Stability_StE.Rec19vs20.NREM = (nanstd(Stability.s19vs20(:, 2)))./sqrt(n_cells);
    Stability_StE.Rec20vs21.NREM = (nanstd(Stability.s20vs21(:, 2)))./sqrt(n_cells);
    
    % Stability Across SD
    % Mean - Baseline Day
    Stability_Avg.SD7vs10.NREM = nanmean(Stability_AcrossSD.s7vs10(:, 2));
    Stability_Avg.SD8vs11.NREM = nanmean(Stability_AcrossSD.s8vs11(:, 2));
    Stability_Avg.SD9vs12.NREM = nanmean(Stability_AcrossSD.s9vs12(:, 2));
    Stability_Avg.SD8vs14.NREM = nanmean(Stability_AcrossSD.s8vs14(:, 2));
    Stability_Avg.SD9vs15.NREM = nanmean(Stability_AcrossSD.s9vs15(:, 2));
    % StE - Baseline Day
    Stability_StE.SD7vs10.NREM = (nanstd(Stability_AcrossSD.s7vs10(:, 2)))./sqrt(n_cells);
    Stability_StE.SD8vs11.NREM = (nanstd(Stability_AcrossSD.s8vs11(:, 2)))./sqrt(n_cells);
    Stability_StE.SD9vs12.NREM = (nanstd(Stability_AcrossSD.s9vs12(:, 2)))./sqrt(n_cells);
    Stability_StE.SD8vs14.NREM = (nanstd(Stability_AcrossSD.s8vs14(:, 2)))./sqrt(n_cells);
    Stability_StE.SD9vs15.NREM = (nanstd(Stability_AcrossSD.s9vs15(:, 2)))./sqrt(n_cells);
    DUMMY = 0;
end
% tmp.NREM = ...
%     [Stability_Avg.Base1vs2.NREM, Stability_Avg.Base2vs3.NREM, Stability_Avg.Base4vs5.NREM, ...
%     Stability_Avg.Base5vs6.NREM, Stability_Avg.Base7vs8.NREM, Stability_Avg.Base8vs9.NREM];

% REM
DUMMY = 1;
while DUMMY == 1
    % Mean - Baseline Day
    Stability_Avg.Base1vs2.REM = nanmean(Stability.s1vs2(:, 3));
    Stability_Avg.Base2vs3.REM = nanmean(Stability.s2vs3(:, 3));
    Stability_Avg.Base4vs5.REM = nanmean(Stability.s4vs5(:, 3));
    Stability_Avg.Base5vs6.REM = nanmean(Stability.s5vs6(:, 3));
    Stability_Avg.Base7vs8.REM = nanmean(Stability.s7vs8(:, 3));
    Stability_Avg.Base8vs9.REM = nanmean(Stability.s8vs9(:, 3));
    % StE - Baseline Day
    Stability_StE.Base1vs2.REM = (nanstd(Stability.s1vs2(:, 3)))./sqrt(n_cells);
    Stability_StE.Base2vs3.REM = (nanstd(Stability.s2vs3(:, 3)))./sqrt(n_cells);
    Stability_StE.Base4vs5.REM = (nanstd(Stability.s4vs5(:, 3)))./sqrt(n_cells);
    Stability_StE.Base5vs6.REM = (nanstd(Stability.s5vs6(:, 3)))./sqrt(n_cells);
    Stability_StE.Base7vs8.REM = (nanstd(Stability.s7vs8(:, 3)))./sqrt(n_cells);
    Stability_StE.Base8vs9.REM = (nanstd(Stability.s8vs9(:, 3)))./sqrt(n_cells);
    
    % Mean - Recovery Day
    Stability_Avg.Rec13vs14.REM = nanmean(Stability.s13vs14(:, 3));
    Stability_Avg.Rec14vs15.REM = nanmean(Stability.s14vs15(:, 3));
    Stability_Avg.Rec16vs17.REM = nanmean(Stability.s16vs17(:, 3));
    Stability_Avg.Rec17vs18.REM = nanmean(Stability.s17vs18(:, 3));
    Stability_Avg.Rec19vs20.REM = nanmean(Stability.s19vs20(:, 3));
    Stability_Avg.Rec20vs21.REM = nanmean(Stability.s20vs21(:, 3));
    % StE - Recovery Day
    Stability_StE.Rec13vs14.REM = (nanstd(Stability.s13vs14(:, 3)))./sqrt(n_cells);
    Stability_StE.Rec14vs15.REM = (nanstd(Stability.s14vs15(:, 3)))./sqrt(n_cells);
    Stability_StE.Rec16vs17.REM = (nanstd(Stability.s16vs17(:, 3)))./sqrt(n_cells);
    Stability_StE.Rec17vs18.REM = (nanstd(Stability.s17vs18(:, 3)))./sqrt(n_cells);
    Stability_StE.Rec19vs20.REM = (nanstd(Stability.s19vs20(:, 3)))./sqrt(n_cells);
    Stability_StE.Rec20vs21.REM = (nanstd(Stability.s20vs21(:, 3)))./sqrt(n_cells);
    
    % Stability Across SD
    % Mean - Baseline Day
    Stability_Avg.SD7vs10.REM = nanmean(Stability_AcrossSD.s7vs10(:, 3));
    Stability_Avg.SD8vs11.REM = nanmean(Stability_AcrossSD.s8vs11(:, 3));
    Stability_Avg.SD9vs12.REM = nanmean(Stability_AcrossSD.s9vs12(:, 3));
    Stability_Avg.SD8vs14.REM = nanmean(Stability_AcrossSD.s8vs14(:, 3));
    Stability_Avg.SD9vs15.REM = nanmean(Stability_AcrossSD.s9vs15(:, 3));
    % StE - Baseline Day
    Stability_StE.SD7vs10.REM = (nanstd(Stability_AcrossSD.s7vs10(:, 3)))./sqrt(n_cells);
    Stability_StE.SD8vs11.REM = (nanstd(Stability_AcrossSD.s8vs11(:, 3)))./sqrt(n_cells);
    Stability_StE.SD9vs12.REM = (nanstd(Stability_AcrossSD.s9vs12(:, 3)))./sqrt(n_cells);
    Stability_StE.SD8vs14.REM = (nanstd(Stability_AcrossSD.s8vs14(:, 3)))./sqrt(n_cells);
    Stability_StE.SD9vs15.REM = (nanstd(Stability_AcrossSD.s9vs15(:, 3)))./sqrt(n_cells);
    DUMMY = 0;
end
% tmp.REM = ...
%     [Stability_Avg.Base1vs2.REM, Stability_Avg.Base2vs3.REM, Stability_Avg.Base4vs5.REM, ...
%     Stability_Avg.Base5vs6.REM, Stability_Avg.Base7vs8.REM, Stability_Avg.Base8vs9.REM];


%% Stability Average - Baseline
% Stability = 1/Firing Rate Variation
clear tmp;
tmp.Awake = ...
    [1/(Stability_Avg.Base1vs2.Awake), 1/(Stability_Avg.Base2vs3.Awake), 1/(Stability_Avg.Base4vs5.Awake), ...
    1/(Stability_Avg.Base5vs6.Awake), 1/(Stability_Avg.Base7vs8.Awake), 1/(Stability_Avg.Base8vs9.Awake)];
Stability_ToT_Avg_Baseline.Awake = nanmean(tmp.Awake);
Stability_ToT_StE_Baseline.Awake = (nanstd(tmp.Awake))./sqrt(n_comparisons_per_day);

tmp.NREM = ...
    [1/(Stability_Avg.Base1vs2.NREM), 1/(Stability_Avg.Base2vs3.NREM), 1/(Stability_Avg.Base4vs5.NREM), ...
    1/(Stability_Avg.Base5vs6.NREM), 1/(Stability_Avg.Base7vs8.NREM), 1/(Stability_Avg.Base8vs9.NREM)];
Stability_ToT_Avg_Baseline.NREM = nanmean(tmp.NREM);
Stability_ToT_StE_Baseline.NREM = (nanstd(tmp.NREM))./sqrt(n_comparisons_per_day);

tmp.REM = ...
    [1/(Stability_Avg.Base1vs2.REM), 1/(Stability_Avg.Base2vs3.REM), 1/(Stability_Avg.Base4vs5.REM), ...
    1/(Stability_Avg.Base5vs6.REM), 1/(Stability_Avg.Base7vs8.REM), 1/(Stability_Avg.Base8vs9.REM)];
Stability_ToT_Avg_Baseline.REM = nanmean(tmp.REM);
Stability_ToT_StE_Baseline.REM = (nanstd(tmp.REM))./sqrt(n_comparisons_per_day);


%% Stability Average - Recovery
% Stability = 1/Firing Rate Variation
tmp.Awake = ...
    [1/(Stability_Avg.Rec13vs14.Awake), 1/(Stability_Avg.Rec14vs15.Awake), 1/(Stability_Avg.Rec16vs17.Awake), ...
    1/(Stability_Avg.Rec17vs18.Awake), 1/(Stability_Avg.Rec19vs20.Awake), 1/(Stability_Avg.Rec20vs21.Awake)];
Stability_ToT_Avg_Recovery.Awake = nanmean(tmp.Awake);
Stability_ToT_StE_Recovery.Awake = (nanstd(tmp.Awake))./sqrt(n_comparisons_per_day);

tmp.NREM = ...
    [1/(Stability_Avg.Rec13vs14.NREM), 1/(Stability_Avg.Rec14vs15.NREM), 1/(Stability_Avg.Rec16vs17.NREM), ...
    1/(Stability_Avg.Rec17vs18.NREM), 1/(Stability_Avg.Rec19vs20.NREM), 1/(Stability_Avg.Rec20vs21.NREM)];
Stability_ToT_Avg_Recovery.NREM = nanmean(tmp.NREM);
Stability_ToT_StE_Recovery.NREM = (nanstd(tmp.NREM))./sqrt(n_comparisons_per_day);

tmp.REM = ...
    [1/(Stability_Avg.Rec13vs14.REM), 1/(Stability_Avg.Rec14vs15.REM), 1/(Stability_Avg.Rec16vs17.REM), ...
    1/(Stability_Avg.Rec17vs18.REM), 1/(Stability_Avg.Rec19vs20.REM), 1/(Stability_Avg.Rec20vs21.REM)];
Stability_ToT_Avg_Recovery.REM = nanmean(tmp.REM);
Stability_ToT_StE_Recovery.REM = (nanstd(tmp.REM))./sqrt(n_comparisons_per_day);

%% Stability Average - SD day


%% Stability Average - across SD
% Stability = 1/Firing Rate Variation
tmp.Awake = ...
    [1/(Stability_Avg.SD8vs11.Awake), 1/(Stability_Avg.SD9vs12.Awake)];
Stability_ToT_Avg_acrossSD.Awake = nanmean(tmp.Awake);
Stability_ToT_StE_acrossSD.Awake = (nanstd(tmp.Awake))./sqrt(n_comparisons_per_day);

tmp.NREM = ...
    [1/(Stability_Avg.SD8vs11.NREM), 1/(Stability_Avg.SD9vs12.NREM)];
Stability_ToT_Avg_acrossSD.NREM = nanmean(tmp.NREM);
Stability_ToT_StE_acrossSD.NREM = (nanstd(tmp.NREM))./sqrt(n_comparisons_per_day);

tmp.REM = ...
    [1/(Stability_Avg.SD8vs11.REM), 1/(Stability_Avg.SD9vs12.REM)];
Stability_ToT_Avg_acrossSD.REM = nanmean(tmp.REM);
Stability_ToT_StE_acrossSD.REM = (nanstd(tmp.REM))./sqrt(n_comparisons_per_day);


%% Plot
n_rows = 2;
n_columns = 3;
XLocation = [1, 2, 3];
X_Max = 60;

figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

% Subplot 1 - Stability average baseline
subplot(n_rows, n_columns, 1)

Y = [Stability_ToT_Avg_Baseline.Awake, Stability_ToT_Avg_Baseline.NREM, Stability_ToT_Avg_Baseline.REM];
errlow = [Stability_ToT_StE_Baseline.Awake, Stability_ToT_StE_Baseline.NREM, Stability_ToT_StE_Baseline.REM];
errhigh = [Stability_ToT_StE_Baseline.Awake, Stability_ToT_StE_Baseline.NREM, Stability_ToT_StE_Baseline.REM];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Awake','NREM','REM'})
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nBaseline');
title(Text_Title)
axis([0, 4, 0, X_Max]);

% Subplot 2 - Stability across SD
subplot(n_rows, n_columns, 2)

Y = [Stability_ToT_Avg_acrossSD.Awake, Stability_ToT_Avg_acrossSD.NREM, Stability_ToT_Avg_acrossSD.REM];
errlow = [Stability_ToT_StE_acrossSD.Awake, Stability_ToT_StE_acrossSD.NREM, Stability_ToT_StE_acrossSD.REM];
errhigh = [Stability_ToT_StE_acrossSD.Awake, Stability_ToT_StE_acrossSD.NREM, Stability_ToT_StE_acrossSD.REM];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Awake','NREM','REM'})
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nacross SD');
title(Text_Title)
axis([0, 4, 0, X_Max]);

% Subplot 3 - Stability average recovery
subplot(n_rows, n_columns, 3)

Y = [Stability_ToT_Avg_Recovery.Awake, Stability_ToT_Avg_Recovery.NREM, Stability_ToT_Avg_Recovery.REM];
errlow = [Stability_ToT_StE_Recovery.Awake, Stability_ToT_StE_Recovery.NREM, Stability_ToT_StE_Recovery.REM];
errhigh = [Stability_ToT_StE_Recovery.Awake, Stability_ToT_StE_Recovery.NREM, Stability_ToT_StE_Recovery.REM];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Awake','NREM','REM'})
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nRecovery');
title(Text_Title)
axis([0, 4, 0, X_Max]);

% Subplot 4 - Stability Awake comparison
X_Max = 30;
subplot(n_rows, n_columns, 4)

Y = [Stability_ToT_Avg_Baseline.Awake, Stability_ToT_Avg_acrossSD.Awake, Stability_ToT_Avg_Recovery.Awake];
errlow = [Stability_ToT_StE_Baseline.Awake, Stability_ToT_StE_acrossSD.Awake, Stability_ToT_StE_Recovery.Awake];
errhigh = [Stability_ToT_StE_Baseline.Awake, Stability_ToT_StE_acrossSD.Awake, Stability_ToT_StE_Recovery.Awake];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Baseline','Across SD','Recovery'})
xtickangle(45)
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nAwake');
title(Text_Title)
axis([0, 4, 0, X_Max]);

% Subplot 5 - Stability NREM comparison
X_Max = 60;
subplot(n_rows, n_columns, 5)

Y = [Stability_ToT_Avg_Baseline.NREM, Stability_ToT_Avg_acrossSD.NREM, Stability_ToT_Avg_Recovery.NREM];
errlow = [Stability_ToT_StE_Baseline.NREM, Stability_ToT_StE_acrossSD.NREM, Stability_ToT_StE_Recovery.NREM];
errhigh = [Stability_ToT_StE_Baseline.NREM, Stability_ToT_StE_acrossSD.NREM, Stability_ToT_StE_Recovery.NREM];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Baseline','Across SD','Recovery'})
xtickangle(45)
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nNREM');
title(Text_Title)
axis([0, 4, 0, X_Max]);

% Subplot 6 - Stability REM comparison
X_Max = 15;
subplot(n_rows, n_columns, 6)

Y = [Stability_ToT_Avg_Baseline.REM, Stability_ToT_Avg_acrossSD.REM, Stability_ToT_Avg_Recovery.REM];
errlow = [Stability_ToT_StE_Baseline.REM, Stability_ToT_StE_acrossSD.REM, Stability_ToT_StE_Recovery.REM];
errhigh = [Stability_ToT_StE_Baseline.REM, Stability_ToT_StE_acrossSD.REM, Stability_ToT_StE_Recovery.REM];
h_bar = bar(XLocation, Y);
hold on;
h_error = errorbar(XLocation, Y, errlow, errhigh, 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
hold off
ax = gca;
ax.FontSize = AxisFontSize; 
xticklabels({'Baseline','Across SD','Recovery'})
xtickangle(45)
grid on; box on; axis square;
ylabel('Average Stability [1/Hz]')
Text_Title = sprintf('Cell Events Rate Stability\nREM');
title(Text_Title)
axis([0, 4, 0, X_Max]);