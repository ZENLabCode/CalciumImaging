function [CellsPerState_Results, CellTag_perMouse, CellTagNum_perMouse] = cluster_cells_integralbased (Integrals_Group, Integral_Freq_Matrix_allMice, Mouse_Names, Mouse_Cells, Opts)
% This function assigns a state preference tag to each cell per session,
% based on the total DFF integral of each single cell, during specific
% states, normalized by the duration of the states ('Integrals Frequency')


% 0 = 'None / Low Activity';
% 1 = 'Not State Selective';
% 2 = 'Awake & NREM';
% 3 = 'Awake & REM';
% 4 = 'NREM & REM';
% 5 = 'Awake';
% 6 = 'NREM';
% 7 = 'REM';

% thr_FR_low = Lower X% percentile
th_RP_low_percentile = 25; % Percent

% Initialize
n_states = 4;
n_mice = Opts.n_mice;

Clustering_Variable = Integral_Freq_Matrix_allMice;

CellTag_perMouse = cell(1, n_mice);
CellTagNum_perMouse = cell(1, n_mice);
CellsPerState_Results = struct;
for i_mouse = 1:n_mice
    tmp = [Mouse_Cells.MouseID];
    n_cells = Mouse_Cells(tmp == i_mouse);
    n_cells = n_cells(1).n_cells;
    
    %% Method 1 - Simple max.
    if Opts.ClusteringMethod == 1
        [Max_FR, Max_FR_State] =  max(Clustering_Variable, [], 2, 'omitnan');
        CellTag = cell(n_cells, 1);
        CellTagArray = NaN(n_cells, 1);
        for i_cell = 1:n_cells
            switch Max_FR_State(i_cell)
                case 1
                    CellTag{i_cell} = 'Awake';
                    CellTagArray(i_cell) = 5;
                case 2
                    CellTag{i_cell} = 'NREM';
                    CellTagArray(i_cell) = 6;
                case 3
                    CellTag{i_cell} = 'REM';
                    CellTagArray(i_cell) = 7;
            end
            CellTag_perMouse{i_mouse} = CellTag;
            CellTagNum_perMouse{i_mouse} = CellTagArray;
        end
    end
    
    %% Method 2 - Inactive cells & Simple max.
    if Opts.ClusteringMethod == 2
        % Inactive cells = cells with activity < thr_FR_low, in every state
        
        tmp_1 = reshape (Clustering_Variable, [1, numel(Clustering_Variable)]);
        tmp_1(tmp_1 == 0) = NaN;
        
        % Get the threshold for inactive cells via percentile
        Y = prctile(tmp_1, [th_RP_low_percentile, 75]);
        thr_FR_low = Y(1);
        % Get the cells that have a minimum firing rate in each specific state
        ActiveCellsStates = zeros(size(Clustering_Variable));
        ActiveCellsStates(Clustering_Variable >= thr_FR_low) = 1;
        
        % Set to NaN the 'inactive' cells
        Clustering_Variable_Active = Clustering_Variable;
        Clustering_Variable_Active(ActiveCellsStates == 0) = NaN;
        
        % Compute the Max FR
        [Max_FR, Max_FR_State] = max(Clustering_Variable_Active, [], 2, 'omitnan');
        Max_FR_State(isnan(Max_FR)) = NaN;
        CellTag = cell(n_cells, 1);
        CellTagArray = NaN(n_cells, 1);
        
        for i_cell = 1:n_cells
            switch Max_FR_State(i_cell)
                case 1
                    CellTag{i_cell} = 'Awake';
                    CellTagArray(i_cell) = 5;
                case 2
                    CellTag{i_cell} = 'NREM';
                    CellTagArray(i_cell) = 6;
                case 3
                    CellTag{i_cell} = 'REM';
                    CellTagArray(i_cell) = 7;
                otherwise % In case it's a NaN
                    CellTag{i_cell} = 'None';
                    CellTagArray(i_cell) = 0;
            end
        end
        CellTag_perMouse{i_mouse} = CellTag;
        CellTagNum_perMouse{i_mouse} = CellTagArray;
    end
    
    %% Method 3 - Threshold on median Ca2+ Firing Rate
    if Opts.ClusteringMethod == 3
        % Inactive cells = cells with activity < thr_FR_low, in every state
        % Cells specificity = cells with activity difference higher than thr_FR_high_StE
        
        DUMMY = 1;
        while DUMMY == 1
            % Get the mean value as a reference for threshold.
            tmp_1 = reshape (Clustering_Variable, [1, numel(Clustering_Variable)]);
            tmp_1(tmp_1 == 0) = NaN;
            
            % Get the threshold for inactive cells via percentile
            Y = prctile(tmp_1, [th_RP_low_percentile, 75]);
            %             thr_FR_low = nanmedian(tmp_1);
            %             thr_FR_high = nanmean(tmp_1);
            thr_FR_low = Y(1);
            thr_FR_high = Y(2);
            
            thr_FR_high_StE = nanstd(tmp_1)./sqrt(n_cells);
            
            % Get the cells that have a minimum firing rate in each specific state
            ActiveCellsStates = zeros(size(Clustering_Variable));
            ActiveCellsStates(Clustering_Variable >= thr_FR_low) = 1;
            %             ActiveCellsStates(Clustering_Variable >= thr_FR_high) = 2;
            
            % Get the difference between the states FR
            DiffMatrix(:, 1) = Clustering_Variable(:, 1) - Clustering_Variable(:, 2); % Wake > NREM
            DiffMatrix(:, 2) = Clustering_Variable(:, 1) - Clustering_Variable(:, 3); % Wake > REM
            DiffMatrix(:, 3) = Clustering_Variable(:, 2) - Clustering_Variable(:, 3); % NREM > REM
            
            % Set to NaN the values where cells are not active enough
            %     DiffMatrix(ActiveCellsStates == 0) = NaN;
            
            % Set to 0 the differences that are below the threshold activity
            DiffMatrix(abs(DiffMatrix) <= thr_FR_high_StE/2) = 0;
            
            % Simplify to "binary" (-1, 0, 1) entries
            DiffMatrixOnes = DiffMatrix;
            DiffMatrixOnes(DiffMatrixOnes < 0) = -1;
            DiffMatrixOnes(DiffMatrixOnes > 0) = 1;
            
            % Scroll each cell and assign a tag according to the highest activity
            % REM selective = REM > Wake, NREM
            % NREM selective = NREM > Wake, REM
            % Wake selective = Wake > NREM, REM
            
            CellTag_tmp = zeros(n_cells, 3);
            for i_cell = 1:n_cells
                current_Diff = DiffMatrixOnes(i_cell, :);
                if ActiveCellsStates(i_cell, 1) == 1 && current_Diff(1, 1) == 1 && current_Diff(1, 2) == 1 % Awake Higher
                    CellTag_tmp(i_cell, 1) = 1;
                end
                if ActiveCellsStates(i_cell, 2) == 1 && current_Diff(1, 1) == -1 && current_Diff(1, 3) == 1 % NREM Higher
                    CellTag_tmp(i_cell, 2) = 1;
                end
                if ActiveCellsStates(i_cell, 3) == 1 && current_Diff(1, 2) == -1 && current_Diff(1, 3) == -1 % REM Higher
                    CellTag_tmp(i_cell, 3) = 1;
                end
                if ActiveCellsStates(i_cell, 2) == 1 && ActiveCellsStates(i_cell, 3) == 1 && current_Diff(1, 1) == -1 && current_Diff(1, 2) == -1 % NREM & REM High
                    CellTag_tmp(i_cell, 2) = 1;
                    CellTag_tmp(i_cell, 3) = 1;
                end
                if ActiveCellsStates(i_cell, 1) == 1 && ActiveCellsStates(i_cell, 3) == 1 && current_Diff(1, 1) == 1 && current_Diff(1, 3) == -1 % Awake & REM High
                    CellTag_tmp(i_cell, 1) = 1;
                    CellTag_tmp(i_cell, 3) = 1;
                end
                if ActiveCellsStates(i_cell, 1) == 1 && ActiveCellsStates(i_cell, 2) == 1 && current_Diff(1, 2) == -1 && current_Diff(1, 3) == -1 % Awake & NREM High
                    CellTag_tmp(i_cell, 1) = 1;
                    CellTag_tmp(i_cell, 2) = 1;
                end
            end
            
            % Finally, assign the group tag.
            CellTag = cell(n_cells, 1);
            CellTagArray = NaN(n_cells, 1);
            for i_cell = 1:n_cells
                current_CellTag = CellTag_tmp(i_cell, :);
                if ActiveCellsStates(i_cell, 1) == 0 && ActiveCellsStates(i_cell, 2) == 0 && ActiveCellsStates(i_cell, 3) == 0 % Cell with no activity
                    CellTag{i_cell} = 'None';
                    CellTagArray(i_cell) = 0;
                elseif current_CellTag(1, 1) == 0 && current_CellTag(1, 2) == 0 && current_CellTag(1, 3) == 0
                    CellTag{i_cell} = 'Not State Selective';
                    CellTagArray(i_cell) = 1;
                elseif current_CellTag(1, 1) == 1 && current_CellTag(1, 2) == 1 && current_CellTag(1, 3) == 1
                    CellTag{i_cell} = 'Not State Selective';
                    CellTagArray(i_cell) = 1;
                elseif current_CellTag(1, 1) == 1 && current_CellTag(1, 2) == 1 && current_CellTag(1, 3) == 0
                    CellTag{i_cell} = 'Awake & NREM';
                    CellTagArray(i_cell) = 2;
                elseif current_CellTag(1, 1) == 1 && current_CellTag(1, 2) == 0 && current_CellTag(1, 3) == 1
                    CellTag{i_cell} = 'Awake & REM';
                    CellTagArray(i_cell) = 3;
                elseif current_CellTag(1, 1) == 0 && current_CellTag(1, 2) == 1 && current_CellTag(1, 3) == 1
                    CellTag{i_cell} = 'NREM & REM';
                    CellTagArray(i_cell) = 4;
                elseif current_CellTag(1, 1) == 1 && current_CellTag(1, 2) == 0 && current_CellTag(1, 3) == 0
                    CellTag{i_cell} = 'Awake';
                    CellTagArray(i_cell) = 5;
                elseif current_CellTag(1, 1) == 0 && current_CellTag(1, 2) == 1 && current_CellTag(1, 3) == 0
                    CellTag{i_cell} = 'NREM';
                    CellTagArray(i_cell) = 6;
                elseif current_CellTag(1, 1) == 0 && current_CellTag(1, 2) == 0 && current_CellTag(1, 3) == 1
                    CellTag{i_cell} = 'REM';
                    CellTagArray(i_cell) = 7;
                end
            end
            CellTag_perMouse{i_mouse} = CellTag;
            CellTagNum_perMouse{i_mouse} = CellTagArray;
            
            clear DiffMatrix
            DUMMY = 0;
        end
    end
end