function [n_events] = get_n_events_per_mouse (Mouse_Names, Events_Grouped_Baseline_1, Events_Grouped_Baseline_2, Events_Grouped_Baseline_3, ...
    Events_Grouped_Baseline_4, Events_Grouped_Baseline_5, Events_Grouped_Baseline_6, ...
    Events_Grouped_Baseline_7, Events_Grouped_Baseline_8, Events_Grouped_Baseline_9, ...
    Events_Grouped_SD_10, Events_Grouped_SD_11, Events_Grouped_SD_12,...
    Events_Grouped_Recovery_13, Events_Grouped_Recovery_14, Events_Grouped_Recovery_15, ...
    Events_Grouped_Recovery_16, Events_Grouped_Recovery_17, Events_Grouped_Recovery_18, ...
    Events_Grouped_Recovery_19, Events_Grouped_Recovery_20, Events_Grouped_Recovery_21)

% This function gets the number of events over different sessions per mouse

n_mice = numel(Mouse_Names);
n_sessions = 21;

n_events = NaN(n_sessions, n_mice);
for i = 1:n_mice
    % Baseline
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_1, Mouse_Names);
    n_events(1, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_2, Mouse_Names);
    n_events(2, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_3, Mouse_Names);
    n_events(3, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_4, Mouse_Names);
    n_events(4, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_5, Mouse_Names);
    n_events(5, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_6, Mouse_Names);
    n_events(6, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_7, Mouse_Names);
    n_events(7, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_8, Mouse_Names);
    n_events(8, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Baseline_9, Mouse_Names);
    n_events(9, i) = numel(tmp{i});

    % SD
    [tmp] = get_EventsPerMouse (Events_Grouped_SD_10, Mouse_Names);
    n_events(10, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_SD_11, Mouse_Names);
    n_events(11, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_SD_12, Mouse_Names);
    n_events(12, i) = numel(tmp{i});
    
    % Recovery
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_13, Mouse_Names);
    n_events(13, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_14, Mouse_Names);
    n_events(14, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_15, Mouse_Names);
    n_events(15, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_16, Mouse_Names);
    n_events(16, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_17, Mouse_Names);
    n_events(17, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_18, Mouse_Names);
    n_events(18, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_19, Mouse_Names);
    n_events(19, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_20, Mouse_Names);
    n_events(20, i) = numel(tmp{i});
    [tmp] = get_EventsPerMouse (Events_Grouped_Recovery_21, Mouse_Names);
    n_events(21, i) = numel(tmp{i});
end
