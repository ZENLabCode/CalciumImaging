function Integral_AllSessions = cmp_integral_per_state_per_cell (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Opts)
% This function computes the integral for each cell per state across all
% recordings, averaging over the states of the same type, and producing
% also an average between all cells of the same mouse and recording session.


n_recordings = numel(CalciumTraces_Clean_AllSessions);

% New normalization: normalize only by the total smoothed minimum, 
% to bring every minimum approximately to 0, but not have residual
% mini-artifacts risk influencing the whole recordings.
for i_recording = 1:n_recordings
    tmp = CalciumTraces_Clean_AllSessions{i_recording};
    tmp_smooth = tmp;
    [~, n_traces] = size(tmp);
    for i_trace = 1:n_traces
        tmp_smooth(:, i_trace) = smooth(tmp_smooth(:, i_trace));
    end
    tmp_smooth_min = min(tmp_smooth, [], 1, 'omitnan');
%     tmp_smooth_min = min(tmp_smooth_min, [], 2, 'omitnan');
    tmp = tmp - tmp_smooth_min;
    
    CalciumTraces_Clean_AllSessions_Normalized{i_recording} = tmp;
end

% Old (wrong) normalization
FLAG_OldMethod = 0;
if FLAG_OldMethod == 1
    % Normalize each recording by its maximum and minimum amplitude
    for i_recording = 1:n_recordings
        tmp = CalciumTraces_Clean_AllSessions{i_recording};
        
        tmp_min = min(tmp, [], 1, 'omitnan');
        tmp_min = min(tmp_min, [], 2, 'omitnan');
        tmp = tmp - tmp_min;
        
        tmp_max = max(tmp, [], 1, 'omitnan');
        tmp_max = max(tmp_max, [], 2, 'omitnan');
        tmp = tmp./tmp_max;
        
        CalciumTraces_Clean_AllSessions_Normalized{i_recording} = tmp;
    end
    
    % Normalize each trace by its maximum and minimum amplitude
    for i_recording = 1:n_recordings
        tmp = CalciumTraces_Clean_AllSessions_Normalized{i_recording};
        
        tmp_min = min(tmp, [], 1, 'omitnan');
        %     tmp_min = min(tmp_min, [], 2, 'omitnan');
        tmp = tmp - tmp_min;
        
        tmp_max = max(tmp, [], 1, 'omitnan');
        %     tmp_max = max(tmp_max, [], 2, 'omitnan');
        tmp = tmp./tmp_max;
        
        CalciumTraces_Clean_AllSessions_Normalized{i_recording} = tmp;
    end
end



% Compute Integrals
for i_recording = 1:n_recordings
    current_Recording_Normalized = CalciumTraces_Clean_AllSessions_Normalized{i_recording};
    current_StateChanges = Hypnogram_AllSessions(i_recording).StateChanges;
    current_StateStability = Hypnogram_AllSessions(i_recording).StateIsStable;
    current_StateType = Hypnogram_AllSessions(i_recording).StateType;
    current_StateDuration = Hypnogram_AllSessions(i_recording).StateDuration;
    
    n_states = numel(current_StateType);
    StateStart = 1;
    i_Awake = 1;
    i_NREM = 1;
    i_REM = 1;

    Integral_perCell_Awake = [];
    Integral_perCell_NREM = [];
    Integral_perCell_REM = [];
    Integral_perCell_Frequency_Awake = [];
    Integral_perCell_Frequency_NREM = [];
    Integral_perCell_Frequency_REM = [];
    for i_state = 1:n_states
        
        if current_StateStability(i_state) == 0 % Skip unstable states.
            % Assign the next state start
            StateStart = current_StateChanges(i_state);
            continue
        end
        % Now we only have stable states
        
        
        StateEnd = current_StateChanges(i_state) - 1;
        % Compute the integral for each cell
        StateDuration = current_StateDuration(i_state);
        current_StateTraces = current_Recording_Normalized(StateStart:StateEnd, :);
        
        current_Integral = sum(current_StateTraces, 1, 'omitnan');
        
        current_IntegralFrequency = current_Integral./StateDuration;
        % Assign to the corresponding state
        
        switch current_StateType(i_state)
            case Opts.General.TagAWAKE
                Integral_perCell_Awake = [Integral_perCell_Awake; current_Integral];
                Integral_perCell_Frequency_Awake = [Integral_perCell_Frequency_Awake; current_IntegralFrequency];
                i_Awake = i_Awake + 1;
            case Opts.General.TagNoNREM
                Integral_perCell_NREM = [Integral_perCell_NREM; current_Integral];
                Integral_perCell_Frequency_NREM = [Integral_perCell_Frequency_NREM; current_IntegralFrequency];
                i_NREM = i_NREM + 1;
            case Opts.General.TagREM
                Integral_perCell_REM = [Integral_perCell_REM; current_Integral];
                Integral_perCell_Frequency_REM = [Integral_perCell_Frequency_REM; current_IntegralFrequency];
                i_REM = i_REM + 1;
        end
        
        
        % Assign the next state start
        StateStart = current_StateChanges(i_state);
    end
    
    % Average per cell
    Integral_Average_perCell.Awake = mean(Integral_perCell_Awake, 1, 'omitnan');
    Integral_Average_perCell.NREM = mean(Integral_perCell_NREM, 1, 'omitnan');
    Integral_Average_perCell.REM = mean(Integral_perCell_REM, 1, 'omitnan');
    IntegralFrequency_Average_perCell.Awake = mean(Integral_perCell_Frequency_Awake, 1, 'omitnan');
    IntegralFrequency_Average_perCell.NREM = mean(Integral_perCell_Frequency_NREM, 1, 'omitnan');
    IntegralFrequency_Average_perCell.REM = mean(Integral_perCell_Frequency_REM, 1, 'omitnan');
    
    % StE per cell
    Integral_StE_perCell.Awake = std(Integral_perCell_Awake, 0, 1, 'omitnan')./sqrt(i_Awake - 1);
    Integral_StE_perCell.NREM = std(Integral_perCell_NREM, 0, 1, 'omitnan')./sqrt(i_NREM - 1);
    Integral_StE_perCell.REM = std(Integral_perCell_REM, 0, 1, 'omitnan')./sqrt(i_REM - 1);
    IntegralFrequency_StE_perCell.Awake = std(Integral_perCell_Frequency_Awake, 0, 1, 'omitnan')./sqrt(i_Awake - 1);
    IntegralFrequency_StE_perCell.NREM = std(Integral_perCell_Frequency_NREM, 0, 1, 'omitnan')./sqrt(i_NREM - 1);
    try 
        IntegralFrequency_StE_perCell.REM = std(Integral_perCell_Frequency_REM, 0, 1, 'omitnan')./sqrt(i_REM - 1); 
    catch
        IntegralFrequency_StE_perCell.REM = NaN;
    end
    
    % TotalAverages
    Integral_Average.Awake = mean(Integral_Average_perCell.Awake, 2, 'omitnan');
    Integral_Average.NREM = mean(Integral_Average_perCell.NREM, 2, 'omitnan');
    Integral_Average.REM = mean(Integral_Average_perCell.REM, 2, 'omitnan');
    Integral_StE.Awake = std(Integral_Average_perCell.Awake, 0, 2, 'omitnan')./sqrt(numel(Integral_Average_perCell.Awake));
    Integral_StE.NREM = std(Integral_Average_perCell.NREM, 0, 2, 'omitnan')./sqrt(numel(Integral_Average_perCell.NREM));
    Integral_StE.REM = std(Integral_Average_perCell.REM, 0, 2, 'omitnan')./sqrt(numel(Integral_Average_perCell.REM));
    
    Integral_AllSessions(i_recording).Integral_Average.Awake = Integral_Average.Awake;
    Integral_AllSessions(i_recording).Integral_Average.NREM = Integral_Average.NREM;
    Integral_AllSessions(i_recording).Integral_Average.REM = Integral_Average.REM;
    Integral_AllSessions(i_recording).Integral_StE.Awake = Integral_StE.Awake;
    Integral_AllSessions(i_recording).Integral_StE.NREM = Integral_StE.NREM;
    Integral_AllSessions(i_recording).Integral_StE.REM = Integral_StE.REM;
    
    Integral_AllSessions(i_recording).Integral_perCell_Awake = Integral_perCell_Awake;
    Integral_AllSessions(i_recording).Integral_perCell_NREM = Integral_perCell_NREM;
    Integral_AllSessions(i_recording).Integral_perCell_REM = Integral_perCell_REM;
    Integral_AllSessions(i_recording).Integral_perCell_Frequency_Awake = Integral_perCell_Frequency_Awake;
    Integral_AllSessions(i_recording).Integral_perCell_Frequency_NREM = Integral_perCell_Frequency_NREM;
    Integral_AllSessions(i_recording).Integral_perCell_Frequency_REM = Integral_perCell_Frequency_REM;
    
    for i_state = 1
        Integral_Average;
    end
end