function [Awake, NREM, REM] = clustering_change_MaxState (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts)
% This function plots the change in clustering over three conditions, in
% case the Max State cluster assignment is used.

CellTag_perMouse_1 = CellTag_perMouse_1';
CellTag_perMouse_2 = CellTag_perMouse_2';
CellTag_perMouse_3 = CellTag_perMouse_3';

CellsTagAll_1 = cell(0);
for i = 1:numel(CellTag_perMouse_1)
    CellsTagAll_1 = [CellsTagAll_1; CellTag_perMouse_1{i}];
end

CellsTagAll_2 = cell(0);
for i = 1:numel(CellTag_perMouse_2)
    CellsTagAll_2 = [CellsTagAll_2; CellTag_perMouse_2{i}];
end

CellsTagAll_3 = cell(0);
for i = 1:numel(CellTag_perMouse_3)
    CellsTagAll_3 = [CellsTagAll_3; CellTag_perMouse_3{i}];
end

try
    CellsTagAll(:, 1) = CellsTagAll_1;
catch
    warning('A cell is missing from some condition')
end

n_cells = numel(CellsTagAll_1);

try
    CellsTagAll(:, 2) = CellsTagAll_2;
catch
    warning('A cell is missing from some condition')
    [dim1, ~] = size(CellsTagAll);
    if numel(CellsTagAll_2) > dim1
        CellsTagAll_2(end) = [];
    elseif numel(CellsTagAll_2) < dim1
        CellsTagAll(end, :) = [];
        n_cells = n_cells - 1;
    end
    try
        CellsTagAll(:, 2) = CellsTagAll_2;
    catch
        keyboard
    end
end

try
    CellsTagAll(:, 3) = CellsTagAll_3;
catch
    warning('A cell is missing from some condition')
    [dim1, ~] = size(CellsTagAll);
    if numel(CellsTagAll_3) > dim1
        CellsTagAll_3(end) = [];
    elseif numel(CellsTagAll_3) < dim1
        CellsTagAll(end, :) = [];
        n_cells = n_cells - 1;
    end
    CellsTagAll(:, 3) = CellsTagAll_3;
end


[n_cells, ~] = size(CellsTagAll);
CellNumTag = NaN(n_cells, 3);
for i = 1:n_cells
    try
        if strcmpi(CellsTagAll(i, 1), 'Awake')
            CellNumTag(i, 1) = 1;
        end
    catch
        keyboard
    end
    if strcmpi(CellsTagAll(i, 1), 'NREM')
        CellNumTag(i, 1) = 2;
    end
    if strcmpi(CellsTagAll(i, 1), 'REM')
        CellNumTag(i, 1) = 4;
    end
    if strcmpi(CellsTagAll(i, 1), 'None')
        CellNumTag(i, 1) = 0;
    end
    if strcmpi(CellsTagAll(i, 1), 'Not State Selective')
        CellNumTag(i, 1) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 2), 'Awake')
        CellNumTag(i, 2) = 1;
    end
    if strcmpi(CellsTagAll(i, 2), 'NREM')
        CellNumTag(i, 2) = 2;
    end
    if strcmpi(CellsTagAll(i, 2), 'REM')
        CellNumTag(i, 2) = 4;
    end
    if strcmpi(CellsTagAll(i, 2), 'None')
        CellNumTag(i, 2) = 0;
    end
    if strcmpi(CellsTagAll(i, 2), 'Not State Selective')
        CellNumTag(i, 2) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 3), 'Awake')
        CellNumTag(i, 3) = 1;
    end
    if strcmpi(CellsTagAll(i, 3), 'NREM')
        CellNumTag(i, 3) = 2;
    end
    if strcmpi(CellsTagAll(i, 3), 'REM')
        CellNumTag(i, 3) = 4;
    end
    if strcmpi(CellsTagAll(i, 3), 'None')
        CellNumTag(i, 3) = 0;
    end
    if strcmpi(CellsTagAll(i, 3), 'Not State Selective')
        CellNumTag(i, 3) = 5;
    end
end

tmp = CellNumTag(:, 1);
CellNumTag_Awake_Baseline = zeros(n_cells, 1);
CellNumTag_Awake_Baseline(tmp == 1) = 1;

[indexes_AwakeStart,~] = find(tmp == 1);
[indexes_NREMStart,~] = find(tmp == 2);
[indexes_REMStart,~] = find(tmp == 4);
[indexes_InactiveStart,~] = find(tmp == 0);
[indexes_UnspecificStart,~] = find(tmp == 5);

n_AwakeStart = numel(indexes_AwakeStart);
n_NREMStart = numel(indexes_NREMStart);
n_REMStart = numel(indexes_REMStart);
n_InactiveStart = numel(indexes_InactiveStart);
n_UnspecificStart = numel(indexes_UnspecificStart);

tmp = CellNumTag(:, 3);

Awake_PostSD_Trans = tmp(indexes_AwakeStart);
Awake.Total = n_AwakeStart;
Awake.Awake = numel(find(Awake_PostSD_Trans == 1));
Awake.NREM = numel(find(Awake_PostSD_Trans == 2));
Awake.REM = numel(find(Awake_PostSD_Trans == 4));
Awake.Inactive = numel(find(Awake_PostSD_Trans == 0));

Awake.Percentage.REM = (Awake.REM./Awake.Total).*100;
Awake.Percentage.Awake = (Awake.Awake./Awake.Total).*100;
Awake.Percentage.NREM = (Awake.NREM./Awake.Total).*100;
Awake.Percentage.Inactive = (Awake.Inactive./Awake.Total).*100;
Awake.Percentage.Unspecific = 100 - (Awake.Percentage.REM + Awake.Percentage.Awake + Awake.Percentage.NREM + Awake.Percentage.Inactive);


NREM_PostSD_Trans = tmp(indexes_NREMStart);
NREM.Total = n_NREMStart;
NREM.Awake = numel(find(NREM_PostSD_Trans == 1));
NREM.NREM = numel(find(NREM_PostSD_Trans == 2));
NREM.REM = numel(find(NREM_PostSD_Trans == 4));
NREM.Inactive = numel(find(NREM_PostSD_Trans == 0));

NREM.Percentage.REM = (NREM.REM./NREM.Total).*100;
NREM.Percentage.Awake = (NREM.Awake./NREM.Total).*100;
NREM.Percentage.NREM = (NREM.NREM./NREM.Total).*100;
NREM.Percentage.Inactive = (NREM.Inactive./NREM.Total).*100;
NREM.Percentage.Unspecific = 100 - (NREM.Percentage.REM + NREM.Percentage.Awake + NREM.Percentage.NREM + NREM.Percentage.Inactive);

REM_PostSD_Trans = tmp(indexes_REMStart);
REM.Total = n_REMStart;
REM.Awake = numel(find(REM_PostSD_Trans == 1));
REM.NREM = numel(find(REM_PostSD_Trans == 2));
REM.REM = numel(find(REM_PostSD_Trans == 4));
REM.Inactive = numel(find(REM_PostSD_Trans == 0));

REM.Percentage.REM = (REM.REM./REM.Total).*100;
REM.Percentage.Awake = (REM.Awake./REM.Total).*100;
REM.Percentage.NREM = (REM.NREM./REM.Total).*100;
REM.Percentage.Inactive = (REM.Inactive./REM.Total).*100;
REM.Percentage.Unspecific = 100 - (REM.Percentage.REM + REM.Percentage.Awake + REM.Percentage.NREM + REM.Percentage.Inactive);

Inactive_PostSD_Trans = tmp(indexes_InactiveStart);
Inactive.Total = n_InactiveStart;
Inactive.Awake = numel(find(Inactive_PostSD_Trans == 1));
Inactive.NREM = numel(find(Inactive_PostSD_Trans == 2));
Inactive.REM = numel(find(Inactive_PostSD_Trans == 4));
Inactive.Inactive = numel(find(Inactive_PostSD_Trans == 0));

Inactive.Percentage.REM = (Inactive.REM./Inactive.Total).*100;
Inactive.Percentage.Awake = (Inactive.Awake./Inactive.Total).*100;
Inactive.Percentage.NREM = (Inactive.NREM./Inactive.Total).*100;
Inactive.Percentage.Inactive = (Inactive.Inactive./Inactive.Total).*100;
Inactive.Percentage.Unspecific = 100 - (Inactive.Percentage.REM + Inactive.Percentage.Awake + Inactive.Percentage.NREM + Inactive.Percentage.Inactive);

Unspecific_PostSD_Trans = tmp(indexes_UnspecificStart);
Unspecific.Total = n_UnspecificStart;
Unspecific.Awake = numel(find(Unspecific_PostSD_Trans == 1));
Unspecific.NREM = numel(find(Unspecific_PostSD_Trans == 2));
Unspecific.REM = numel(find(Unspecific_PostSD_Trans == 4));
Unspecific.Inactive = numel(find(Unspecific_PostSD_Trans == 0));

Unspecific.Percentage.REM = (Unspecific.REM./Unspecific.Total).*100;
Unspecific.Percentage.Awake = (Unspecific.Awake./Unspecific.Total).*100;
Unspecific.Percentage.NREM = (Unspecific.NREM./Unspecific.Total).*100;
Unspecific.Percentage.Inactive = (Unspecific.Inactive./Unspecific.Total).*100;
Unspecific.Percentage.Unspecific = 100 - (Unspecific.Percentage.REM + Unspecific.Percentage.Awake + Unspecific.Percentage.NREM + Unspecific.Percentage.Inactive);



if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    Unspecific_PostSD_Trans = NaN;
    Unspecific.Total = NaN;
    Unspecific.Awake = NaN;
    Unspecific.NREM = NaN;
    Unspecific.REM = NaN;
    Unspecific.Inactive = NaN;

    Unspecific.Percentage.REM = NaN;
    Unspecific.Percentage.Awake = NaN;
    Unspecific.Percentage.NREM = NaN;
    Unspecific.Percentage.Inactive = NaN;
    Unspecific.Percentage.Unspecific = NaN;
    
    Awake.Percentage.Unspecific = NaN;
    NREM.Percentage.Unspecific = NaN;
    REM.Percentage.Unspecific = NaN;
    Inactive.Percentage.Unspecific = NaN;
end


%% Actual Plot

% Set the colors of the plot.
t2col = [1 0 0];   %red        
t3col = [0 1 0];   %green
t1col = [0 0 1];   %blue
t4col = [0.1 0.1 0.1];   %magenta
t5col = [0 0 0]; 
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    tilecolor = [t1col; t2col; t3col; t5col];
elseif Opts.ClusteringMethod == 3
    tilecolor = [t1col; t2col; t3col; t4col; t5col];
end

% Plot options
n_rows = 1;
n_columns = 4;
FontSizeTitles = 18;
FontSizeAnnotationSmall = 14;
AxisFontSize = 14;

% Plot
figure('units','normalized','outerposition',[0 0 1 1]);

% Subplot 1
subplot(n_rows, n_columns, 1);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    h_pie = pie_modified([Awake.Percentage.Awake, Awake.Percentage.NREM, Awake.Percentage.REM, Awake.Percentage.Inactive], tilecolor);
elseif Opts.ClusteringMethod == 3
    h_pie = pie_modified([Awake.Percentage.Awake, Awake.Percentage.NREM, Awake.Percentage.REM, Awake.Percentage.Unspecific, Awake.Percentage.Inactive], tilecolor);
end
Text_Title = sprintf('Awake Specific Cells %s', Opts.SubTitle_part);
title(Text_Title, 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    legend({'Awake', 'NREM', 'REM', 'Inactive'})
elseif Opts.ClusteringMethod == 3
    legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})
end

% Subplot 2
subplot(n_rows, n_columns, 2);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    h_pie = pie_modified([REM.Percentage.Awake, REM.Percentage.NREM, REM.Percentage.REM, REM.Percentage.Inactive], tilecolor);
elseif Opts.ClusteringMethod == 3
    h_pie = pie_modified([REM.Percentage.Awake, REM.Percentage.NREM, REM.Percentage.REM, REM.Percentage.Unspecific, REM.Percentage.Inactive], tilecolor);
end
Text_Title = sprintf('REM Specific Cells %s', Opts.SubTitle_part);
title(Text_Title, 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    legend({'Awake', 'NREM', 'REM', 'Inactive'})
elseif Opts.ClusteringMethod == 3
    legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})
end

% Subplot 3
subplot(n_rows, n_columns, 3);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    h_pie = pie_modified([NREM.Percentage.Awake, NREM.Percentage.NREM, NREM.Percentage.REM, NREM.Percentage.Inactive], tilecolor);
elseif Opts.ClusteringMethod == 3
    h_pie = pie_modified([NREM.Percentage.Awake, NREM.Percentage.NREM, NREM.Percentage.REM, NREM.Percentage.Unspecific, NREM.Percentage.Inactive], tilecolor);
end

Text_Title = sprintf('NREM Specific Cells %s', Opts.SubTitle_part);
title(Text_Title, 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    legend({'Awake', 'NREM', 'REM', 'Inactive'})
elseif Opts.ClusteringMethod == 3
    legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})
end

% Subplot 4
subplot(n_rows, n_columns, 4);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    h_pie = pie_modified([Inactive.Percentage.Awake, Inactive.Percentage.NREM, Inactive.Percentage.REM, Inactive.Percentage.Inactive], tilecolor);
elseif Opts.ClusteringMethod == 3
    h_pie = pie_modified([Inactive.Percentage.Awake, Inactive.Percentage.NREM, Inactive.Percentage.REM, Inactive.Percentage.Unspecific, Inactive.Percentage.Inactive], tilecolor);
end
Text_Title = sprintf('Inactive Specific Cells %s', Opts.SubTitle_part);
title(Text_Title, 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    legend({'Awake', 'NREM', 'REM', 'Inactive'})
elseif Opts.ClusteringMethod == 3
    legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})
end

Annotation_position_x = 0.1;
Annotation_position_x_step = 0.21;

% Annotation with number of cells
Text_Annotation = sprintf('Number of Previously\n Awake Cells = %d', Awake.Total);
Text_Annotation_position = [Annotation_position_x, 0.37, 0.5, 0];
h_Annotation = annotation('textbox', Text_Annotation_position, 'string', Text_Annotation);
h_Annotation.LineStyle = 'none';
h_Annotation.FontSize = FontSizeAnnotationSmall;

Annotation_position_x = Annotation_position_x + Annotation_position_x_step;
Text_Annotation = sprintf('Number of Previously\n REM Cells = %d', REM.Total);
Text_Annotation_position = [Annotation_position_x, 0.37, 0.5, 0];
h_Annotation = annotation('textbox', Text_Annotation_position, 'string', Text_Annotation);
h_Annotation.LineStyle = 'none';
h_Annotation.FontSize = FontSizeAnnotationSmall;

Annotation_position_x = Annotation_position_x + Annotation_position_x_step;
Text_Annotation = sprintf('Number of Previously\n NREM Cells = %d', NREM.Total);
Text_Annotation_position = [Annotation_position_x, 0.37, 0.5, 0];
h_Annotation = annotation('textbox', Text_Annotation_position, 'string', Text_Annotation);
h_Annotation.LineStyle = 'none';
h_Annotation.FontSize = FontSizeAnnotationSmall;

Annotation_position_x = Annotation_position_x + Annotation_position_x_step;
Text_Annotation = sprintf('Number of Previously\n Inactive Cells = %d', Inactive.Total);
Text_Annotation_position = [Annotation_position_x, 0.37, 0.5, 0];
h_Annotation = annotation('textbox', Text_Annotation_position, 'string', Text_Annotation);
h_Annotation.LineStyle = 'none';
h_Annotation.FontSize = FontSizeAnnotationSmall;


Text_Annotation = sprintf('Total Number of Cells = %d', n_cells);
Text_Annotation_position = [0.1, 0.27, 0.5, 0];
h_Annotation = annotation('textbox', Text_Annotation_position, 'string', Text_Annotation);
h_Annotation.LineStyle = 'none';
h_Annotation.FontSize = FontSizeTitles;

% Main title
h_suptitle = suptitle(Opts.SupTitle_Text);
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';


%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = Opts.SupTitle_Text;
    FileName = strrep(FileName, newline, '');  % Replace newline with nothing
    % FileName = 'Figure Cells Clustered per State';
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

% tmp_pText = findobj(h_pie, 'Type', 'text');
% tmp_percentValues = get(tmp_pText, 'String');
% if numel(tmp_percentValues) < 3
%     tmp_percentValues{3} = '0%'; % REM 0%
% end
% tmp_combinedtxt = strcat(tmp_txt, tmp_percentValues); 
% tmp_pText(1).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{1}, n_EventsComposites_Awake);% tmp_combinedtxt(1);
% tmp_pText(2).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{2}, n_EventsComposites_NREM); % tmp_combinedtxt(2);
% if numel(tmp_pText) >= 3
%     tmp_pText(3).String = sprintf('%s\n(%.f Events)', tmp_combinedtxt{3}, n_EventsComposites_REM); % tmp_combinedtxt(3);
% end
% 
% 
% 
% 
% tmp(CellNumTag_Awake_Baseline == 1)
% 
% CellNumTag_Awake_PostSD = zeros(509, 1);
% CellNumTag_Awake_PostSD(tmp == 1) = 1;

