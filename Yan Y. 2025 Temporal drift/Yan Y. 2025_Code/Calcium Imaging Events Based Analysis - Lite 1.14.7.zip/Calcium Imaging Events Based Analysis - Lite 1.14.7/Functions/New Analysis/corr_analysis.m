function corr_analysis (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, HypnoState, Mouse_Names, Opts)

Matrix_Distance_Type = Opts.Matrix_Distance_Type;

n_sessions = numel(HypnoState);
n_mice = numel(Mouse_Names);

% Separate Traces and Hypnogram per mouse
CalciumTraces_perMouse = cell(n_mice, 1);
Hypnogram_perMouse = cell(n_mice, 1);
HypnogramDuration_perMouse = cell(n_mice, 1);
StateType_perMouse = cell(n_mice, 1);
StateDuration_perMouse = cell(n_mice, 1);
for i_mouse = 1:n_mice
    Current_Mouse = Mouse_Names{i_mouse};
    CalciumTraces = cell(0);
    Hypnogram = cell(0);
    Hypnogram_Duration = cell(0);
    StateType_array = cell(0);
    StateDuration_array = cell(0);
    for i_session  = 1:n_sessions
        if strcmpi(HypnoState(i_session).MouseName, Current_Mouse) == 1
            CurrentHypno = Hypnogram_AllSessions(i_session).Hypnogram;
            CurrentHypno_Duration = Hypnogram_AllSessions(i_session).StateDuration_Array;
            CurrentStateType = Hypnogram_AllSessions(i_session).StateType;
            CurrentStateDuration = Hypnogram_AllSessions(i_session).StateDuration;
            
            CalciumTraces = [CalciumTraces; CalciumTraces_Clean_AllSessions{i_session}];
            Hypnogram = [Hypnogram; CurrentHypno];
            StateType_array = [StateType_array; CurrentStateType];
            StateDuration_array = [StateDuration_array; CurrentStateDuration];
        end
    end
    CalciumTraces_perMouse{i_mouse} = CalciumTraces;
    Hypnogram_perMouse{i_mouse} = Hypnogram;
    HypnogramDuration_perMouse{i_mouse} = Hypnogram_Duration;
    StateType_perMouse{i_mouse} = StateType_array;
    StateDuration_perMouse{i_mouse} = StateDuration_array;
end
clear CalciumTraces; clear Hypnogram; clear CurrentHypno; clear Hypnogram_Duration; clear CurrentHypno_Duration;



Distance_Matrices = cell(n_mice, 1);
for i_mouse = 1:n_mice
    CurrentTraces_Sessions = CalciumTraces_perMouse{i_mouse};
    tmp_n_sessions = numel(CurrentTraces_Sessions);
    CorrMatrices = cell(tmp_n_sessions, 1);
    % Compute the correlation between the whole traces.
    % Obtain a n_cells x n_cells correlation matrix for each session
    for i_session = 1:tmp_n_sessions
        Current_CalciumTraces = CurrentTraces_Sessions{i_session};
       [CorrWholeState, CorrWholeState_p] = corr(Current_CalciumTraces, 'rows', 'complete'); 
       CorrMatrices{i_session} = CorrWholeState;
    end
    D = NaN(tmp_n_sessions, tmp_n_sessions);
    
    % Compute the pairwise distance between these correlation matrices
    % Take then the average of each, showing in the end the 
    % n_sessions x n_sessions matrix of average distances between the
    % various correlation maps
    for i_session = 1:tmp_n_sessions
        for j_session = 1:tmp_n_sessions
            if i_session == j_session
                D(i_session, j_session) = NaN;
            else
                tmp = pdist2(CorrMatrices{i_session},CorrMatrices{j_session}, Matrix_Distance_Type);
                D(i_session, j_session) = nanmean(nanmean(tmp));
            end
        end
    end
    
    % Normalize D
    D_norm = rescale(D);
    % Save for each mouse
    Distance_Matrices{i_mouse} = D_norm;
end


% pcolor(CorrMatrices{i_session})
% set(gca, 'YDir','reverse')
% ax = gca;
% ax.FontSize = AxisFontSize;
% ylabel('Cell ID', 'FontSize', 18)
% xlabel('Cell ID', 'FontSize', 18)
% title('Example Correlation Matrix for a single session', 'FontSize', FontSizeTitles)
% keyboard

n_rows = 2;
n_columns = 3;

figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

Ticks_Array = ([1, 4, 7, 10, 13, 16, 19]);
Ticks_Array = Ticks_Array + 0.5;
Ticks_Labels = ({'Day 1','Day 2','Day 3', 'SD', 'Rec 1', 'Rec 2', 'Rec 3'});

for i_mouse = 1:n_mice
    subplot(n_rows, n_columns, i_mouse)
%     imagesc(Distance_Matrices{i_mouse})
    pcolor((Distance_Matrices{i_mouse})')
    set(gca, 'YDir','reverse')
    ax = gca;
    ax.FontSize = AxisFontSize;
    axis square
    ylabel('Recording Session', 'FontSize', 18)
    yticks(Ticks_Array)
    yticklabels(Ticks_Labels)
    xticks(Ticks_Array)
    xticklabels(Ticks_Labels)
    xtickangle(45)
    Text_Title = sprintf('Mouse #%d', i_mouse);
    title(Text_Title, 'FontSize', FontSizeTitles)
    h_colorbar = colorbar;
end
Text_Suptitle = sprintf('Distance Between Cell Correlation Maps');
h_suptitle = suptitle(Text_Suptitle);
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';