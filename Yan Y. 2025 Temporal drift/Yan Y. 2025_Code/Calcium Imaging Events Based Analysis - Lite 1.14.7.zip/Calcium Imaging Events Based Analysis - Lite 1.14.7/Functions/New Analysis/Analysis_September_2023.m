% Plot the Connectivity Indexes Average over Mice, over sessions.
% Plot the Average Correlation Time Series for each state (average per mouse)
% Plot the Events Rate time evolution per Session
% Plot the Events Rate time evolution per Session - Normalized
% Plot the Events Rate variation evolution per Session - Normalized


%% Plot the Connectivity Indexes Average over Mice, over sessions.
PlotLineWidth = 2;
ErrorHeadSize = 10;
figure;
hold on;
errorbar(Connectivity_Index_OverTime_Mouse_Average(1,:), Connectivity_Index_OverTime_Mouse_StE(1,:), 'b', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
errorbar(Connectivity_Index_OverTime_Mouse_Average(2,:), Connectivity_Index_OverTime_Mouse_StE(2,:), 'r', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
errorbar(Connectivity_Index_OverTime_Mouse_Average(4,:), Connectivity_Index_OverTime_Mouse_StE(4,:), 'g', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
box on; grid on;
xlabel('Session');
ylabel('Average Connectivity Index');
title('Average Connectivity Index');
legend({'Awake', 'NREM', 'REM'})


%% Plot the Average Correlation Time Series for each state (average per mouse)
PlotLineWidth = 2;
ErrorHeadSize = 10;

figure;
hold on;
errorbar(CorrVariation_TimeSeries_Avg(1,:), CorrVariation_TimeSeries_StE(1,:), 'b', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
errorbar(CorrVariation_TimeSeries_Avg(2,:), CorrVariation_TimeSeries_StE(2,:), 'r', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
errorbar(CorrVariation_TimeSeries_Avg(4,:), CorrVariation_TimeSeries_StE(4,:), 'g', 'LineWidth', PlotLineWidth, 'CapSize', ErrorHeadSize);
box on; grid on;
xlabel('Session');
ylabel('Average Correlation variation over time');
title('Average Correlation VARIATION between each cell trace');
legend({'Awake', 'NREM', 'REM'})


%% Plot the Events Rate time evolution per Session
figure;
PlotLineWidth = 1;
n_mice = numel(Mouse_Names);
for i_mouse = 1:n_mice
    subplot(n_mice, 1, i_mouse)
    EventsRate_TimeArray = EventsRate_TimeArray_perMouse{i_mouse};
    [dim1,n_cells,n_sessions] = size(EventsRate_TimeArray);
    hold on;
    for i_cell = 1:n_cells
        EventsRate_TimeArray_CurrentCell = EventsRate_TimeArray(:, i_cell, :);
        plot(EventsRate_TimeArray_CurrentCell(1,:), 'b', 'LineWidth', PlotLineWidth);
        plot(EventsRate_TimeArray_CurrentCell(2,:), 'r', 'LineWidth', PlotLineWidth);
        plot(EventsRate_TimeArray_CurrentCell(4,:), 'g', 'LineWidth', PlotLineWidth);
    end
    box on; grid on;
    xlabel('Session');
    ylabel('Event Rate [Hz]');
    title_str = sprintf('Event Rate Change over time\n%s', Mouse_Names{i_mouse});
    title(title_str);
    legend({'Awake', 'NREM', 'REM'})
    
end



%% Plot the Events Rate time evolution per Session - Normalized
figure;
PlotLineWidth = 1;
n_mice = numel(Mouse_Names);
for i_mouse = 1:n_mice
    subplot(n_mice, 1, i_mouse)
    EventsRateNormalized_TimeArray = EventsRateNormalized_TimeArray_perMouse{i_mouse};
    [dim1,n_cells,n_sessions] = size(EventsRateNormalized_TimeArray);
    hold on;
    for i_cell = 1:n_cells
        EventsRate_TimeArray_CurrentCell = EventsRateNormalized_TimeArray(:, i_cell, :);
        plot(EventsRate_TimeArray_CurrentCell(1,:), 'b', 'LineWidth', PlotLineWidth);
        plot(EventsRate_TimeArray_CurrentCell(2,:), 'r', 'LineWidth', PlotLineWidth);
        plot(EventsRate_TimeArray_CurrentCell(4,:), 'g', 'LineWidth', PlotLineWidth);
    end
    box on; grid on;
    xlabel('Session');
    ylabel('Event Rate [Hz], normalized by state average');
    title_str = sprintf('Event Rate (Normalized) Change over time\n%s', Mouse_Names{i_mouse});
    title(title_str);
    legend({'Awake', 'NREM', 'REM'})
    
end



%% Plot the Events Rate variation evolution per Session - Normalized
figure;
PlotLineWidth = 1;
n_mice = numel(Mouse_Names);
for i_mouse = 1:n_mice
    subplot(n_mice, 1, i_mouse)
    EventsRateVariation_Normalized_Mean_TimeArray = EventsRateVariation_Mean_TimeArray_perMouse{i_mouse};
    [dim1,n_cells,n_sessions] = size(EventsRateNormalized_TimeArray);
    hold on;
    plot(EventsRateVariation_Normalized_Mean_TimeArray(1,:), 'b', 'LineWidth', PlotLineWidth);
    plot(EventsRateVariation_Normalized_Mean_TimeArray(2,:), 'r', 'LineWidth', PlotLineWidth);
    plot(EventsRateVariation_Normalized_Mean_TimeArray(4,:), 'g', 'LineWidth', PlotLineWidth);

    box on; grid on;
    xlabel('Session');
    ylabel('Event Rate Variation average, normalized by state average');
    title_str = sprintf('Event Rate (Normalized) Variation\nAverage over cells\n Change over time\n%s', Mouse_Names{i_mouse});
    title(title_str);
    legend({'Awake', 'NREM', 'REM'})
    
end


%% Average Correlation of a Cell with every other

% fprintf('\nFinished Analisis: Total Elapsed Time = %ds\n\n', nansum(elapsed_time));
% i_session_tot = i_session_tot - 1;
% 
% Connectivity_Index_OverTime_perMouse = cmp_ConnectivityIndex_sessionsArray (MeanOfStates_PerSession);
% 
% Connectivity_Index_OverTime_Mouse_Average = mean(Connectivity_Index_OverTime_perMouse, 3, "omitnan"); % Average over the 3rd dimension, which is the number of mice
% Connectivity_Index_OverTime_Mouse_StE = std(Connectivity_Index_OverTime_perMouse, 0, 3, "omitnan")./sqrt(n_mice); % Average over the 3rd dimension, which is the number of mice
% % Remove columns of NaNs
% tmp = sum(isnan(Connectivity_Index_OverTime_Mouse_Average), 1);
% Connectivity_Index_OverTime_Mouse_Average(:, tmp>=4) = [];
% Connectivity_Index_OverTime_Mouse_StE(:, tmp>=4) = [];
% 
% % Make an array that associates each session with its corresponding mice
% % number.
% MouseNumber_Array = NaN(n_sessions, 1);
% for i_session = 1:n_sessions
%     MeanOfStates_CurrentSession = MeanOfStates_PerSession{i_session};
%     try
%         MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(1).MouseNumber;
%     catch
%         MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(2).MouseNumber;
%     end
% end