function [Selectivity, State_Selectivity_Variation, Average_Activity_Variation, Activity_Normalized, Cell_Stable] = cmp_StateSelectivityVariation_perCell (Events_Freq_Matrix_perMouse, n_cells, Opts)
% This function computes the variation in the events frequency state
% selectivity per cell, and per session. State selectivity is intented as
% how much a cell is preferentially active in a state instead than another.
% Each cell is defined for each recording session by its normalized mean
% Events Rate, per State, normalized by the maximum across all sessions for
% that same cell.
% Each cell is then assigned a point on an imaginary 3D axis of Wake 
% (1,0,0), NREM (0,1,0), and REM (0,0,1).
% The Selectivity for a State is defined as the Euclidean Distance between
% one cell activity point in the 3D states axis, and each of the states.
% A Selectivity close to 0 means that the cell is closer to that specific
% axis, therefore more selective to that state! 
% A Selectivity close to 1 means that the cells is 'neutral' to that state,
% while a Selectivity between 1 and 2 means that the cell is
% 'anti-selective' for that state, firing mostly during states different to
% that one.
% A general Absolute Selectivity is also computed as the minimum
% selectivity between each state, as a measure of how much a cell is
% selective in general.

% Cell_Stable is an array that classifies each cell according to their
% state-stability. If they activity does not often changes over time during
% that state, the cell is classified as stable for that state. Further, if
% a cell is classified as mostly stable, for every state, it is classified
% as stable overall.

n_states = 3;
n_sessions = numel(Events_Freq_Matrix_perMouse);

% This number determines the cells that will not be assigned a Stability
% Tag in the Cell_Stable array, because they have too many NaN values in
% the State_Selectivity_Matrix.
max_nan_session = n_sessions/2; % Default: At least 1/2 of the sessions should be valid.

% Minimum number of times a cell should remain stable to be defined stable.
min_stability = n_sessions/(n_states*2);

variation_thr_multiplier = 1.5; % Default 1. This value multiplies the standard deviation of a cell activity. The higher this value is, the less stringient the criteria is to determine a cell as stable.
    
% Get max frequency per state and normalize all cells.
all_cells_per_session = cell(n_sessions, 1);
all_cells_sessions_matrix = NaN(n_sessions, n_cells, n_states);
for i_session = 1:n_sessions
    current_session = Events_Freq_Matrix_perMouse{i_session};
    n_mice = numel(current_session);
    all_cells = [];
    for i_mouse = 1:n_mice
        current_mouse = current_session{i_mouse};
        all_cells = [all_cells; current_mouse];
    end
    all_cells_per_session{i_session} = all_cells;
    all_cells_sessions_matrix(i_session, :, :) = all_cells;
    clear all_cells
end

% Max frequency for each cell over every session, per state
Max_Freq_perCell_perState = nanmax(all_cells_sessions_matrix, [], 1);
Max_Freq_perCell_perState = squeeze(Max_Freq_perCell_perState);
Max_Freq_perCell = nanmax(Max_Freq_perCell_perState, [], 2);

Selectivity = struct;
State_Selectivity_Matrix_allSessions = NaN(n_cells, n_states, n_sessions);
all_cells_per_session_normalized_per_cell = cell(n_sessions, 1);
all_cells_sessions_matrix_normalized = NaN(n_sessions, n_cells, n_states);
for i_session = 1:n_sessions
    all_cells = all_cells_per_session{i_session};
    all_cells_normalized_per_cell = all_cells./Max_Freq_perCell;
    
    % Distance from 'State Selective Point' (e.g. [1,0,0])
    Selectivity(i_session).Wake = pdist2(all_cells_normalized_per_cell, [1,0,0], 'euclidean');
    Selectivity(i_session).NREM = pdist2(all_cells_normalized_per_cell, [0,1,0], 'euclidean');
    Selectivity(i_session).REM = pdist2(all_cells_normalized_per_cell, [0,0,1], 'euclidean');
    State_Selectivity_Matrix = [Selectivity(i_session).Wake, Selectivity(i_session).NREM, Selectivity(i_session).REM];
    Selectivity(i_session).State_Selectivity_Matrix = State_Selectivity_Matrix;
    Selectivity(i_session).Absolute = min(Selectivity(i_session).State_Selectivity_Matrix, [], 2, 'omitnan');
    all_cells_sessions_matrix_normalized(i_session, :, :) = all_cells_normalized_per_cell;
    
    State_Selectivity_Matrix_allSessions(:, :, i_session) = State_Selectivity_Matrix;
    all_cells_per_session_normalized_per_cell{i_session} = all_cells_normalized_per_cell;
    clear all_cells
end
Activity_Normalized = all_cells_per_session_normalized_per_cell';

% Compute the average activity variation between consecutive sessions
Average_Activity_Variation_Matrix = diff(all_cells_sessions_matrix_normalized, 1, 1);
Average_Activity_Variation_Abs = abs(Average_Activity_Variation_Matrix);
Average_Activity_Variation_AbsMean = mean(Average_Activity_Variation_Abs, 2, 'omitnan');
Average_Activity_Variation_AbsMean = squeeze(Average_Activity_Variation_AbsMean);
Average_Activity_Variation_AbsStD = std(Average_Activity_Variation_Abs, 0, 2, 'omitnan');
Average_Activity_Variation_AbsStD = squeeze(Average_Activity_Variation_AbsStD);
Average_Activity_Variation_AbsStE = Average_Activity_Variation_AbsStD./sqrt(n_cells);

Average_Activity_Variation.Mean = Average_Activity_Variation_AbsMean;
Average_Activity_Variation.StE = Average_Activity_Variation_AbsStE;
Average_Activity_Variation.Average_Activity_Matrix = Average_Activity_Variation_Matrix;

% Compute the average stability variation between consecutive sessions
State_Selectivity_Matrix_Variation = diff(State_Selectivity_Matrix_allSessions, 1, 3);
State_Selectivity_Matrix_Variation_Abs = abs(State_Selectivity_Matrix_Variation);
State_Selectivity_Matrix_Variation_AbsMean = mean(State_Selectivity_Matrix_Variation_Abs, 1, 'omitnan');
State_Selectivity_Matrix_Variation_AbsMean = squeeze(State_Selectivity_Matrix_Variation_AbsMean);
State_Selectivity_Matrix_Variation_AbsStD = std(State_Selectivity_Matrix_Variation_Abs, 0, 1, 'omitnan');
State_Selectivity_Matrix_Variation_AbsStD = squeeze(State_Selectivity_Matrix_Variation_AbsStD);
State_Selectivity_Matrix_Variation_AbsStE = State_Selectivity_Matrix_Variation_AbsStD./sqrt(n_cells);

State_Selectivity_Variation.Mean = State_Selectivity_Matrix_Variation_AbsMean';
State_Selectivity_Variation.StE = State_Selectivity_Matrix_Variation_AbsStE';
State_Selectivity_Variation.State_Selectivity_Matrix_Variation = State_Selectivity_Matrix_Variation;



%% Separate stable cells
% Classify a cell as state-stable if it rarely sensibly changed its activity
% during a specific state

% Squeeze into array
tmp = State_Selectivity_Variation.State_Selectivity_Matrix_Variation;
cell_variations.Awake = squeeze(tmp(:, 1, :));
cell_variations.NREM = squeeze(tmp(:, 2, :));
cell_variations.REM = squeeze(tmp(:, 3, :));
[dim1, dim2] = size (cell_variations.Awake);

cell_variations_array.Awake = reshape(cell_variations.Awake,[1, dim1*dim2]);
cell_variations_array.NREM = reshape(cell_variations.NREM,[1, dim1*dim2]);
cell_variations_array.REM = reshape(cell_variations.REM,[1, dim1*dim2]);

% Get the threshold to use to classify stable cells
cell_variations_distribution_Mean.Awake = mean(cell_variations_array.Awake, 2, 'omitnan');
cell_variations_distribution_Mean.NREM = mean(cell_variations_array.NREM, 2, 'omitnan');
cell_variations_distribution_Mean.REM = mean(cell_variations_array.REM, 2, 'omitnan');
cell_variations_distribution_Std.Awake = std(cell_variations_array.Awake, 0, 2, 'omitnan');
cell_variations_distribution_Std.NREM = std(cell_variations_array.NREM, 0, 2, 'omitnan');
cell_variations_distribution_Std.REM = std(cell_variations_array.REM, 0, 2, 'omitnan');

variation_threshold.Awake = cell_variations_distribution_Std.Awake.*variation_thr_multiplier;
variation_threshold.NREM = cell_variations_distribution_Std.NREM.*variation_thr_multiplier;
variation_threshold.REM = cell_variations_distribution_Std.REM.*variation_thr_multiplier;

State_Selectivity_Matrix_Variation_Binary_Awake = zeros(dim1, dim2);
State_Selectivity_Matrix_Variation_Binary_NREM = zeros(dim1, dim2);
State_Selectivity_Matrix_Variation_Binary_REM = zeros(dim1, dim2);
tmp = squeeze(State_Selectivity_Matrix_Variation(:, 1, :));

% Awake
% keyboard
State_Selectivity_Matrix_Variation_Binary_Awake(tmp > variation_threshold.Awake) = 1;
State_Selectivity_Matrix_Variation_Binary_Awake(tmp < - variation_threshold.Awake) = 1;
State_Selectivity_Matrix_Variation_Binary_Awake(isnan(tmp)) = NaN;
% Count how many times a cell changed its activity
State_Selectivity_Matrix_Variation_Binary_Awake_Cum = nansum(State_Selectivity_Matrix_Variation_Binary_Awake, 2);
% Count the number of NaNs
State_Selectivity_Matrix_Variation_Binary_Awake_NaN = sum(double(isnan(State_Selectivity_Matrix_Variation_Binary_Awake)), 2);
% Skip cells that had too many NaNs
State_Selectivity_Matrix_Variation_Binary_Awake_Cum(State_Selectivity_Matrix_Variation_Binary_Awake_NaN >= max_nan_session) = NaN;
% Compute the mean number of times cells changed their activity
State_Selectivity_Matrix_Variation_Binary_Awake_Cum_Mean_Round = round(mean(State_Selectivity_Matrix_Variation_Binary_Awake_Cum, 1, 'omitnan'));
State_Selectivity_Matrix_Variation_Binary_Awake_Cum_Std = std(State_Selectivity_Matrix_Variation_Binary_Awake_Cum, 1, 1, 'omitnan');
% Mark each cell ID for stability
tmp_Cell_Stable = zeros(size(State_Selectivity_Matrix_Variation_Binary_Awake_Cum));
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_Awake_Cum > State_Selectivity_Matrix_Variation_Binary_Awake_Cum_Mean_Round + 1) = -1;
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_Awake_Cum < State_Selectivity_Matrix_Variation_Binary_Awake_Cum_Mean_Round - 1) = 1;
% Skip cells that had too many NaNs
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_Awake_NaN >= max_nan_session) = NaN;
Cell_Stable.Awake = tmp_Cell_Stable;

% NREM

State_Selectivity_Matrix_Variation_Binary_NREM(tmp > variation_threshold.NREM) = 1;
State_Selectivity_Matrix_Variation_Binary_NREM(tmp < - variation_threshold.NREM) = 1;
State_Selectivity_Matrix_Variation_Binary_NREM(isnan(tmp)) = NaN;
% Count how many times a cell changed its activity
State_Selectivity_Matrix_Variation_Binary_NREM_Cum = nansum(State_Selectivity_Matrix_Variation_Binary_NREM, 2);
% Count the number of NaNs
State_Selectivity_Matrix_Variation_Binary_NREM_NaN = sum(double(isnan(State_Selectivity_Matrix_Variation_Binary_NREM)), 2);
% Skip cells that had too many NaNs
State_Selectivity_Matrix_Variation_Binary_NREM_Cum(State_Selectivity_Matrix_Variation_Binary_NREM_NaN >= max_nan_session) = NaN;
% Compute the mean number of times cells changed their activity
State_Selectivity_Matrix_Variation_Binary_NREM_Cum_Mean_Round = round(mean(State_Selectivity_Matrix_Variation_Binary_NREM_Cum, 1, 'omitnan'));
State_Selectivity_Matrix_Variation_Binary_NREM_Cum_Std = std(State_Selectivity_Matrix_Variation_Binary_NREM_Cum, 1, 1, 'omitnan');
% Mark each cell ID for stability
tmp_Cell_Stable = zeros(size(State_Selectivity_Matrix_Variation_Binary_NREM_Cum));
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_NREM_Cum > State_Selectivity_Matrix_Variation_Binary_NREM_Cum_Mean_Round + 1) = -1;
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_NREM_Cum < State_Selectivity_Matrix_Variation_Binary_NREM_Cum_Mean_Round - 1) = 1;
% Skip cells that had too many NaNs
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_NREM_NaN >= max_nan_session) = NaN;
Cell_Stable.NREM = tmp_Cell_Stable;

% REM

State_Selectivity_Matrix_Variation_Binary_REM(tmp > variation_threshold.REM) = 1;
State_Selectivity_Matrix_Variation_Binary_REM(tmp < - variation_threshold.REM) = 1;
State_Selectivity_Matrix_Variation_Binary_REM(isnan(tmp)) = NaN;
% Count how many times a cell changed its activity
State_Selectivity_Matrix_Variation_Binary_REM_Cum = nansum(State_Selectivity_Matrix_Variation_Binary_REM, 2);
% Count the number of NaNs
State_Selectivity_Matrix_Variation_Binary_REM_NaN = sum(double(isnan(State_Selectivity_Matrix_Variation_Binary_REM)), 2);
% Skip cells that had too many NaNs
State_Selectivity_Matrix_Variation_Binary_REM_Cum(State_Selectivity_Matrix_Variation_Binary_REM_NaN >= max_nan_session) = NaN;
% Compute the mean number of times cells changed their activity
State_Selectivity_Matrix_Variation_Binary_REM_Cum_Mean_Round = round(mean(State_Selectivity_Matrix_Variation_Binary_REM_Cum, 1, 'omitnan'));
State_Selectivity_Matrix_Variation_Binary_REM_Cum_Std = std(State_Selectivity_Matrix_Variation_Binary_REM_Cum, 1, 1, 'omitnan');
% Mark each cell ID for stability
tmp_Cell_Stable = zeros(size(State_Selectivity_Matrix_Variation_Binary_REM_Cum));
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_REM_Cum > State_Selectivity_Matrix_Variation_Binary_REM_Cum_Mean_Round + 1) = -1;
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_REM_Cum < State_Selectivity_Matrix_Variation_Binary_REM_Cum_Mean_Round - 1) = 1;
% Skip cells that had too many NaNs
tmp_Cell_Stable(State_Selectivity_Matrix_Variation_Binary_REM_NaN >= max_nan_session) = NaN;
Cell_Stable.REM = tmp_Cell_Stable;

% Cells stable or unstable overall

tmp = Cell_Stable.Awake + Cell_Stable.NREM + Cell_Stable.REM;
tmp_Cell_Stable = zeros(size(Cell_Stable.Awake));
tmp_Cell_Stable(tmp >= n_states) = 1;
tmp_Cell_Stable(tmp <= -n_states) = -1;
% Skip cells that had too many NaNs
tmp = State_Selectivity_Matrix_Variation_Binary_Awake_NaN + State_Selectivity_Matrix_Variation_Binary_NREM_NaN + State_Selectivity_Matrix_Variation_Binary_REM_NaN;
tmp_Cell_Stable(tmp >= (n_sessions/4).*n_states) = NaN;

Cell_Stable.AllStates = tmp_Cell_Stable;


