function [Events_Freq_Matrix_perMouse, Events_Freq_Matrix_allMice, Integral_Freq_Matrix_perMouse, Integral_Freq_Matrix_allMice] = Sessions_Analysis_Events_Frequencies (Events, Hypnograms, Integrals, Mouse_Names, Mouse_Cells, Opts)
% This function gets the Events Frequencies of each cell, and the 
% 'Integrals Frequencies' (the total integral of the signal per state, 
% normalized per state length) for a specific group of Sessions.

Events_Freq_Matrix_perMouse = cell(numel(Mouse_Names), 1);
Integral_Freq_Matrix_perMouse = cell(numel(Mouse_Names), 1);
Events_Freq_Matrix_allMice = [];
Integral_Freq_Matrix_allMice = [];

for i_mouse = 1:numel(Mouse_Names)
    Current_Mouse = Mouse_Names{i_mouse};
    tmp = [Mouse_Cells.MouseID];
    Current_N_Cells = Mouse_Cells(tmp == i_mouse);
    [Events_Current_Mouse] = separate_events_per_mouse (Events, Current_Mouse);
    tmp = Hypnograms;
    tmp_int = Integrals;
    hypno_to_remove = [];
    for i_Hypnogram = 1:numel(tmp)
        if ~strcmpi(tmp(i_Hypnogram).MouseName, Current_Mouse)
            hypno_to_remove = [hypno_to_remove, i_Hypnogram];
        end
    end
    tmp(hypno_to_remove) = [];
    tmp_int(hypno_to_remove) = [];
    
    % Get total duration of states for this mouse.
    tmp_HypnoAll = [tmp.Hypnogram];
    tmp_StateDuration = [tmp.StateDuration_Array];
    tmp_HypnoAll(tmp_StateDuration < Opts.General.MinStableStateDuration) = [];
    TotalDuration.Awake = numel(tmp_HypnoAll(tmp_HypnoAll == 1))./Opts.General.FrameRate;
    TotalDuration.NREM = numel(tmp_HypnoAll(tmp_HypnoAll == 2))./Opts.General.FrameRate;
    TotalDuration.REM = numel(tmp_HypnoAll(tmp_HypnoAll == 4))./Opts.General.FrameRate;
    
    % Get the Events Matrix for the current Mouse
    Events_Freq_Matrix_perMouse{i_mouse} = events_freq_per_cell(Events_Current_Mouse, TotalDuration, Current_N_Cells);
    Events_Freq_Matrix_allMice = [Events_Freq_Matrix_allMice; Events_Freq_Matrix_perMouse{i_mouse}];
    
    % Integrals
    
    tmp_int_freq_Awake = [tmp_int.Integral_perCell_Frequency_Awake];
    tmp_int_freq_NREM = [tmp_int.Integral_perCell_Frequency_NREM];
    tmp_int_freq_REM = [tmp_int.Integral_perCell_Frequency_REM];
    
    [n_recs.Awake, ~] = size(tmp_int_freq_Awake);
    [n_recs.NREM, ~] = size(tmp_int_freq_NREM);
    [n_recs.REM, ~] = size(tmp_int_freq_REM);
    n_cells = Current_N_Cells(1).n_cells;
    
    if n_recs.Awake ~= 0
        tmp_int_freq.Awake.Avg = mean(tmp_int_freq_Awake, 1, 'omitnan');
        tmp_int_freq.Awake.StE = std(tmp_int_freq_Awake, 0, 1, 'omitnan')./sqrt(n_recs.Awake);
    else
        tmp_int_freq.Awake.Avg = NaN(1, n_cells);
        tmp_int_freq.Awake.StE = NaN(1, n_cells);        
    end
    if n_recs.NREM ~= 0
        tmp_int_freq.NREM.Avg = mean(tmp_int_freq_NREM, 1, 'omitnan');
        tmp_int_freq.NREM.StE = std(tmp_int_freq_NREM, 0, 1, 'omitnan')./sqrt(n_recs.NREM);
    else
        tmp_int_freq.NREM.Avg = NaN(1, n_cells);
        tmp_int_freq.NREM.StE = NaN(1, n_cells);
    end
    if n_recs.REM ~= 0
        tmp_int_freq.REM.Avg = mean(tmp_int_freq_REM, 1, 'omitnan');
        tmp_int_freq.REM.StE = std(tmp_int_freq_REM, 0, 1, 'omitnan')./sqrt(n_recs.REM);
    else
        tmp_int_freq.REM.Avg = NaN(1, n_cells);
        tmp_int_freq.REM.StE = NaN(1, n_cells);
    end
    
    Integral_Freq_Matrix_CurrentMouse = ([tmp_int_freq.Awake.Avg; tmp_int_freq.NREM.Avg; tmp_int_freq.REM.Avg])';
    Integral_Freq_Matrix_perMouse{i_mouse} = Integral_Freq_Matrix_CurrentMouse;
    Integral_Freq_Matrix_allMice = [Integral_Freq_Matrix_allMice; Integral_Freq_Matrix_CurrentMouse];

end


