function [EventsFrequency_Sessions_Mean, EventsFrequency_Sessions_StE, Events_Frequency_perSession_Stats] = get_EventsFrequency_Avg_perMouse_perSession (Events_Freq_Matrix_perMouse)
% Get the average events frequency (over mice) per state, per session.

n_sessions = numel(Events_Freq_Matrix_perMouse);
n_mice = numel(Events_Freq_Matrix_perMouse{1});
n_states = 3;


%% Frequency Matrix for plotting
EventsFrequency_Sessions_Mean = NaN(n_sessions, n_states);
EventsFrequency_Sessions_StE = NaN(n_sessions, n_states);
EventsFrequency_Matrix4Anova_Awake = NaN(n_mice, n_sessions);
EventsFrequency_Matrix4Anova_NREM = NaN(n_mice, n_sessions);
EventsFrequency_Matrix4Anova_REM = NaN(n_mice, n_sessions);
SessionNames = cell(1, n_sessions);
for i_session = 1:n_sessions
    current_session = Events_Freq_Matrix_perMouse{i_session};
    mouse_mean = NaN(n_mice, n_states);
    for i_mouse = 1:n_mice
        tmp = current_session{i_mouse};
        mouse_mean(i_mouse, :) = nanmean(tmp, 1);
    end
    EventsFrequency_Sessions_Mean(i_session, :) = nanmean(mouse_mean, 1);
    EventsFrequency_Sessions_StE(i_session, :) = nanstd(mouse_mean, 1)./sqrt(n_mice);
    
    EventsFrequency_Matrix4Anova_Awake(:, i_session) = mouse_mean(:, 1);
    EventsFrequency_Matrix4Anova_NREM(:, i_session) = mouse_mean(:, 2);
    EventsFrequency_Matrix4Anova_REM(:, i_session) = mouse_mean(:, 3);
    
    SessionNames{i_session} = sprintf('Session %d', i_session);
end


%% Statistics
Baseline_Morning_Awake = [EventsFrequency_Matrix4Anova_Awake(:, 1); EventsFrequency_Matrix4Anova_Awake(:, 4); EventsFrequency_Matrix4Anova_Awake(:, 7)];
Baseline_3pm_Awake = [EventsFrequency_Matrix4Anova_Awake(:, 2); EventsFrequency_Matrix4Anova_Awake(:, 5); EventsFrequency_Matrix4Anova_Awake(:, 8)];
Baseline_5pm_Awake = [EventsFrequency_Matrix4Anova_Awake(:, 3); EventsFrequency_Matrix4Anova_Awake(:, 6); EventsFrequency_Matrix4Anova_Awake(:, 9)];
Baseline_Morning_NREM = [EventsFrequency_Matrix4Anova_NREM(:, 1); EventsFrequency_Matrix4Anova_NREM(:, 4); EventsFrequency_Matrix4Anova_NREM(:, 7)];
Baseline_3pm_NREM = [EventsFrequency_Matrix4Anova_NREM(:, 2); EventsFrequency_Matrix4Anova_NREM(:, 5); EventsFrequency_Matrix4Anova_NREM(:, 8)];
Baseline_5pm_NREM = [EventsFrequency_Matrix4Anova_NREM(:, 3); EventsFrequency_Matrix4Anova_NREM(:, 6); EventsFrequency_Matrix4Anova_NREM(:, 9)];
Baseline_Morning_REM = [EventsFrequency_Matrix4Anova_NREM(:, 1); EventsFrequency_Matrix4Anova_NREM(:, 4); EventsFrequency_Matrix4Anova_NREM(:, 7)];
Baseline_3pm_REM = [EventsFrequency_Matrix4Anova_NREM(:, 2); EventsFrequency_Matrix4Anova_NREM(:, 5); EventsFrequency_Matrix4Anova_NREM(:, 8)];
Baseline_5pm_REM = [EventsFrequency_Matrix4Anova_NREM(:, 3); EventsFrequency_Matrix4Anova_NREM(:, 6); EventsFrequency_Matrix4Anova_NREM(:, 9)];

[p,~,stats] = ranksum(Baseline_Morning_Awake, EventsFrequency_Matrix4Anova_Awake(:, 10));
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_morning.p = p;
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_morning.stats = stats;
[p,~,stats] = ranksum(Baseline_3pm_Awake, EventsFrequency_Matrix4Anova_Awake(:, 11));
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_3pm.p = p;
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_3pm.stats = stats;
[p,~,stats] = ranksum(Baseline_5pm_Awake, EventsFrequency_Matrix4Anova_Awake(:, 12));
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_5pm.p = p;
Events_Frequency_perSession_Stats.Wake.ranksum.SD_vs_Baseline_5pm.stats = stats;

[p,~,stats] = ranksum(Baseline_Morning_NREM, EventsFrequency_Matrix4Anova_NREM(:, 10));
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_morning.p = p;
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_morning.stats = stats;
[p,~,stats] = ranksum(Baseline_3pm_NREM, EventsFrequency_Matrix4Anova_NREM(:, 11));
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_3pm.p = p;
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_3pm.stats = stats;
[p,~,stats] = ranksum(Baseline_5pm_NREM, EventsFrequency_Matrix4Anova_NREM(:, 12));
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_5pm.p = p;
Events_Frequency_perSession_Stats.NREM.ranksum.SD_vs_Baseline_5pm.stats = stats;

[p,~,stats] = ranksum(Baseline_Morning_REM, EventsFrequency_Matrix4Anova_REM(:, 10));
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_morning.p = p;
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_morning.stats = stats;
[p,~,stats] = ranksum(Baseline_3pm_REM, EventsFrequency_Matrix4Anova_REM(:, 11));
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_3pm.p = p;
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_3pm.stats = stats;
[p,~,stats] = ranksum(Baseline_5pm_REM, EventsFrequency_Matrix4Anova_REM(:, 12));
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_5pm.p = p;
Events_Frequency_perSession_Stats.REM.ranksum.SD_vs_Baseline_5pm.stats = stats;

[p,tbl,stats] = anova1(EventsFrequency_Matrix4Anova_Awake, SessionNames);
Events_Frequency_perSession_Stats.Wake.anova.p_value = p;
Events_Frequency_perSession_Stats.Wake.anova.tbl = tbl;
Events_Frequency_perSession_Stats.Wake.anova.statistics = stats;
[c,m,~,gnames] = multcompare(stats);
Events_Frequency_perSession_Stats.Wake.anova.multicomp.comparisons = c;
Events_Frequency_perSession_Stats.Wake.anova.multicomp.means_and_ste = m;
Events_Frequency_perSession_Stats.Wake.anova.multicomp.groups = gnames;
[p,tbl,stats] = anova1(EventsFrequency_Matrix4Anova_NREM, SessionNames);
Events_Frequency_perSession_Stats.NREM.anova.p_value = p;
Events_Frequency_perSession_Stats.NREM.anova.tbl = tbl;
Events_Frequency_perSession_Stats.NREM.anova.statistics = stats;
[c,m,~,gnames] = multcompare(stats);
Events_Frequency_perSession_Stats.NREM.anova.multicomp.comparisons = c;
Events_Frequency_perSession_Stats.NREM.anova.multicomp.means_and_ste = m;
Events_Frequency_perSession_Stats.NREM.anova.multicomp.groups = gnames;
[p,tbl,stats] = anova1(EventsFrequency_Matrix4Anova_REM, SessionNames);
Events_Frequency_perSession_Stats.REM.anova.p_value = p;
Events_Frequency_perSession_Stats.REM.anova.tbl = tbl;
Events_Frequency_perSession_Stats.REM.anova.statistics = stats;
[c,m,~,gnames] = multcompare(stats);
Events_Frequency_perSession_Stats.REM.anova.multicomp.comparisons = c;
Events_Frequency_perSession_Stats.REM.anova.multicomp.means_and_ste = m;
Events_Frequency_perSession_Stats.REM.anova.multicomp.groups = gnames;