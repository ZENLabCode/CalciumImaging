
% To start this script you need the following variables loaded:
% Events_AllSessions
% CalciumTraces_Clean_AllSessions
% Hypnogram_AllSessions
% HypnoState
% Mouse_Names
% MouseCellsRecorded
% Opts

% These variables are generated and saved automatically in a separate file
% by the Analyze_all_mouse function or by the use of the GUI for the events
% based analysis.

% If you select "Integrals_Frequency" as clustering variable, most analysis
% should function even without the "Events_AllSessions" varibale, but
% others will still be required.

%% Options
% Please specify the cell type.
CellType = 'MCH';
Opts.CellType = CellType;
if ~isfield(Opts.General, 'FolderNameDelimiter')
    Opts.General.FolderNameDelimiter = '\';
end

% Clustering Variables
Opts.ClusteringVariable = 'Events_Rate'; % 'Events_Rate', 'Integrals_Frequency'. 'N_Events', or 'Integral_Sum' are experimental, WIP options, they might not work.
Opts.ClusteringMethod = 2; % 1 = Simple max. 2 = Inactive cells & Max. 3 = Threshold on median Ca2+ Firing Rate (clustering with more groups)

% Distance between Matrices (don't change if you don't know what this is)
Opts.Matrix_Distance_Type = 'Cosine';

% Flags
FLAG_Normalize_byNoiseLevel = 1; % Normalize each trace (cell) separately by its noise level?
FLAG_group_based_on_time_of_the_day = 0; % Group data together based on the time of the day? Default = 0
FLAG_PlotClustering_Single = 0; % Plot every single clustering in a pie chart
Opts.FLAG_Memory_Saving = 1; % clear a few variables during the execution to save some RAM

% Figures Folder
CellType_Folder = set_figuresFolder (Opts);
Opts.Dir_Figures = CellType_Folder;

% Save Figures Automatically?
Opts.SaveFiguresAutomatically = 0; % Change between 1 and 0, self explanatory.

% ====================================================================== %

%% Initialization

% Get n_cells
Mouse_Cells = cmp_number_of_cells (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names);
tmp_control = Opts.Mouse_Sessions;
% Get n_mice, n_sessions, n_cells
n_mice = numel(Mouse_Names);
n_sessions = Opts.n_sessions/n_mice;
n_cells = sum(MouseCellsRecorded);
if floor(n_sessions) == n_sessions && all(tmp_control == tmp_control(1))
    warning_sessions_txt = sprintf(repmat('%d ', 1, length([Opts.Mouse_Sessions])), [Opts.Mouse_Sessions]);
    warning_txt = sprintf('The number of sessions seems to be different for some mice (%s)\n Make sure the number of sessions is the same, or address the problem manually.\n For now, the number of sessions was set as the minimum between all mice.', warning_sessions_txt);
    warning(warning_txt)
    warning_txt = sprintf('Some analysis might fail with different number of sessions per mice, in particular the Network-based one.\n\n', warning_sessions_txt);
    warning(warning_txt)
    n_sessions = min(Opts.Mouse_Sessions);
end
clear tmp_control
Cell_MouseID = [];
for i_mouse = 1:n_mice
    Cell_MouseID = [Cell_MouseID; ones(MouseCellsRecorded(i_mouse), 1).*i_mouse];
end

% Session Analysis 
Events_perSession = separate_all_sessions (Events_AllSessions, HypnoState);

% Fix possible errors in Hypnogram 3s
tmp_backupHypno = Hypnogram_AllSessions;
for i_session = 1:numel(Hypnogram_AllSessions)
    tmp = Hypnogram_AllSessions(i_session).Hypnogram;
    tmp(tmp == 3)= 4;
    Hypnogram_AllSessions(i_session).Hypnogram = tmp;
    tmp = Hypnogram_AllSessions(i_session).StateType;
    tmp2 = Hypnogram_AllSessions(i_session).StateChanges;
    tmp3 = Hypnogram_AllSessions(i_session).StateDuration;
    tmp4 = tmp;
    tmp(tmp4 == 3)= [];
    tmp2(tmp4 == 3)= [];
    tmp3(tmp4 == 3)= [];
    Hypnogram_AllSessions(i_session).StateType = tmp;
    Hypnogram_AllSessions(i_session).StateChanges = tmp2;
    Hypnogram_AllSessions(i_session).StateDuration = tmp3;
    if any((Hypnogram_AllSessions(i_session).Hypnogram) == 3)
       warning ('3s were found') 
       plot(tmp)
       numel(find(tmp == 3))
       keyboard
    end
end
clear tmp_backupHypno
% Check that the StateIsStable field exists
if ~isfield(Hypnogram_AllSessions, 'StateIsStable')
    for i_session = 1:numel(Hypnogram_AllSessions)
        current_hypnoStateDuration_Array = Hypnogram_AllSessions(i_session).StateDuration_Array;
        current_hypnoStateChanges = Hypnogram_AllSessions(i_session).StateChanges;
        StateIsStable = current_hypnoStateDuration_Array(current_hypnoStateChanges);
        StateIsStable(StateIsStable < Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 0;
        StateIsStable(StateIsStable >= Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 1;
        Hypnogram_AllSessions(i_session).StateIsStable = StateIsStable;
    end
    clear StateIsStable; clear current_hypnoStateDuration_Array; clear current_hypnoStateChanges
end

% Normalize each trace by its noise level? (Note: 05-Dec-2023: the
% correlation analysis takes as input the CalciumTraces_Clean_AllSessions
% directly, regardless of the choice)
if FLAG_Normalize_byNoiseLevel == 1
    CalciumTraces_Normalized_AllSessions = normalize_byNoiseLevels (CalciumTraces_Clean_AllSessions, Opts);
    CalciumTraces_AllSessions = CalciumTraces_Normalized_AllSessions;
    clear CalciumTraces_Normalized_AllSessions
else
    CalciumTraces_AllSessions = CalciumTraces_Clean_AllSessions;
end

% Compute the integral of each trace over states and sessions
Integral_AllSessions = cmp_integral_per_state_per_cell (CalciumTraces_AllSessions, Hypnogram_AllSessions, Opts);


%% Events Grouping
if FLAG_group_based_on_time_of_the_day == 1
    % Grouping based on time of the day and baseline/SD/rec
    DUMMY = 1;
    while DUMMY == 1
        % Baseline
        % Baseline Morning
        Group = [1, 4, 7];
        [Events_Grouped_Baseline_10am, Hypnogram_Group_Baseline_10am] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % Baseline 3pm
        Group = [2, 5, 8];
        [Events_Grouped_Baseline_3pm, Hypnogram_Group_Baseline_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % Baseline 5pm
        Group = [3, 6, 9];
        [Events_Grouped_Baseline_5pm, Hypnogram_Group_Baseline_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % SD
        % SD 12pm
        Group = 10;
        [Events_Grouped_SD_12pm, Hypnogram_Group_SD_12pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % SD 12pm
        Group = 11;
        [Events_Grouped_SD_3pm, Hypnogram_Group_SD_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % SD 5pm
        Group = 12;
        [Events_Grouped_SD_5pm, Hypnogram_Group_SD_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        
        % Recovery
        % Recovery Morning
        Group = [13, 16, 19];
        [Events_Grouped_Recovery_10am, Hypnogram_Group_Recovery_10am] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % Recovery 3pm
        Group = [14, 17, 20];
        [Events_Grouped_Recovery_3pm, Hypnogram_Group_Recovery_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        
        % Recovery 5pm
        Group = [15, 18, 21];
        [Events_Grouped_Recovery_5pm, Hypnogram_Group_Recovery_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
        DUMMY = 0;
    end
    
    % Get the events frequency for each session for each mouse.
    DUMMY = 1;
    while DUMMY == 1
        % Baseline
        [Events_Freq_Matrix_perMouse_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_10am] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_10am, Hypnogram_Group_Baseline_10am, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_3pm, Hypnogram_Group_Baseline_3pm, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_Baseline_5pm, Events_Freq_Matrix_allMice_Baseline_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_5pm, Hypnogram_Group_Baseline_5pm, Mouse_Names, Mouse_Cells, Opts);
        
        % SD
        [Events_Freq_Matrix_perMouse_SD_12pm, Events_Freq_Matrix_allMice_SD_12pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_12pm, Hypnogram_Group_SD_12pm, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_SD_3pm, Events_Freq_Matrix_allMice_SD_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_3pm, Hypnogram_Group_SD_3pm, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_SD_5pm, Events_Freq_Matrix_allMice_SD_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_5pm, Hypnogram_Group_SD_5pm, Mouse_Names, Mouse_Cells, Opts);
        
        % Recovery
        [Events_Freq_Matrix_perMouse_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_10am] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_10am, Hypnogram_Group_Recovery_10am, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_3pm, Hypnogram_Group_Recovery_3pm, Mouse_Names, Mouse_Cells, Opts);
        [Events_Freq_Matrix_perMouse_Recovery_5pm, Events_Freq_Matrix_allMice_Recovery_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_5pm, Hypnogram_Group_Recovery_5pm, Mouse_Names, Mouse_Cells, Opts);
        
        % %% Get the difference between Firing Rate
        % FR_difference_baseline_10am3pm = abs (Events_Freq_Matrix_allMice_Baseline_10am - Events_Freq_Matrix_allMice_Baseline_3pm);
        %
        % FR_difference_baseline_recovery_10am = abs (Events_Freq_Matrix_allMice_Baseline_10am - Events_Freq_Matrix_allMice_Recovery_10am);
        
        DUMMY = 0;
    end
    % Plot Ordered, comparison between days.
    plot_events_frequency_session_comparison (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm);
    
    % Plot Ordered, comparison between states.
    plot_events_frequency_session_comparison_ordered (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm);
    
    % Stability Plots and results
    Cmp_Stability;
    
    % ??? WIP
    EventsFreq_Results = plot_bar_horizontal(Events_Grouped_SD_5pm, Mouse_Names, HypnoState, Hypnogram_Group_SD_5pm, MouseCellsRecorded, Opts.Dir_Figures, Opts);
else
    % Grouping: Each session separated.
    Events_Grouped = cell(n_sessions, 1);
    Hypnogram_Group = cell(n_sessions, 1);
    for i_session = 1:n_sessions
        Group = i_session;
        [Events_Grouped{i_session}, Hypnogram_Group{i_session}, Integrals_Group{i_session}] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Integral_AllSessions, Group);
    end
    Integrals_Group = Integrals_Group';
    
    % Get the events frequency for each session for each mouse.
    % This calculation is not dividing by the number of cells (28-09-2023)
    Events_Freq_Matrix_perMouse = cell(n_sessions, 1);
    Events_Freq_Matrix_allMice = cell(n_sessions, 1);
    Integral_Freq_Matrix_perMouse = cell(n_sessions, 1);
    Integral_Freq_Matrix_allMice = cell(n_sessions, 1);
    for i_session = 1:n_sessions
        [Events_Freq_Matrix_perMouse{i_session}, Events_Freq_Matrix_allMice{i_session}, Integral_Freq_Matrix_perMouse{i_session}, Integral_Freq_Matrix_allMice{i_session}] = Sessions_Analysis_Events_Frequencies (Events_Grouped{i_session}, Hypnogram_Group{i_session}, Integrals_Group{i_session}, Mouse_Names, Mouse_Cells, Opts);
    end
end

% Get the average events frequency (over mice) per state, per session.
[EventsFrequency_Sessions_Mean, EventsFrequency_Sessions_StE, Events_Frequency_perSession_Stats] = get_EventsFrequency_Avg_perMouse_perSession (Events_Freq_Matrix_perMouse);

plot_EventsFreq_Average_TS (EventsFrequency_Sessions_Mean, EventsFrequency_Sessions_StE, Opts);

% Get the average Integrals Frequency (over mice) per state, per session.
[IntegralsFrequency_Sessions_Mean, IntegralsFrequency_Sessions_StE, Integrals_Frequency_perSession_Stats] = get_EventsFrequency_Avg_perMouse_perSession (Integral_Freq_Matrix_perMouse);

plot_IntegralsFreq_Average_TS (IntegralsFrequency_Sessions_Mean, IntegralsFrequency_Sessions_StE, Opts);
if Opts.FLAG_Memory_Saving == 1
    clear Events_perSession
end

%% Clustering

% FileNames List
DUMMY = 0;
while DUMMY == 1
    FileNameList{1} = sprintf('%s - Day 1 - 10am - Cells Clustered per State', CellType);
    FileNameList{2} = sprintf('%s - Day 1 - 3pm - Cells Clustered per State', CellType);
    FileNameList{3} = sprintf('%s - Day 1 - 5pm - Cells Clustered per State', CellType);
    FileNameList{4} = sprintf('%s - Day 2 - 10am - Cells Clustered per State', CellType);
    FileNameList{5} = sprintf('%s - Day 2 - 3pm - Cells Clustered per State', CellType);
    FileNameList{6} = sprintf('%s - Day 2 - 5pm - Cells Clustered per State', CellType);
    FileNameList{7} = sprintf('%s - Day 3 - 10am - Cells Clustered per State', CellType);
    FileNameList{8} = sprintf('%s - Day 3 - 3pm - Cells Clustered per State', CellType);
    FileNameList{9} = sprintf('%s - Day 3 - 5pm - Cells Clustered per State', CellType);
    FileNameList{10} = sprintf('%s - Day 4 (SD) - 12pm - Cells Clustered per State', CellType);
    FileNameList{11} = sprintf('%s - Day 4 (SD) - 3pm - Cells Clustered per State', CellType);
    FileNameList{12} = sprintf('%s - Day 4 (SD) - 5pm - Cells Clustered per State', CellType);
    FileNameList{13} = sprintf('%s - Day 5 - 10am - Cells Clustered per State', CellType);
    FileNameList{14} = sprintf('%s - Day 5 - 3pm - Cells Clustered per State', CellType);
    FileNameList{15} = sprintf('%s - Day 5 - 5pm - Cells Clustered per State', CellType);
    FileNameList{16} = sprintf('%s - Day 6 - 10am - Cells Clustered per State', CellType);
    FileNameList{17} = sprintf('%s - Day 6 - 3pm - Cells Clustered per State', CellType);
    FileNameList{18} = sprintf('%s - Day 6 - 5pm - Cells Clustered per State', CellType);
    FileNameList{19} = sprintf('%s - Day 7 - 10am - Cells Clustered per State', CellType);
    FileNameList{20} = sprintf('%s - Day 7 - 3pm - Cells Clustered per State', CellType);
    FileNameList{21} = sprintf('%s - Day 7 - 5pm - Cells Clustered per State', CellType);
    DUMMY = 0;
end

% Clustering
if strcmpi(Opts.ClusteringVariable, 'Events_Rate') == 1 % Clustering by Events
    CellsPerState_Results = cell(n_sessions, 1);
    CellTag_perMouse = cell(n_sessions, 1);
    CellTagNum_perMouse = cell(n_sessions, 1);
    for i_sessions = 1:n_sessions
        [CellsPerState_Results{i_sessions}, CellTag_perMouse{i_sessions}, CellTagNum_perMouse{i_sessions}] = clustering_cells_activitybased (Events_Grouped{i_sessions}, Mouse_Names, Mouse_Cells, Opts);
%         Opts.tmp_FileName = FileNameList{i_sessions};
%         if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{i_sessions}, Opts); end
    end
elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency') == 1 % Clustering by DFF Integral
    CellsPerState_Results = cell(n_sessions, 1);
    CellTag_perMouse = cell(n_sessions, 1);
    CellTagNum_perMouse = cell(n_sessions, 1);
    for i_sessions = 1:n_sessions
        [CellsPerState_Results{i_sessions}, CellTag_perMouse{i_sessions}, CellTagNum_perMouse{i_sessions}] = cluster_cells_integralbased (Integrals_Group{i_sessions}, Integral_Freq_Matrix_allMice{i_sessions}, Mouse_Names, Mouse_Cells, Opts);
        Opts.tmp_FileName = FileNameList{i_sessions};
        if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{i_sessions}, Opts); end
    end
end


%% Clustering Change
% This analysis might be old and the text in the figures not generated
% automatically, please make sure this is coherent.
% DUMMY = 0;
% while DUMMY == 1
%     if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
%         
%         % Change during a single baseline day.
%         Opts.SubTitle_part = sprintf('\nBaseline Across Day 1');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 1 (10am) - Baseline Day 1 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{1}, CellTag_perMouse{3}, CellTag_perMouse{3}, Opts)
%         % Change across Baseline - 5pm
%         Opts.SubTitle_part = sprintf('\nBaseline Across Days');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 1 (5pm) - Baseline Day 2 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{3}, CellTag_perMouse{6}, CellTag_perMouse{6}, Opts)
%         % Change across SD - 5pm
%         Opts.SubTitle_part = sprintf('\nSD Change');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 3 (5pm) - SD Day 1 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{9}, CellTag_perMouse{12}, CellTag_perMouse{12}, Opts)
%         % Change across Baseline Day 3 (5pm) - Recovery Day 1 (5pm)
%         Opts.SubTitle_part = sprintf('\nSD Change');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nSD Day (5pm) - Recovery Day 1 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{12}, CellTag_perMouse{15}, CellTag_perMouse{15}, Opts)
%         % Change across Baseline Day 3 (5pm) - Recovery Day 1 (5pm)
%         Opts.SubTitle_part = sprintf('\nSD Change');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 3 (5pm) - Recovery Day 1 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{9}, CellTag_perMouse{15}, CellTag_perMouse{15}, Opts)
%         % Change across Recovery - 5pm
%         Opts.SubTitle_part = sprintf('\nRecovery Across Days');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nRecovery Day 1 (5pm) - Recovery Day 2 (5pm)');
%         clustering_change_MaxState (CellTag_perMouse{15}, CellTag_perMouse{18}, CellTag_perMouse{18}, Opts)
%         % Change across Recovery - 5pm (3pm)
%         Opts.SubTitle_part = sprintf('\nRecovery Across Days');
%         Opts.SupTitle_Text = sprintf('State specificity variation between\nRecovery Day 2 (3pm) - Recovery Day 3 (3pm)');
%         clustering_change_MaxState (CellTag_perMouse{17}, CellTag_perMouse{20}, CellTag_perMouse{20}, Opts)
%         
%     elseif Opts.ClusteringMethod == 3
%         
%         % Change during a single baseline day.
%         clustering_change (CellTag_perMouse{1}, CellTag_perMouse{2}, CellTag_perMouse{3}, Opts)
%         % Change across Baseline - 5pm
%         clustering_change (CellTag_perMouse{3}, CellTag_perMouse{6}, CellTag_perMouse{9}, Opts)
%         % Change across SD - 5pm
%         clustering_change (CellTag_perMouse{9}, CellTag_perMouse{12}, CellTag_perMouse{15}, Opts)
%         % Change across Recovery - 5pm
%         clustering_change (CellTag_perMouse{15}, CellTag_perMouse{18}, CellTag_perMouse{21}, Opts)
%     end
%     DUMMY = 0;
% end
% 

%% State Selectivity Analysis
% Get variation of selectivity (in terms of Events_Frequency or Intergals_Frequency) per cell, and the average per session
if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
    [Selectivity, State_Selectivity_Variation, Average_Activity_Variation, Activity_Normalized, Cell_Stable] = cmp_StateSelectivityVariation_perCell (Events_Freq_Matrix_perMouse, n_cells, Opts);
elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
    [Selectivity, State_Selectivity_Variation, Average_Activity_Variation, Activity_Normalized, Cell_Stable] = cmp_StateSelectivityVariation_perCell (Integral_Freq_Matrix_perMouse, n_cells, Opts);
end
Selectivity_Normalized = selectivity_normalization (Selectivity);
Cell_Stable_perMouse = separate_cells_stable_per_mouse (Cell_Stable, MouseCellsRecorded);


plot_Average_Selectivity_Variation (State_Selectivity_Variation, Opts)
plot_Average_Activity_Variation (Average_Activity_Variation, Opts)

plot_Selectivity_Variation_Test (State_Selectivity_Variation)

plot_Trianglular_Activity(Activity_Normalized, Selectivity_Normalized, Opts)


%% Clustering flow evolution 
% Compute the evolution matrix for every cell separately
[CellTags_EvolutionMatrix, CellTags_EvolutionMatrix_Ordered, OrderID] = cmp_CellTags_Evolution_Matrix(CellTagNum_perMouse, Opts);

% Reorder the Freq_Matrix_perMouse according to the same order as in the 
% CellTags_EvolutionMatrix_Ordered
[Events_Freq_Matrix_AllCells_Ordered, Events_Freq_Matrix_AllCells] = ReOrder_Freq_Matrix_perMouse (CellTags_EvolutionMatrix_Ordered, Events_Freq_Matrix_perMouse, OrderID);
[Integral_Freq_Matrix_AllCells_Ordered, Integral_Freq_Matrix_AllCells] = ReOrder_Freq_Matrix_perMouse (CellTags_EvolutionMatrix_Ordered, Integral_Freq_Matrix_perMouse, OrderID);

Cell_MouseID_Ordered = Cell_MouseID(OrderID);

% Plot the evolution matrix for each cell, based solely on the Events
% Frequency per state, translated into RGB
Events_Frequency_RGB_Tracking_v2 (Events_Freq_Matrix_AllCells, Opts);
Events_Frequency_RGB_Tracking_v2 (Integral_Freq_Matrix_AllCells, Opts);

% Plot the evolution matrix for each cell, based solely on the Events
% Frequency per state, translated into RGB ...with cells ordered by their
% clustering, to match the previous Evolution_Matrix plot
Events_Frequency_RGB_Tracking_v2 (Events_Freq_Matrix_AllCells_Ordered, Opts);
Events_Frequency_RGB_Tracking_v2 (Integral_Freq_Matrix_AllCells_Ordered, Opts);


% Flow Plots
try % Baseline
    Sessions_Num = [1, 2, 3, 4]; % Baseline
    ticklabels_array = {'Day 1 - 10am','Day 1 - 3pm','Day 2 - 5pm','Day 2 - 10am','Day 2 - 3pm','Day 2 - 5pm', 'Day 3 - 10am','Day 3 - 3pm','Day 3 - 5pm'}; % Baseline
    title_txt = 'Baseline';
    if Opts.ClusteringMethod == 3
        [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix_Ordered, Sessions_Num, ticklabels_array, title_txt, Opts);
    else
        [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix, Sessions_Num, ticklabels_array, title_txt, Opts);
    end
catch
    warning('Sanesky flow plot returned an error, check that the sessions involved exist.')
end

try % Across SD
Sessions_Num = [7, 8, 9, 10, 11, 12, 13, 14, 15]; % Across SD
ticklabels_array = {'Day 3 - 10am','Day 3 - 3pm','Day 3 - 5pm','Day 4 (SD) - 12pm','Day 4 - 3pm','Day 4 - 5pm', 'Day 5 - 10am','Day 5 - 3pm','Day 5 - 5pm'}; % Across SD
title_txt = 'Across SD';
if Opts.ClusteringMethod == 3
    [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix_Ordered, Sessions_Num, ticklabels_array, title_txt, Opts);
else
    [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix, Sessions_Num, ticklabels_array, title_txt, Opts);
end
catch
    warning('Sanesky flow plot returned an error, check that the sessions involved exist.')
end

try % Recovery
    Sessions_Num = [13, 14, 15, 16, 17, 18, 19, 20, 21]; % Recovery
    ticklabels_array = {'Day 5 - 10am','Day 5 - 3pm','Day 5 - 5pm','Day 6 - 10am','Day 6 - 3pm','Day 6 - 5pm', 'Day 7 - 10am','Day 7 - 3pm','Day 7 - 5pm'}; % Recovery
    title_txt = 'Recovery';
    if Opts.ClusteringMethod == 3
        [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix_Ordered, Sessions_Num, ticklabels_array, title_txt, Opts);
    else
        [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix, Sessions_Num, ticklabels_array, title_txt, Opts);
    end
catch
    warning('Sanesky flow plot returned an error, check that the sessions involved exist.')
end



%% Traces at Transitions Plot
Opts.HighlightedSession = 1; % The sleep deprivation session to highlight in the plots
traces_transitions_plot (CalciumTraces_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);

% Plot Traces for specifically State-Selective cells.
StateSelected = 'Awake'; % AwakeAll, NREMAll, REMAll, Awake, NREM, REM, (If clustering method is 3, also: LowActive, NotStateSelective, Awake & NREM, Awake & REM, NREM & REM)
traces_transitions_plot_clustering_selective (CalciumTraces_AllSessions, Hypnogram_AllSessions, CellTagNum_perMouse, Mouse_Names, StateSelected, Opts);
StateSelected = 'NREM'; % AwakeAll, NREMAll, REMAll, Awake, NREM, REM, (If clustering method is 3, also: LowActive, NotStateSelective, Awake & NREM, Awake & REM, NREM & REM)
traces_transitions_plot_clustering_selective (CalciumTraces_AllSessions, Hypnogram_AllSessions, CellTagNum_perMouse, Mouse_Names, StateSelected, Opts);
StateSelected = 'REM'; % AwakeAll, NREMAll, REMAll, Awake, NREM, REM, (If clustering method is 3, also: LowActive, NotStateSelective, Awake & NREM, Awake & REM, NREM & REM)
traces_transitions_plot_clustering_selective (CalciumTraces_AllSessions, Hypnogram_AllSessions, CellTagNum_perMouse, Mouse_Names, StateSelected, Opts);

traces_transitions_plot_clustering_selective_stability (CalciumTraces_AllSessions, Hypnogram_AllSessions, CellTagNum_perMouse, Cell_Stable_perMouse, Mouse_Names, StateSelected, Opts)


%% 
Opts.FLAG_Remove_Inactive_Cells = 0; % Remove entries in Events_Data for inactive cells? If not removed, the Events_Data will have more consistent number of cells, but their values will be filled with NaNs
[Events_Data, MouseMeans] = Init_Plot_EventsPerState(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);

plot_bar_sessions_comparisons (Events_Data, MouseCellsRecorded, Opts, sessions)


%% Events Rate per cell change over time.
[EventsRate_TimeArray_perMouse, EventsRateNormalized_TimeArray_perMouse, ...
    EventsRateVariation_Mean_TimeArray_perMouse, EventsRateVariation_StE_TimeArray_perMouse, ...
    EventsRateVariationNormalized_Mean_TimeArray_perMouse, EventsRateVariationNormalized_StE_TimeArray_perMouse] = cmp_EventsRate_perCell_overTime(Events_AllSessions, Mouse_Names, HypnoState, Opts);

Analysis_September_2023;


%% Correlation and Graph Analysis
if Opts.FLAG_Memory_Saving == 1
   clear Events_AllSessions; clear CalciumTraces_AllSessions
end
[Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, ~, ~, Connectivity_Index_OverTime_Mouse_Average, Connectivity_Index_OverTime_Mouse_StE, Betweenness_Result] = Continuous_Raw_Analysis_Lite2 (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
% [Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, CalciumTraces_Noisy_AllSessions, Stats_MeanOfStatesDifferences_PerSession, Stats_MeanOfStatesDifferences_PerMouse, Connectivity_Index_OverTime_Mouse_Average, Connectivity_Index_OverTime_Mouse_StE] = Continuous_Raw_Analysis_Lite (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
% Plot the Connectivity Indexes Average over Mice, over sessions.
% Plot the Average Correlation Time Series for each state (average per mouse)
% Plot the Events Rate time evolution per Session
% Plot the Events Rate time evolution per Session - Normalized
% Plot the Events Rate variation evolution per Session - Normalized







%% Plots WIP
corr_analysis (CalciumTraces_AllSessions, Hypnogram_AllSessions, HypnoState, Mouse_Names, Opts)

% Plot Example Traces
ExampleSession2Plot = 1;
ExampleSession = CalciumTraces_AllSessions{ExampleSession2Plot};
ExampleHypnogram = Hypnogram_AllSessions(ExampleSession2Plot).Hypnogram;
plot_ImagingAllAndHypno(ExampleSession, ExampleHypnogram, Hypnogram_AllSessions(ExampleSession2Plot).calTime)
% Plot Example Single Trace
ExampleTrace2Plot = 4;
ExampleTrace = ExampleSession(:, ExampleTrace2Plot);
plot_ImagingAndHypno(ExampleTrace, ExampleHypnogram, Hypnogram_AllSessions(ExampleSession2Plot).calTime)

% Clustering Continuity Evolution
plot_clustering_continuity (CellTagNum_perMouse, CellType, Opts);

% Analysis per State ===== WIP =====
State_Info_perSession = SingleState_Analysis_per_mouse(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
SingleState_Analysis_Plots(State_Info_perSession, Mouse_Names, Opts);

% Plots Awake Stability ===== WIP =====
plot_events_frequency_awake_stability (Events_Freq_Matrix_allMice{1}, Events_Freq_Matrix_allMice{2}, Events_Freq_Matrix_allMice{3}, Events_Freq_Matrix_allMice{4}, Events_Freq_Matrix_allMice{5}, Events_Freq_Matrix_allMice{6}, Events_Freq_Matrix_allMice{7}, Events_Freq_Matrix_allMice{8}, Events_Freq_Matrix_allMice{9}, Events_Freq_Matrix_allMice{10}, Events_Freq_Matrix_allMice{11}, Events_Freq_Matrix_allMice{12}, Events_Freq_Matrix_allMice{13}, Events_Freq_Matrix_allMice{14}, Events_Freq_Matrix_allMice{15}, Events_Freq_Matrix_allMice{16}, Events_Freq_Matrix_allMice{17}, Events_Freq_Matrix_allMice{18}, Events_Freq_Matrix_allMice{19}, Events_Freq_Matrix_allMice{20}, Events_Freq_Matrix_allMice{21});

% Plots Awake ===== WIP =====
plot_events_frequency_awake_comparison_ordered (Events_Freq_Matrix_allMice{7}, Events_Freq_Matrix_allMice{8}, Events_Freq_Matrix_allMice{9}, Events_Freq_Matrix_allMice{10}, Events_Freq_Matrix_allMice{11}, Events_Freq_Matrix_allMice{12}, Events_Freq_Matrix_allMice{13}, Events_Freq_Matrix_allMice{14}, Events_Freq_Matrix_allMice{15});


