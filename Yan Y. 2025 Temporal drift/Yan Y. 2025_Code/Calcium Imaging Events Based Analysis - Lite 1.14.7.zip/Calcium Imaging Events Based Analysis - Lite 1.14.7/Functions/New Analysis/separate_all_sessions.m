function Events_perSession = separate_all_sessions (Events, HypnoState)

Events_perSession = cell(nanmax([HypnoState.Session]), 1);

for i_session = 1:nanmax([HypnoState.Session])
    [Events_perSession{i_session}] = separate_events_per_session (Events, i_session);
end
