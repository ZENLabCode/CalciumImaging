function [Events_Grouped, Hypnogram_Group, Integrals_Group] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Integral_AllSessions, Group)
% Group is an array of N numbers, which indicate the indexes of the
% sessions to put together.

% Group Events
Events_Grouped = Events_perSession{Group(1)};

if numel(Group) >= 2
    for i_group = 2:numel(Group)
        i_session = Group(i_group);
        Events_Grouped = [Events_Grouped, Events_perSession{i_session}];
    end
end

% Group Hypnograms
tmp = find([Hypnogram_AllSessions.Session] == Group(1));

Hypnogram_Group = Hypnogram_AllSessions(tmp);

if numel(Group) >= 2
    for i_group = 2:numel(Group)
        i_session = Group(i_group);
        tmp = find([Hypnogram_AllSessions.Session] == i_session);
        Hypnogram_Group = [Hypnogram_Group, Hypnogram_AllSessions(tmp)];
    end
end

% Group Integrals
tmp = find([Hypnogram_AllSessions.Session] == Group(1));

Integrals_Group = Integral_AllSessions(tmp);

if numel(Group) >= 2
    for i_group = 2:numel(Group)
        i_session = Group(i_group);
        tmp = find([Hypnogram_AllSessions.Session] == i_session);
        Integrals_Group = [Integrals_Group, Integral_AllSessions(tmp)]';
    end
end