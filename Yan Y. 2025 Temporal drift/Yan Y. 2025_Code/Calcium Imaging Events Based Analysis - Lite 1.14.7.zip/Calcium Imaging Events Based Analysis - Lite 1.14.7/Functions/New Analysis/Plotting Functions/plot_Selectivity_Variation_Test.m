function plot_Selectivity_Variation_Test (State_Selectivity_Variation)
% This is a test plot function


State_Selectivity_Matrix_Variation = State_Selectivity_Variation.State_Selectivity_Matrix_Variation;

State_Selectivity_Matrix_Variation_Wake = squeeze(State_Selectivity_Matrix_Variation(:, 1, :));
State_Selectivity_Matrix_Variation_NREM = squeeze(State_Selectivity_Matrix_Variation(:, 2, :));
State_Selectivity_Matrix_Variation_REM = squeeze(State_Selectivity_Matrix_Variation(:, 3, :));

% Wake
figure
pcolor(State_Selectivity_Matrix_Variation_Wake)

State_Selectivity_Matrix_Variation_Wake_2 = diff(State_Selectivity_Matrix_Variation_Wake, 1, 2);

colorbar
figure
pcolor(State_Selectivity_Matrix_Variation_Wake_2)
colorbar

% NREM
figure
pcolor(State_Selectivity_Matrix_Variation_NREM)

State_Selectivity_Matrix_Variation_NREM_2 = diff(State_Selectivity_Matrix_Variation_NREM, 1, 2);

colorbar
figure
pcolor(State_Selectivity_Matrix_Variation_NREM_2)
colorbar

% REM
figure
pcolor(State_Selectivity_Matrix_Variation_REM)

State_Selectivity_Matrix_Variation_REM_2 = diff(State_Selectivity_Matrix_Variation_REM, 1, 2);

colorbar
figure
pcolor(State_Selectivity_Matrix_Variation_REM_2)
colorbar