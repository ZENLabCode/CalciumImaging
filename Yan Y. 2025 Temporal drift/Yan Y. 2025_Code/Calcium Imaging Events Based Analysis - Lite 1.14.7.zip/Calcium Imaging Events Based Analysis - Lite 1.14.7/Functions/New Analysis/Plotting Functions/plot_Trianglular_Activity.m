function plot_Trianglular_Activity(Activity_Normalized, Selectivity_Normalized, Opts)


n_sessions = numel(Activity_Normalized);
n_cells = sum(Opts.Mouse_N_Cells);

% Randomly select n neurons
n_RandomNeurons = 5; % Do not select more than 5, unless you want to increase the number of colors
neuronsIDs = randperm(n_cells, n_RandomNeurons);
% Random Neurons Colors
RandomNeuronsColors = {[1, 0, 0], [1, 1, 0], [0, 1, 0], [1, 0, 1], [0, 1, 1]}; % Red; Yellow; Green; Purple; Cyan

% Figure options
FontSize = 18;
MarkersSize = 6; % Matlab's default is 6
MarkersSize_RandomNeurons = 10;
FLAG_NormalizedPlots = 1; % Use manually normalized plots?


%% Write Activity Triangulation Film
fprintf('\nWriting Film\n\n')

% Prepare .avi 
video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'
video_name = sprintf('%s - Activity Film', Opts.CellType);

% Initialize and open video object.
video_obj = VideoWriter(video_name, video_profile);
video_obj.FrameRate = 3; % Change to speed up or slow down the framerate

open(video_obj);
for i_session = 1:n_sessions
    fig_tmp = figure('Renderer', 'painters', 'Position', [500 500 800 600]);
    Current_Activity = Activity_Normalized{i_session};
    % Fix out of bounds objects
    Current_Activity(Current_Activity>=1) = 1;
    Current_Activity(Current_Activity<=0) = 0;
    
    % Manually normalize
    if FLAG_NormalizedPlots == 1
        Current_Activity = Current_Activity./sum(Current_Activity, 2);
    end
    
    % Get the activity of the random neurons to plot in a different color
    RandomNeuronActivity = Current_Activity(neuronsIDs, :);
    % Remove these neurons from the rest of the plot
    Current_Activity(neuronsIDs, :) = [];
    
    terplot(1);
    pause(0.05)
    h = ternaryc(Current_Activity(:, 1), Current_Activity(:, 2), Current_Activity(:, 3));
    set(h, 'MarkerSize', MarkersSize)
    hold on
    for i_neuron = 1:n_RandomNeurons
       CurrentRandomNeuron = RandomNeuronActivity(i_neuron, :);
       h = ternaryc(CurrentRandomNeuron(1), CurrentRandomNeuron(2), CurrentRandomNeuron(3)); 
       set(h, 'MarkerFaceColor', RandomNeuronsColors{i_neuron}, 'MarkerEdgeColor', RandomNeuronsColors{i_neuron}, 'MarkerSize', MarkersSize_RandomNeurons)
    end
    hold off
    pause(0.05)

    allTextHandles = findall(gca, 'Type', 'Text');
    delete(allTextHandles);
    text(-0.125, -0.05, 'Wake', 'FontSize', FontSize)
    text(1.025, -0.05, 'NREM', 'FontSize', FontSize)
    text(0.45, 0.915, 'REM', 'FontSize', FontSize)
    text(0.85, 0.85, sprintf('Session %d', i_session), 'FontSize', FontSize)
    current_frame = getframe(fig_tmp);
    writeVideo(video_obj, current_frame);
    pause(0.025)
    close
end

close(video_obj);
close % Close the figure used to produce the film.
fprintf('\nFilm saved successfully in .avi format.\n\n')




%% Write Activity Triangulation Film
fprintf('\nWriting Film\n\n')

% Prepare .avi 
video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'
filenametxt_tmp = sprintf('Clustering %s Based', Opts.ClusteringVariable);
video_name = sprintf('%s - %s - Selectivity Film', Opts.CellType, filenametxt_tmp);

% Initialize and open video object.
video_obj = VideoWriter(video_name, video_profile);
video_obj.FrameRate = 3; % Change to speed up or slow down the framerate

open(video_obj);
for i_session = 1:n_sessions
    fig_tmp = figure('Renderer', 'painters', 'Position', [500 500 800 600]);
    Current_Selectivity = Selectivity_Normalized(i_session).State_Selectivity_Matrix;
    
    % Fix out of bounds objects
    Current_Selectivity(Current_Selectivity>=1) = 1;
    Current_Selectivity(Current_Selectivity<=0) = 0;
    
    % Manually normalize
    if FLAG_NormalizedPlots == 1
        Current_Selectivity = Current_Selectivity./sum(Current_Selectivity, 2);
    end
    
    % Get the activity of the random neurons to plot in a different color
    RandomNeuronSelectivity = Current_Selectivity(neuronsIDs, :);
    % Remove these neurons from the rest of the plot
    Current_Selectivity(neuronsIDs, :) = [];
    
    terplot(1);
    pause(0.05)
    h = ternaryc(Current_Selectivity(:, 1), Current_Selectivity(:, 2), Current_Selectivity(:, 3));
    set(h, 'MarkerSize', MarkersSize)
    
    hold on
    for i_neuron = 1:n_RandomNeurons
        CurrentRandomNeuron = RandomNeuronSelectivity(i_neuron, :);
        h = ternaryc(CurrentRandomNeuron(1), CurrentRandomNeuron(2), CurrentRandomNeuron(3));
        set(h, 'MarkerFaceColor', RandomNeuronsColors{i_neuron}, 'MarkerEdgeColor', RandomNeuronsColors{i_neuron}, 'MarkerSize', MarkersSize_RandomNeurons)
    end
    hold off
    pause(0.05)
    
    allTextHandles = findall(gca, 'Type', 'Text');
    delete(allTextHandles);
    text(-0.125, -0.05, 'Wake', 'FontSize', FontSize)
    text(1.025, -0.05, 'NREM', 'FontSize', FontSize)
    text(0.45, 0.915, 'REM', 'FontSize', FontSize)
    text(0.85, 0.85, sprintf('Session %d', i_session), 'FontSize', FontSize)
    current_frame = getframe(fig_tmp);
    writeVideo(video_obj, current_frame);
    pause(0.025)
    close
end

close(video_obj);
close % Close the figure used to produce the film.
fprintf('\nFilm saved successfully in .avi format.\n\n')
