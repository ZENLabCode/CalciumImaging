function plot_EventsFreq_Average_TS (EventsFrequency_Sessions_Mean, EventsFrequency_Sessions_StE, Opts)
% Plots the time series over sessions of the average events frequency over
% different mice.

% Options
FontSizeTitles = 24;
AxisFontSize = 14;
ColorBar_FontSize = 14;
Plot_LineWidth = 2;

Ticks_Array = ([1, 4, 7, 10, 13, 16, 19]);
Ticks_Labels = ({'Day 1','Day 2','Day 3', 'SD', 'Rec 1', 'Rec 2', 'Rec 3'});

[n_sessions, n_states] = size(EventsFrequency_Sessions_Mean);

% Figure
figure('units', 'normalized', 'outerposition',[0 0 1 1]);

hold on
% Wake
errorbar(EventsFrequency_Sessions_Mean(:, 1), EventsFrequency_Sessions_StE(:, 1), 'b', 'LineWidth', Plot_LineWidth);
% NREM
errorbar(EventsFrequency_Sessions_Mean(:, 2), EventsFrequency_Sessions_StE(:, 2), 'r', 'LineWidth', Plot_LineWidth);
% REM
errorbar(EventsFrequency_Sessions_Mean(:, 3), EventsFrequency_Sessions_StE(:, 3), 'g', 'LineWidth', Plot_LineWidth);

hold off

ax = gca;
ax.FontSize = AxisFontSize; 
title(sprintf('%s - Events Frequency - Average over mice', Opts.CellType), 'FontSize', FontSizeTitles)
ylabel('Events Frequency [Hz]', 'FontSize', 18)
xlim([0, n_sessions] + 0.5);
grid on; grid minor; box on; axis square;

xticks(Ticks_Array)
xticklabels(Ticks_Labels);

legend({'Wake', 'NREM', 'REM'})

%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Events Frequency over Sessions', Opts.CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
