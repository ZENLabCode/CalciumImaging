function plot_Average_Activity_Variation (Average_Activity_Variation, Opts)



[n_sessions, ~] = size(Average_Activity_Variation.Mean); 
n_sessions = n_sessions + 1;

%% Plot 1 - Average Activity Variation over Sessions
AxisFontSize = 16;
TitleFontSize = 26;
SupTitleFontSize = 26;
Plot_LineWidth = 2.5;

Sessions = 1:n_sessions - 1;
Average_Activity_Variation_tmp = Average_Activity_Variation.Mean;
Average_Activity_Variation_StE_tmp = Average_Activity_Variation.StE;

figure('units','normalized','outerposition',[0 0 1 1]);

hold on;
errorbar(Average_Activity_Variation_tmp(:, 1), Average_Activity_Variation_StE_tmp(:, 1), 'b', 'LineWidth', Plot_LineWidth);
errorbar(Average_Activity_Variation_tmp(:, 2), Average_Activity_Variation_StE_tmp(:, 2), 'r', 'LineWidth', Plot_LineWidth);
errorbar(Average_Activity_Variation_tmp(:, 3), Average_Activity_Variation_StE_tmp(:, 3), 'g', 'LineWidth', Plot_LineWidth);
hold off
ax = gca;
ax.FontSize = AxisFontSize; 

grid on; grid minor; box on; axis square;
if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
    title(sprintf('%s - Average Events Frequency Variation\nAverage per Cell', Opts.CellType), 'FontSize', TitleFontSize)
    ylabel('Average Events Frequency Variation [Hz]', 'FontSize', 18)
elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
    title(sprintf('%s - Average Integrals Frequency Variation\nAverage per Cell', Opts.CellType), 'FontSize', TitleFontSize)
    ylabel('Average Integrals Frequency Variation', 'FontSize', 18)
end
xlabel('Time [Session]', 'FontSize', 18)
xlim([0, n_sessions]);

legend({'Wake', 'NREM', 'REM'})

% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Average Activity Variation over Sessions - Events Based', Opts.CellType);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Average Activity Variation over Sessions - Integrals Based', Opts.CellType);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

