function h_piechart = plot_clustering(CellTagNum_perMouse, Opts)
% This plot will show the distribution of the cells per state selectivity
% (according to the clustering parameters chosen in 
% 'clustering_cells_activitybased'), in a pie plot. The numbers shown are
% the average between all recorded mice.

AxisFontSize = 14;

n_mice = numel(CellTagNum_perMouse);
n_cells = NaN(1, n_mice);
for i_mouse = 1:n_mice
    n_cells(i_mouse) = numel(CellTagNum_perMouse{1, i_mouse});
    N(i_mouse).None = numel(find(CellTagNum_perMouse{1, i_mouse} == 0));
    N(i_mouse).Unspecific = numel(find(CellTagNum_perMouse{1, i_mouse} == 1));
    N(i_mouse).Awake_NREM = numel(find(CellTagNum_perMouse{1, i_mouse} == 2));
    N(i_mouse).Awake_REM = numel(find(CellTagNum_perMouse{1, i_mouse} == 3));
    N(i_mouse).NREM_REM = numel(find(CellTagNum_perMouse{1, i_mouse} == 4));
    N(i_mouse).Awake = numel(find(CellTagNum_perMouse{1, i_mouse} == 5));
    N(i_mouse).NREM = numel(find(CellTagNum_perMouse{1, i_mouse} == 6));
    N(i_mouse).REM = numel(find(CellTagNum_perMouse{1, i_mouse} == 7));
end
M = squeeze(struct2cell(N));
M = cell2mat(M);
for i_mouse = 1:n_mice
    M(:, i_mouse) = M(:, i_mouse)./n_cells(i_mouse);
end

% Collapse into average
AverageCount = nanmean(M, 2);

% Labels 
labels = {'Inactive', 'Unspecific', 'Awake&NREM', 'Awake&REM', 'NREM&REM', 'Awake', 'NREM', 'REM'};

% Plot
figure;
h_piechart = pie(AverageCount, labels);

% Colors (Adjust them as automatically as possible, may require manual
% adjustments too..)

patchHand = findobj(h_piechart, 'Type', 'Patch'); 
if exist ('Opts', 'var')
    if isfield(Opts, 'ClusteringMethod')
        if Opts.ClusteringMethod == 1
            patchHand(1).FaceColor = 'b';
            patchHand(2).FaceColor = 'r';
            patchHand(3).FaceColor = 'g';
        end
        
        if Opts.ClusteringMethod == 2
            patchHand(1).FaceColor = 'k';
            patchHand(2).FaceColor = 'b';
            patchHand(3).FaceColor = 'r';
            patchHand(4).FaceColor = 'g';
        end
    end
end
% Tmp text for labels
AverageCountNoZero = AverageCount(AverageCount > 0);
for i = 1:numel(AverageCountNoZero)
    tmp_txt{i} = sprintf('\n%.1f%%', AverageCountNoZero(i).*100);
end
tmp_txt(isempty(tmp_txt)) = [];
% Update labels
tmp_pText = findobj(h_piechart, 'Type', 'text');
tmp_LabelsOrig = get(tmp_pText, 'String');
tmp_combinedtxt = strcat(tmp_LabelsOrig, tmp_txt');
for i = 1:numel(AverageCountNoZero)
    tmp_pText(i).String = tmp_combinedtxt{i};
end
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);

% Title and # mice
suptitle('Distribution of cells according to activation state selectivity')

annotation('textbox', [0.02, 0.1, 0.25, 0], 'string', sprintf('(Average of %d mice)', n_mice), 'LineStyle', 'none');




%% Save
if Opts.SaveFiguresAutomatically == 1
    % FileName = 'Figure Cells Clustered per State';
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, Opts.tmp_FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

