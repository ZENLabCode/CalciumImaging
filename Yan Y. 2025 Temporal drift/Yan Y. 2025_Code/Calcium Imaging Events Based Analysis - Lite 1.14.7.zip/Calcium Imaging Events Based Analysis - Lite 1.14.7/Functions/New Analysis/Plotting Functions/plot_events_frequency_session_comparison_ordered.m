function plot_events_frequency_session_comparison_ordered (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm)

n_rows = 3;
n_columns = 3;

colormax = nanmax([Events_Freq_Matrix_allMice_Baseline_10am; Events_Freq_Matrix_allMice_Baseline_3pm; Events_Freq_Matrix_allMice_Baseline_5pm; Events_Freq_Matrix_allMice_Recovery_10am; Events_Freq_Matrix_allMice_Recovery_3pm; Events_Freq_Matrix_allMice_Recovery_5pm; Events_Freq_Matrix_allMice_SD_12pm; Events_Freq_Matrix_allMice_SD_3pm; Events_Freq_Matrix_allMice_SD_5pm]);
freq_globalmax = nanmax(colormax);
freq_globalmin = 0;
ColorLimits = [freq_globalmin, freq_globalmax];

% % Control for missing cell (WIP patchwork)
% [n_cells, ~] = size (Events_Freq_Matrix_allMice_SD_3pm);
% if n_cells ~= 257
%     Events_Freq_Matrix_allMice_SD_3pm(end+1, :) = NaN(1, 3);
% end

figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

% Sort Awake
Awake_morning = sortrows([Events_Freq_Matrix_allMice_Baseline_10am(:, 1), Events_Freq_Matrix_allMice_SD_12pm(:, 1), Events_Freq_Matrix_allMice_Recovery_10am(:, 1)], 1, 'descend');
Awake_3pm = sortrows([Events_Freq_Matrix_allMice_Baseline_3pm(:, 1), Events_Freq_Matrix_allMice_SD_3pm(:, 1), Events_Freq_Matrix_allMice_Recovery_3pm(:, 1)], 1, 'descend');
Awake_5pm = sortrows([Events_Freq_Matrix_allMice_Baseline_5pm(:, 1), Events_Freq_Matrix_allMice_SD_5pm(:, 1), Events_Freq_Matrix_allMice_Recovery_5pm(:, 1)], 1, 'descend');
% Sort NREM
NREM_morning = sortrows([Events_Freq_Matrix_allMice_Baseline_10am(:, 2), Events_Freq_Matrix_allMice_SD_12pm(:, 2), Events_Freq_Matrix_allMice_Recovery_10am(:, 2)], 1, 'descend');
NREM_3pm = sortrows([Events_Freq_Matrix_allMice_Baseline_3pm(:, 2), Events_Freq_Matrix_allMice_SD_3pm(:, 2), Events_Freq_Matrix_allMice_Recovery_3pm(:, 2)], 1, 'descend');
NREM_5pm = sortrows([Events_Freq_Matrix_allMice_Baseline_5pm(:, 2), Events_Freq_Matrix_allMice_SD_5pm(:, 2), Events_Freq_Matrix_allMice_Recovery_5pm(:, 2)], 1, 'descend');
% Sort REM
REM_morning = sortrows([Events_Freq_Matrix_allMice_Baseline_10am(:, 3), Events_Freq_Matrix_allMice_SD_12pm(:, 3), Events_Freq_Matrix_allMice_Recovery_10am(:, 3)], 1, 'descend');
REM_3pm = sortrows([Events_Freq_Matrix_allMice_Baseline_3pm(:, 3), Events_Freq_Matrix_allMice_SD_3pm(:, 3), Events_Freq_Matrix_allMice_Recovery_3pm(:, 3)], 1, 'descend');
REM_5pm = sortrows([Events_Freq_Matrix_allMice_Baseline_5pm(:, 3), Events_Freq_Matrix_allMice_SD_5pm(:, 3), Events_Freq_Matrix_allMice_Recovery_5pm(:, 3)], 1, 'descend');

% First Awake
subplot(n_rows, n_columns, 1)
imagesc(Awake_morning)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - Morning', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 2)
imagesc(Awake_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 3)
imagesc(Awake_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_1 = colorbar;
h_colorbar_1.Label.String = 'Events Frequency (Hz)';
h_colorbar_1.Label.FontSize = ColorBar_FontSize;


% Second NREM
subplot(n_rows, n_columns, 4)
imagesc(NREM_morning)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 5)
imagesc(NREM_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 6)
imagesc(NREM_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_2 = colorbar;
h_colorbar_2.Label.String = 'Events Frequency (Hz)';
h_colorbar_2.Label.FontSize = ColorBar_FontSize;


% Third Raw - 5pm
subplot(n_rows, n_columns, 7)
imagesc(REM_morning)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 8)
imagesc(REM_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 9)
imagesc(REM_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline','SD','Recovery'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_3 = colorbar;
h_colorbar_3.Label.String = 'Events Frequency (Hz)';
h_colorbar_3.Label.FontSize = ColorBar_FontSize;

% h_colorbar_2.Visible = 'off';
% h_colorbar_3.Visible = 'off';


h_suptitle = suptitle('Calcium Events rate per cell over days');
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';