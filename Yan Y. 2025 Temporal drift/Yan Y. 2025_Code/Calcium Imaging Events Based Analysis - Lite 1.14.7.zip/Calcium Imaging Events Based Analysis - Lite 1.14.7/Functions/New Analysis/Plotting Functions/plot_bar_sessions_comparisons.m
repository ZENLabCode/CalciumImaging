function plot_bar_sessions_comparisons (Events_Data, MouseCellsRecorded, Opts, sessions)
% Produces Bar Plots to compare either the Events Data or the Integrals
% of different brain states, between different sessions.
% The sessions to be compared are to be given in the array 'sessions'
% example: sessions = [1, 2, 3, 4]



%% Options
FontSize_Titles = 20;
FontSize_AxisLabels = 18;
FontSize_Axis = 14;
FontSize_Legend = 14;
Xaxis_spacing_short = 1;
Xaxis_spacing_long = 3;


%% Controls
if exist('sessions', 'var') == 0
    warning('The "sessions" array was not provided. Only examining the 1st session.');
    sessions = 1;
end
if isempty(sessions)
    warning('The "sessions" array was given empty. Only examining the 1st session.');
    sessions = 1;
end


%% Data
n_session = numel(sessions);
XLocation_Awake = 1:Xaxis_spacing_short:n_session*Xaxis_spacing_short;
XLocation_NREM = (Xaxis_spacing_long + 1 + n_session*Xaxis_spacing_short):Xaxis_spacing_short:(Xaxis_spacing_long + n_session*Xaxis_spacing_short) + n_session*Xaxis_spacing_short;
XLocation_REM = (Xaxis_spacing_long*2 + 1 + n_session*Xaxis_spacing_short*2):Xaxis_spacing_short:(Xaxis_spacing_long*2 + n_session*Xaxis_spacing_short*2) + n_session*Xaxis_spacing_short;


keyboard
for i_session = 1:n_session
    current_session_n = sessions(i_session);
    Events_Rate = Events_Data(current_session_n).EventRate;
    
    
    for i_mouse = 1:numel(Mouse_Names)
        if i_mouse == 1
            CurrentMouse_Cell_Indexes = 1:MouseCellsRecorded(i_mouse);
        else
            CurrentMouse_Cell_Indexes = MouseCellsRecorded(i_mouse - 1) + 1:MouseCellsRecorded(i_mouse);
        end
        
        MouseMean(i_mouse).Awake = mean([Events_Rate(CurrentMouse_Cell_Indexes).Awake], 'omitnan');
        MouseMean(i_mouse).NREM = mean([Events_Rate(CurrentMouse_Cell_Indexes).NoNREM], 'omitnan');
        MouseMean(i_mouse).REM = mean([Events_Rate(CurrentMouse_Cell_Indexes).REM], 'omitnan');
        MouseStE(i_mouse).Awake = std([Events_Rate(CurrentMouse_Cell_Indexes).Awake], 'omitnan');
        MouseStE(i_mouse).NREM = std([Events_Rate(CurrentMouse_Cell_Indexes).NoNREM], 'omitnan');
        MouseStE(i_mouse).REM = std([Events_Rate(CurrentMouse_Cell_Indexes).REM], 'omitnan');
    end
    
    Events_Rate_Mean(i_session).Awake = mean([Events_Rate.Awake], 'omitnan');
    Events_Rate_Mean(i_session).NREM = mean([Events_Rate.NoNREM], 'omitnan');
    Events_Rate_Mean(i_session).REM = mean([Events_Rate.REM], 'omitnan');
    Events_Rate_StE(i_session).Awake = std([Events_Rate.Awake], 'omitnan')./sqrt(numel(~isnan([Events_Rate.Awake])));
    Events_Rate_StE(i_session).NREM = std([Events_Rate.NoNREM], 'omitnan')./sqrt(numel(~isnan([Events_Rate.NoNREM])));
    Events_Rate_StE(i_session).REM = std([Events_Rate.REM], 'omitnan')./sqrt(numel(~isnan([Events_Rate.REM])));
    
end


%% Figure
figure('units','normalized','outerposition',[0 0 1 1]);

hold on;
h_bar{1} = bar(XLocation_Awake, [Events_Rate_Mean.Awake], 'b');
h_bar{2} = bar(XLocation_NREM, [Events_Rate_Mean.NREM], 'r');
h_bar{3} = bar(XLocation_REM, [Events_Rate_Mean.REM], 'g');
h_error = errorbar(XLocation_Awake, [Events_Rate_Mean.Awake], [Events_Rate_StE.Awake], [Events_Rate_StE.Awake], 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
h_error = errorbar(XLocation_NREM, [Events_Rate_Mean.NREM], [Events_Rate_StE.NREM], [Events_Rate_StE.NREM], 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';
h_error = errorbar(XLocation_REM, [Events_Rate_Mean.REM], [Events_Rate_StE.REM], [Events_Rate_StE.REM], 'Color', [0, 0, 0]);    
h_error.LineStyle = 'none';

grid on;
box on;
ax = gca;
ax.FontSize = FontSize_Axis; 


xlabel('Sessions Comparisons', 'FontSize', FontSize_AxisLabels)
ylabel('Events Rate [Hz]', 'FontSize', FontSize_AxisLabels)
title_str = sprintf('Events Rate over different sessions - %s', Opts.CellType);
title(title_str, 'FontSize', FontSize_Titles)

h_legend = legend([h_bar{:}], 'Awake', 'NREM','REM');
h_legend.FontSize = FontSize_Legend;

XTicks = [XLocation_Awake, XLocation_NREM, XLocation_REM];
xticks(XTicks)

xticklabels([sessions, sessions, sessions])
