function plot_n_events (Events_N_Average, Events_N_StE, Opts)
% Plots the number of events over different sessions.


figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;
Plot_LineWidth = 2;

Ticks_Array = ([1, 4, 7, 10, 13, 16, 19]);
Ticks_Labels = ({'Day 1','Day 2','Day 3', 'SD', 'Rec 1', 'Rec 2', 'Rec 3'});

% plot(Events_N_Average, 'LineWidth', Plot_LineWidth);
errorbar(Events_N_Average, Events_N_StE, 'b', 'LineWidth', Plot_LineWidth);

ax = gca;
ax.FontSize = AxisFontSize; 
title('Total Number of events per session', 'FontSize', FontSizeTitles)
ylabel('Events Number', 'FontSize', 18)
xlim([0, numel(Events_N_Average)] + 0.5);
grid on; grid minor;

xticks(Ticks_Array)
xticklabels(Ticks_Labels);

%% Save
if Opts.SaveFiguresAutomatically == 1
    % FileName = 'Figure Cells Clustered per State';
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, Opts.tmp_FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
