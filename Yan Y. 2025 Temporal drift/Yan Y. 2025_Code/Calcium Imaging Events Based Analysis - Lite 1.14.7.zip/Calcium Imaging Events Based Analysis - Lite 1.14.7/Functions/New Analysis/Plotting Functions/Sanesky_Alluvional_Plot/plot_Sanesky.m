function [Data_Flow, Variations] = plot_Sanesky (CellTags_EvolutionMatrix, Sessions_Num, ticklabels_array, title_txt, Opts)




n_sessions = numel(Sessions_Num);

% Tags:
% None = 0
% Awake = 5
% NREM = 6
% REM = 7

indexes_Inactive = cell(n_sessions, 1);
indexes_Unspecific = cell(n_sessions, 1);
indexes_Awake = cell(n_sessions, 1);
indexes_NREM = cell(n_sessions, 1);
indexes_REM = cell(n_sessions, 1);
indexes_Awake_REM = cell(n_sessions, 1);
indexes_Awake_NREM = cell(n_sessions, 1);
indexes_REM_NREM = cell(n_sessions, 1);

n_Inactive = NaN(n_sessions, 1);
n_Unspecific = NaN(n_sessions, 1);
n_Awake = NaN(n_sessions, 1);
n_NREM = NaN(n_sessions, 1);
n_REM = NaN(n_sessions, 1);
n_Awake_REM = NaN(n_sessions, 1);
n_Awake_NREM = NaN(n_sessions, 1);
n_REM_NREM = NaN(n_sessions, 1);

if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    Awake_Tag = 1;
    NREM_Tag = 2;
    REM_Tag = 4;
    Inactive_Tag = 0;
    
    % Convert?
    CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 0) = Inactive_Tag;
    CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 5) = Awake_Tag;
    CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 6) = NREM_Tag;
    CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 7) = REM_Tag;
    
    Cells_Evolution_SelectedSessions = CellTags_EvolutionMatrix(:, Sessions_Num);
    
    session_counter = 1:n_sessions;
    for i_session = 1:n_sessions
        % Compute numbers and specificity
        CellsTag_CurrentSession = Cells_Evolution_SelectedSessions(:, session_counter(i_session));
        
        [indexes_Awake{i_session}, ~] = find(CellsTag_CurrentSession == Awake_Tag);
        [indexes_NREM{i_session}, ~] = find(CellsTag_CurrentSession == NREM_Tag);
        [indexes_REM{i_session}, ~] = find(CellsTag_CurrentSession == REM_Tag);
        [indexes_Inactive{i_session}, ~] = find(CellsTag_CurrentSession == Inactive_Tag);
        
        n_Awake(i_session) = numel(indexes_Awake{i_session});
        n_NREM(i_session) = numel(indexes_NREM{i_session});
        n_REM(i_session) = numel(indexes_REM{i_session});
        n_Inactive(i_session) = numel(indexes_Inactive{i_session});
        
        % Compute Variations between the two consecutive sessions
        if i_session > 1
            Awake_Post_State = CellsTag_CurrentSession(indexes_Awake{i_session - 1});
            NREM_Post_State = CellsTag_CurrentSession(indexes_NREM{i_session - 1});
            REM_Post_State = CellsTag_CurrentSession(indexes_REM{i_session - 1});
            Inactive_Post_State = CellsTag_CurrentSession(indexes_Inactive{i_session - 1});
            
            % Compute Variations between the first two sessions
            Variations(i_session - 1).Awake2Awake = numel(find(Awake_Post_State == Awake_Tag));
            Variations(i_session - 1).Awake2NREM = numel(find(Awake_Post_State == NREM_Tag));
            Variations(i_session - 1).Awake2REM = numel(find(Awake_Post_State == REM_Tag));
            Variations(i_session - 1).Awake2Inactive = numel(find(Awake_Post_State == Inactive_Tag));
            Variations(i_session - 1).NREM2Awake = numel(find(NREM_Post_State == Awake_Tag));
            Variations(i_session - 1).NREM2NREM = numel(find(NREM_Post_State == NREM_Tag));
            Variations(i_session - 1).NREM2REM = numel(find(NREM_Post_State == REM_Tag));
            Variations(i_session - 1).NREM2Inactive = numel(find(NREM_Post_State == Inactive_Tag));
            Variations(i_session - 1).REM2Awake = numel(find(REM_Post_State == Awake_Tag));
            Variations(i_session - 1).REM2NREM = numel(find(REM_Post_State == NREM_Tag));
            Variations(i_session - 1).REM2REM = numel(find(REM_Post_State == REM_Tag));
            Variations(i_session - 1).REM2Inactive = numel(find(REM_Post_State == Inactive_Tag));
            Variations(i_session - 1).Inactive2Awake = numel(find(Inactive_Post_State == Awake_Tag));
            Variations(i_session - 1).Inactive2NREM = numel(find(Inactive_Post_State == NREM_Tag));
            Variations(i_session - 1).Inactive2REM = numel(find(Inactive_Post_State == REM_Tag));
            Variations(i_session - 1).Inactive2Inactive = numel(find(Inactive_Post_State == Inactive_Tag));
            
            VariationsPercentage(i_session - 1).Awake2Awake = (Variations(i_session - 1).Awake2Awake./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2NREM = (Variations(i_session - 1).Awake2NREM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2REM = (Variations(i_session - 1).Awake2REM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2Inactive = (Variations(i_session - 1).Awake2Inactive./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Awake = (Variations(i_session - 1).NREM2Awake./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2NREM = (Variations(i_session - 1).NREM2NREM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2REM = (Variations(i_session - 1).NREM2REM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Inactive = (Variations(i_session - 1).NREM2Inactive./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Awake = (Variations(i_session - 1).REM2Awake./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2NREM = (Variations(i_session - 1).REM2NREM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2REM = (Variations(i_session - 1).REM2REM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Inactive = (Variations(i_session - 1).REM2Inactive./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Awake = (Variations(i_session - 1).Inactive2Awake./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2NREM = (Variations(i_session - 1).Inactive2NREM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2REM = (Variations(i_session - 1).Inactive2REM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Inactive = (Variations(i_session - 1).Inactive2Inactive./n_Inactive(i_session - 1)).*100;
        end
        
    end

elseif Opts.ClusteringMethod == 3
    Inactive_Tag = 0;
    Unspecific_Tag = 1;
    Awake_Tag = 2;
    AwakeREM_Tag = 3;
    REM_Tag = 4;
    REM_NREM_Tag = 5;
    NREM_Tag = 6;
    AwakeNREM_Tag = 7;
    
    Cells_Evolution_SelectedSessions = CellTags_EvolutionMatrix(:, Sessions_Num);
    
    session_counter = 1:n_sessions;
    for i_session = 1:n_sessions
        % Compute numbers and specificity
        CellsTag_CurrentSession = Cells_Evolution_SelectedSessions(:, session_counter(i_session));
        [indexes_Unspecific{i_session}, ~] = find(CellsTag_CurrentSession == Unspecific_Tag);
        [indexes_Inactive{i_session}, ~] = find(CellsTag_CurrentSession == Inactive_Tag);
        [indexes_Awake{i_session}, ~] = find(CellsTag_CurrentSession == Awake_Tag);
        [indexes_NREM{i_session}, ~] = find(CellsTag_CurrentSession == NREM_Tag);
        [indexes_REM{i_session}, ~] = find(CellsTag_CurrentSession == REM_Tag);
        [indexes_Awake_REM{i_session}, ~] = find(CellsTag_CurrentSession == AwakeREM_Tag);
        [indexes_Awake_NREM{i_session}, ~] = find(CellsTag_CurrentSession == AwakeNREM_Tag);
        [indexes_REM_NREM{i_session}, ~] = find(CellsTag_CurrentSession == REM_NREM_Tag);
        
        n_Inactive(i_session) = numel(indexes_Inactive{i_session});
        n_Unspecific(i_session) = numel(indexes_Unspecific{i_session});
        n_Awake(i_session) = numel(indexes_Awake{i_session});
        n_NREM(i_session) = numel(indexes_NREM{i_session});
        n_REM(i_session) = numel(indexes_REM{i_session});
        n_Awake_REM(i_session) = numel(indexes_Awake_REM{i_session});
        n_Awake_NREM(i_session) = numel(indexes_Awake_NREM{i_session});
        n_REM_NREM(i_session) = numel(indexes_REM_NREM{i_session});
        
        % Compute Variations between the two consecutive sessions
        if i_session > 1
            Inactive_Post_State = CellsTag_CurrentSession(indexes_Inactive{i_session - 1});
            Unspecific_Post_State = CellsTag_CurrentSession(indexes_Unspecific{i_session - 1});
            Awake_Post_State = CellsTag_CurrentSession(indexes_Awake{i_session - 1});
            NREM_Post_State = CellsTag_CurrentSession(indexes_NREM{i_session - 1});
            REM_Post_State = CellsTag_CurrentSession(indexes_REM{i_session - 1});
            Awake_REM_Post_State = CellsTag_CurrentSession(indexes_Awake_REM{i_session - 1});
            Awake_NREM_Post_State = CellsTag_CurrentSession(indexes_Awake_NREM{i_session - 1});
            REM_NREM_Post_State = CellsTag_CurrentSession(indexes_REM_NREM{i_session - 1});
            
            % Compute Variations between the first two sessions
            Variations(i_session - 1).Awake2Inactive = numel(find(Awake_Post_State == Inactive_Tag));
            Variations(i_session - 1).Awake2Unspecific = numel(find(Awake_Post_State == Unspecific_Tag));
            Variations(i_session - 1).Awake2Awake = numel(find(Awake_Post_State == Awake_Tag));
            Variations(i_session - 1).Awake2NREM = numel(find(Awake_Post_State == NREM_Tag));
            Variations(i_session - 1).Awake2REM = numel(find(Awake_Post_State == REM_Tag));
            Variations(i_session - 1).Awake2Awake_REM = numel(find(Awake_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).Awake2Awake_NREM = numel(find(Awake_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).Awake2REM_NREM = numel(find(Awake_Post_State == REM_NREM_Tag));

            Variations(i_session - 1).NREM2Inactive = numel(find(NREM_Post_State == Inactive_Tag));
            Variations(i_session - 1).NREM2Unspecific = numel(find(NREM_Post_State == Unspecific_Tag));
            Variations(i_session - 1).NREM2Awake = numel(find(NREM_Post_State == Awake_Tag));
            Variations(i_session - 1).NREM2NREM = numel(find(NREM_Post_State == NREM_Tag));
            Variations(i_session - 1).NREM2REM = numel(find(NREM_Post_State == REM_Tag));
            Variations(i_session - 1).NREM2Awake_REM = numel(find(NREM_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).NREM2Awake_NREM = numel(find(NREM_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).NREM2REM_NREM = numel(find(NREM_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).REM2Inactive = numel(find(REM_Post_State == Inactive_Tag));
            Variations(i_session - 1).REM2Unspecific = numel(find(REM_Post_State == Unspecific_Tag));
            Variations(i_session - 1).REM2Awake = numel(find(REM_Post_State == Awake_Tag));
            Variations(i_session - 1).REM2NREM = numel(find(REM_Post_State == NREM_Tag));
            Variations(i_session - 1).REM2REM = numel(find(REM_Post_State == REM_Tag));
            Variations(i_session - 1).REM2Awake_REM = numel(find(REM_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).REM2Awake_NREM = numel(find(REM_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).REM2REM_NREM = numel(find(REM_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).Inactive2Inactive = numel(find(Inactive_Post_State == Inactive_Tag));
            Variations(i_session - 1).Inactive2Unspecific = numel(find(Inactive_Post_State == Unspecific_Tag));
            Variations(i_session - 1).Inactive2Awake = numel(find(Inactive_Post_State == Awake_Tag));
            Variations(i_session - 1).Inactive2NREM = numel(find(Inactive_Post_State == NREM_Tag));
            Variations(i_session - 1).Inactive2REM = numel(find(Inactive_Post_State == REM_Tag));
            Variations(i_session - 1).Inactive2Awake_REM = numel(find(Inactive_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).Inactive2Awake_NREM = numel(find(Inactive_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).Inactive2REM_NREM = numel(find(Inactive_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).Unspecific2Inactive = numel(find(Unspecific_Post_State == Inactive_Tag));
            Variations(i_session - 1).Unspecific2Unspecific = numel(find(Unspecific_Post_State == Unspecific_Tag));
            Variations(i_session - 1).Unspecific2Awake = numel(find(Unspecific_Post_State == Awake_Tag));
            Variations(i_session - 1).Unspecific2NREM = numel(find(Unspecific_Post_State == NREM_Tag));
            Variations(i_session - 1).Unspecific2REM = numel(find(Unspecific_Post_State == REM_Tag));
            Variations(i_session - 1).Unspecific2Awake_REM = numel(find(Unspecific_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).Unspecific2Awake_NREM = numel(find(Unspecific_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).Unspecific2REM_NREM = numel(find(Unspecific_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).Awake_REM2Inactive = numel(find(Awake_REM_Post_State == Inactive_Tag));
            Variations(i_session - 1).Awake_REM2Unspecific = numel(find(Awake_REM_Post_State == Unspecific_Tag));
            Variations(i_session - 1).Awake_REM2Awake = numel(find(Awake_REM_Post_State == Awake_Tag));
            Variations(i_session - 1).Awake_REM2NREM = numel(find(Awake_REM_Post_State == NREM_Tag));
            Variations(i_session - 1).Awake_REM2REM = numel(find(Awake_REM_Post_State == REM_Tag));
            Variations(i_session - 1).Awake_REM2Awake_REM = numel(find(Awake_REM_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).Awake_REM2Awake_NREM = numel(find(Awake_REM_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).Awake_REM2REM_NREM = numel(find(Awake_REM_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).Awake_NREM2Inactive = numel(find(Awake_NREM_Post_State == Inactive_Tag));
            Variations(i_session - 1).Awake_NREM2Unspecific = numel(find(Awake_NREM_Post_State == Unspecific_Tag));
            Variations(i_session - 1).Awake_NREM2Awake = numel(find(Awake_NREM_Post_State == Awake_Tag));
            Variations(i_session - 1).Awake_NREM2NREM = numel(find(Awake_NREM_Post_State == NREM_Tag));
            Variations(i_session - 1).Awake_NREM2REM = numel(find(Awake_NREM_Post_State == REM_Tag));
            Variations(i_session - 1).Awake_NREM2Awake_REM = numel(find(Awake_NREM_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).Awake_NREM2Awake_NREM = numel(find(Awake_NREM_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).Awake_NREM2REM_NREM = numel(find(Awake_NREM_Post_State == REM_NREM_Tag));
            
            Variations(i_session - 1).REM_NREM2Inactive = numel(find(REM_NREM_Post_State == Inactive_Tag));
            Variations(i_session - 1).REM_NREM2Unspecific = numel(find(REM_NREM_Post_State == Unspecific_Tag));
            Variations(i_session - 1).REM_NREM2Awake = numel(find(REM_NREM_Post_State == Awake_Tag));
            Variations(i_session - 1).REM_NREM2NREM = numel(find(REM_NREM_Post_State == NREM_Tag));
            Variations(i_session - 1).REM_NREM2REM = numel(find(REM_NREM_Post_State == REM_Tag));
            Variations(i_session - 1).REM_NREM2Awake_REM = numel(find(REM_NREM_Post_State == AwakeREM_Tag));
            Variations(i_session - 1).REM_NREM2Awake_NREM = numel(find(REM_NREM_Post_State == AwakeNREM_Tag));
            Variations(i_session - 1).REM_NREM2REM_NREM = numel(find(REM_NREM_Post_State == REM_NREM_Tag));
            
            VariationsPercentage(i_session - 1).Awake2Inactive = (Variations(i_session - 1).Awake2Inactive./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2Unspecific = (Variations(i_session - 1).Awake2Unspecific./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2Awake = (Variations(i_session - 1).Awake2Awake./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2NREM = (Variations(i_session - 1).Awake2NREM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2REM = (Variations(i_session - 1).Awake2REM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2Awake_REM = (Variations(i_session - 1).Awake2Awake_REM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2Awake_NREM = (Variations(i_session - 1).Awake2Awake_NREM./n_Awake(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake2REM_NREM = (Variations(i_session - 1).Awake2REM_NREM./n_Awake(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).NREM2Inactive = (Variations(i_session - 1).NREM2Inactive./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Unspecific = (Variations(i_session - 1).NREM2Unspecific./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Awake = (Variations(i_session - 1).NREM2Awake./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2NREM = (Variations(i_session - 1).NREM2NREM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2REM = (Variations(i_session - 1).NREM2REM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Awake_REM = (Variations(i_session - 1).NREM2Awake_REM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2Awake_NREM = (Variations(i_session - 1).NREM2Awake_NREM./n_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).NREM2REM_NREM = (Variations(i_session - 1).NREM2REM_NREM./n_NREM(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).REM2Inactive = (Variations(i_session - 1).REM2Inactive./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Unspecific = (Variations(i_session - 1).REM2Unspecific./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Awake = (Variations(i_session - 1).REM2Awake./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2NREM = (Variations(i_session - 1).REM2NREM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2REM = (Variations(i_session - 1).REM2REM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Awake_REM = (Variations(i_session - 1).REM2Awake_REM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2Awake_NREM = (Variations(i_session - 1).REM2Awake_NREM./n_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM2REM_NREM = (Variations(i_session - 1).REM2REM_NREM./n_REM(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).Inactive2Inactive = (Variations(i_session - 1).Inactive2Inactive./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Unspecific = (Variations(i_session - 1).Inactive2Unspecific./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Awake = (Variations(i_session - 1).Inactive2Awake./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2NREM = (Variations(i_session - 1).Inactive2NREM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2REM = (Variations(i_session - 1).Inactive2REM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Awake_REM = (Variations(i_session - 1).Inactive2Awake_REM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2Awake_NREM = (Variations(i_session - 1).Inactive2Awake_NREM./n_Inactive(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Inactive2REM_NREM = (Variations(i_session - 1).Inactive2REM_NREM./n_Inactive(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).Unspecific2Inactive = (Variations(i_session - 1).Unspecific2Inactive./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2Unspecific = (Variations(i_session - 1).Unspecific2Unspecific./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2Awake = (Variations(i_session - 1).Unspecific2Awake./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2NREM = (Variations(i_session - 1).Unspecific2NREM./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2REM = (Variations(i_session - 1).Unspecific2REM./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2Awake_REM = (Variations(i_session - 1).Unspecific2Awake_REM./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2Awake_NREM = (Variations(i_session - 1).Unspecific2Awake_NREM./n_Unspecific(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Unspecific2REM_NREM = (Variations(i_session - 1).Unspecific2REM_NREM./n_Unspecific(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).Awake_REM2Inactive = (Variations(i_session - 1).Awake_REM2Inactive./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2Unspecific = (Variations(i_session - 1).Awake_REM2Unspecific./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2Awake = (Variations(i_session - 1).Awake_REM2Awake./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2NREM = (Variations(i_session - 1).Awake_REM2NREM./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2REM = (Variations(i_session - 1).Awake_REM2REM./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2Awake_REM = (Variations(i_session - 1).Awake_REM2Awake_REM./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2Awake_NREM = (Variations(i_session - 1).Awake_REM2Awake_NREM./n_Awake_REM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_REM2REM_NREM = (Variations(i_session - 1).Awake_REM2REM_NREM./n_Awake_REM(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).Awake_NREM2Inactive = (Variations(i_session - 1).Awake_NREM2Inactive./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2Unspecific = (Variations(i_session - 1).Awake_NREM2Unspecific./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2Awake = (Variations(i_session - 1).Awake_NREM2Awake./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2NREM = (Variations(i_session - 1).Awake_NREM2NREM./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2REM = (Variations(i_session - 1).Awake_NREM2REM./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2Awake_REM = (Variations(i_session - 1).Awake_NREM2Awake_REM./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2Awake_NREM = (Variations(i_session - 1).Awake_NREM2Awake_NREM./n_Awake_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).Awake_NREM2REM_NREM = (Variations(i_session - 1).Awake_NREM2REM_NREM./n_Awake_NREM(i_session - 1)).*100;
            
            VariationsPercentage(i_session - 1).REM_NREM2Inactive = (Variations(i_session - 1).REM_NREM2Inactive./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2Unspecific = (Variations(i_session - 1).REM_NREM2Unspecific./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2Awake = (Variations(i_session - 1).REM_NREM2Awake./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2NREM = (Variations(i_session - 1).REM_NREM2NREM./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2REM = (Variations(i_session - 1).REM_NREM2REM./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2Awake_REM = (Variations(i_session - 1).REM_NREM2Awake_REM./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2Awake_NREM = (Variations(i_session - 1).REM_NREM2Awake_NREM./n_REM_NREM(i_session - 1)).*100;
            VariationsPercentage(i_session - 1).REM_NREM2REM_NREM = (Variations(i_session - 1).REM_NREM2REM_NREM./n_REM_NREM(i_session - 1)).*100;
        end
        
    end
end



clear Data*
%% Load Data for Plot
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    Data_Left = cell(n_sessions - 1, 1);
    Data_Right = cell(n_sessions - 1, 1);
    Data_Left{1} = [n_Awake(1), n_NREM(1), n_REM(1), n_Inactive(1)];
    for i_session = 2:n_sessions - 1
        % Data of the left panel in each block
        Data_Left{i_session} = [n_Awake(i_session), n_NREM(i_session), n_REM(i_session), n_Inactive(i_session)];
        % Data of the Right panel in each block
        Data_Right{i_session - 1} = Data_Left{i_session};
        Data_Right{i_session} = [n_Awake(i_session + 1), n_NREM(i_session + 1), n_REM(i_session + 1), n_Inactive(i_session + 1)];
    end
    
    % Data of flows in each block
    for i_flow = 1:n_sessions - 1
        Data_Flow{i_flow}=[Variations(i_flow).Awake2Awake, Variations(i_flow).Awake2NREM, Variations(i_flow).Awake2REM, Variations(i_flow).Awake2Inactive; ...
            Variations(i_flow).NREM2Awake, Variations(i_flow).NREM2NREM, Variations(i_flow).NREM2REM, Variations(i_flow).NREM2Inactive; ...
            Variations(i_flow).REM2Awake, Variations(i_flow).REM2NREM, Variations(i_flow).REM2REM, Variations(i_flow).REM2Inactive; ...
            Variations(i_flow).Inactive2Awake, Variations(i_flow).Inactive2NREM, Variations(i_flow).Inactive2REM, Variations(i_flow).Inactive2Inactive];
    end
    
elseif Opts.ClusteringMethod == 3
    Data_Left = cell(n_sessions - 1, 1);
    Data_Right = cell(n_sessions - 1, 1);
    Data_Left{1} = [n_Awake(1), n_Awake_REM(1), n_REM(1), n_REM_NREM(1), n_NREM(1), n_Awake_NREM(1), n_Unspecific(1), n_Inactive(1)];
    for i_session = 2:n_sessions - 1
        % Data of the left panel in each block
        Data_Left{i_session} = [n_Awake(i_session), n_Awake_REM(i_session), n_REM(i_session), n_REM_NREM(i_session), n_NREM(i_session), n_Awake_NREM(i_session), n_Unspecific(i_session), n_Inactive(i_session)];
        % Data of the Right panel in each block
        Data_Right{i_session - 1} = Data_Left{i_session};
        Data_Right{i_session} = [n_Awake(i_session + 1), n_Awake_REM(i_session + 1), n_REM(i_session + 1), n_REM_NREM(i_session + 1), n_NREM(i_session + 1), n_Awake_NREM(i_session + 1), n_Unspecific(i_session + 1), n_Inactive(i_session + 1)];
    end
    
    % Data of flows in each block
    for i_flow = 1:n_sessions - 1
        Data_Flow{i_flow}=[Variations(i_flow).Awake2Awake, Variations(i_flow).Awake2Awake_REM, Variations(i_flow).Awake2REM, Variations(i_flow).Awake2REM_NREM, Variations(i_flow).Awake2NREM, Variations(i_flow).Awake2Awake_NREM, Variations(i_flow).Awake2Unspecific, Variations(i_flow).Awake2Inactive; ...
            Variations(i_flow).Awake_REM2Awake, Variations(i_flow).Awake_REM2Awake_REM, Variations(i_flow).Awake_REM2REM, Variations(i_flow).Awake_REM2REM_NREM, Variations(i_flow).Awake_REM2NREM, Variations(i_flow).Awake_REM2Awake_NREM, Variations(i_flow).Awake_REM2Unspecific, Variations(i_flow).Awake_REM2Inactive; ...
            Variations(i_flow).REM2Awake, Variations(i_flow).REM2Awake_REM, Variations(i_flow).REM2REM, Variations(i_flow).REM2REM_NREM, Variations(i_flow).REM2NREM, Variations(i_flow).REM2Awake_NREM, Variations(i_flow).REM2Unspecific, Variations(i_flow).REM2Inactive; ...
            Variations(i_flow).REM_NREM2Awake, Variations(i_flow).REM_NREM2Awake_REM, Variations(i_flow).REM_NREM2REM, Variations(i_flow).REM_NREM2REM_NREM, Variations(i_flow).REM_NREM2NREM, Variations(i_flow).REM_NREM2Awake_NREM, Variations(i_flow).REM_NREM2Unspecific, Variations(i_flow).REM_NREM2Inactive; ...
            Variations(i_flow).NREM2Awake, Variations(i_flow).NREM2Awake_REM, Variations(i_flow).NREM2REM, Variations(i_flow).NREM2REM_NREM, Variations(i_flow).NREM2NREM, Variations(i_flow).NREM2Awake_NREM, Variations(i_flow).NREM2Unspecific, Variations(i_flow).NREM2Inactive; ...
            Variations(i_flow).Awake_NREM2Awake, Variations(i_flow).Awake_NREM2Awake_REM, Variations(i_flow).Awake_NREM2REM, Variations(i_flow).Awake_NREM2REM_NREM, Variations(i_flow).Awake_NREM2NREM, Variations(i_flow).Awake_NREM2Awake_NREM, Variations(i_flow).Awake_NREM2Unspecific, Variations(i_flow).Awake_NREM2Inactive; ...
            Variations(i_flow).Unspecific2Awake, Variations(i_flow).Unspecific2Awake_REM, Variations(i_flow).Unspecific2REM, Variations(i_flow).Unspecific2REM_NREM, Variations(i_flow).Unspecific2NREM, Variations(i_flow).Unspecific2Awake_NREM, Variations(i_flow).Unspecific2Unspecific, Variations(i_flow).Unspecific2Inactive; ...
            Variations(i_flow).Inactive2Awake, Variations(i_flow).Inactive2Awake_REM, Variations(i_flow).Inactive2REM, Variations(i_flow).Inactive2REM_NREM, Variations(i_flow).Inactive2NREM, Variations(i_flow).Inactive2Awake_NREM, Variations(i_flow).Inactive2Unspecific, Variations(i_flow).Inactive2Inactive];
    end
end



%% Plot Options
% X-axis
X = 0:1:n_sessions;

% Panel colors
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    PanelColors_Default = [0 0 1; 1 0 0; 0 1 0; 0 0 0]; % Awake, NREM, REM, Unspecific
elseif Opts.ClusteringMethod == 3
    PanelColors_Default = [0 0 1; 0 1 1; 0 1 0; 1 1 0; 1 0 0; 1 0 1; 0.2 0.2 0.2; 0 0 0]; % Awake, AwakeREM, REM, REMNREM, NREM, AwakeNREM, Unspecific, Inactive
end
barcolors = cell(n_sessions, 1);
for i_session = 1:n_sessions
    barcolors{i_session}= PanelColors_Default;
end

% Flow Color
Flow_Color = [.5 .7 .7];

% Panel width
Panels_Width = 25;


%% Plot
figure('units','normalized','outerposition',[0 0 1 1]);

for j = 1:n_sessions - 1
    if j > 1
        ymax = max(ymax,sankey_yheight(Data_Left{j-1},Data_Right{j-1}));
        y1_category_points = sankey_alluvialflow(Data_Left{j}, Data_Right{j}, Data_Flow{j}, X(j), X(j+1), y1_category_points,ymax,barcolors{j},barcolors{j+1},Panels_Width,Flow_Color);
    else
        y1_category_points = [];
        ymax = sankey_yheight(Data_Left{j},Data_Right{j});
        y1_category_points = sankey_alluvialflow(Data_Left{j}, Data_Right{j}, Data_Flow{j}, X(j), X(j+1), y1_category_points,ymax,barcolors{j},barcolors{j+1},Panels_Width,Flow_Color);
    end
end

axis on
ax = gca;
ax.Color = 'none';
ax.YAxis.Visible = 'off';
ax.Color = 'none';
ax.FontName = 'Arial';
ax.FontSize = 14;
xticks(X)

xticklabels(ticklabels_array);


%% Save
if Opts.SaveFiguresAutomatically == 1
    % FileName = 'Figure Cells Clustered per State';
    FileName = sprintf('%s - Population Flow Plot - Clustering Method %d - Clustering Variable %s - %s', Opts.CellType, Opts.ClusteringMethod, Opts.ClusteringVariable, title_txt);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

