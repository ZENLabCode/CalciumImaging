function CellNumTag = Arrange_CellTags (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts)



CellTag_perMouse_1 = CellTag_perMouse_1';
CellTag_perMouse_2 = CellTag_perMouse_2';
CellTag_perMouse_3 = CellTag_perMouse_3';

CellsTagAll_1 = cell(0);
for i = 1:numel(CellTag_perMouse_1)
    CellsTagAll_1 = [CellsTagAll_1; CellTag_perMouse_1{i}];
end

CellsTagAll_2 = cell(0);
for i = 1:numel(CellTag_perMouse_2)
    CellsTagAll_2 = [CellsTagAll_2; CellTag_perMouse_2{i}];
end

CellsTagAll_3 = cell(0);
for i = 1:numel(CellTag_perMouse_3)
    CellsTagAll_3 = [CellsTagAll_3; CellTag_perMouse_3{i}];
end

try
    CellsTagAll(:, 1) = CellsTagAll_1;
catch
    warning('A cell is missing from some condition')
end

n_cells = numel(CellsTagAll_1);

try
    CellsTagAll(:, 2) = CellsTagAll_2;
catch
    warning('A cell is missing from some condition')
    [dim1, ~] = size(CellsTagAll);
    if numel(CellsTagAll_2) > dim1
        CellsTagAll_2(end) = [];
    elseif numel(CellsTagAll_2) < dim1
        CellsTagAll(end, :) = [];
        n_cells = n_cells - 1;
    end
    try
        CellsTagAll(:, 2) = CellsTagAll_2;
    catch
        keyboard
    end
end

try
    CellsTagAll(:, 3) = CellsTagAll_3;
catch
    warning('A cell is missing from some condition')
    [dim1, ~] = size(CellsTagAll);
    if numel(CellsTagAll_3) > dim1
        CellsTagAll_3(end) = [];
    elseif numel(CellsTagAll_3) < dim1
        CellsTagAll(end, :) = [];
        n_cells = n_cells - 1;
    end
    CellsTagAll(:, 3) = CellsTagAll_3;
end


[n_cells, ~] = size(CellsTagAll);
CellNumTag = NaN(n_cells, 3);
for i = 1:n_cells
    try
        if strcmpi(CellsTagAll(i, 1), 'Awake')
            CellNumTag(i, 1) = 1;
        end
    catch
        keyboard
    end
    if strcmpi(CellsTagAll(i, 1), 'NREM')
        CellNumTag(i, 1) = 2;
    end
    if strcmpi(CellsTagAll(i, 1), 'REM')
        CellNumTag(i, 1) = 4;
    end
    if strcmpi(CellsTagAll(i, 1), 'None')
        CellNumTag(i, 1) = 0;
    end
    if strcmpi(CellsTagAll(i, 1), 'Not State Selective')
        CellNumTag(i, 1) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 2), 'Awake')
        CellNumTag(i, 2) = 1;
    end
    if strcmpi(CellsTagAll(i, 2), 'NREM')
        CellNumTag(i, 2) = 2;
    end
    if strcmpi(CellsTagAll(i, 2), 'REM')
        CellNumTag(i, 2) = 4;
    end
    if strcmpi(CellsTagAll(i, 2), 'None')
        CellNumTag(i, 2) = 0;
    end
    if strcmpi(CellsTagAll(i, 2), 'Not State Selective')
        CellNumTag(i, 2) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 3), 'Awake')
        CellNumTag(i, 3) = 1;
    end
    if strcmpi(CellsTagAll(i, 3), 'NREM')
        CellNumTag(i, 3) = 2;
    end
    if strcmpi(CellsTagAll(i, 3), 'REM')
        CellNumTag(i, 3) = 4;
    end
    if strcmpi(CellsTagAll(i, 3), 'None')
        CellNumTag(i, 3) = 0;
    end
    if strcmpi(CellsTagAll(i, 3), 'Not State Selective')
        CellNumTag(i, 3) = 5;
    end
end
