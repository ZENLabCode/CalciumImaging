function plot_Sanesky (CellTags_EvolutionMatrix)

Sessions_Num = [1, 2, 3];
n_sessions = numel(Sessions_Num);

keyboard
% Tags:
% None = 0
% Awake = 5
% NREM = 6
% REM = 7

Awake_Tag = 1;
NREM_Tag = 2;
REM_Tag = 4;
Unspecific_Tag = 0;

% Convert?
CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 5) = Awake_Tag;
CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 6) = NREM_Tag;
CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 7) = REM_Tag;
CellTags_EvolutionMatrix(CellTags_EvolutionMatrix == 0) = Unspecific_Tag;

Cells_Evolution_SelectedSessions = CellTags_EvolutionMatrix(:, Sessions_Num);

% Compute numbers and specificity for the 1st Session
CellsTag_CurrentSession = Cells_Evolution_SelectedSessions(:, Sessions_Num(1));
% CellsTag_CurrentSession = CellNumTag(:, 1);

[indexes_Awake{1}, ~] = find(CellsTag_CurrentSession == Awake_Tag);
[indexes_NREM{1}, ~] = find(CellsTag_CurrentSession == NREM_Tag);
[indexes_REM{1}, ~] = find(CellsTag_CurrentSession == REM_Tag);
[indexes_Unspecific{1}, ~] = find(CellsTag_CurrentSession == Unspecific_Tag);

n_Awake(1) = numel(indexes_Awake{1});
n_NREM(1) = numel(indexes_NREM{1});
n_REM(1) = numel(indexes_REM{1});
n_Unspecific(1) = numel(indexes_Unspecific{1});

% Compute numbers and specificity for the 2nd Session
CellsTag_CurrentSession = Cells_Evolution_SelectedSessions(:, Sessions_Num(2));

[indexes_Awake{2},~] = find(CellsTag_CurrentSession == Awake_Tag);
[indexes_NREM{2},~] = find(CellsTag_CurrentSession == NREM_Tag);
[indexes_REM{2},~] = find(CellsTag_CurrentSession == REM_Tag);
[indexes_Unspecific{2},~] = find(CellsTag_CurrentSession == Unspecific_Tag);

n_Awake(2) = numel(indexes_Awake{2});
n_NREM(2) = numel(indexes_NREM{2});
n_REM(2) = numel(indexes_REM{2});
n_Unspecific(2) = numel(indexes_Unspecific{2});

Awake_Post_State = CellsTag_CurrentSession(indexes_Awake{1});
NREM_Post_State = CellsTag_CurrentSession(indexes_NREM{1});
REM_Post_State = CellsTag_CurrentSession(indexes_REM{1});
Unspecific_Post_State = CellsTag_CurrentSession(indexes_Unspecific{1});

% Compute Variations between the first two sessions
Variations(1).Awake2Awake = numel(find(Awake_Post_State == Awake_Tag));
Variations(1).Awake2NREM = numel(find(Awake_Post_State == NREM_Tag));
Variations(1).Awake2REM = numel(find(Awake_Post_State == REM_Tag));
Variations(1).Awake2Unspecific = numel(find(Awake_Post_State == Unspecific_Tag));
Variations(1).NREM2Awake = numel(find(NREM_Post_State == Awake_Tag));
Variations(1).NREM2NREM = numel(find(NREM_Post_State == NREM_Tag));
Variations(1).NREM2REM = numel(find(NREM_Post_State == REM_Tag));
Variations(1).NREM2Unspecific = numel(find(NREM_Post_State == Unspecific_Tag));
Variations(1).REM2Awake = numel(find(REM_Post_State == Awake_Tag));
Variations(1).REM2NREM = numel(find(REM_Post_State == NREM_Tag));
Variations(1).REM2REM = numel(find(REM_Post_State == REM_Tag));
Variations(1).REM2Unspecific = numel(find(REM_Post_State == Unspecific_Tag));
Variations(1).Unspecific2Awake = numel(find(Unspecific_Post_State == Awake_Tag));
Variations(1).Unspecific2NREM = numel(find(Unspecific_Post_State == NREM_Tag));
Variations(1).Unspecific2REM = numel(find(Unspecific_Post_State == REM_Tag));
Variations(1).Unspecific2Unspecific = numel(find(Unspecific_Post_State == Unspecific_Tag));

VariationsPercentage(1).Awake2Awake = (Variations(1).Awake2Awake./n_Awake(1)).*100;
VariationsPercentage(1).Awake2NREM = (Variations(1).Awake2NREM./n_Awake(1)).*100;
VariationsPercentage(1).Awake2REM = (Variations(1).Awake2REM./n_Awake(1)).*100;
VariationsPercentage(1).Awake2Unspecific = (Variations(1).Awake2Unspecific./n_Awake(1)).*100;
VariationsPercentage(1).NREM2Awake = (Variations(1).NREM2Awake./n_NREM(1)).*100;
VariationsPercentage(1).NREM2NREM = (Variations(1).NREM2NREM./n_NREM(1)).*100;
VariationsPercentage(1).NREM2REM = (Variations(1).NREM2REM./n_NREM(1)).*100;
VariationsPercentage(1).NREM2Unspecific = (Variations(1).NREM2Unspecific./n_NREM(1)).*100;
VariationsPercentage(1).REM2Awake = (Variations(1).REM2Awake./n_REM(1)).*100;
VariationsPercentage(1).REM2NREM = (Variations(1).REM2NREM./n_REM(1)).*100;
VariationsPercentage(1).REM2REM = (Variations(1).REM2REM./n_REM(1)).*100;
VariationsPercentage(1).REM2Unspecific = (Variations(1).REM2Unspecific./n_REM(1)).*100;
VariationsPercentage(1).Unspecific2Awake = (Variations(1).Unspecific2Awake./n_Unspecific(1)).*100;
VariationsPercentage(1).Unspecific2NREM = (Variations(1).Unspecific2NREM./n_Unspecific(1)).*100;
VariationsPercentage(1).Unspecific2REM = (Variations(1).Unspecific2REM./n_Unspecific(1)).*100;
VariationsPercentage(1).Unspecific2Unspecific = (Variations(1).Unspecific2Unspecific./n_Unspecific(1)).*100;

% Compute numbers and specificity for the 3rd Session
CellsTag_CurrentSession = Cells_Evolution_SelectedSessions(:, Sessions_Num(3));

[indexes_Awake{3},~] = find(CellsTag_CurrentSession == Awake_Tag);
[indexes_NREM{3},~] = find(CellsTag_CurrentSession == NREM_Tag);
[indexes_REM{3},~] = find(CellsTag_CurrentSession == REM_Tag);
[indexes_Unspecific{3},~] = find(CellsTag_CurrentSession == Unspecific_Tag);

n_Awake(3) = numel(indexes_Awake{3});
n_NREM(3) = numel(indexes_NREM{3});
n_REM(3) = numel(indexes_REM{3});
n_Unspecific(3) = numel(indexes_Unspecific{3});

Awake_Post_State = CellsTag_CurrentSession(indexes_Awake{2});
NREM_Post_State = CellsTag_CurrentSession(indexes_NREM{2});
REM_Post_State = CellsTag_CurrentSession(indexes_REM{2});
Unspecific_Post_State = CellsTag_CurrentSession(indexes_Unspecific{2});

% Compute Variations between the first two sessions
Variations(2).Awake2Awake = numel(find(Awake_Post_State == Awake_Tag));
Variations(2).Awake2NREM = numel(find(Awake_Post_State == NREM_Tag));
Variations(2).Awake2REM = numel(find(Awake_Post_State == REM_Tag));
Variations(2).Awake2Unspecific = numel(find(Awake_Post_State == Unspecific_Tag));
Variations(2).NREM2Awake = numel(find(NREM_Post_State == Awake_Tag));
Variations(2).NREM2NREM = numel(find(NREM_Post_State == NREM_Tag));
Variations(2).NREM2REM = numel(find(NREM_Post_State == REM_Tag));
Variations(2).NREM2Unspecific = numel(find(NREM_Post_State == Unspecific_Tag));
Variations(2).REM2Awake = numel(find(REM_Post_State == Awake_Tag));
Variations(2).REM2NREM = numel(find(REM_Post_State == NREM_Tag));
Variations(2).REM2REM = numel(find(REM_Post_State == REM_Tag));
Variations(2).REM2Unspecific = numel(find(REM_Post_State == Unspecific_Tag));
Variations(2).Unspecific2Awake = numel(find(Unspecific_Post_State == Awake_Tag));
Variations(2).Unspecific2NREM = numel(find(Unspecific_Post_State == NREM_Tag));
Variations(2).Unspecific2REM = numel(find(Unspecific_Post_State == REM_Tag));
Variations(2).Unspecific2Unspecific = numel(find(Unspecific_Post_State == Unspecific_Tag));

VariationsPercentage(2).Awake2Awake = (Variations(2).Awake2Awake./n_Awake(2)).*100;
VariationsPercentage(2).Awake2NREM = (Variations(2).Awake2NREM./n_Awake(2)).*100;
VariationsPercentage(2).Awake2REM = (Variations(2).Awake2REM./n_Awake(2)).*100;
VariationsPercentage(2).Awake2Unspecific = (Variations(2).Awake2Unspecific./n_Awake(2)).*100;
VariationsPercentage(2).NREM2Awake = (Variations(2).NREM2Awake./n_NREM(2)).*100;
VariationsPercentage(2).NREM2NREM = (Variations(2).NREM2NREM./n_NREM(2)).*100;
VariationsPercentage(2).NREM2REM = (Variations(2).NREM2REM./n_NREM(2)).*100;
VariationsPercentage(2).NREM2Unspecific = (Variations(2).NREM2Unspecific./n_NREM(2)).*100;
VariationsPercentage(2).REM2Awake = (Variations(2).REM2Awake./n_REM(2)).*100;
VariationsPercentage(2).REM2NREM = (Variations(2).REM2NREM./n_REM(2)).*100;
VariationsPercentage(2).REM2REM = (Variations(2).REM2REM./n_REM(2)).*100;
VariationsPercentage(2).REM2Unspecific = (Variations(2).REM2Unspecific./n_REM(2)).*100;
VariationsPercentage(2).Unspecific2Awake = (Variations(2).Unspecific2Awake./n_Unspecific(2)).*100;
VariationsPercentage(2).Unspecific2NREM = (Variations(2).Unspecific2NREM./n_Unspecific(2)).*100;
VariationsPercentage(2).Unspecific2REM = (Variations(2).Unspecific2REM./n_Unspecific(2)).*100;
VariationsPercentage(2).Unspecific2Unspecific = (Variations(2).Unspecific2Unspecific./n_Unspecific(2)).*100;

% Data_Left{1} =
% Data_Left{2} =
% Data_Left{3} =

clear Data*

% Example data
% data of the left panel in each block
Data_Left{1} = [n_Awake(1), n_NREM(1), n_REM(1), n_Unspecific(1)];
Data_Left{2} = [n_Awake(2), n_NREM(2), n_REM(2), n_Unspecific(2)];
% Data_Left{3} = [n_Awake(3), n_NREM(3), n_REM(3), n_Unspecific(3)];

% data of the right panel in each block
Data_Right{1} = Data_Left{2};
Data_Right{2} = [n_Awake(3), n_NREM(3), n_REM(3), n_Unspecific(3)];
% Data_Right{3} = [2, 6, 3];

% data of flows in each block
for i_flow = 1:n_sessions - 1
    Data_Flow{i_flow}=[Variations(i_flow).Awake2Awake, Variations(i_flow).Awake2NREM, Variations(i_flow).Awake2REM, Variations(i_flow).Awake2Unspecific; ...
        Variations(i_flow).NREM2Awake, Variations(i_flow).NREM2NREM, Variations(i_flow).NREM2REM, Variations(i_flow).NREM2Unspecific; ...
        Variations(i_flow).REM2Awake, Variations(i_flow).REM2NREM, Variations(i_flow).REM2REM, Variations(i_flow).REM2Unspecific; ...
        Variations(i_flow).Unspecific2Awake, Variations(i_flow).Unspecific2NREM, Variations(i_flow).Unspecific2REM, Variations(i_flow).Unspecific2Unspecific];
    % Data_Flow{3}=[1, 1, 1, 1; 1, 1, 1, 1; 0, 1, 1, 1];
end
% x-axis
X=[0 1 2];

% panel color
PanelColors_Default = [0 0 1; 1 0 0; 0 1 0; 0 0 0];
barcolors{1}= PanelColors_Default;
barcolors{2}= PanelColors_Default;
barcolors{3}= PanelColors_Default;
% barcolors{4}= PanelColors_Default;

% Flow Color
Flow_Color = [.7 .7 .7];

% Panel width
Panels_Width = 25;

figure

for j=1:n_sessions - 1
    if j>1
        ymax=max(ymax,sankey_yheight(Data_Left{j-1},Data_Right{j-1}));
        y1_category_points=sankey_alluvialflow(Data_Left{j}, Data_Right{j}, Data_Flow{j}, X(j), X(j+1), y1_category_points,ymax,barcolors{j},barcolors{j+1},Panels_Width,Flow_Color);
    else
        y1_category_points=[];
        ymax=sankey_yheight(Data_Left{j},Data_Right{j});
        y1_category_points=sankey_alluvialflow(Data_Left{j}, Data_Right{j}, Data_Flow{j}, X(j), X(j+1), y1_category_points,ymax,barcolors{j},barcolors{j+1},Panels_Width,Flow_Color);
    end
end