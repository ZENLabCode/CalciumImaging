function traces_transitions_plot (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts)


n_mice = numel(Mouse_Names);
n_TotalSessions = numel(Hypnogram_AllSessions);

Flag_Highlight_Session = 1; % Highlight a specific session in the plot? (in red)
Transition_Length = 40; % [s]
Transition_Duration = Transition_Length.*Opts.General.FrameRate;


if isfield(Opts, 'HighlightedSession')
    HighlightedSession = Opts.HighlightedSession; % The session to highlight
else
    Flag_Highlight_Session = 0;
end

% Compute for each mouse separately the average Calcium Trace around
% transitions.

for i_mouse = 1:n_mice
    % Get Current Mouse
    Mouse_Name_Current_Mouse = Mouse_Names{i_mouse};
    i_current_session = 0;
    for i_session = 1:n_TotalSessions
        if strcmpi(Hypnogram_AllSessions(i_session).MouseName, Mouse_Name_Current_Mouse)
            i_current_session = i_current_session +1;
            Hypnogram_Current_Mouse(i_current_session) = Hypnogram_AllSessions(i_session);
            CalciumTraces_Current_Mouse{i_current_session} = CalciumTraces_Clean_AllSessions{i_session};
        end
    end
    
    % Consider each Session Separately
    n_sessions = numel(Hypnogram_Current_Mouse);
    for i_session = 1:n_sessions
        Hypnogram_Current_Session = Hypnogram_Current_Mouse(i_session);
        CalciumTraces_Current_Session = CalciumTraces_Current_Mouse{i_session};
        
        % Compute average trace
        CalciumTraces_Mean_Current_Session = nanmean(CalciumTraces_Current_Session, 2);
        RecordingDuration = numel(CalciumTraces_Mean_Current_Session);
        
        % Consider only stable states.
        n_states = numel(Hypnogram_Current_Session.StateDuration);
        StableState_Index = [];
        for i_state = 2:n_states
            if Hypnogram_Current_Session.StateDuration(i_state) >= (Opts.General.MinStableStateDuration)*(Opts.General.FrameRate)
                StableState_Index = [StableState_Index, i_state];
            end
        end
        tmp_Transitions_Array = [Hypnogram_Current_Session.StateChanges];
        tmp_StatesTag_Array = [Hypnogram_Current_Session.StateType];
        StableState_Start_Array = tmp_Transitions_Array(StableState_Index);
        StableState_Tag_Array = tmp_StatesTag_Array(StableState_Index);
        n_transitions = numel(StableState_Start_Array);
        StableStatePrevious_Index_Array = NaN(n_transitions, 1);
        StableStatePrevious_Tag_Array = NaN(n_transitions, 1);
        ToRemove = [];
        for i_state = 1:n_transitions
            if StableState_Start_Array(i_state) <= Transition_Duration + 1 || StableState_Start_Array(i_state) >= RecordingDuration - (Transition_Duration - 1)
                ToRemove = [ToRemove, i_state];
                continue
            end
            if StableState_Index(i_state) > 1
                StableStatePrevious_Index_Array(i_state) = StableState_Index(i_state) - 1;
                StableStatePrevious_Tag_Array(i_state) = tmp_StatesTag_Array(StableState_Index(i_state) - 1);
            end
        end
        % Ignore states that come too early or late in the recordings.
        StableState_Index(ToRemove) = [];
        StableState_Start_Array(ToRemove) = [];
        StableState_Tag_Array(ToRemove) = [];
        StableStatePrevious_Index_Array(ToRemove) = [];
        StableStatePrevious_Tag_Array(ToRemove) = [];
        n_transitions = numel(StableState_Start_Array);
        
        % Get the Traces at each transition
        Transition_Segments_tmp = NaN(n_transitions, (1 + (Transition_Duration*2)));
        Transition_Segments.Awake2NREM = Transition_Segments_tmp;
        Transition_Segments.NREM2REM = Transition_Segments_tmp;
        Transition_Segments.NREM2Awake = Transition_Segments_tmp;
        Transition_Segments.REM2Awake = Transition_Segments_tmp;
        
        for i_state_start = 1:n_transitions
            try
                tmp = CalciumTraces_Mean_Current_Session((StableState_Start_Array(i_state_start) - Transition_Duration):(StableState_Start_Array(i_state_start) + Transition_Duration));
                tmp = tmp - nanmin(tmp); % Subtract the minimum for more comparable data.
                tmp = tmp./nanmax(tmp); % Normalize for more comparable data
                if StableState_Tag_Array(i_state_start) == Opts.General.TagAWAKE
                    if StableStatePrevious_Tag_Array(i_state_start) == 2
                        Transition_Segments.NREM2Awake(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                    elseif StableStatePrevious_Tag_Array(i_state_start) == 4
                        Transition_Segments.REM2Awake(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                    end
                elseif StableState_Tag_Array(i_state_start) == Opts.General.TagNoNREM
                        Transition_Segments.Awake2NREM(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                elseif StableState_Tag_Array(i_state_start) == Opts.General.TagREM
                    Transition_Segments.NREM2REM(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                end
            catch
                keyboard
            end
        end
        
        % Mean over all transitions
        Transition_Segments_Mean_perSession(i_session).Awake2NREM = nanmean(Transition_Segments.Awake2NREM, 1);
        Transition_Segments_Mean_perSession(i_session).NREM2REM = nanmean(Transition_Segments.NREM2REM, 1);
        Transition_Segments_Mean_perSession(i_session).NREM2Awake = nanmean(Transition_Segments.NREM2Awake, 1);
        Transition_Segments_Mean_perSession(i_session).REM2Awake = nanmean(Transition_Segments.REM2Awake, 1);       
        
    end
    Transition_Segments_Mean_perMouse{i_mouse} = Transition_Segments_Mean_perSession;
    
    
    clear Hypnogram_Current_Mouse
    clear CalciumTraces_Current_Mouse
end


% Mean everything per mouse
AllTracesMatrix_Awake2NREM = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_NREM2REM = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_NREM2Awake = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_REM2Awake = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);

for i_session = 1:n_sessions
    for i_mouse = 1:n_mice
        current_mouse_Transitions = Transition_Segments_Mean_perMouse{i_mouse};
        tmp_transitions_Awake2NREM = cell(n_sessions, 1);
        tmp_transitions_NREM2REM = cell(n_sessions, 1);
        tmp_transitions_NREM2Awake = cell(n_sessions, 1);
        tmp_transitions_REM2Awake = cell(n_sessions, 1);
        
        for i = 1:n_sessions
            tmp_transitions_Awake2NREM{i} = current_mouse_Transitions(i).Awake2NREM;
            tmp_transitions_NREM2REM{i} = current_mouse_Transitions(i).NREM2REM;
            tmp_transitions_NREM2Awake{i} = current_mouse_Transitions(i).NREM2Awake;
            tmp_transitions_REM2Awake{i} = current_mouse_Transitions(i).REM2Awake;
        end
        tmp_transitions_Awake2NREM = cell2mat(tmp_transitions_Awake2NREM);
        tmp_transitions_NREM2REM = cell2mat(tmp_transitions_NREM2REM);
        tmp_transitions_NREM2Awake = cell2mat(tmp_transitions_NREM2Awake);
        tmp_transitions_REM2Awake = cell2mat(tmp_transitions_REM2Awake);
        AllTracesMatrix_Awake2NREM(:,:, i_mouse) = tmp_transitions_Awake2NREM;
        AllTracesMatrix_NREM2REM(:,:, i_mouse) = tmp_transitions_NREM2REM;
        AllTracesMatrix_NREM2Awake(:,:, i_mouse) = tmp_transitions_NREM2Awake;
        AllTracesMatrix_REM2Awake(:,:, i_mouse) = tmp_transitions_REM2Awake;
    end
end
Traces_MeansPerMice_Awake2NREM = nanmean(AllTracesMatrix_Awake2NREM, 3);
Traces_MeansPerMice_NREM2REM = nanmean(AllTracesMatrix_NREM2REM, 3);
Traces_MeansPerMice_NREM2Awake = nanmean(AllTracesMatrix_NREM2Awake, 3);
Traces_MeansPerMice_REM2Awake = nanmean(AllTracesMatrix_REM2Awake, 3);

% Put minimum to zero.
for i_session = 1:n_sessions
    Traces_MeansPerMice_Awake2NREM(i_session, :) = Traces_MeansPerMice_Awake2NREM(i_session, :) - nanmin(Traces_MeansPerMice_Awake2NREM(i_session, :));
    Traces_MeansPerMice_NREM2REM(i_session, :) = Traces_MeansPerMice_NREM2REM(i_session, :) - nanmin(Traces_MeansPerMice_NREM2REM(i_session, :));
    Traces_MeansPerMice_NREM2Awake(i_session, :) = Traces_MeansPerMice_NREM2Awake(i_session, :) - nanmin(Traces_MeansPerMice_NREM2Awake(i_session, :));
    Traces_MeansPerMice_REM2Awake(i_session, :) = Traces_MeansPerMice_REM2Awake(i_session, :) - nanmin(Traces_MeansPerMice_REM2Awake(i_session, :));
end

grandavg_Awake2NREM = smooth(nanmean(Traces_MeansPerMice_Awake2NREM, 1));
grandavg_NREM2REM = smooth(nanmean(Traces_MeansPerMice_NREM2REM, 1));
grandavg_NREM2Awake = smooth(nanmean(Traces_MeansPerMice_NREM2Awake, 1));
grandavg_REM2Awake = smooth(nanmean(Traces_MeansPerMice_REM2Awake, 1));


%% Plot 

% Options
Time_Array = (-Transition_Duration:Transition_Duration)./Opts.General.FrameRate; % [s], distance from transition

n_subplot_rows = 1;
n_subplot_columns = 4;
xticks_array = -Transition_Length:5:Transition_Length;
yticks_array = 0:0.2:1;
axis_limits = [-Transition_Length, Transition_Length, 0, 1];
axis_FontSize = 16;
TitleFontSize = 16;
SupTitleFontSize = 26;
GrandMean_LineWidth = 2.5;
figure('units','normalized','outerposition',[0 0 1 1]);

% Awake2NREM
subplot(n_subplot_rows, n_subplot_columns, 1);

hold on;
for i_session = 1:n_sessions
    if i_session == HighlightedSession
        plot(Time_Array, Traces_MeansPerMice_Awake2NREM(i_session, :), 'k')
    else
        plot(Time_Array, Traces_MeansPerMice_Awake2NREM(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_Awake2NREM, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('Wake to NREM', 'FontSize', TitleFontSize)

xlabel('Distance from State Transition [s]')
ylabel('Average \DeltaF/F Normalized')

% NREM2REM
subplot(n_subplot_rows, n_subplot_columns, 2);

hold on;
for i_session = 1:n_sessions
    if Flag_Highlight_Session == 1
        if i_session == HighlightedSession
            plot(Time_Array, Traces_MeansPerMice_NREM2REM(i_session, :), 'r')
        else
            plot(Time_Array, Traces_MeansPerMice_NREM2REM(i_session, :), 'k')
        end
    else
        plot(Time_Array, Traces_MeansPerMice_NREM2REM(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_NREM2REM, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('NREM to REM', 'FontSize', TitleFontSize)

% NREM2Awake
subplot(n_subplot_rows, n_subplot_columns, 3);

hold on;
for i_session = 1:n_sessions
    if Flag_Highlight_Session == 1
        if i_session == HighlightedSession
            plot(Time_Array, Traces_MeansPerMice_NREM2Awake(i_session, :), 'r')
        else
            plot(Time_Array, Traces_MeansPerMice_NREM2Awake(i_session, :), 'k')
        end
    else
        plot(Time_Array, Traces_MeansPerMice_NREM2Awake(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_NREM2Awake, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('NREM to Wake', 'FontSize', TitleFontSize)

% REM2Awake
subplot(n_subplot_rows, n_subplot_columns, 4);

hold on;
for i_session = 1:n_sessions
    if Flag_Highlight_Session == 1
        if i_session == HighlightedSession
            plot(Time_Array, Traces_MeansPerMice_REM2Awake(i_session, :), 'r')
        else
            plot(Time_Array, Traces_MeansPerMice_REM2Awake(i_session, :), 'k')
        end
        plot(Time_Array, Traces_MeansPerMice_REM2Awake(i_session, :), 'k')
    else
    end
end
plot(Time_Array, grandavg_REM2Awake, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('REM to Wake', 'FontSize', TitleFontSize)

suptitle_text = sprintf('%s\nTraces at Transitions for each Recording Session\nAverage over mice.', Opts.CellType);
try
    if verLessThan('matlab','9.5')
        h_suptitle = suptitle(suptitle_text);
        h_suptitle.FontSize = SupTitleFontSize;
        h_suptitle.FontWeight = 'bold';
    else
        h_suptitle = sgtitle(suptitle_text, 'FontSize', SupTitleFontSize, 'FontWeight', 'bold');
    end
catch
    warning ('Could not add suptitle.')
end

%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Traces Transitions Plot', Opts.CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end