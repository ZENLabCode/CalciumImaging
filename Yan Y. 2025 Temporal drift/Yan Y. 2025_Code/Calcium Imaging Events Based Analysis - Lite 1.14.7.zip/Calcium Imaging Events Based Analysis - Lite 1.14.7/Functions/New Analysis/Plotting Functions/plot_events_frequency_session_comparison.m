function plot_events_frequency_session_comparison (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm)

n_rows = 3;
n_columns = 3;

colormax = nanmax([Events_Freq_Matrix_allMice_Baseline_10am; Events_Freq_Matrix_allMice_Baseline_3pm; Events_Freq_Matrix_allMice_Baseline_5pm; Events_Freq_Matrix_allMice_Recovery_10am; Events_Freq_Matrix_allMice_Recovery_3pm; Events_Freq_Matrix_allMice_Recovery_5pm; Events_Freq_Matrix_allMice_SD_12pm; Events_Freq_Matrix_allMice_SD_3pm; Events_Freq_Matrix_allMice_SD_5pm]);
freq_globalmax = nanmax(colormax);
freq_globalmin = 0;
ColorLimits = [freq_globalmin, freq_globalmax];

figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

% Sort stuff according to first state
% Baseline
Events_Freq_Matrix_allMice_Baseline_10am = sortrows(Events_Freq_Matrix_allMice_Baseline_10am, 1, 'descend');
Events_Freq_Matrix_allMice_Baseline_3pm = sortrows(Events_Freq_Matrix_allMice_Baseline_3pm, 1, 'descend');
Events_Freq_Matrix_allMice_Baseline_5pm = sortrows(Events_Freq_Matrix_allMice_Baseline_5pm, 1, 'descend');
% Recovery
Events_Freq_Matrix_allMice_Recovery_10am = sortrows(Events_Freq_Matrix_allMice_Recovery_10am, 1, 'descend');
Events_Freq_Matrix_allMice_Recovery_3pm = sortrows(Events_Freq_Matrix_allMice_Recovery_3pm, 1, 'descend');
Events_Freq_Matrix_allMice_Recovery_5pm = sortrows(Events_Freq_Matrix_allMice_Recovery_5pm, 1, 'descend');
% SD
Events_Freq_Matrix_allMice_SD_12pm = sortrows(Events_Freq_Matrix_allMice_SD_12pm, 1, 'descend');
Events_Freq_Matrix_allMice_SD_3pm = sortrows(Events_Freq_Matrix_allMice_SD_3pm, 1, 'descend');
Events_Freq_Matrix_allMice_SD_5pm = sortrows(Events_Freq_Matrix_allMice_SD_5pm, 1, 'descend');



% First Raw - Morning
subplot(n_rows, n_columns, 1)
imagesc(Events_Freq_Matrix_allMice_Baseline_10am)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Baseline - 10am', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 2)
imagesc(Events_Freq_Matrix_allMice_SD_12pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('SD - 12pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 3)
imagesc(Events_Freq_Matrix_allMice_Recovery_10am)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Recovery - 10am', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_1 = colorbar;
h_colorbar_1.Label.String = 'Events Frequency (Hz)';
h_colorbar_1.Label.FontSize = ColorBar_FontSize;


% Second Raw - 3pm

subplot(n_rows, n_columns, 4)
imagesc(Events_Freq_Matrix_allMice_Baseline_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Baseline - 3pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 5)
imagesc(Events_Freq_Matrix_allMice_SD_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('SD - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 6)
imagesc(Events_Freq_Matrix_allMice_Recovery_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Recovery - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_2 = colorbar;
h_colorbar_2.Label.String = 'Events Frequency (Hz)';
h_colorbar_2.Label.FontSize = ColorBar_FontSize;

% Second Raw - 5pm
subplot(n_rows, n_columns, 7)
imagesc(Events_Freq_Matrix_allMice_Baseline_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Baseline - 5pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 8)
imagesc(Events_Freq_Matrix_allMice_SD_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('SD - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 9)
imagesc(Events_Freq_Matrix_allMice_Recovery_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Recovery - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_3 = colorbar;
h_colorbar_3.Label.String = 'Events Frequency (Hz)';
h_colorbar_3.Label.FontSize = ColorBar_FontSize;

% h_colorbar_2.Visible = 'off';
% h_colorbar_3.Visible = 'off';



h_suptitle = suptitle('Firing Rate per cell over days');
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';