function plot_clustering_continuity (CellTagNum_perMouse, CellType, Opts)

% Clustering Tags
% 0 = Inactive
% 5 = Wake
% 6 = NREM
% 7 = REM


%% Plot Options
FontSizeTitles = 18;
AxisFontSize = 14;
Legend_FontSize = 14;
Plot_1_LineWidth = 2;


%% Initialization
% Get the number of cells per cluster for each Session.
n_sessions = numel(CellTagNum_perMouse);
CellsN = struct('Inactive', NaN, 'Awake', NaN, 'NREM', NaN, 'REM', NaN);
CellsNNorm = struct('Inactive', NaN, 'Awake', NaN, 'NREM', NaN, 'REM', NaN);
for i_Session = 1:n_sessions
    current_session_cells = CellTagNum_perMouse{i_Session};
    n_mice = numel(current_session_cells);
    tmp_CellsN = struct('Inactive', NaN, 'Awake', NaN, 'NREM', NaN, 'REM', NaN);
    tmp_CellsNNorm = struct('Inactive', NaN, 'Awake', NaN, 'NREM', NaN, 'REM', NaN);
    for i_mouse = 1:n_mice
        current_mouse_cells = current_session_cells{i_mouse};
        current_N_cells = numel(current_mouse_cells);
        tmp_CellsN(i_mouse).Inactive = numel(find(current_mouse_cells == 0));
        tmp_CellsN(i_mouse).Awake = numel(find(current_mouse_cells == 5));
        tmp_CellsN(i_mouse).NREM = numel(find(current_mouse_cells == 6));
        tmp_CellsN(i_mouse).REM = numel(find(current_mouse_cells == 7));
        tmp_CellsNNorm(i_mouse).Inactive = ((tmp_CellsN(i_mouse).Inactive)./current_N_cells);
        tmp_CellsNNorm(i_mouse).Awake = ((tmp_CellsN(i_mouse).Awake)./current_N_cells);
        tmp_CellsNNorm(i_mouse).NREM = ((tmp_CellsN(i_mouse).NREM)./current_N_cells);
        tmp_CellsNNorm(i_mouse).REM = ((tmp_CellsN(i_mouse).REM)./current_N_cells);
    end
    CellsN(i_Session).Inactive = nansum([tmp_CellsN.Inactive]);
    CellsN(i_Session).Awake = nansum([tmp_CellsN.Awake]);
    CellsN(i_Session).NREM = nansum([tmp_CellsN.NREM]);
    CellsN(i_Session).REM = nansum([tmp_CellsN.REM]);
    CellsNNorm(i_Session).Inactive = nanmean([tmp_CellsNNorm.Inactive]);
    CellsNNorm(i_Session).Awake = nanmean([tmp_CellsNNorm.Awake]);
    CellsNNorm(i_Session).NREM = nanmean([tmp_CellsNNorm.NREM]);
    CellsNNorm(i_Session).REM = nanmean([tmp_CellsNNorm.REM]);
    CellsNNorm_StE(i_Session).Inactive = nanstd([tmp_CellsNNorm.Inactive])./sqrt(n_mice);
    CellsNNorm_StE(i_Session).Awake = nanstd([tmp_CellsNNorm.Awake])./sqrt(n_mice);
    CellsNNorm_StE(i_Session).NREM = nanstd([tmp_CellsNNorm.NREM])./sqrt(n_mice);
    CellsNNorm_StE(i_Session).REM = nanstd([tmp_CellsNNorm.REM])./sqrt(n_mice);
end

% Prepare the Data Array.


%% Plot 1 - Time Evolution
% Initialize
time_points = 1:n_sessions;
xticks_array = 1:3:n_sessions;
xticklabel_array = {'Day 1', 'Day 2', 'Day 3', 'SD Day', 'Day 5', 'Day 6', 'Day 7'};
legend_items = {'Inactive', 'Awake', 'NREM', 'REM'};
title_str = sprintf('Clusters Composition over time\nAverage per Mouse - %s', CellType);

figure('units','normalized','outerposition',[0 0 1 1]);

% Plot
hold on;
% errorbar([CellsNNorm.Inactive], [CellsNNorm_StE.Inactive], 'k', 'LineWidth', Plot_1_LineWidth)
% errorbar([CellsNNorm.Awake], [CellsNNorm_StE.Awake], 'b', 'LineWidth', Plot_1_LineWidth)
% errorbar([CellsNNorm.NREM], [CellsNNorm_StE.NREM], 'r', 'LineWidth', Plot_1_LineWidth)
% errorbar([CellsNNorm.REM], [CellsNNorm_StE.REM], 'g', 'LineWidth', Plot_1_LineWidth)
plot([CellsNNorm.Inactive], 'k', 'LineWidth', Plot_1_LineWidth)
plot([CellsNNorm.Awake], 'b', 'LineWidth', Plot_1_LineWidth)
plot([CellsNNorm.NREM], 'r', 'LineWidth', Plot_1_LineWidth)
plot([CellsNNorm.REM], 'g', 'LineWidth', Plot_1_LineWidth)

error_Inactive = [([CellsNNorm.Inactive] + [CellsNNorm_StE.Inactive]), (fliplr([CellsNNorm.Inactive] - [CellsNNorm_StE.Inactive]))];
h_filled = fill([time_points, fliplr(time_points)], error_Inactive, 'k');
h_filled.FaceAlpha = 0.4;
error_Awake = [([CellsNNorm.Awake] + [CellsNNorm_StE.Awake]), (fliplr([CellsNNorm.Awake] - [CellsNNorm_StE.Awake]))];
h_filled = fill([time_points, fliplr(time_points)], error_Awake, 'b');
h_filled.FaceAlpha = 0.4;
error_NREM = [([CellsNNorm.NREM] + [CellsNNorm_StE.NREM]), (fliplr([CellsNNorm.NREM] - [CellsNNorm_StE.NREM]))];
h_filled = fill([time_points, fliplr(time_points)], error_NREM, 'r');
h_filled.FaceAlpha = 0.4;
error_REM = [([CellsNNorm.REM] + [CellsNNorm_StE.REM]), (fliplr([CellsNNorm.REM] - [CellsNNorm_StE.REM]))];
h_filled = fill([time_points, fliplr(time_points)], error_REM, 'g');
h_filled.FaceAlpha = 0.4;
hold off;

% Make it pretty
axis([1, 21, 0, 1]);
ax = gca;
ax.FontSize = AxisFontSize; 

xticks(xticks_array)
xticklabels(xticklabel_array);
xlabel('Recording Session')
ylabel('Cluster Population')
grid on; box on;

h_legend = legend(legend_items);
h_legend.FontSize = Legend_FontSize;
title(title_str, 'FontSize', FontSizeTitles);


%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Clusters Evolution Plot 1', CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


% bar(Data, 'stacked')