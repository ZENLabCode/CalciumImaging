function plot_Average_Selectivity_Variation (State_Selectivity_Variation, Opts)



[n_sessions, ~] = size(State_Selectivity_Variation.Mean); 
n_sessions = n_sessions + 1;

%% Plot 1 - Average Selectivity Variation over Sessions
AxisFontSize = 16;
TitleFontSize = 26;
SupTitleFontSize = 26;
Plot_LineWidth = 2.5;

Sessions = 1:n_sessions - 1;
Average_Selectivity_Variation_tmp = State_Selectivity_Variation.Mean;
Average_Selectivity_Variation_StE_tmp = State_Selectivity_Variation.StE;

figure('units','normalized','outerposition',[0 0 1 1]);

hold on;
errorbar(Average_Selectivity_Variation_tmp(:, 1), Average_Selectivity_Variation_StE_tmp(:, 1), 'b', 'LineWidth', Plot_LineWidth);
errorbar(Average_Selectivity_Variation_tmp(:, 2), Average_Selectivity_Variation_StE_tmp(:, 2), 'r', 'LineWidth', Plot_LineWidth);
errorbar(Average_Selectivity_Variation_tmp(:, 3), Average_Selectivity_Variation_StE_tmp(:, 3), 'g', 'LineWidth', Plot_LineWidth);
hold off
ax = gca;
ax.FontSize = AxisFontSize; 

grid on; grid minor; box on; axis square;

title(sprintf('%s - State Selectivity Variation\nAverage per Cell', Opts.CellType), 'FontSize', TitleFontSize)
ylabel('Average Selectivity Variation [Hz]', 'FontSize', 18)
xlabel('Time [Session]', 'FontSize', 18)
xlim([0, n_sessions]);

legend({'Wake', 'NREM', 'REM'})

% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Average State Selectivity over Sessions', Opts.CellType);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Average Activity Variation over Sessions - Integrals Based', Opts.CellType);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

