function plot_IntegralsFreq_Average_TS (IntegralsFrequency_Sessions_Mean, IntegralsFrequency_Sessions_StE, Opts)
% Plots the time series over sessions of the average events frequency over
% different mice.

% Options
FontSizeTitles = 24;
AxisFontSize = 14;
ColorBar_FontSize = 14;
Plot_LineWidth = 2;

Ticks_Array = ([1, 4, 7, 10, 13, 16, 19]);
Ticks_Labels = ({'Day 1','Day 2','Day 3', 'SD', 'Rec 1', 'Rec 2', 'Rec 3'});

[n_sessions, n_states] = size(IntegralsFrequency_Sessions_Mean);

% Figure
figure('units', 'normalized', 'outerposition',[0 0 1 1]);

hold on
% Wake
errorbar(IntegralsFrequency_Sessions_Mean(:, 1), IntegralsFrequency_Sessions_StE(:, 1), 'b', 'LineWidth', Plot_LineWidth);
% NREM
errorbar(IntegralsFrequency_Sessions_Mean(:, 2), IntegralsFrequency_Sessions_StE(:, 2), 'r', 'LineWidth', Plot_LineWidth);
% REM
errorbar(IntegralsFrequency_Sessions_Mean(:, 3), IntegralsFrequency_Sessions_StE(:, 3), 'g', 'LineWidth', Plot_LineWidth);

hold off

ax = gca;
ax.FontSize = AxisFontSize; 
title(sprintf('%s - Integral Frequency - Average over mice', Opts.CellType), 'FontSize', FontSizeTitles)
ylabel('Integrals Frequency [Hz]', 'FontSize', 18)
xlim([0, n_sessions] + 0.5);
grid on; grid minor; box on; axis square;

xticks(Ticks_Array)
xticklabels(Ticks_Labels);

legend({'Wake', 'NREM', 'REM'})

%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Integrals Frequency over Sessions', Opts.CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
