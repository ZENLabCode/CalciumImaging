function plot_all_sessions_averages (CalciumTraces_Clean_AllSessions, Opts)

n_sessions = numel(CalciumTraces_Clean_AllSessions);
plot_LineWidth = 1;

FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

figure('units','normalized','outerposition',[0 0 1 1]);
Session_Average_Array = cell(n_sessions, 1);
for i_session = 1:n_sessions
    subplot(n_sessions, 1, i_session)
    hold on
    Session_Average = nanmean(CalciumTraces_Clean_AllSessions{i_session}, 2);
    Session_Average_smooth = smooth(Session_Average);
    Session_Average_Array{i_session} = Session_Average_smooth;
    [exp_decay_rate{i_session}, exp_decay_multiplier{i_session}, exp_fit_coeff_interval{i_session}, exp_fit_curve{i_session}] = fit_exponential(Session_Average_smooth, Opts.General.FrameRate);
    time_array = 1:numel(Session_Average_smooth);
    decay_curve = exp_decay_multiplier{i_session}.*(time_array.^exp_decay_rate{i_session});
    plot(Session_Average, 'k', 'LineWidth', plot_LineWidth)
    plot(decay_curve, 'r', 'LineWidth', plot_LineWidth)
    box on;
    grid on;
    xlim([0, inf])
    ax = gca;
    ax.FontSize = AxisFontSize;
end

