function traces_transitions_plot_clustering_selective (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, CellTagNum_perMouse, Mouse_Names, StateSelected, Opts)
% This function plots the state transitions, considering only the cells
% that are selective to a specific state / cluster.
% StateSelected can be:
% AwakeAll, NREMAll, REMAll, Awake, NREM, REM
% If clustering method is 3, also: 
% LowActive, NotStateSelective, Awake & NREM, Awake & REM, NREM & REM)
% AwakeAll, NREMAll, REMAll will include also cells that are only partly
% selective for that state, for instance AwakeAll will consider Awake,
% Awake&REM, Awake&NREM cells.

n_mice = numel(Mouse_Names);
n_TotalSessions = numel(Hypnogram_AllSessions);
Transition_Duration = 20; % [s]
Transition_Duration = Transition_Duration.*Opts.General.FrameRate;
SD_Session = 10;
% Compute for each mouse separately the average Calcium Trace around
% transitions.


% Clustering Tags
% 0 = Inactive
% 5 = Wake
% 6 = NREM
% 7 = REM
% ================
% 0 = 'None / Low Activity';
% 1 = 'Not State Selective';
% 2 = 'Awake & NREM';
% 3 = 'Awake & REM';
% 4 = 'NREM & REM';
% 5 = 'Awake';
% 6 = 'NREM';
% 7 = 'REM';

for i_mouse = 1:n_mice
    % Get Current Mouse
    Mouse_Name_Current_Mouse = Mouse_Names{i_mouse};
    i_current_session = 0;
    for i_session = 1:n_TotalSessions
        if strcmpi(Hypnogram_AllSessions(i_session).MouseName, Mouse_Name_Current_Mouse)
            i_current_session = i_current_session +1;
            Hypnogram_Current_Mouse(i_current_session) = Hypnogram_AllSessions(i_session);
            CalciumTraces_Current_Mouse{i_current_session} = CalciumTraces_Clean_AllSessions{i_session};
        end
    end
    n_sessions = numel(Hypnogram_Current_Mouse);
    
    % Get Current Mouse Classification
    for i_session = 1:n_sessions
        tmp1_CellTagNum_perMouse = CellTagNum_perMouse{i_session,1};
        CurrentMouse_CellTagNum(:, i_session) = tmp1_CellTagNum_perMouse{i_mouse};
    end
    clear tmp1_CellTagNum_perMouse
    
    % Consider each Session Separately
    for i_session = 1:n_sessions
        Hypnogram_Current_Session = Hypnogram_Current_Mouse(i_session);
        CalciumTraces_Current_Session = CalciumTraces_Current_Mouse{i_session};
        Current_Session_Classification = CurrentMouse_CellTagNum(:, i_session);
        
        % Isolate the traces of cells classified in the specific state that
        % is examined
        Cells_Selected = zeros(size(Current_Session_Classification));
        switch StateSelected
            case 'AwakeAll'
                Cells_Selected(Current_Session_Classification == 5) = 1;
                Cells_Selected(Current_Session_Classification == 2) = 1;
                Cells_Selected(Current_Session_Classification == 3) = 1;
            case 'NREMAll'
                Cells_Selected(Current_Session_Classification == 6) = 1;
                Cells_Selected(Current_Session_Classification == 2) = 1;
                Cells_Selected(Current_Session_Classification == 4) = 1;
            case 'REMAll'
                Cells_Selected(Current_Session_Classification == 7) = 1;
                Cells_Selected(Current_Session_Classification == 3) = 1;
                Cells_Selected(Current_Session_Classification == 4) = 1;
            otherwise
                if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
                    switch StateSelected
                        case 'Awake'
                            Cells_Selected(Current_Session_Classification == 5) = 1;
                            Cells_Selected(Current_Session_Classification == 2) = 1;
                            Cells_Selected(Current_Session_Classification == 3) = 1;
                        case 'NREM'
                            Cells_Selected(Current_Session_Classification == 6) = 1;
                            Cells_Selected(Current_Session_Classification == 2) = 1;
                            Cells_Selected(Current_Session_Classification == 4) = 1;
                        case 'REM'
                            Cells_Selected(Current_Session_Classification == 7) = 1;
                            Cells_Selected(Current_Session_Classification == 3) = 1;
                            Cells_Selected(Current_Session_Classification == 4) = 1;
                    end
                elseif Opts.ClusteringMethod == 3
                    switch StateSelected
                        case 'LowActive'
                            Cells_Selected(Current_Session_Classification == 0) = 1;
                        case 'NotStateSelective'
                            Cells_Selected(Current_Session_Classification == 1) = 1;
                        case 'Awake & NREM'
                            Cells_Selected(Current_Session_Classification == 2) = 1;
                        case 'Awake & REM'
                            Cells_Selected(Current_Session_Classification == 3) = 1;
                        case 'NREM & REM'
                            Cells_Selected(Current_Session_Classification == 4) = 1;
                        case 'Awake'
                            Cells_Selected(Current_Session_Classification == 5) = 1;
                        case 'NREM'
                            Cells_Selected(Current_Session_Classification == 6) = 1;
                        case 'REM'
                            Cells_Selected(Current_Session_Classification == 7) = 1;
                    end
                end
        end
        % Isolate Traces
        CalciumTraces_Selected = CalciumTraces_Current_Session(:, Cells_Selected == 1);
        
        % Compute average trace
        CalciumTraces_Mean_Current_Session = nanmean(CalciumTraces_Selected, 2);
        RecordingDuration = numel(CalciumTraces_Mean_Current_Session);
        
        % Consider only stable states.
        n_states = numel(Hypnogram_Current_Session.StateDuration);
        StableState_Index = [];
        for i_state = 2:n_states
            if Hypnogram_Current_Session.StateDuration(i_state) >= (Opts.General.MinStableStateDuration)*(Opts.General.FrameRate)
                StableState_Index = [StableState_Index, i_state];
            end
        end
        tmp_Transitions_Array = [Hypnogram_Current_Session.StateChanges];
        tmp_StatesTag_Array = [Hypnogram_Current_Session.StateType];
        StableState_Start_Array = tmp_Transitions_Array(StableState_Index);
        StableState_Tag_Array = tmp_StatesTag_Array(StableState_Index);
        n_transitions = numel(StableState_Start_Array);
        StableStatePrevious_Index_Array = NaN(n_transitions, 1);
        StableStatePrevious_Tag_Array = NaN(n_transitions, 1);
        ToRemove = [];
        for i_state = 1:n_transitions
            if StableState_Start_Array(i_state) <= Transition_Duration + 1 || StableState_Start_Array(i_state) >= RecordingDuration - (Transition_Duration - 1)
                ToRemove = [ToRemove, i_state];
                continue
            end
            if StableState_Index(i_state) > 1
                StableStatePrevious_Index_Array(i_state) = StableState_Index(i_state) - 1;
                StableStatePrevious_Tag_Array(i_state) = tmp_StatesTag_Array(StableState_Index(i_state) - 1);
            end
        end
        % Ignore states that come too early or late in the recordings.
        StableState_Index(ToRemove) = [];
        StableState_Start_Array(ToRemove) = [];
        StableState_Tag_Array(ToRemove) = [];
        StableStatePrevious_Index_Array(ToRemove) = [];
        StableStatePrevious_Tag_Array(ToRemove) = [];
        n_transitions = numel(StableState_Start_Array);
        
        % Get the Traces at each transition
        Transition_Segments_tmp = NaN(n_transitions, (1 + (Transition_Duration*2)));
        Transition_Segments.Awake2NREM = Transition_Segments_tmp;
        Transition_Segments.NREM2REM = Transition_Segments_tmp;
        Transition_Segments.NREM2Awake = Transition_Segments_tmp;
        Transition_Segments.REM2Awake = Transition_Segments_tmp;
        
        for i_state_start = 1:n_transitions
            try
                tmp = CalciumTraces_Mean_Current_Session((StableState_Start_Array(i_state_start) - Transition_Duration):(StableState_Start_Array(i_state_start) + Transition_Duration));
                tmp = tmp - nanmin(tmp); % Subtract the minimum for more comparable data.
                tmp = tmp./nanmax(tmp); % Normalize for more comparable data
                if StableState_Tag_Array(i_state_start) == Opts.General.TagAWAKE
                    if StableStatePrevious_Tag_Array(i_state_start) == 2
                        Transition_Segments.NREM2Awake(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                    elseif StableStatePrevious_Tag_Array(i_state_start) == 4
                        Transition_Segments.REM2Awake(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                    end
                elseif StableState_Tag_Array(i_state_start) == Opts.General.TagNoNREM
                        Transition_Segments.Awake2NREM(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                elseif StableState_Tag_Array(i_state_start) == Opts.General.TagREM
                    Transition_Segments.NREM2REM(i_state_start, 1:(1 + (Transition_Duration*2))) = tmp;
                end
            catch
                keyboard
            end
        end
        
        % Mean over all transitions
        Transition_Segments_Mean_perSession(i_session).Awake2NREM = nanmean(Transition_Segments.Awake2NREM, 1);
        Transition_Segments_Mean_perSession(i_session).NREM2REM = nanmean(Transition_Segments.NREM2REM, 1);
        Transition_Segments_Mean_perSession(i_session).NREM2Awake = nanmean(Transition_Segments.NREM2Awake, 1);
        Transition_Segments_Mean_perSession(i_session).REM2Awake = nanmean(Transition_Segments.REM2Awake, 1);       
        
    end
    Transition_Segments_Mean_perMouse{i_mouse} = Transition_Segments_Mean_perSession;
    
    
    clear Hypnogram_Current_Mouse
    clear CalciumTraces_Current_Mouse
    clear CurrentMouse_CellTagNum
end


% Mean everything per mouse
AllTracesMatrix_Awake2NREM = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_NREM2REM = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_NREM2Awake = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);
AllTracesMatrix_REM2Awake = NaN(n_sessions, (2*Transition_Duration)+1, n_mice);

for i_session = 1:n_sessions
    for i_mouse = 1:n_mice
        current_mouse_Transitions = Transition_Segments_Mean_perMouse{i_mouse};
        tmp_transitions_Awake2NREM = cell(n_sessions, 1);
        tmp_transitions_NREM2REM = cell(n_sessions, 1);
        tmp_transitions_NREM2Awake = cell(n_sessions, 1);
        tmp_transitions_REM2Awake = cell(n_sessions, 1);
        
        for i = 1:n_sessions
            tmp_transitions_Awake2NREM{i} = current_mouse_Transitions(i).Awake2NREM;
            tmp_transitions_NREM2REM{i} = current_mouse_Transitions(i).NREM2REM;
            tmp_transitions_NREM2Awake{i} = current_mouse_Transitions(i).NREM2Awake;
            tmp_transitions_REM2Awake{i} = current_mouse_Transitions(i).REM2Awake;
        end
        tmp_transitions_Awake2NREM = cell2mat(tmp_transitions_Awake2NREM);
        tmp_transitions_NREM2REM = cell2mat(tmp_transitions_NREM2REM);
        tmp_transitions_NREM2Awake = cell2mat(tmp_transitions_NREM2Awake);
        tmp_transitions_REM2Awake = cell2mat(tmp_transitions_REM2Awake);
        AllTracesMatrix_Awake2NREM(:,:, i_mouse) = tmp_transitions_Awake2NREM;
        AllTracesMatrix_NREM2REM(:,:, i_mouse) = tmp_transitions_NREM2REM;
        AllTracesMatrix_NREM2Awake(:,:, i_mouse) = tmp_transitions_NREM2Awake;
        AllTracesMatrix_REM2Awake(:,:, i_mouse) = tmp_transitions_REM2Awake;
    end
end
Traces_MeansPerMice_Awake2NREM = nanmean(AllTracesMatrix_Awake2NREM, 3);
Traces_MeansPerMice_NREM2REM = nanmean(AllTracesMatrix_NREM2REM, 3);
Traces_MeansPerMice_NREM2Awake = nanmean(AllTracesMatrix_NREM2Awake, 3);
Traces_MeansPerMice_REM2Awake = nanmean(AllTracesMatrix_REM2Awake, 3);

% Put minimum to zero.
for i_session = 1:n_sessions
    Traces_MeansPerMice_Awake2NREM(i_session, :) = Traces_MeansPerMice_Awake2NREM(i_session, :) - nanmin(Traces_MeansPerMice_Awake2NREM(i_session, :));
    Traces_MeansPerMice_NREM2REM(i_session, :) = Traces_MeansPerMice_NREM2REM(i_session, :) - nanmin(Traces_MeansPerMice_NREM2REM(i_session, :));
    Traces_MeansPerMice_NREM2Awake(i_session, :) = Traces_MeansPerMice_NREM2Awake(i_session, :) - nanmin(Traces_MeansPerMice_NREM2Awake(i_session, :));
    Traces_MeansPerMice_REM2Awake(i_session, :) = Traces_MeansPerMice_REM2Awake(i_session, :) - nanmin(Traces_MeansPerMice_REM2Awake(i_session, :));
end
%% Calculate dFF change in each transition group (by Yudong 26.09.2023)
% Given data
data_sets = {'Traces_MeansPerMice_Awake2NREM', 'Traces_MeansPerMice_NREM2REM', 'Traces_MeansPerMice_NREM2Awake', 'Traces_MeansPerMice_REM2Awake'};
num_sessions = 1;
%sampling_rate = 10; % 10 Hz
%Transition_Duration = 20; % seconds

% Preallocate matrices for storing results
mean_dFF_changes = zeros(1, length(data_sets));
SEM_dFF_changes = zeros(1, length(data_sets));

% Create a table to store dFF_change for each dataset
dFF_change_table = table();

% Process each data set
for i = 1:length(data_sets)
    current_data_set = eval(data_sets{i}); % Retrieve the matrix for the current data set
    
    % Find the column index for the transition point (0 second)
    transition_index = round(size(current_data_set, 2) / 2);

    % Preallocate matrix for storing the change in dFF values for each session
    dFF_change = zeros(num_sessions, 1);

    % Calculate the change in dFF for each session
    for session = 1:num_sessions
        % Calculate mean dFF value for 20 seconds before transition (ignoring NaNs)
        before_mean = nanmean(current_data_set(session, (transition_index-Transition_Duration):transition_index-1));
        
        % Calculate mean dFF value for 20 seconds after transition (ignoring NaNs)
        after_mean = nanmean(current_data_set(session, transition_index:transition_index+Transition_Duration));
        
        % Calculate the change in dFF
        dFF_change(session) = after_mean - before_mean;
    end
    
     % Add dFF_change to the table with appropriate column name
    dFF_change_table.(data_sets{i}) = dFF_change;
    
    % Calculate the mean and SEM for the current data set (ignoring NaNs)
    mean_dFF_changes(i) = nanmean(dFF_change);
    SEM_dFF_changes(i) = nanstd(dFF_change) / sqrt(num_sessions - sum(isnan(dFF_change)));
end

% Save the table to the workspace
assignin('base', 'dFF_change_table', dFF_change_table); 

% Plotting
figure; 
bar(mean_dFF_changes, 'FaceColor', [0.7 0.7 0.7]); % Gray bars for mean values
hold on;
errorbar(1:length(data_sets), mean_dFF_changes, SEM_dFF_changes, 'k.', 'LineWidth', 2); % Error bars for SEMs
main_title = 'Mean dFF Changes with SEM for Different Transitions';
subtitle = StateSelected; % Formatting the subtitle with the value from StateSelected
title({main_title, subtitle}); % Adding the subtitle using cell array

ylabel('dFF Change');
set(gca, 'XTick', 1:length(data_sets), 'XTickLabel', data_sets);
xtickangle(45); % Rotate x-tick labels for better visibility
ylim([-0.7,0.7]);
yticks(-0.7:0.1:0.7)


% % %Save
% if Opts.SaveFiguresAutomatically == 1
%     FileName = sprintf('%s - dFF change - %s Selective Cells', Opts.CellType, StateSelected);
%     FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
%     print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
%     saveas(gcf, strcat(FilePath, '.png'))
%     saveas(gcf, strcat(FilePath, '.fig'))
%     close gcf
% end

%%
%Calculate the mean of all recording sessions
grandavg_Awake2NREM = smooth(nanmean(Traces_MeansPerMice_Awake2NREM, 1));
grandavg_NREM2REM = smooth(nanmean(Traces_MeansPerMice_NREM2REM, 1));
grandavg_NREM2Awake = smooth(nanmean(Traces_MeansPerMice_NREM2Awake, 1));
grandavg_REM2Awake = smooth(nanmean(Traces_MeansPerMice_REM2Awake, 1));


%% Plot 

% Options
Time_Array = (-Transition_Duration:Transition_Duration)./Opts.General.FrameRate; % [s], distance from transition

n_subplot_rows = 1;
n_subplot_columns = 4;
xticks_array = -20:10:20;
yticks_array = 0:0.2:1;
axis_limits = [-20, 20, 0, 1];
axis_FontSize = 16;
TitleFontSize = 16;
SupTitleFontSize = 26;
GrandMean_LineWidth = 2.5;
figure('units','normalized','outerposition',[0 0 1 1]);

% Awake2NREM
subplot(n_subplot_rows, n_subplot_columns, 1);

hold on;
for i_session = 1:n_sessions
    if i_session == SD_Session
        plot(Time_Array, Traces_MeansPerMice_Awake2NREM(i_session, :), 'k')
    else
        plot(Time_Array, Traces_MeansPerMice_Awake2NREM(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_Awake2NREM, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('Wake to NREM', 'FontSize', TitleFontSize)

xlabel('Distance from State Transition [s]')
ylabel('Average \DeltaF/F Normalized')

% NREM2REM
subplot(n_subplot_rows, n_subplot_columns, 2);

hold on;
for i_session = 1:n_sessions
    if i_session == SD_Session
        plot(Time_Array, Traces_MeansPerMice_NREM2REM(i_session, :), 'k')
    else
        plot(Time_Array, Traces_MeansPerMice_NREM2REM(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_NREM2REM, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('NREM to REM', 'FontSize', TitleFontSize)

% NREM2Awake
subplot(n_subplot_rows, n_subplot_columns, 3);

hold on;
for i_session = 1:n_sessions
    if i_session == SD_Session
        plot(Time_Array, Traces_MeansPerMice_NREM2Awake(i_session, :), 'k')
    else
        plot(Time_Array, Traces_MeansPerMice_NREM2Awake(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_NREM2Awake, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('NREM to Wake', 'FontSize', TitleFontSize)

% REM2Awake
subplot(n_subplot_rows, n_subplot_columns, 4);

hold on;
for i_session = 1:n_sessions
    if i_session == SD_Session
        plot(Time_Array, Traces_MeansPerMice_REM2Awake(i_session, :), 'k')
    else
        plot(Time_Array, Traces_MeansPerMice_REM2Awake(i_session, :), 'k')
    end
end
plot(Time_Array, grandavg_REM2Awake, 'r', 'LineWidth', GrandMean_LineWidth)
ax = gca;
axis square
box on
grid on
xticks(xticks_array)
yticks(yticks_array)
axis(axis_limits)
ax.FontSize = axis_FontSize;
title('REM to Wake', 'FontSize', TitleFontSize)

suptitle_text = sprintf('%s\nTraces at Transitions for each Recording Session\nAverage over mice\n%s Selective Cells.', Opts.CellType, StateSelected);
try
    if verLessThan('matlab','9.5')
        h_suptitle = suptitle(suptitle_text);
        h_suptitle.FontSize = SupTitleFontSize;
        h_suptitle.FontWeight = 'bold';
    else
        h_suptitle = sgtitle(suptitle_text, 'FontSize', SupTitleFontSize, 'FontWeight', 'bold');
    end
catch
    warning ('Could not add suptitle.')
end


%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Traces Transitions Plot - %s Selective Cells', Opts.CellType, StateSelected);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end