function [Freq_Matrix_AllCells_Sorted, Freq_Matrix_AllCells] = ReOrder_Freq_Matrix_perMouse (CellTags_EvolutionMatrix_Ordered, Freq_Matrix_perMouse, OrderID)


[n_cells, n_sessions] = size(CellTags_EvolutionMatrix_Ordered);

Freq_Matrix_AllCells = NaN(n_cells, 3, n_sessions);
for i_session = 1:n_sessions
    tmp = Freq_Matrix_perMouse{i_session};
    n_mice = numel(tmp);
    
    if n_mice > 1 
        current_session_array_unsorted = [];
        for i_mouse = 1:n_mice
            current_session_array_unsorted = [current_session_array_unsorted;tmp{i_mouse}];
        end
        current_session_array_sorted = current_session_array_unsorted(OrderID,:);
%         for i_mouse = 1:n_mice-1 % change by Albert 14.11.2023 since it
%         was only work for two animals, now we put all the animals
%         together
%             tmp1 = [tmp{i_mouse}];
%             tmp2 = [tmp{i_mouse + 1}];
%             current_session_array_unsorted = [tmp1; tmp2];
%             current_session_array_sorted = current_session_array_unsorted(OrderID,:);
%         end
    else
        current_session_array_unsorted = tmp{1};
        current_session_array_sorted = current_session_array_unsorted(OrderID,:);
    end
    
    Freq_Matrix_AllCells(:, :, i_session) = current_session_array_unsorted;
    Freq_Matrix_AllCells_Sorted(:, :, i_session) = current_session_array_sorted;
end
