function clustering_change (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts)

CellTag_perMouse_1 = CellTag_perMouse_1';
CellTag_perMouse_2 = CellTag_perMouse_2';
CellTag_perMouse_3 = CellTag_perMouse_3';

CellsTagAll_1 = cell(0);
for i = 1:numel(CellTag_perMouse_1)
    CellsTagAll_1 = [CellsTagAll_1; CellTag_perMouse_1{i}];
end

CellsTagAll_2 = cell(0);
for i = 1:numel(CellTag_perMouse_2)
    CellsTagAll_2 = [CellsTagAll_2; CellTag_perMouse_2{i}];
end

CellsTagAll_3 = cell(0);
for i = 1:numel(CellTag_perMouse_3)
    CellsTagAll_3 = [CellsTagAll_3; CellTag_perMouse_3{i}];
end

CellsTagAll(:, 1) = CellsTagAll_1;
CellsTagAll(:, 2) = CellsTagAll_2;
CellsTagAll(:, 3) = CellsTagAll_3;
n_cells = numel(CellsTagAll_1);
CellNumTag = NaN(n_cells, 3);
for i = 1:n_cells
    if strcmpi(CellsTagAll(i, 1), 'Awake')
        CellNumTag(i, 1) = 1;
    end
    if strcmpi(CellsTagAll(i, 1), 'NREM')
        CellNumTag(i, 1) = 2;
    end
    if strcmpi(CellsTagAll(i, 1), 'REM')
        CellNumTag(i, 1) = 4;
    end
    if strcmpi(CellsTagAll(i, 1), 'None')
        CellNumTag(i, 1) = 0;
    end
    if strcmpi(CellsTagAll(i, 1), 'Not State Selective')
        CellNumTag(i, 1) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 2), 'Awake')
        CellNumTag(i, 2) = 1;
    end
    if strcmpi(CellsTagAll(i, 2), 'NREM')
        CellNumTag(i, 2) = 2;
    end
    if strcmpi(CellsTagAll(i, 2), 'REM')
        CellNumTag(i, 2) = 4;
    end
    if strcmpi(CellsTagAll(i, 2), 'None')
        CellNumTag(i, 2) = 0;
    end
    if strcmpi(CellsTagAll(i, 2), 'Not State Selective')
        CellNumTag(i, 2) = 5;
    end
    
    if strcmpi(CellsTagAll(i, 3), 'Awake')
        CellNumTag(i, 3) = 1;
    end
    if strcmpi(CellsTagAll(i, 3), 'NREM')
        CellNumTag(i, 3) = 2;
    end
    if strcmpi(CellsTagAll(i, 3), 'REM')
        CellNumTag(i, 3) = 4;
    end
    if strcmpi(CellsTagAll(i, 3), 'None')
        CellNumTag(i, 3) = 0;
    end
    if strcmpi(CellsTagAll(i, 3), 'Not State Selective')
        CellNumTag(i, 3) = 5;
    end
end

tmp = CellNumTag(:, 1);
CellNumTag_Awake_Baseline = zeros(n_cells, 1);
CellNumTag_Awake_Baseline(tmp == 1) = 1;

[indexes_AwakeStart,~] = find(tmp == 1);
[indexes_NREMStart,~] = find(tmp == 2);
[indexes_REMStart,~] = find(tmp == 4);
[indexes_InactiveStart,~] = find(tmp == 0);
[indexes_UnspecificStart,~] = find(tmp == 5);

n_AwakeStart = numel(indexes_AwakeStart);
n_NREMStart = numel(indexes_NREMStart);
n_REMStart = numel(indexes_REMStart);
n_InactiveStart = numel(indexes_InactiveStart);
n_UnspecificStart = numel(indexes_UnspecificStart);

tmp = CellNumTag(:, 3);

Awake_PostSD_Trans = tmp(indexes_AwakeStart);
Awake.Total = n_AwakeStart;
Awake.Awake = numel(find(Awake_PostSD_Trans == 1));
Awake.NREM = numel(find(Awake_PostSD_Trans == 2));
Awake.REM = numel(find(Awake_PostSD_Trans == 4));
Awake.Inactive = numel(find(Awake_PostSD_Trans == 0));

Awake.Percentage.REM = (Awake.REM./Awake.Total).*100;
Awake.Percentage.Awake = (Awake.Awake./Awake.Total).*100;
Awake.Percentage.NREM = (Awake.NREM./Awake.Total).*100;
Awake.Percentage.Inactive = (Awake.Inactive./Awake.Total).*100;
Awake.Percentage.Unpsecific = 100 - (Awake.Percentage.REM + Awake.Percentage.Awake + Awake.Percentage.NREM + Awake.Percentage.Inactive);


NREM_PostSD_Trans = tmp(indexes_NREMStart);
NREM.Total = n_NREMStart;
NREM.Awake = numel(find(NREM_PostSD_Trans == 1));
NREM.NREM = numel(find(NREM_PostSD_Trans == 2));
NREM.REM = numel(find(NREM_PostSD_Trans == 4));
NREM.Inactive = numel(find(NREM_PostSD_Trans == 0));

NREM.Percentage.REM = (NREM.REM./NREM.Total).*100;
NREM.Percentage.Awake = (NREM.Awake./NREM.Total).*100;
NREM.Percentage.NREM = (NREM.NREM./NREM.Total).*100;
NREM.Percentage.Inactive = (NREM.Inactive./NREM.Total).*100;
NREM.Percentage.Unpsecific = 100 - (NREM.Percentage.REM + NREM.Percentage.Awake + NREM.Percentage.NREM + NREM.Percentage.Inactive);

REM_PostSD_Trans = tmp(indexes_REMStart);
REM.Total = n_REMStart;
REM.Awake = numel(find(REM_PostSD_Trans == 1));
REM.NREM = numel(find(REM_PostSD_Trans == 2));
REM.REM = numel(find(REM_PostSD_Trans == 4));
REM.Inactive = numel(find(REM_PostSD_Trans == 0));

REM.Percentage.REM = (REM.REM./REM.Total).*100;
REM.Percentage.Awake = (REM.Awake./REM.Total).*100;
REM.Percentage.NREM = (REM.NREM./REM.Total).*100;
REM.Percentage.Inactive = (REM.Inactive./REM.Total).*100;
REM.Percentage.Unpsecific = 100 - (REM.Percentage.REM + REM.Percentage.Awake + REM.Percentage.NREM + REM.Percentage.Inactive);

Inactive_PostSD_Trans = tmp(indexes_InactiveStart);
Inactive.Total = n_InactiveStart;
Inactive.Awake = numel(find(Inactive_PostSD_Trans == 1));
Inactive.NREM = numel(find(Inactive_PostSD_Trans == 2));
Inactive.REM = numel(find(Inactive_PostSD_Trans == 4));
Inactive.Inactive = numel(find(Inactive_PostSD_Trans == 0));

Inactive.Percentage.REM = (Inactive.REM./Inactive.Total).*100;
Inactive.Percentage.Awake = (Inactive.Awake./Inactive.Total).*100;
Inactive.Percentage.NREM = (Inactive.NREM./Inactive.Total).*100;
Inactive.Percentage.Inactive = (Inactive.Inactive./Inactive.Total).*100;
Inactive.Percentage.Unpsecific = 100 - (Inactive.Percentage.REM + Inactive.Percentage.Awake + Inactive.Percentage.NREM + Inactive.Percentage.Inactive);

Unspecific_PostSD_Trans = tmp(indexes_UnspecificStart);
Unspecific.Total = n_UnspecificStart;
Unspecific.Awake = numel(find(Unspecific_PostSD_Trans == 1));
Unspecific.NREM = numel(find(Unspecific_PostSD_Trans == 2));
Unspecific.REM = numel(find(Unspecific_PostSD_Trans == 4));
Unspecific.Inactive = numel(find(Unspecific_PostSD_Trans == 0));

Unspecific.Percentage.REM = (Unspecific.REM./Unspecific.Total).*100;
Unspecific.Percentage.Awake = (Unspecific.Awake./Unspecific.Total).*100;
Unspecific.Percentage.NREM = (Unspecific.NREM./Unspecific.Total).*100;
Unspecific.Percentage.Inactive = (Unspecific.Inactive./Unspecific.Total).*100;
Unspecific.Percentage.Unpsecific = 100 - (Unspecific.Percentage.REM + Unspecific.Percentage.Awake + Unspecific.Percentage.NREM + Unspecific.Percentage.Inactive);

t2col = [1 0 0];   %red        
t3col = [0 1 0];   %green
t1col = [0 0 1];   %blue
t4col = [0.1 0.1 0.1];   %magenta
t5col = [1 1 1]; 
tilecolor = [t1col; t2col; t3col; t4col; t5col]; 

n_rows = 1;
n_columns = 4;
FontSizeTitles = 18;
AxisFontSize = 14;
SupTitleFontSize = 28;

figure('units','normalized','outerposition',[0 0 1 1]);

subplot(n_rows, n_columns, 1);
h_pie = pie_modified([Awake.Percentage.Awake, Awake.Percentage.NREM, Awake.Percentage.REM, Awake.Percentage.Unpsecific, Awake.Percentage.Inactive], tilecolor);
title('Awake Specific cells after SD', 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})

subplot(n_rows, n_columns, 2);
h_pie = pie_modified([REM.Percentage.Awake, REM.Percentage.NREM, REM.Percentage.REM, REM.Percentage.Unpsecific, REM.Percentage.Inactive], tilecolor);
title('REM Specific cells after SD', 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
legend({'Awake', 'REM', 'Unspecific', 'Inactive'})

subplot(n_rows, n_columns, 3);
h_pie = pie_modified([Inactive.Percentage.Awake, Inactive.Percentage.NREM, Inactive.Percentage.REM, Inactive.Percentage.Unpsecific, Inactive.Percentage.Inactive], tilecolor);
title('Inactive Specific cells after SD', 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})

subplot(n_rows, n_columns, 4);
h_pie = pie_modified([Unspecific.Percentage.Awake, Unspecific.Percentage.NREM, Unspecific.Percentage.REM, Unspecific.Percentage.Unpsecific, Unspecific.Percentage.Inactive], tilecolor);
title('Unspecific cells after SD', 'FontSize', FontSizeTitles)
ax = gca;
set(findobj(ax, 'type', 'text'), 'FontSize', AxisFontSize);
legend({'Awake', 'NREM', 'REM', 'Unspecific', 'Inactive'})


SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 3 - Recovery Day 1');
try
    if verLessThan('matlab','9.5')
        h_suptitle = suptitle(suptitle_text);
        h_suptitle.FontSize = SupTitleFontSize;
        h_suptitle.FontWeight = 'bold';
    else
        h_suptitle = sgtitle(suptitle_text, 'FontSize', SupTitleFontSize, 'FontWeight', 'bold');
    end
catch
    warning ('Could not add suptitle.')
end
