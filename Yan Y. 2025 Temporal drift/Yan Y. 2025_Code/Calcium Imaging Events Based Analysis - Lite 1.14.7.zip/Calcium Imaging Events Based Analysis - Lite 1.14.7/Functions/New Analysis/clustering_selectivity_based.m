function CellTagNum_perMouse_SelectivityBased = clustering_selectivity_based (Selectivity)






Selectivity_Threshold = 0.6;


n_sessions = numel(Selectivity);


keyboard
for i_session = 1:n_sessions
    Selectivity_Wake = Selectivity(i_session).Wake;
    Selectivity_NREM = Selectivity(i_session).NREM;
    Selectivity_REM = Selectivity(i_session).REM;
    
end