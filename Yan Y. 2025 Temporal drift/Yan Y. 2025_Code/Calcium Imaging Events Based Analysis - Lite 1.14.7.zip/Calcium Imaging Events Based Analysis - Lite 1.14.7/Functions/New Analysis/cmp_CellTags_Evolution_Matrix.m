function [CellTags_EvolutionMatrix, CellTags_EvolutionMatrix_Ordered, OrderID] = cmp_CellTags_Evolution_Matrix(CellTagNum_perMouse, Opts)


% 0 = 'None / Low Activity';
% 1 = 'Not State Selective';
% 2 = 'Awake & NREM';
% 3 = 'Awake & REM';
% 4 = 'NREM & REM';
% 5 = 'Awake';
% 6 = 'NREM';
% 7 = 'REM';

n_sessions = numel(CellTagNum_perMouse);
n_mice = numel(CellTagNum_perMouse{1, 1});

%% Plot Options
FontSizeTitles = 18;
AxisFontSize = 14;
Legend_FontSize = 14;
Plot_1_LineWidth = 2;
xticks_array = 1.5:3:n_sessions;
xticklabel_array = {'Day 1', 'Day 2', 'Day 3', 'SD Day', 'Day 5', 'Day 6', 'Day 7'};

black = [0, 0, 0];
grey = [0.2, 0.2, 0.2];
bluegreen = [0, 1, 1];
redgreen = [1, 1, 0];
green = [0, 1, 0];
blue = [0, 0, 1];
red = [1, 0, 0];


%% Compute
% Put cells from all mice together
CellTags_per_Session = cell(1);

for i_session = 1:n_sessions
    current_session = CellTagNum_perMouse{i_session};
    for i_mouse = 1:n_mice
        CellTags_per_Session{i_mouse, i_session} = current_session{i_mouse};
    end
end

% Cells Tag Evolution Matrix
for i_session = 1:n_sessions
    tmp = CellTags_per_Session(:, i_session);
    CellTags_EvolutionMatrix(:, i_session) = cell2mat(tmp);
end


%% Align the Matrix according to how cells are stable.
[CellTags_EvolutionMatrix_Ordered, OrderID] = sortrows(CellTags_EvolutionMatrix);

if Opts.ClusteringMethod == 3
    % 0 = 'None / Low Activity';
    % 1 = 'Not State Selective';
    % 2 = 'Awake';
    % 3 = 'Awake & REM';
    % 4 = 'REM';
    % 5 = 'NREM & REM';
    % 6 = 'NREM';
    % 7 = 'Awake & NREM';
    pause_time = 0.5;
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 2) = 12;
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 4) = 14;
    
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 5) = 2; pause(pause_time); % Awake =>
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 3) = 3; pause(pause_time);  %
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 7) = 4; pause(pause_time);  %
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 12) = 5; pause(pause_time);  %
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 6) = 6; pause(pause_time);  %
    CellTags_EvolutionMatrix_Ordered(CellTags_EvolutionMatrix_Ordered == 14) = 7; pause(pause_time);  %
    
    CellTags_EvolutionMatrix_Ordered = sortrows(CellTags_EvolutionMatrix_Ordered);
end

%% Plot
figure('units','normalized','outerposition',[0 0 1 1]);

[dim1, dim2] = size(CellTags_EvolutionMatrix_Ordered);

cmap = colormap(jet(64));
N = 10;
x = linspace(1, size(cmap, 1), N);
cmap = cmap(x, :);
% 0 = 'None / Low Activity';
% 1 = 'Not State Selective';
% 2 = 'Awake & NREM';
% 3 = 'Awake & REM';
% 4 = 'NREM & REM';
% 5 = 'Awake';
% 6 = 'NREM';
% 7 = 'REM';
cmap(1,:) = black;
cmap(2,:) = grey;
cmap(5,:) = bluegreen;
cmap(6,:) = redgreen;
cmap(8,:) = blue;
cmap(9,:) = red;
cmap(10,:) = green;


if Opts.ClusteringMethod == 3
    % 0 = 'None / Low Activity';
    % 1 = 'Not State Selective';
    % 2 = 'Awake';
    % 3 = 'Awake & REM';
    % 4 = 'REM';
    % 5 = 'NREM & REM';
    % 6 = 'NREM';
    % 7 = 'Awake & NREM';
    cmap(1,:) = black;
    cmap(2,:) = grey;
    cmap(3,:) = blue;
    cmap(5,:) = bluegreen;
    cmap(6,:) = green;
    cmap(9,:) = redgreen;
    cmap(10,:) = red;
end

colormap(cmap)
CellTags_EvolutionMatrix_Plot = [CellTags_EvolutionMatrix_Ordered, zeros(dim1, 1)];
CellTags_EvolutionMatrix_Plot = [CellTags_EvolutionMatrix_Plot; zeros(1, dim2+1)];
h_plot = pcolor(CellTags_EvolutionMatrix_Plot);

axis square; axis tight;

ax = gca;
ax.FontSize = AxisFontSize; 

xticks(xticks_array)
xticklabels(xticklabel_array);

% Add Legend
hold on;
h = zeros(3, 1);
if Opts.ClusteringMethod == 3
    h(1) = plot(NaN,NaN, 'color', black);
    h(2) = plot(NaN,NaN, 'color', grey);
    h(3) = plot(NaN,NaN, 'color', blue);
    h(4) = plot(NaN,NaN, 'color', bluegreen);
    h(5) = plot(NaN,NaN, 'color', green);
    h(6) = plot(NaN,NaN, 'color', redgreen);
    h(7) = plot(NaN,NaN, 'color', red);
    [h_legend, h_legend_obj] = legend(h, 'Low Active', 'Unspecific', 'Wake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM', 'location', 'bestoutside');
else
    h(1) = plot(NaN,NaN, 'color', black);
    h(2) = plot(NaN,NaN, 'color', blue);
    h(3) = plot(NaN,NaN, 'color', red);
    h(4) = plot(NaN,NaN, 'color', green);
    [h_legend, h_legend_obj] = legend(h, 'Low Active', 'Wake', 'NREM', 'REM', 'location', 'bestoutside');
end
hl = findobj(h_legend_obj, 'type', 'line');
set(hl,'LineWidth', 3);
h_legend.LineWidth = 2;


%% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Evolution of Cells Specificity - Clustering Type %d - Events Rate based', Opts.CellType, Opts.ClusteringMethod);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Evolution of Cells Specificity - Clustering Type %d - Integrals Frequency based', Opts.CellType, Opts.ClusteringMethod);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

