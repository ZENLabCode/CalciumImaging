function Selectivity_Normalized = selectivity_normalization (Selectivity)
% This function changes the selectivity from 0 to 2, where 0 is more
% selective for a specific state, 1 is neutral, and 2 is 'anti-selective',
% to a selectivity that ranges from 0 to 1, where 0 is anti-selective, and 1
% is completely selective.


starting_max = 2;

n_sessions = numel(Selectivity);
for i_session = 1:n_sessions
    Selectivity_Normalized(i_session).Wake = 1 - Selectivity(i_session).Wake ./ starting_max;
    Selectivity_Normalized(i_session).NREM = 1 - Selectivity(i_session).NREM ./ starting_max;
    Selectivity_Normalized(i_session).REM = 1 - Selectivity(i_session).REM ./ starting_max;
    Selectivity_Normalized(i_session).State_Selectivity_Matrix = 1 - Selectivity(i_session).State_Selectivity_Matrix ./ starting_max;
    Selectivity_Normalized(i_session).Absolute = 1 - Selectivity(i_session).Absolute ./ starting_max;
end