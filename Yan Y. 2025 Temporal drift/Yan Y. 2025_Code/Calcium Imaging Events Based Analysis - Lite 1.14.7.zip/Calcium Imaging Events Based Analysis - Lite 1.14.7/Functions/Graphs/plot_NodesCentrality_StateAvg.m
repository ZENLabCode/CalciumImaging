function StatesCentrality = plot_NodesCentrality_StateAvg (Mouse_Analysis, FrameRate)
% This function computes the average Node (neuron) centrality over the same
% states of the same mice. It takes into account only states that are at
% least min_state_duration frames long.


n_mice = numel(Mouse_Analysis);
min_state_duration = 20*FrameRate;
n_rows = 4;
n_columns = n_mice;
i_subplot = 1;

figure

CentralityMax = NaN(1, n_mice);
% StatesCentrality(i_mouse).Mean_Awake = NaN(1, n_mice);
% StatesCentrality(i_mouse).Std_Awake = NaN(1, n_mice);
% StatesCentrality(i_mouse).SE_Awake = NaN(1, n_mice);
% StatesCentrality(i_mouse).Mean_NoNREM = NaN(1, n_mice);
% StatesCentrality(i_mouse).Std_NoNREM = NaN(1, n_mice);
% StatesCentrality(i_mouse).SE_NoNREM = NaN(1, n_mice);
% StatesCentrality(i_mouse).Mean_REM = NaN(1, n_mice);
% StatesCentrality(i_mouse).Std_REM = NaN(1, n_mice);
% StatesCentrality(i_mouse).SE_REM = NaN(1, n_mice);
for i_mouse = 1:n_mice
    Current_States = Mouse_Analysis(i_mouse).States_Analysis;
    n_states = numel(Current_States);
    [n_nodes, ~] = size(Current_States(1).AjdacencyMatrixWeighted);
    
    StatesTags = [Current_States.StateTag];
    StatesTags_Matrix = repmat(StatesTags, n_nodes, 1);
    StatesNodesCentrality_BinaryMatrix = zeros(n_nodes, n_states);
    StatesNodesCentrality_Matrix = NaN(n_nodes, n_states);
    for i_state = 1:n_states
        Current_State_Tag = Current_States(i_state).StateTag;
        NodesArray = zeros(n_nodes, 1);
        NodesCentrality = zeros(n_nodes, 1);
        Current_State_Duration = Current_States(i_state).StartEnd(2) - Current_States(i_state).StartEnd(1) + 1;
        if Current_State_Duration < min_state_duration  % Unstable state (duration lower than minimal)
            NodesCentrality = NaN(n_nodes, 1);
            StatesNodesCentrality_Matrix(:, i_state) = NaN(n_nodes, 1);
        else % Duration ok
            tmp = Current_States(i_state).Corr_Graph_Centrality;
            Current_Centrality = tmp.Eigenvector_Weighted;
            Current_Nodes = tmp.Node_Tag;
            if ~isscalar(Current_Nodes)
                if ~isnan(Current_Nodes)
                    NodesArray(Current_Nodes) = 1;
                    NodesCentrality(Current_Nodes) = Current_Centrality;
                else
                    NodesCentrality = NaN(n_nodes, 1);
                    NodesArray = zeros(n_nodes, 1);
                end
                
            end
        end
        StatesNodesCentrality_BinaryMatrix(:, i_state) = NodesArray;
        StatesNodesCentrality_Matrix(:, i_state) = NodesCentrality;
    end
    StatesNodesCentrality_Matrix_Awake = StatesNodesCentrality_Matrix(StatesTags_Matrix == 1);
    StatesNodesCentrality_Matrix_Awake = reshape(StatesNodesCentrality_Matrix_Awake, n_nodes, numel(StatesTags(StatesTags == 1)));
    StatesNodesCentrality_Matrix_NoNREM = StatesNodesCentrality_Matrix(StatesTags_Matrix == 2);
    StatesNodesCentrality_Matrix_NoNREM = reshape(StatesNodesCentrality_Matrix_NoNREM, n_nodes, numel(StatesTags(StatesTags == 2)));
    StatesNodesCentrality_Matrix_REM = StatesNodesCentrality_Matrix(StatesTags_Matrix == 4);
    StatesNodesCentrality_Matrix_REM = reshape(StatesNodesCentrality_Matrix_REM, n_nodes, numel(StatesTags(StatesTags == 4)));

    StatesCentrality_Mean_Awake_current = nanmean(StatesNodesCentrality_Matrix_Awake, 2);
    StatesCentrality_Std_Awake_current = nanstd(StatesNodesCentrality_Matrix_Awake, 0, 2);
    [~, tmp] = size(StatesNodesCentrality_Matrix_Awake);
    StatesCentrality_SE_Awake_current = StatesCentrality_Std_Awake_current./sqrt(tmp);
    StatesCentrality_Mean_NoNREM_current = nanmean(StatesNodesCentrality_Matrix_NoNREM, 2);
    StatesCentrality_Std_NoNREM_current = nanstd(StatesNodesCentrality_Matrix_NoNREM, 0, 2);
    [~, tmp] = size(StatesNodesCentrality_Matrix_NoNREM);
    StatesCentrality_SE_NoNREM_current = StatesCentrality_Std_NoNREM_current./sqrt(tmp);
    StatesCentrality_Mean_REM_current = nanmean(StatesNodesCentrality_Matrix_REM, 2);
    StatesCentrality_Std_REM_current = nanstd(StatesNodesCentrality_Matrix_REM, 0, 2);
    [~, tmp] = size(StatesNodesCentrality_Matrix_REM);
    StatesCentrality_SE_REM_current = StatesCentrality_Std_REM_current./sqrt(tmp);
    
    StatesCentrality(i_mouse).Mean_Awake = StatesCentrality_Mean_Awake_current;
    StatesCentrality(i_mouse).Std_Awake = StatesCentrality_Std_Awake_current;
    StatesCentrality(i_mouse).SE_Awake = StatesCentrality_SE_Awake_current;
    StatesCentrality(i_mouse).Mean_NoNREM = StatesCentrality_Mean_NoNREM_current;
    StatesCentrality(i_mouse).Std_NoNREM = StatesCentrality_Std_NoNREM_current;
    StatesCentrality(i_mouse).SE_NoNREM = StatesCentrality_SE_NoNREM_current;
    StatesCentrality(i_mouse).Mean_REM = StatesCentrality_Mean_REM_current;
    StatesCentrality(i_mouse).Std_REM = StatesCentrality_Std_REM_current;
    StatesCentrality(i_mouse).SE_REM = StatesCentrality_SE_REM_current;
    
    % Plots
    subplot(n_rows, n_columns, i_mouse);
    barwitherr(StatesCentrality_SE_Awake_current, StatesCentrality_Mean_Awake_current, 'b');
    subplot(n_rows, n_columns, n_mice + i_mouse);
    barwitherr(StatesCentrality_SE_NoNREM_current, StatesCentrality_Mean_NoNREM_current, 'r');
    subplot(n_rows, n_columns, 2*n_mice + i_mouse);
    barwitherr(StatesCentrality_SE_REM_current, StatesCentrality_Mean_REM_current, 'g');
    subplot(n_rows, n_columns, 3*n_mice + i_mouse);
    barwitherr(StatesCentrality_SE_Awake_current, StatesCentrality_Mean_Awake_current, 'b', 'FaceAlpha', 0.2); hold on;
    barwitherr(StatesCentrality_SE_NoNREM_current, StatesCentrality_Mean_NoNREM_current, 'r', 'FaceAlpha', 0.2); hold on;
    barwitherr(StatesCentrality_SE_REM_current, StatesCentrality_Mean_REM_current, 'g', 'FaceAlpha', 0.2); hold on;
    CentralityMax(i_mouse) = nanmax([nanmax(StatesCentrality_Mean_Awake_current), nanmax(StatesCentrality_Mean_NoNREM_current), nanmax(StatesCentrality_Mean_REM_current)]);
    
end
CentralityMax = nanmax(CentralityMax);

for i_subplot = 1:n_columns*n_rows
    subplot(n_rows, n_columns, i_subplot);
        axis([-inf, inf, 0, CentralityMax]);
end
