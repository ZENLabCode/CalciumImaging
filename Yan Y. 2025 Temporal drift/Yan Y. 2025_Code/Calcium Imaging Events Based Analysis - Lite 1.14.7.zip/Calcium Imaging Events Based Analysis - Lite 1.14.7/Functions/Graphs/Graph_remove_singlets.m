function [Graph_noSinglets, Graph_noSinglets_abs] = Graph_remove_singlets (Graph)
% This function removes any isolated node from a Graph.


% Get Graph Weights
Graph_Weights = (Graph.Edges.Weight);

% Remove AutoConnections.
tmp = Graph.Edges.EndNodes;
Graph_noSinglets = Graph;
for i_tmp = (numel(tmp)/2):-1:1
    if tmp(i_tmp, 1) == tmp(i_tmp, 2)
        Graph_noSinglets = rmedge(Graph_noSinglets, tmp(i_tmp, 1), tmp(i_tmp, 2));
        Graph_Weights(i_tmp) = [];
    end
end
clear tmp
tmp = Graph_noSinglets.Edges.EndNodes;

% Remove Singlets
if ~isempty(Graph_Weights) % Check for any connection to be present.
    tmp1 = tmp(:, 1);
    tmp2 = tmp(:, 2);
    [u, ~, w] = unique([tmp1 tmp2]);
    str_node_labels = cellstr(num2str(u));
    if numel(str_node_labels) > 2
        Graph_noSinglets = graph(w(1:end/2), w(end/2+1:end), Graph_Weights, str_node_labels);
        Graph_noSinglets_abs = graph(w(1:end/2), w(end/2+1:end), abs(Graph_Weights), str_node_labels);
    else % If there are no connections (likely for short states)
        Graph_noSinglets = [];
        Graph_noSinglets_abs = [];
    end
else % If there are no connections (likely for short states)
    Graph_noSinglets = [];
    Graph_noSinglets_abs = [];
end