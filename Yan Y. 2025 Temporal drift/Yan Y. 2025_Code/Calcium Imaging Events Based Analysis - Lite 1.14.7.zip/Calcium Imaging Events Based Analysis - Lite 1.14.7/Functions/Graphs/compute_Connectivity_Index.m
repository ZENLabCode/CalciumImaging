function [Graph_Connectivity_Index, Graph_Connectivity_Index_StE, Graph_Connectivity_Index_per_cell] = compute_Connectivity_Index (Corr_Matrix, CorrStatesMean_ThrP, CorrStatesMean_ThrN)
% The Connectivity Index is a measure of the strength of connection
% between a Graph's Nodes: it is the mean of the total connectiveness
% of each single Node.
% The "connectiveness" of each node is the sum of the weights of a
% node's connection with every other node, divided by the number of
% nodes. This would be = 0 if there are no connections, and = 1 if
% the node has perfect connection (=correlation) with every other node.

% If CorrStatesMean_ThrP & CorrStatesMean_ThrN are left empty,
% Corr_Matrix is considered the Adjacency Matrix of the Graph, and the
% Connectivity Index is computed accordingly.

[n_cells, ~] = size (Corr_Matrix);
if isempty(CorrStatesMean_ThrP) || isempty(CorrStatesMean_ThrP) % Corr_Matrix is the Adjecency Matrix
    
    if isequal(Corr_Matrix, Corr_Matrix.') % Check if the Adjecency Matrix is symmetrical or not
        tmp = Corr_Matrix;
    elseif istril(Corr_Matrix) || istriu(Corr_Matrix)
        tmp = Corr_Matrix + Corr_Matrix';
    end
    
else % Corr_Matrix is the raw Correlation Matrix
    tmp1 = triu(Corr_Matrix);
    tmp1(tmp1 < CorrStatesMean_ThrP) = NaN;
    CorrWholeState_Significant(:,:,1) = tmp1;
    
    tmp2 = tril(Corr_Matrix);
    tmp2(tmp2 < CorrStatesMean_ThrP) = NaN;
    CorrWholeState_Significant(:,:,2) = tmp2;
    
    tmp3 = triu(Corr_Matrix);
    tmp3(tmp3 > CorrStatesMean_ThrN) = NaN;
    CorrWholeState_Significant(:,:,3) = tmp3;
    
    tmp4 = tril(Corr_Matrix);
    tmp4(tmp4 > CorrStatesMean_ThrN) = NaN;
    CorrWholeState_Significant(:,:,4) = tmp4;
    
    tmp = nansum(CorrWholeState_Significant, 3);
    for i_cell = 1:n_cells
        tmp(i_cell, i_cell) = NaN;
    end
    tmp = abs(tmp);
    
    tmp = abs(cat(3, tmp1, tmp3));
    tmp = nansum(tmp, 3);
    for i_cell = 1:n_cells
        tmp(i_cell, i_cell) = NaN;
    end
end

Graph_Connectivity_Index_per_cell = (nansum(tmp))./(n_cells);
Graph_Connectivity_Index = nanmean(Graph_Connectivity_Index_per_cell);
Graph_Connectivity_Index_StE = nanstd(Graph_Connectivity_Index_per_cell)./sqrt(n_cells);