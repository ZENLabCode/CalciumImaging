function Graph_Centrality = compute_centrality (Graph)
% This function computes several centrality measures for the input Graph.

if ~isempty(Graph)
    tmp = str2double(table2array([Graph.Nodes]));
    tmp1 = centrality(Graph, 'eigenvector', 'Importance', Graph.Edges.Weight);
    try
    tmp2 = [tmp1, tmp];
    catch
        keyboard
    end
    [tmp3, tmp_index] = sortrows(tmp2, 'descend');
    Graph_Centrality.Node_Tag = tmp;
    Graph_Centrality.Node_Tag_OrderedbyEigenW = tmp3(:, 2);
    Graph_Centrality.Degree = centrality(Graph, 'degree');
    Graph_Centrality.Degree_Weighted = centrality(Graph, 'degree', 'Importance', Graph.Edges.Weight);
    Graph_Centrality.Eigenvector = centrality(Graph, 'eigenvector');
    Graph_Centrality.Eigenvector_Weighted = tmp1;
    Graph_Centrality.Betweenness = centrality(Graph, 'betweenness', 'Cost', Graph.Edges.Weight);
else
    Graph_Centrality.Node_Tag = NaN;
    Graph_Centrality.Node_Tag_OrderedbyEigenW = NaN;
    Graph_Centrality.Degree = NaN;
    Graph_Centrality.Degree_Weighted = NaN;
    Graph_Centrality.Eigenvector = NaN;
    Graph_Centrality.Eigenvector_Weighted = NaN;
    Graph_Centrality.Betweenness = NaN;
end