function SubNetworks = get_subnetworks_sub1 (Graph_Links, Graph_Weights, Subnetworks_Nodes, CellNodes, n_cells)
% This function is intended as a sub-function to "get_subnetworks".
% It computes notable characteristics of each subnetwork, returned in the
% output structure array "SubNetworks".
% Fields describe the central nodes, the connectivity and the graph itself
% composing the sub-network, the correcponding Adjacency matrix in
% symmetrical form with zeros in the main diagonal, and the Connectivity
% Indexes (CIs).
% The described subnetwork is composed of the Main Node, the other nodes of
% the network, and their connections (also with nodes external to the
% subnetowork).
% The CIs are to be intended as the CIs between the single subnetworks, and
% cells connected to their nodes (ConnectedNodes).


% Get Subnetworks list of connections
n_clusters = numel(Subnetworks_Nodes);
Graph_Connections = [Graph_Links, Graph_Weights];
SubNetworks = struct;
for i_net = 1:n_clusters
    % Get sources, targets and connection weights
    
    sources = [];
    targets = [];
    weights = [];
    tmp_nodes = cell2mat(Subnetworks_Nodes(i_net));
    for i_node = 1:numel(tmp_nodes)
        a1 = Graph_Connections(Graph_Connections(:, 1) == tmp_nodes(i_node), :);
        a2 = Graph_Connections(Graph_Connections(:, 2) == tmp_nodes(i_node), :);
        if ~isempty(a1)
            sources = [sources; a1(:, 1)];
            targets = [targets; a1(:, 2)];
            weights = [weights; a1(:, 3)];
        end
        if ~isempty(a2)
            sources = [sources; a2(:, 1)];
            targets = [targets; a2(:, 2)];
            weights = [weights; a2(:, 3)];
        end
    end
    
    % Control for duplicates
    tmp_links = [sources, targets, weights];
    [links_unique, ~, ~] = unique(tmp_links, 'rows');
    sources = links_unique(:, 1);
    targets = links_unique(:, 2);
    weights = links_unique(:, 3);
    
    % Adjecency Matrix
    AdjacencyMatrix = zeros(n_cells);
    for i_cell = 1:numel(sources)
        AdjacencyMatrix(sources(i_cell), targets(i_cell)) = weights(i_cell);
    end
    AdjacencyMatrix = AdjacencyMatrix + AdjacencyMatrix';
    if ~isequal(AdjacencyMatrix, AdjacencyMatrix.')
       warning('Adjecency matrix not symmetrical in subnetwork #%d.', i_net) 
    end
    % Reduced Adjecency Matrix (removing disconnected cells)
    AdjacencyMatrix_Reduced = AdjacencyMatrix;
    disconnected_nodes = [];
    i_node = 0;
    for i_cell = 1:n_cells
        if ~any(AdjacencyMatrix(i_cell, :))
            i_node = i_node + 1;
            disconnected_nodes(i_node) = i_cell;
        end
    end
    AdjacencyMatrix_Reduced(disconnected_nodes, :) = [];
    AdjacencyMatrix_Reduced(:, disconnected_nodes) = [];
    
    % Connectivity Indexes
    [Graph_Connectivity_Index, ~, Graph_Connectivity_Index_per_cell] = compute_Connectivity_Index (AdjacencyMatrix_Reduced, [], []);
    
    % Graph
    subgraph = graph(sources, targets, weights);
    [~, subgraph] = Graph_remove_singlets (subgraph);
    
    % Centrality 
    subGraph_Centrality = compute_centrality (subgraph);
    
    % Save Parameters in Output structure
    SubNetworks(i_net).MainNode = CellNodes(i_net);
    SubNetworks(i_net).MainNode_Centrality = []; % Intended as its centrality in the parent Network
    SubNetworks(i_net).Nodes = Subnetworks_Nodes; % Nodes part of the sub-network
    SubNetworks(i_net).Connections = [sources, targets, weights];
    SubNetworks(i_net).ConnectedNodes = unique([sources; targets]); % Nodes with connections to the sub-network
    SubNetworks(i_net).Graph = subgraph;
    SubNetworks(i_net).AdjacencyMatrix = AdjacencyMatrix; % Matrix is symmetrical with main diagonal = 0
    SubNetworks(i_net).Centrality = subGraph_Centrality; % Matrix is symmetrical with main diagonal = 0
    SubNetworks(i_net).ConnectivityIndex = Graph_Connectivity_Index;
    SubNetworks(i_net).NodesConnectivityIndex = Graph_Connectivity_Index_per_cell;
end
    
