function plot_graph_onProj (MeanOfStates, MouseName, cluster_assignment, Opts)
% Plots a connectivity Graph (thought for correlation based connectivity)
% on the image projection of the recording
% plot_graph_onProj (MeanOfStates_PerMouse{1, 1}, Mouse_Names{1, 1}, cluster_assignment, Opts); 


%% Set Defaults
if nargin < 3
    Opts = set_options;
    Opts.CorrAnalysis.Opts_GraphPlot.label_color = 'k';
    Opts.CorrAnalysis.Opts_GraphPlot.Centrality_Displayed = Degree_Weighted;
    Opts.CorrAnalysis.Opts_GraphPlot.Marker_Thickness_Mult = 2;
end

fprintf('Functional Connectivity Graph for mouse %s...\n', MouseName)


%% Options
Neighbourhood_Element_Radius = 18;
FLAG_CentralityRankedPlot = 1;
min_weight_fixed = 0.05;
max_weight_fixed = 5;
CellBorderLineWidth = 1.5;
CellNodeBorderLineWidth = 3;
% LineWidth_Min = 0.5;
% LineWidth_Max = 5;

tmp_ROI_FileName_ImageJ = 'RoiSet.zip'; % Expected name of the ROI file coming from ImageJ
tmp_ROI_FileName_mat = 'ROIs.mat'; % Expected name of the ROI file coming from matlab
Projection_FileName = 'StackProjection_std.mat';
tmp_FileName_Figure_1 = sprintf('Graphs - %s', MouseName);
tmp_FileName_Figure_2 = sprintf('Centrality Ranking - %s', MouseName);


%% Set Input-Output Directories
Mouse_Dir = [Opts.Dir_Data, '\', MouseName];
Projection_FilePathFull = [Mouse_Dir, '\', Projection_FileName];
% Figures Dir
% PlotPath = [Opts.Dir_Figures, '\', 'Graphs - Mean of States'];
% if exist(PlotPath, 'dir') == 0
%    mkdir(PlotPath);
%    addpath(genpath(PlotPath));
% end


%% Get Projections
% Get projections.
if exist(Projection_FilePathFull, 'file') ~= 0
    data_tmp_struct = load(Projection_FilePathFull);
    tmp_var_1 = struct2cell(data_tmp_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    StackProjection = tmp_var_2;
else % If could not find projection file (the background image to display)
    warning('Could not find "%s" in folder %s, please manualy select the file \n', Projection_FileName, Mouse_Dir);
    [tmp_filename_projection, tmp_filepath_projection] = uigetfile('*.mat', 'Select Stack Projection file (.mat)');
    data_tmp_struct = load([tmp_filepath_projection, '/', tmp_filename_projection]);
    tmp_var_1 = struct2cell(data_tmp_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    StackProjection = tmp_var_2;
    try %  Try saving a copy automatically
        save([Mouse_Dir, '/', 'StackProjection.mat'], 'StackProjection')
        warning('A copy of the file "%s" was saved automatically in %s', tmp_filename_projection, Mouse_Dir)
    catch
        warning('An attempt has been made at saving copy of the file "%s" in %s, but it failed', tmp_filename_projection, Mouse_Dir)
    end
end





%% Get ROIs.
% Check for ROI file.
tmp_ROI_FilePathFull_ImageJ = [Mouse_Dir, '\', tmp_ROI_FileName_ImageJ];
tmp_ROI_FilePathFull_mat = [Mouse_Dir, '\', tmp_ROI_FileName_mat];

if exist(tmp_ROI_FilePathFull_ImageJ, 'file') ~= 0
    ROI_FileName = tmp_ROI_FileName_ImageJ;
    ROI_FilePathFull = tmp_ROI_FilePathFull_ImageJ;
elseif exist(tmp_ROI_FileName_mat, 'file') ~= 0
    ROI_FileName = tmp_ROI_FileName_mat;
    ROI_FilePathFull = tmp_ROI_FilePathFull_mat;
else
    fprintf('Could not find any ROI file for mouse %s.\n\n', MouseName);
end
clear tmp_ROI_FileName_mat; clear tmp_ROI_FileName_ImageJ; 
clear tmp_ROI_FilePathFull_mat; clear tmp_ROI_FilePathFull_ImageJ; 

if exist('ROI_FilePathFull', 'var') == 0 % If the file can not be found, ask the user
    [ROI_FileName, ROI_FilePathFull] = uigetfile(Mouse_Dir);
    ROI_FilePathFull = [ROI_FilePathFull, ROI_FileName];
end

fprintf('Getting ROIs...\n');
if exist(ROI_FilePathFull, 'file') == 0 % If the file can not be found, ask the user.
    warning('Could not find "%s" in folder %s.\n', ROI_FileName, Mouse_Dir);
    [ROI_FileName, ROI_FilePathFull] = uigetfile('*.mat', 'Select ROI file (.mat)');
    data_tmp_struct = load([ROI_FilePathFull, '/', ROI_FileName]);
    tmp_var_1 = struct2cell(data_tmp_struct);
    ROIs = tmp_var_1{1, 1};
    try %  Try saving a copy automatically
        save([Mouse_Dir, '/', 'ROIs.mat'], 'ROIs')
        warning('A copy of the file "%s" was saved automatically in %s', ROI_FileName, Mouse_Dir)
    catch
        warning('An attempt has been made at saving copy of the file "%s" in %s, but it failed', ROI_FileName, Mouse_Dir)
    end
    tmp_ROI = ROIs;
    FLAG_ROI_input = '.mat';
else
    try
        [tmp_ROI] = ReadImageJROI(ROI_FilePathFull);
        FLAG_ROI_input = 'ImageJ';
    catch
        load(ROI_FilePathFull, 'ROIs');
        tmp_ROI = ROIs;
        FLAG_ROI_input = '.mat';
    end
end
n_cells = numel(tmp_ROI);
if strcmpi(FLAG_ROI_input, 'ImageJ')
    for i_cell = 1:n_cells
        tmp_ROI{1, i_cell} = tmp_ROI{1, i_cell}.mnCoordinates;
    end
    StackProjection = StackProjection';
end
[dim1, dim2] = size(StackProjection);
% [dim1, dim2] = size(ROIs{1});


% Get ROI Borders & Barycenter
ROI_barycenter = NaN(n_cells, 2);
border_elements = NaN(1, n_cells);
ROI = struct('ROI', [], 'Border', [], 'Barycenter', [], 'Radius', []);

for i_cell = 1:n_cells
    if strcmpi(FLAG_ROI_input, 'ImageJ')
        ROI_coords = tmp_ROI{1, i_cell};
        tmp_logic_img = zeros(dim1, dim2); % Reset the blank image
        
        % Draw single cell logic ROI.
        for i_coord = 1:numel(ROI_coords(:, 1))
            try
            tmp_logic_img(double(int32(ROI_coords(i_coord, 1))), double(int32(ROI_coords(i_coord, 2)))) = 1;
            catch
                keyboard
            end
        end
        ROI_Surface = logical(tmp_logic_img);
        
    elseif strcmpi(FLAG_ROI_input, '.mat')
        ROI_Surface = logical(tmp_ROI{1, i_cell});
    end
        % Connect existing gaps.
        SE_Neigh = strel('disk', Neighbourhood_Element_Radius); % Creates structuring neighbourhood element
        ROI_Surface = imclose(ROI_Surface, SE_Neigh); % Closes gaps
        ROI_Surface = imfill(ROI_Surface, 'holes');
        
        % Barycenter.
        [tmp_ROI_filled_1, tmp_ROI_filled_2] = find(ROI_Surface);
        tmp_ROI_filled = [tmp_ROI_filled_1, tmp_ROI_filled_2];
        ROI_barycenter(i_cell, 1:2) = [round(nanmean(tmp_ROI_filled(:, 1))), round(nanmean(tmp_ROI_filled(:, 2)))];
        % Make sure it's not out of bounds.
        if ROI_barycenter(i_cell, 1) > dim1
            ROI_barycenter(i_cell, 1) = dim1;
        end
        if ROI_barycenter(i_cell, 2) > dim2
            ROI_barycenter(i_cell, 2) = dim2;
        end
        
        % Get Border.
        [ROI_Borders, ~, ~, ~] = bwboundaries(ROI_Surface, 8);
        ROI_Borders = ROI_Borders{1};
        % Controls for integrity of borders
        border_elements(1, i_cell) = numel(ROI_Borders(:, 1));
        
        % Average Cell Radius (Average distance barycenter-border)
        tmp_dist = NaN(numel(ROI_Borders(:, 1)), 1);
        for i_border_unit = 1:numel(ROI_Borders(:, 1))
            tmp_dist(i_border_unit, 1) = pdist([ROI_barycenter(i_cell,:); ROI_Borders(i_border_unit, :)], 'euclidean');
        end
        ROI_Radius = nanmean(tmp_dist);
        
        ROI(i_cell).ROI = ROI_Surface;
        ROI(i_cell).Border = ROI_Borders;
        ROI(i_cell).Barycenter = ROI_barycenter(i_cell, 1:2);
        ROI(i_cell).Radius = ROI_Radius;
end

% Controls for integrity of borders
tmp_border_elements_std = nanstd(border_elements);
tmp_border_elements_mean = nanmean(border_elements);
for i_cell = 1:n_cells
    if border_elements(i_cell) > tmp_border_elements_mean + 4*tmp_border_elements_std
        fprintf('ROI of cell %d, mouse %s might be open.\n', i_cell, MouseName);
    end
end
fprintf('...Done!\n\n');


%% Plots
% Normalize Projection
StackProjection = (StackProjection - nanmin(nanmin(StackProjection)))./nanmax(nanmax(StackProjection - nanmin(nanmin(StackProjection))));

% If there is a mismatch between the stack projection and the ROI
% dimentions, then send warning, and set background to gray
[dim1_ROI, dim2_ROI] = size(ROI(1).ROI);
if dim1 ~= dim1_ROI || dim2 ~= dim2_ROI
    warning (sprintf('\n~~~\nThe dimensions of the ROIs do not match with the background image dimensions.\nUsing a grey background instead.\n~~~\n'))
    StackProjection = 0.25.*ones(size(ROI(1).ROI));
end

StackProjection_RGB = cat(3, StackProjection, StackProjection, StackProjection);

for i_state = 1:4
    switch i_state 
        case 1
            StateName = 'Awake';
        case 2
            StateName = 'NonREM';
        case 3
            continue
        case 4
            StateName = 'REM';
    end
    Graph = MeanOfStates(i_state).Corr_Graph_MeanOfStates;
    Graph_Centrality = MeanOfStates(i_state).Corr_Graph_Centrality;
    Graph_Connectivity_Index = MeanOfStates(i_state).Corr_Graph_Connectivity_Index;
    currentState_ClusterAssignment = cluster_assignment{i_state};
    
    if ~isempty(Graph) % Check for the Graph to at least exist
        %% Plot Graph
        % Set Line Widths according to Weights 
        try
            Graph_Weights = abs(Graph.Edges.Weight);
        catch
            if isnan(Graph)
                Graph_Weights = [];
            end
        end
        if ~isempty(Graph_Weights) % Check for any connection to be present.
            
            % Set maximum (grey) luminance to 0.5
            StackProjection_RGB_ROIs = StackProjection_RGB./2;
            
            % Get Nodes
            Graph_Nodes = str2double(Graph.Nodes{:, 1});
            n_nodes = numel(Graph_Nodes);
            
            % Get average & max Connections Weight (to normalize the connection lines width)            
            Graph_Weights = (Graph.Edges{:, 2});
            weigths_min = nanmin(Graph_Weights);
            weigths_max = nanmax(Graph_Weights);
            weigths_mean = nanmean(Graph_Weights);
            weigths_std = nanstd(Graph_Weights);
            Graph_Weights_Plot = Graph_Weights - weigths_min + min_weight_fixed; % Set minumum weight at the fixed value
            Graph_Weights_Plot = (Graph_Weights_Plot./(weigths_max - weigths_min + min_weight_fixed)).*max_weight_fixed;
            
            if numel(Graph_Weights) >= 2 % Check that there is at least a connection
                % Highlight neurons: blue if they are not part
                % of the functional map, red if they are.
                for i_cell = 1:n_cells
                    current_ROI = double(ROI(i_cell).ROI);
                    % Assign color to Nodes and Non-Nodes Cells
                    current_color = 3; % Blue
                    for i_node = 1:n_nodes
                        if str2double(Graph.Nodes{i_node, 1}) == i_cell
                            current_color = 1; % Red
                            break
                        end
                    end
                    % Increase the specific color by a constant, in the ROI
                    % area
                    currentProjection_color = StackProjection_RGB_ROIs(:, :, current_color);
%                     if nanmax(currentProjection_color(current_ROI == 1)) < 0.5 % Check that it does not go out of borders
%                         currentProjection_color(current_ROI == 1) = currentProjection_color(current_ROI == 1).*2;
%                     end
                    currentProjection_color(current_ROI == 1) = 0.75.*ones(size(currentProjection_color(current_ROI == 1)));
                    StackProjection_RGB_ROIs(:, :, current_color) = currentProjection_color;
                end
                % Find cells not part of the network
                % cells_isolated = zeros(1, n_cells);
                cells_numbered = 1:n_cells;
                cells_isolated = cells_numbered;
                cells_isolated(Graph_Nodes) = [];
                cells_active = cells_numbered(Graph_Nodes);
                
                figure(); set(gcf,'position', get(0,'screensize'));
                imshow(StackProjection_RGB_ROIs, 'InitialMagnification', 'fit');
                
                % Draw connections
                hold on;
                for i_edge = 1:numel(Graph.Edges(:, 1))
                    current_Link = str2double(Graph.Edges{i_edge, 1});
                    current_Weight = Graph_Weights_Plot(i_edge);
                    current_Edge_Coord_1 = ROI(current_Link(1)).Barycenter;
                    current_Edge_Coord_2 = ROI(current_Link(2)).Barycenter;
                    if Graph_Weights(i_edge) > weigths_min + weigths_std
                        h_linkplot = plot([current_Edge_Coord_1(2), current_Edge_Coord_2(2)], [current_Edge_Coord_1(1), current_Edge_Coord_2(1)], 'LineWidth', current_Weight, 'Color', [1, 0, 0]);
                    else
                        h_linkplot = plot([current_Edge_Coord_1(2), current_Edge_Coord_2(2)], [current_Edge_Coord_1(1), current_Edge_Coord_2(1)], '--', 'LineWidth', current_Weight, 'Color', [1, 0, 0]);
                        h_linkplot.Color(4) = 0.5;
                    end
                end
                
                % Add neuron label to the center of each neuron
                for i_cell = 1:n_cells
                    current_Barycenter = ROI(i_cell).Barycenter;
                    text(current_Barycenter(2), current_Barycenter(1), num2str(i_cell), 'FontSize', 8, 'Color', 'black')
                end
                
                title(sprintf('%s\nConnectivity Index: %0.3g', StateName, Graph_Connectivity_Index));
                                
                % Set color of the border of each cell according to the
                % subnetwork it belongs to.
                tmp_clusters_labels = unique(currentState_ClusterAssignment(~isnan(currentState_ClusterAssignment)));
                n_subnetworks = numel(tmp_clusters_labels);
                tmp_clusters_labels(:, 2) = 1:n_subnetworks;
                % Trick to get a color for each subnetwork
                tmp_fig = figure('visible', 'off');
                SubNetworkColorRGB = NaN(n_subnetworks, 3);
                for i_subnetwork = 1:n_subnetworks
                    tmp_h_plotS(i_subnetwork) = plot(1:10, 1:10);
                    hold on;
                    SubNetworkColorRGB(i_subnetwork, :) = get(tmp_h_plotS(i_subnetwork), 'Color');
                end
                close gcf
                for i_cell = 1:n_cells
                    current_SubNetwork = currentState_ClusterAssignment(i_cell);
                    if isnan(current_SubNetwork)
                        continue
                    end
                    current_SubNetwork_translated = tmp_clusters_labels((tmp_clusters_labels(:, 1) == current_SubNetwork), 2);
                    current_Border = ROI(i_cell).Border;
                    if  any(tmp_clusters_labels(:, 1) == i_cell)
                        h_border = plot(current_Border(:, 2), current_Border(:, 1), 'Color', SubNetworkColorRGB(current_SubNetwork_translated, :), 'LineWidth', CellNodeBorderLineWidth);
                    else
                        h_border = plot(current_Border(:, 2), current_Border(:, 1), 'Color', SubNetworkColorRGB(current_SubNetwork_translated, :), 'LineWidth', CellBorderLineWidth);
                    end
                end
                
                % Set Marker Sizes according to Edges Centrality <<<------------------------- Change to color code?
                
                
            end
            
        else % If there are no connections (likely for short states)
            h_linkplot = plot([1, 1], 'LineStyle', 'none', 'Marker', 'none');
        end
        
        PlotPath = Opts.Dir_Figures;
        
        % Save
        FileName_Figure_1 = sprintf('%s - %s', tmp_FileName_Figure_1, StateName);
        FilePath = sprintf('%s\\%s', PlotPath, FileName_Figure_1);
        if Opts.CorrAnalysis.Opts_MeanStatesPlots.FLAG_Save == 1
            print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
            saveas(gcf, strcat(FilePath, '.jpg'))
            saveas(gcf, strcat(FilePath, '.fig'))
            close gcf
        end
        
        %% Plot neurons ranked by centrality
        if FLAG_CentralityRankedPlot == 1
            figure; set(gcf,'position', get(0,'screensize'));
            n_subplots_x = 3;
            i_subplot = 1;
            % Eigenvector Weighted
            tmp_Centrality_EigenWeighted_Sorted = NaN(n_cells, 1);

            try
                tmp_Centrality_EigenWeighted_Sorted(cells_active) = Graph_Centrality.Eigenvector_Weighted; % Keep the inactive cells with Centrality = 0
            catch
                if isscalar(Graph_Centrality)
                    if isnan(Graph_Centrality)
                        fprintf('Graph Centrality was a NaN.\n')
                    end
                end
            end
            [tmp_Centrality_EigenWeighted_Sorted(:, 1), tmp_Centrality_EigenWeighted_Sorted(:, 2)] = sort(tmp_Centrality_EigenWeighted_Sorted, 'descend');
            tmp_Centrality_EigenWeighted_Sorted(1:(numel(cells_isolated)), :) = []; % Remove inactive cells from centrality display
            labels_neuron_ID = cell(n_nodes, 1);
            for i_neuron = 1:n_nodes
                labels_neuron_ID{i_neuron, 1} = sprintf('# %d', tmp_Centrality_EigenWeighted_Sorted(i_neuron, 2));
            end
            
            subplot(1, n_subplots_x, i_subplot);
            h_barplot = barh(tmp_Centrality_EigenWeighted_Sorted(:, 1));
            set(gca, 'YDir','reverse'); % Invert the y axis
            yticks(1:n_nodes);
            yticklabels(labels_neuron_ID);
            ylabel('Neuron ID');
            xlabel(sprintf('Centrality Index\n(Eigenvector Weighted)'))
            set(gca, 'YGrid', 'off', 'XGrid', 'on');
            i_subplot = i_subplot + 1;
            
            % Betweenness
            tmp_Centrality_Betweenness_Sorted = NaN(n_cells, 1);
            try
                tmp_Centrality_Betweenness_Sorted(cells_active) = Graph_Centrality.Betweenness; % Keep the inactive cells with Centrality = 0
            catch
                if isscalar(Graph_Centrality)
                    if isnan(Graph_Centrality)
                        fprintf('Graph Centrality was a NaN.\n')
                    end
                end
            end
            [tmp_Centrality_Betweenness_Sorted(:, 1), tmp_Centrality_Betweenness_Sorted(:, 2)] = sort(tmp_Centrality_Betweenness_Sorted, 'descend');
            tmp_Centrality_Betweenness_Sorted(1:(numel(cells_isolated)), :) = []; % Remove inactive cells from centrality display
            labels_neuron_ID = cell(n_nodes, 1);
            for i_neuron = 1:n_nodes
                labels_neuron_ID{i_neuron, 1} = sprintf('# %d', tmp_Centrality_Betweenness_Sorted(i_neuron, 2));
            end
            
            subplot(1, n_subplots_x, i_subplot);
            h_barplot = barh(tmp_Centrality_Betweenness_Sorted(:, 1));
            set(gca, 'YDir','reverse'); % Invert the y axis
            yticks(1:n_nodes);
            yticklabels(labels_neuron_ID);
            ylabel('Neuron ID');
            xlabel(sprintf('Centrality Index\n(Betweenness)'))
            set(gca, 'YGrid', 'off', 'XGrid', 'on');
            i_subplot = i_subplot + 1;
            
            % Degree Weighted
            tmp_Centrality_DegreeWeighted_Sorted = NaN(n_cells, 1);
            try
                tmp_Centrality_DegreeWeighted_Sorted(cells_active) = Graph_Centrality.Degree_Weighted; % Keep the inactive cells with Centrality = 0
            catch
                if isscalar(Graph_Centrality)
                    if isnan(Graph_Centrality)
                        fprintf('Graph Centrality was a NaN.\n')
                    end
                end
            end
            [tmp_Centrality_DegreeWeighted_Sorted(:, 1), tmp_Centrality_DegreeWeighted_Sorted(:, 2)] = sort(tmp_Centrality_DegreeWeighted_Sorted, 'descend');
            tmp_Centrality_DegreeWeighted_Sorted(1:(numel(cells_isolated)), :) = []; % Remove inactive cells from centrality display
            labels_neuron_ID = cell(n_nodes, 1);
            for i_neuron = 1:n_nodes
                labels_neuron_ID{i_neuron, 1} = sprintf('# %d', tmp_Centrality_DegreeWeighted_Sorted(i_neuron, 2));
            end
            
            subplot(1, n_subplots_x, i_subplot);
            h_barplot = barh(tmp_Centrality_DegreeWeighted_Sorted(:, 1));
            set(gca, 'YDir','reverse'); % Invert the y axis
            yticks(1:n_nodes);
            yticklabels(labels_neuron_ID);
            ylabel('Neuron ID');
            xlabel(sprintf('Centrality Index\n(Degree Weighted)'))
            set(gca, 'YGrid', 'off', 'XGrid', 'on');
            i_subplot = i_subplot + 1;
            
            h_suptitle = suptitle(sprintf('Centrality of Neurons - %s\nCorrelation Threshold = %s', StateName, MeanOfStates(i_state).Corr_Thr_Criterion));
            
            % Save
            FileName_Figure_2 = sprintf('%s - %s', tmp_FileName_Figure_2, StateName);
            FilePath = sprintf('%s\\%s', PlotPath, FileName_Figure_2);
            if Opts.CorrAnalysis.Opts_MeanStatesPlots.FLAG_Save == 1
                print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
                saveas(gcf, strcat(FilePath, '.jpg'))
                saveas(gcf, strcat(FilePath, '.fig'))
                close gcf
            end
        
        end
        
        
    else % If there's no graph
        h_graph = plot([1, 1], 'LineStyle', 'none', 'Marker', 'none');
    end
        
end

