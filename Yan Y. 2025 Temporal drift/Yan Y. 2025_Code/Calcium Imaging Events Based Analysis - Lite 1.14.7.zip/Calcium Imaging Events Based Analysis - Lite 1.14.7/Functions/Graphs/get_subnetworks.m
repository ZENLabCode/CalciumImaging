function [cluster_assignment, SubNetworks] = get_subnetworks (MeanOfStates, MouseName, Opts)


% [cluster_assignment, SubNetworks] = get_subnetworks (MeanOfStates_PerMouse{1, 1}(1), Mouse_Names{1}, Opts)
rng default

connections_degree = 1; % Use only 1st-degree connections?
FLAG_Merge_SingleNode_Cluster = 1; % Merge clusters of only 1 elements with the most correlated one?


%% Initialize variables
Graph = MeanOfStates.Corr_Graph_MeanOfStates;
Graph_Centrality = MeanOfStates.Corr_Graph_Centrality;
Graph_Connectivity_Index = MeanOfStates.Corr_Graph_Connectivity_Index;
if numel(find(MeanOfStates.AdjacencyMatrix_MeanOfStates)) == 0 && isempty(Graph) % Check for the presence of a network in the first place...
    fprintf('The Graph variable is empty. The Adjecency Matrix is the null matrix or a NaN matrix.\n')
    cluster_assignment = NaN;
    SubNetworks = struct;
    return
end


try
    Graph_Nodes = str2double(Graph.Nodes{:, 1});
catch
    if isscalar(Graph)
        if isnan(Graph)
            fprintf('The Graph variable is not a struct. Graph = %d.\n', Graph)
            cluster_assignment = NaN;
            SubNetworks = struct;
            return
        end
    end
end
Graph_Links = str2double(Graph.Edges{:, 1});
Graph_Weights = abs(Graph.Edges.Weight);
Graph_Connections = [Graph_Links, Graph_Weights];

[n_cells, ~] = size(MeanOfStates.Corr_Matrix_Mean);
n_nodes = numel(Graph_Nodes);
cells_numbered = 1:n_cells;
cells_isolated = cells_numbered;
cells_isolated(Graph_Nodes) = [];
cells_active = cells_numbered(Graph_Nodes);

% Define a functional distance: 1 - connectivity weight
Graph_Connections(:, 4) = (1 - Graph_Weights)./Graph_Weights;
n_Connections = numel(Graph_Connections(:, 1));

% All possible links (bidirectional)
LinksAll = nchoosek(1:n_cells, 2);
n_Links = numel(LinksAll(:, 1));
ConnectionsAll = LinksAll;
ConnectionsAll(:, 3:4) = NaN(n_Links, 2);

% Symmetrical connections
tmp(:, 1) = Graph_Connections(:, 2);
tmp(:, 2) = Graph_Connections(:, 1);
tmp(:, 3:4) = Graph_Connections(:, 3:4);
Graph_ConnectionsSym = [Graph_Connections; tmp];
Graph_ConnectionsSym = sortrows(Graph_ConnectionsSym, [1, 2]);

for i_connection = 1:n_Connections
    x = Graph_Connections(i_connection, 1);
    y = Graph_Connections(i_connection, 2);
    for i = 1:n_Links
        if ConnectionsAll(i, 1) == x && ConnectionsAll(i, 2) == y
            ConnectionsAll(i, 3) = Graph_Connections(i_connection, 3);
            ConnectionsAll(i, 4) = Graph_Connections(i_connection, 4);
            break
        end
    end
end

% Connections matrix
ConnectionsMatrix = zeros(n_Connections, n_Connections);
for i_connection = 1:n_Connections*2
    x = Graph_ConnectionsSym(i_connection, 1);
    y = Graph_ConnectionsSym(i_connection, 2);
    ConnectionsMatrix(x, y) = Graph_ConnectionsSym(i_connection, 4);
end

% y = squareform(ConnectionsMatrix);
% y(y == 0) = NaN;
% Z = linkage(y);
% dendrogram(Z)


% Non-Euclidean Space


%% Clustering 1

AdjacencyMatrix = MeanOfStates.AdjacencyMatrix_MeanOfStates;
CumChange_AdjMatrix = AdjacencyMatrix;
% Compute betweenness.
C_Betweenness = NaN(n_cells, 1);
C_Betweenness(cells_active) = Graph_Centrality.Betweenness;
C_EigenWeighted = NaN(n_cells, 1);
C_EigenWeighted(cells_active) = Graph_Centrality.Eigenvector_Weighted;
C_DegreeWeighted = NaN(n_cells, 1);
C_DegreeWeighted(cells_active) = Graph_Centrality.Degree_Weighted;

CumChange_C_Betweenness = C_Betweenness;
CumChange_C_EigenWeighted = C_EigenWeighted;
CumChange_C_DegreeWeighted = C_DegreeWeighted;
C_Change_Absolute_Betweenness = NaN(n_cells, 1);
C_Change_Absolute_EigenWeighted = NaN(n_cells, 1);
C_Change_Absolute_DegreeWeighted = NaN(n_cells, 1);

% Check if there are only lonely connections
[tmp_MaxBetweenness, tmp_CellNode] = nanmax(C_Betweenness);
if isnan(tmp_MaxBetweenness) || tmp_MaxBetweenness == 0
    cluster_assignment = NaN(n_cells, 1);
    for i_connection = 1:numel(Graph_Links(:, 1))
        cluster_assignment(Graph_Links(i_connection, :)) = Graph_Links(i_connection, 1);
        SubNetworks(i_connection).MainNode = Graph_Links(i_connection, 1);
        SubNetworks(i_connection).MainNode_Centrality = NaN; % Intended as its centrality in the parent Network
        SubNetworks(i_connection).Nodes = Graph_Links(i_connection, :); % Nodes part of the sub-network
        SubNetworks(i_connection).Connections = [Graph_Links(i_connection, :), Graph_Weights(i_connection, :)];
        SubNetworks(i_connection).ConnectedNodes = Graph_Links(i_connection, :); % Nodes with connections to the sub-network
        SubNetworks(i_connection).Graph = NaN;
        SubNetworks(i_connection).AdjacencyMatrix = NaN;
        SubNetworks(i_connection).Centrality = NaN;
        SubNetworks(i_connection).ConnectivityIndex = NaN;
        SubNetworks(i_connection).NodesConnectivityIndex = NaN;
    end
    return
end

% Start looping.
CellNodes = NaN;
FLAG_loop = 1;
i_CellNode = 1;
while FLAG_loop == 1
    % Select cell with highest betweenness (X) to make its own cluster.
    % (Iterate selecting the next X-cell based on the network with all 
    % the removed X-cells..)
    [current_MaxBetweenness, current_CellNode] = nanmax(CumChange_C_Betweenness);
    % End when there are only cells with 0 betweeness.
    if isnan(current_MaxBetweenness) || current_MaxBetweenness == 0
        break
    end
    CellNodes(i_CellNode) = current_CellNode;
    
    % Remove cell from network.
    Current_AdjMatrix = AdjacencyMatrix;
    Current_AdjMatrix(current_CellNode, :) = 0;
    Current_AdjMatrix(:, current_CellNode) = 0;
    CumChange_AdjMatrix(current_CellNode, :) = 0;
    CumChange_AdjMatrix(:, current_CellNode) = 0;
    
    % Update Graph
    Current_Graph = graph(Current_AdjMatrix, 'upper');
    [~, Current_Graph] = Graph_remove_singlets (Current_Graph);
    
    % If the next network is empty, stop
    if numel(find(CumChange_AdjMatrix)) <= 1 
        break
    end
    
    % Recompute betweenness and weighted centralities for each cell.
    Current_Centrality = compute_centrality (Current_Graph);
    Current_Graph_Nodes = str2double(Current_Graph.Nodes{:, 1});
    Current_cells_active = cells_numbered(Current_Graph_Nodes);
    Current_C_Betweenness = NaN(n_cells, 1);
    Current_C_Betweenness(Current_cells_active) = Current_Centrality.Betweenness;
    Current_C_EigenWeighted = NaN(n_cells, 1);
    Current_C_EigenWeighted(Current_cells_active) = Current_Centrality.Eigenvector_Weighted;
    Current_C_DegreeWeighted = NaN(n_cells, 1);
    Current_C_DegreeWeighted(Current_cells_active) = Current_Centrality.Degree_Weighted;
    
    % Compute cumulative graph changes
    try
        CumChange_Graph = graph(CumChange_AdjMatrix, 'upper');
        [~, CumChange_Graph] = Graph_remove_singlets (CumChange_Graph);
        CumChange_Centrality = compute_centrality (CumChange_Graph);
        CumChange_Graph_Nodes = str2double(CumChange_Graph.Nodes{:, 1});
        CumChange_cells_active = cells_numbered(CumChange_Graph_Nodes);
    catch
        keyboard
    end
    
    CumChange_C_Betweenness = NaN(n_cells, 1);
    CumChange_C_Betweenness(CumChange_cells_active) = CumChange_Centrality.Betweenness;
    CumChange_C_EigenWeighted = NaN(n_cells, 1);
    CumChange_C_EigenWeighted(CumChange_cells_active) = CumChange_Centrality.Eigenvector_Weighted;
    CumChange_C_DegreeWeighted = NaN(n_cells, 1);
    CumChange_C_DegreeWeighted(CumChange_cells_active) = CumChange_Centrality.Degree_Weighted;
    
    % Compute the current change in centralities
    tmp1 = C_Betweenness;
    tmp2 = Current_C_Betweenness;
    tmp2(isnan(tmp1)) = 0;
    tmp1(isnan(tmp1)) = 0;
    C_Change_Absolute_Betweenness(:, i_CellNode) = tmp1 - tmp2;
    
    tmp1 = C_EigenWeighted;
    tmp2 = Current_C_EigenWeighted;
    tmp2(isnan(tmp1)) = 0;
    tmp1(isnan(tmp1)) = 0;
    C_Change_Absolute_EigenWeighted(:, i_CellNode) = tmp1 - tmp2;
    
    tmp1 = C_DegreeWeighted;
    tmp2 = Current_C_DegreeWeighted;
    tmp2(isnan(tmp1)) = 0;
    tmp1(isnan(tmp1)) = 0;
    C_Change_Absolute_DegreeWeighted(:, i_CellNode) = tmp1 - tmp2;
    
    % End when only cells with 0 betweeness.
    
    i_CellNode = i_CellNode + 1;
end

% Initialize Clusters as the main nodes.
cluster_assignment = NaN(n_cells, 1);
cluster_assignment(CellNodes) = CellNodes;

% Assign cells to clusters
for i_cell = 1:n_cells
    if any(CellNodes == i_cell) % Skip central nodes
        continue
    end
    if any(isnan(C_Change_Absolute_DegreeWeighted(i_cell, :)))
        % Assigns cells that remained isolated by the removal of a main node to
        % the corresponding cluster
        max_loc = find(isnan(C_Change_Absolute_DegreeWeighted(i_cell, :)));
    else
        if ~any(C_Change_Absolute_DegreeWeighted(i_cell, :) ~= 0) % Skip Lonely cells (do not assign)
            continue
        else
            % Assign the cells according to their highest change in centrality
            [max_value, max_loc] = max(C_Change_Absolute_DegreeWeighted(i_cell, :));
        end
    end
    cluster_assignment(i_cell) = CellNodes(max_loc);
end
CellNodes_Ordered = sort(CellNodes);
n_clusters = numel(CellNodes);

% Merge clusters with 1 element with most correlated one
if FLAG_Merge_SingleNode_Cluster == 1
    tmp = unique(cluster_assignment);
    tmp_cluster_numbers = histc(cluster_assignment, tmp(~isnan(tmp)));
    tmp = find(tmp_cluster_numbers == 1, 1);
    if ~isempty(tmp) % If 1-element clusters are found
        LinkCells = NaN(numel(tmp), 1);
        for i_cluster = 1:numel(tmp) % Find element that they are most correlated with
            current_element = CellNodes_Ordered(tmp(i_cluster));
            tmp_col = AdjacencyMatrix(:, current_element);
            tmp_row = AdjacencyMatrix(current_element, :);
            tmp_col_row = tmp_col + tmp_row';
            [tmp_max1, tmp_max_pos1] = nanmax(tmp_col);
            [tmp_max2, tmp_max_pos2] = nanmax(tmp_row);
            % Merge with the most correlated element's cluster
            if tmp_max1 > tmp_max2
                cluster_assignment(current_element) = cluster_assignment(tmp_max_pos1);
            else
                cluster_assignment(current_element) = cluster_assignment(tmp_max_pos2);
            end
            LinkCells(i_cluster) = current_element;
            CellNodes(CellNodes == current_element) = [];
        end
        % Update CellNodes & n_clusters
        CellNodes_Ordered = sort(CellNodes);
        n_clusters = numel(CellNodes);
    end
end

% Merge clusters according to high connectivity criteria

% Connectivity criteria is: average degree of connectivity between two
% clusters (which degree? direct weighted?)

% How to enstablish the connectivity threshold to merge clusters? Find
% minimum case? Enstablish simulated distribution (no, it's going to be
% smooth exponential decay...)
%  Find minimum case taking into account minimal correlation-connetions
%  between each neuron (e.g. the minimum weight a connection can have to be
%  counted as significant)


% Get SubNetworks nodes.
Subnetworks_Nodes = cell(n_clusters, 1);
for i_net = 1:n_clusters
    Subnetworks_Nodes{i_net} = find(cluster_assignment == CellNodes_Ordered(i_net));
end
% Get SubNetworks properties.
SubNetworks = get_subnetworks_sub1 (Graph_Links, Graph_Weights, Subnetworks_Nodes, CellNodes_Ordered, n_cells);














% for i_edge = 1:n_Connections
%     a1 = str2double(Graph.Edges{i_edge, 1});
%     a2 = a1(2);
%     a1 = a1(1);
%     if any(CellNodes_Ordered == a1) || any(CellNodes_Ordered == a2)
%         SubGraph = Graph;
%         SubGraph.Edges{:, 1} = []
%         SubGraph.Edges{i_edge, 1} = Graph.Edges{i_edge, 1};
%         SubGraph.Edges{i_edge, 2} = Graph.Edges{i_edge, 2};
%     end
% end
% LinkCells is an experimental measure: its the cells that are at the
% border between two sub-networks. It is either cells with very high
% betweenness, but form 1-cell only clusters, or cells that belong almost
% equally to two clusters. 


% TEST If leftover douplets, assign them to their own cluster.



%% Clustering 2


%% Clustering 3

% Compute 10k configs

% ---
% Compute one configuration

% Assign all cells to each own cluster
% Start from random cell.
% Check all its Z-distances.
% If distance < inf, 
% Merge with:
%   - closest cell
%   - random cell with probability = f(distance)
% Stop when?
% ---


%%
% test
% Z = linkage(Graph_Connections(:, 4));
% 
% Centrality_Betweenness_Sorted = NaN(n_cells, 1);
% Centrality_Betweenness_Sorted(cells_active) = Graph_Centrality.Betweenness; % Keep the inactive cells with no Centrality
% Centrality_Betweenness_Sorted(cells_isolated, 1) = 0; % Set inactive cells centrality to 0
% [Centrality_Betweenness_Sorted(:, 1), Centrality_Betweenness_Sorted(:, 2)] = sort(Centrality_Betweenness_Sorted, 'descend');

