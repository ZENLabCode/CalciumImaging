function Connectivity_Index_OverTime_perMouse = cmp_ConnectivityIndex_sessionsArray (MeanOfStates_PerSession)

% Gets the Connectivity Index array over each session and state
n_sessions = numel(MeanOfStates_PerSession);


MouseNumber_Array = NaN(n_sessions, 1);
for i_session = 1:n_sessions
    MeanOfStates_CurrentSession = MeanOfStates_PerSession{i_session};
    try
        MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(1).MouseNumber;
    catch
        MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(2).MouseNumber;
    end
end
n_mice = numel(unique(MouseNumber_Array));
Connectivity_Index_OverTime_perMouse = NaN(4, n_sessions, n_mice);

MeanOfStates_CurrentSession = MeanOfStates_PerSession{1};
previous_mouse = MouseNumber_Array(1);
for i_state = 1:4
    if i_state == 3
        continue
    end
    
    j_session = 1;
    for i_session = 1:n_sessions
        MeanOfStates_CurrentSession = MeanOfStates_PerSession{i_session};
        tmp = diff(MouseNumber_Array);
         
        try
            Connectivity_Index_OverTime_perMouse(i_state, j_session, MouseNumber_Array(i_session)) = MeanOfStates_CurrentSession(i_state).Corr_Graph_Connectivity_Index;
        catch
            try
                Connectivity_Index_OverTime_perMouse(i_state, j_session, MouseNumber_Array(i_session)) = NaN;
            catch
                keyboard
            end
        end
        % Advance the index of the output array
        if i_session < n_sessions
            if tmp(i_session) >= 1
                j_session = 1;
            else
                j_session = j_session + 1;
            end
        else
            j_session = j_session + 1;
        end
        
    end
end