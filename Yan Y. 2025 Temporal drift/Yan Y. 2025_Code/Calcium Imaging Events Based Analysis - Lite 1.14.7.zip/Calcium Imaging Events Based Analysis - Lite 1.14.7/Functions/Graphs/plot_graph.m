function [h_graph] = plot_graph (Graph, Graph_Centrality, Graph_Connectivity_Index, Opts_GraphPlot)
% Plots a connectivity Graph (thought for correlation based connectivity)

% Set Defaults
if nargin < 4
    Opts_GraphPlot.label_color = 'k';
    Opts_GraphPlot.Centrality_Displayed = Degree_Weighted;
    Opts_GraphPlot.Marker_Thickness_Mult = 2;
    str_ylabel = 'Connectivity Graph';
    str_title = 'Connectivity Graph';
else
    if Opts_GraphPlot.state_info.StateNumber ~= 0
        str_ylabel = sprintf('State #%s - %s.\nDuration %g[s])', Opts_GraphPlot.state_info.StateNumber, Opts_GraphPlot.state_info.StateTag, Opts_GraphPlot.state_info.Duration);
        str_title = sprintf('State #%s - %s.\nConnectivity Index = %d. Duration = %g[s])', Opts_GraphPlot.state_info.StateNumber, Opts_GraphPlot.state_info.StateTag, Graph_Connectivity_Index, Opts_GraphPlot.state_info.Duration);
    else
        str_ylabel = sprintf('Connectivity Map - %s States.\nConnectivity Index = %d.', Opts_GraphPlot.state_info.StateTag, Graph_Connectivity_Index);
        str_title = sprintf('Connectivity Map - %s States.\nConnectivity Index = %d.', Opts_GraphPlot.state_info.StateTag, Graph_Connectivity_Index);
    end
    
end
if nargin < 3
   Graph_Connectivity_Index = NaN; 
end
if nargin < 2
   warning('Centrality measure missing: every node is being plotted with the same weigth.')
   Graph_Centrality.Degree = ones(numel(Corr_Graph.Nodes), 1);
   Graph_Centrality.Degree_Weighted = ones(numel(Corr_Graph.Nodes), 1);
   Graph_Centrality.Eigenvector = ones(numel(Corr_Graph.Nodes), 1);
   Graph_Centrality.Eigenvector_Weighted = ones(numel(Corr_Graph.Nodes), 1);
   Graph_Centrality.Betweenness = ones(numel(Corr_Graph.Nodes), 1);
end

% Options
LineWidth_Min = 0.5;
LineWidth_Max = 5;
Graph_Layout = 'layered'; % Layout can be 'auto', 'force', 'circle', 'layered', 'force3'
FLAG_rotate90 = 1; % Rotate axis 90'
FLAG_Remove_Ticks = 1;
title_FontSize = 14;

% Plot
if ~isempty(Graph) % Check for the Graph to at least exist
    % Get Graph Weights
    Graph_Weights = abs(Graph.Edges.Weight);
    if ~isempty(Graph_Weights) % Check for any connection to be present.
        tmp_graph_weights_min = nanmin(Graph_Weights);
        tmp_min = LineWidth_Min/LineWidth_Max;
        if tmp_graph_weights_min > tmp_min
            Graph_Weights = Graph_Weights - (tmp_graph_weights_min - tmp_min);
        end
        LineWidths = LineWidth_Max*(Graph_Weights)/max(Graph_Weights);
        if numel(Graph_Weights) > 2
            % Plot Graph
            h_graph = plot(Graph, 'Layout', Graph_Layout, 'EdgeLabel', Graph_Weights, 'LineWidth', LineWidths);
            h_graph.EdgeLabel = [];
            switch Opts_GraphPlot.Centrality_Displayed
                case 'Degree Weighted'
                    h_graph.MarkerSize = Graph_Centrality.Degree_Weighted.*(Opts_GraphPlot.Marker_Thickness_Mult);
                case 'Degree'
                    h_graph.MarkerSize = Graph_Centrality.Degree.*(Opts_GraphPlot.Marker_Thickness_Mult);
                case 'Eigenvector'
                    h_graph.MarkerSize = Graph_Centrality.Eigenvector.*(Opts_GraphPlot.Marker_Thickness_Mult);
                case 'Eigenvector Weighted'
                    h_graph.MarkerSize = Graph_Centrality.Eigenvector_Weighted.*(Opts_GraphPlot.Marker_Thickness_Mult);
                case 'Betweenness'
                    h_graph.MarkerSize = Graph_Centrality.Betweenness.*(Opts_GraphPlot.Marker_Thickness_Mult);
                otherwise
                    warning('Requested to display the wrong Degree of Centrality in the Plot as Markers Size.')
            end
            
        else % If there are no connections (likely for short states)
            h_graph = plot([1, 1], 'LineStyle', 'none', 'Marker', 'none');
        end
    else % If there are no connections (likely for short states)
        h_graph = plot([1, 1], 'LineStyle', 'none', 'Marker', 'none');
    end
else
    h_graph = plot([1, 1], 'LineStyle', 'none', 'Marker', 'none');
end

if FLAG_rotate90 == 1
    camroll(-90)
end

if FLAG_Remove_Ticks == 1
    set(gca,'xtick',[])
    set(gca,'xticklabel',[])
    set(gca,'ytick',[])
    set(gca,'yticklabel',[])
end

box on;
axis tight;
axis square;
title(str_title, 'Color', Opts_GraphPlot.label_color, 'FontSize', title_FontSize);

% ylabel(str_ylabel, 'Color', Opts_GraphPlot.label_color);