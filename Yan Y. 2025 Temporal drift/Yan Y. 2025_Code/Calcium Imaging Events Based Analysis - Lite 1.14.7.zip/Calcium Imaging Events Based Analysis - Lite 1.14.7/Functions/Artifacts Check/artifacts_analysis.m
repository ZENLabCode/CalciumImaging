function Transition_Artifacts = artifacts_analysis (CalciumTraces, Hypnogram_AllSessions, MouseName, Opts)
% This function plots all the traces, together with the Hypnogram, EMG, 
% and a trace that shows where artifacts are detected.
% This function is called by artifacts_check_allSessions

transition_duration = Opts.transition_duration;

EMG = Hypnogram_AllSessions.EMG;
Artifacts_Trace = Hypnogram_AllSessions.Artifacts_Trace;
Hypnogram = Hypnogram_AllSessions.Hypnogram;
calTime = Hypnogram_AllSessions.calTime;
StateChanges = Hypnogram_AllSessions.StateChanges;
StateIsStable = Hypnogram_AllSessions.StateIsStable;
StableStates = Hypnogram(StateChanges);

n_frames = numel(Hypnogram);


%% Compute Fraction of artifacts at each state change.
Transition_Artifacts.A2N.N = 0;
Transition_Artifacts.N2A.N = 0;
Transition_Artifacts.N2R.N = 0;
Transition_Artifacts.R2A.N = 0;
Transition_Artifacts.R2N.N = 0;
Transition_Artifacts.A2N.N_Artifact = 0;
Transition_Artifacts.N2A.N_Artifact = 0;
Transition_Artifacts.N2R.N_Artifact = 0;
Transition_Artifacts.R2A.N_Artifact = 0;
Transition_Artifacts.R2N.N_Artifact = 0;
Transition_Artifacts.UnstableStates = 0;

for i_state = 2:numel(StableStates)
    PreviousState = StableStates(i_state - 1);
    CurrentState = StableStates(i_state);

    % Check if there are artifacts during the transition period.
    Current_Transition_TimePoint = StateChanges(i_state);
    if Current_Transition_TimePoint + transition_duration > n_frames
        TimeInterval_Artifacts = Artifacts_Trace(Current_Transition_TimePoint:end);
    else
        TimeInterval_Artifacts = Artifacts_Trace(Current_Transition_TimePoint:Current_Transition_TimePoint + transition_duration);
    end
    FLAG_Artifacts = nansum(TimeInterval_Artifacts);
    FLAG_Artifacts = logical(FLAG_Artifacts);
    
    if StateIsStable(i_state) == 0
        Transition_Artifacts.UnstableStates = Transition_Artifacts.UnstableStates + 1;
        continue
    end
    
    if  FLAG_Artifacts == 1
        if PreviousState == 1 && CurrentState == 2
            Transition_Artifacts.A2N.N = Transition_Artifacts.A2N.N + 1;
            Transition_Artifacts.A2N.N_Artifact = Transition_Artifacts.A2N.N_Artifact + 1;
        elseif PreviousState == 2 && CurrentState == 1
            Transition_Artifacts.N2A.N = Transition_Artifacts.N2A.N + 1;
            Transition_Artifacts.N2A.N_Artifact = Transition_Artifacts.N2A.N_Artifact + 1;
        elseif PreviousState == 2 && CurrentState == 4
            Transition_Artifacts.N2R.N = Transition_Artifacts.N2R.N + 1;
            Transition_Artifacts.N2R.N_Artifact = Transition_Artifacts.N2R.N_Artifact + 1;
        elseif PreviousState == 4 && CurrentState == 1
            Transition_Artifacts.R2A.N = Transition_Artifacts.R2A.N + 1;
            Transition_Artifacts.R2A.N_Artifact = Transition_Artifacts.R2A.N_Artifact + 1;
        elseif PreviousState == 4 && CurrentState == 2
            Transition_Artifacts.R2N.N = Transition_Artifacts.R2N.N + 1;
            Transition_Artifacts.R2N.N_Artifact = Transition_Artifacts.R2N.N_Artifact + 1;
        end
    else
        if PreviousState == 1 && CurrentState == 2
            Transition_Artifacts.A2N.N = Transition_Artifacts.A2N.N + 1;
        elseif PreviousState == 2 && CurrentState == 1
            Transition_Artifacts.N2A.N = Transition_Artifacts.N2A.N + 1;
        elseif PreviousState == 2 && CurrentState == 4
            Transition_Artifacts.N2R.N = Transition_Artifacts.N2R.N + 1;
        elseif PreviousState == 4 && CurrentState == 1
            Transition_Artifacts.R2A.N = Transition_Artifacts.R2A.N + 1;
        elseif PreviousState == 4 && CurrentState == 2
            Transition_Artifacts.R2N.N = Transition_Artifacts.R2N.N + 1;
        end
    end
end
Transition_Artifacts.TotalStates = numel(StableStates) - Transition_Artifacts.UnstableStates;

StateChanges(1) = []; % Remove starting state (it does not start with a state change)
StateIsStable(1) = []; % Remove starting state (it does not start with a state change)
StateChanges(StateIsStable == 0) = []; % Remove unstable states



%% Initialize Figure

figure('units','normalized','outerposition', [0 0 1 1]);

SubPlot_Position_1 = [0.13, 0.35, 0.775, 0.575];
SubPlot_Position_2 = SubPlot_Position_1 - [0, 0.275, 0, 0.35];

FontSize_ylabel = 16;
FontSize_xlabel = 16;
FontSize_title = 28;

[dim1, dim2] = size(CalciumTraces);


%% Subplot 1
% h_subplot_1 = subplot(2, 1, 1, 'Position', SubPlot_Position_1);
h_subplot_1 = subplot(2, 1, 1);

yyaxis left
plot(calTime, Hypnogram, 'b', 'LineWidth', 2);
axis([-inf, inf, 0.5, 4.5]);
ylabel('State', 'FontWeight', 'bold', 'FontSize', FontSize_ylabel)
yticks([1, 2, 4])
yticklabels({'Awake', 'NREM', 'REM'})
ax = gca;
ax.YAxis(1).Color = 'b'; 
hold on;

yyaxis right
for i_trace = 1:dim2
    plot(calTime, CalciumTraces(:, i_trace) + i_trace*10, '-k');
end
set(gca,'FontSize',14)

yticks([])
% ylabel('Traces', 'FontSize', FontSize_ylabel)
title('Example Recording Session', 'FontWeight', 'bold', 'FontSize', FontSize_title)

grid on;


%% Subplot 2
h_subplot_2 = subplot(2, 1, 2);

yyaxis left
plot(calTime, Artifacts_Trace, '-r', 'LineWidth', 2)
axis([-inf, inf, -0.5, 1.5]);
ylabel('Artifacts Detection')
yticks([0, 1])
hold on;

yyaxis right
plot(calTime, EMG, 'b', 'LineWidth', 1);
axis tight
ylabel('EMG')
hold off
set(gca,'FontSize',14)

ax = gca;
ax.YAxis(1).Color = 'r'; 
ax.YAxis(2).Color = 'b'; 

grid on;

xlabel('Time [s]', 'FontWeight', 'bold', 'FontSize', FontSize_xlabel)


h_subplot_1.Position = SubPlot_Position_1;
h_subplot_2.Position = SubPlot_Position_2;


%% Save
if Opts.SaveFiguresAutomatically == 1
    % FileName = 'Figure Cells Clustered per State';
    tmpPath = [Opts.Dir_Figures, '\', 'Artifact Plots'];
    if ~isfolder(tmpPath)
        mkdir(tmpPath)
        addpath(genpath(tmpPath));
    end
    FilePath = sprintf('%s\\%s', tmpPath, MouseName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


