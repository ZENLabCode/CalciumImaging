function [Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, CalciumTraces_Noisy_AllSessions, Stats_MeanOfStatesDifferences_PerSession, Stats_MeanOfStatesDifferences_PerMouse, Connectivity_Index_OverTime_Mouse_Average, Connectivity_Index_OverTime_Mouse_StE, Betweenness_Result] = Continuous_Raw_Analysis_Lite (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts)
% This function analyzes the raw calcium traces of a mouse recordings.
% Things like correlation between traces and entropy are computed.
% The analysis and traces are taken either as entire trace per state, or as
% a continuos signal, in the form of a sliding window.

Stats_MeanOfStatesDifferences_PerSession = [];
Stats_MeanOfStatesDifferences_PerMouse = [];

% %% Options
% if nargin < 4
%     warning('Options not found for "Continuous_Raw_Analysis": using default values.')
%     Opts = set_options;
% end

FLAG_AddWhiteNoise = Opts.ContinuousAnalys.FLAG_AddWhiteNoise;
FLAG_Save_Film = Opts.ContinuousAnalys.FLAG_Save_Film;
FLAG_ReorderCorr = Opts.ContinuousAnalys.FLAG_ReorderCorr;
BoxHeight_Multiplier = Opts.ContinuousAnalys.PlotEntropy.BoxHeight_Multiplier;
FontSize_ylabel = Opts.ContinuousAnalys.PlotEntropy.FontSize_ylabel;
FontSize_suptitle = Opts.ContinuousAnalys.PlotEntropy.FontSize_suptitle;
FrameRate = Opts.General.FrameRate;


%% Analysis per Mouse
n_cells = Opts.Mouse_N_Cells;
n_mice = Opts.n_mice;
n_sessions = Opts.n_sessions;
mouse_sessions = Opts.Mouse_Sessions;
MeanOfStates_PerSession = cell(1, n_sessions);
MeanOfStates_PerMouse = cell(1, n_mice);
CalciumTraces_Noisy_AllSessions = cell(1, n_sessions);
elapsed_time = NaN(1, n_mice);
% Scroll each mouse.
i_session_tot = 1;
for i_mouse = 1:n_mice
    tic
    Current_MouseName = Mouse_Names{i_mouse};
    current_N_Sessions = mouse_sessions(i_mouse);
    
    fprintf('---Analyzing Mouse %s---\n', Current_MouseName);
    % Scroll sessions.
    for i_session = 1:current_N_Sessions
        fprintf('   Analyzing Session %d\n', i_session);
        % Get traces
        CalciumTraces = CalciumTraces_Clean_AllSessions{i_session_tot};
        % Further cleaning of too negative values.
        tmp_traces_mean = nanmean(CalciumTraces, 2);
        CalciumTraces(tmp_traces_mean < -2, :) = NaN;
        
        % Compute correlation between the traces. 
        Hypnogram_CurrentMouse = Hypnogram_AllSessions(i_session_tot).Hypnogram;
        StateChanges_CurrentMouse = Hypnogram_AllSessions(i_session_tot).StateChanges;
        if FLAG_AddWhiteNoise == 1
            CalciumTraces_Noisy = InjectNoise2CalciumTraces (CalciumTraces);
            clear CalciumTraces
            CalciumTraces_Noisy_AllSessions{1, i_session_tot} = CalciumTraces_Noisy;
            % [correlation_film, entropy_trace] = Analyze_Raw_over_TimeWindow (CalciumTraces_Noisy, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [correlation_film, ~] = Analyze_Raw_over_TimeWindow (CalciumTraces_Noisy, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [States, MeanOfStates_tmp] = Analyze_Correlation_Film (CalciumTraces_Noisy, correlation_film, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, i_mouse, Opts);
        else
            [correlation_film, ~] = Analyze_Raw_over_TimeWindow (CalciumTraces, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [States, MeanOfStates_tmp] = Analyze_Correlation_Film (CalciumTraces, correlation_film, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, i_mouse, Opts);
        end

        if i_session == 1
            States_perSession = States;
            n_session_states = numel(States);
            i_states = n_session_states;
        else
            n_session_states = numel(States);
            States_perSession(i_states+1:i_states+n_session_states) = States;
            i_states = i_states + n_session_states;
        end
        
        % Mouse_Analysis(i_session_tot).Correlation_Film = correlation_film;
        if exits('entropy_trace')
            entropy_trace = [];
        end
        Mouse_Analysis(i_session_tot).Entropy_Trace = entropy_trace;
        Mouse_Analysis(i_session_tot).States_Analysis = States;
        MeanOfStates_PerSession{i_session_tot} = MeanOfStates_tmp;
        
        
        % Compute a shuffled correlation film.
        if i_session == 1
            fprintf('   Computing Shuffled Traces Correlation\n');
            if FLAG_AddWhiteNoise == 1
                [n_timepoints, n_traces] = size(CalciumTraces_Noisy);
            else
                [n_timepoints, n_traces] = size(CalciumTraces);
            end
            bins_length = FrameRate.*10;
            bins_number = floor(n_timepoints/bins_length);
            CalciumTraces_Shuffled = NaN(bins_number*bins_length, n_traces);
            for i_trace = 1:n_traces
                % Cut it to dimension
                if FLAG_AddWhiteNoise == 1
                    tmp_trace = CalciumTraces_Noisy(:, i_trace);
                else
                    tmp_trace = CalciumTraces(:, i_trace);
                end
                tmp_trace = tmp_trace(1:bins_number*bins_length);
                tmp_trace = reshape(tmp_trace, [bins_number, bins_length]);
                random_sorting = randperm(bins_number);
                for i_bin = 1:bins_number
                    tmp_trace_randomsorted(i_bin, :) = tmp_trace(random_sorting(i_bin), :);
                end
                % Put the traces back together
                tmp_trace_2 = reshape(tmp_trace_randomsorted, [bins_length*bins_number, 1]);
                CalciumTraces_Shuffled(:, i_trace) = tmp_trace_2;
                clear tmp_trace; clear tmp_trace_randomsorted; clear tmp_trace_2
            end
            last_time_segment = ((bins_number*bins_length) + 1):n_timepoints;
            if FLAG_AddWhiteNoise == 1
                CalciumTraces_Shuffled(last_time_segment, :) = CalciumTraces_Noisy(last_time_segment, :);
                clear CalciumTraces_Noisy
            else
                CalciumTraces_Shuffled(last_time_segment, :) = CalciumTraces(last_time_segment, :);
                clear CalciumTraces
            end

            [correlation_film_shuffled, entropy_trace_shuffled] = Analyze_Raw_over_TimeWindow (CalciumTraces_Shuffled, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [States_Shuffled, MeanOfStates_Shuffled_tmp] = Analyze_Correlation_Film (CalciumTraces_Shuffled, correlation_film_shuffled, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, i_mouse, Opts);
            MeanOfStates_PerSession_Shuffled{1} = MeanOfStates_Shuffled_tmp;
            States_perSession_Shuffled = cell(1);
            States_perSession_Shuffled = States_Shuffled;
            Mouse_Analysis_Shuffled(i_session_tot).Entropy_Trace = entropy_trace_shuffled;
            Mouse_Analysis_Shuffled(i_session_tot).States_Analysis = States_Shuffled;
            clear tmp_trace_randomsorted; clear tmp_trace; clear tmp_trace2
        end
        i_session_tot = i_session_tot + 1;
    end
    % Gets the Connectivity Index array over each session and state
    
    % Compute mean correlation related measures per mouse, including the
    % Graphs, considering all states of the same type of all sessions.
    MeanOfStates_PerMouse{i_mouse} = cmp_MeanCorrPerMouse (States_perSession, Opts);
    MeanOfStates_PerMouseShuffled{i_mouse} = cmp_MeanCorrPerMouse (States_perSession_Shuffled, Opts);
    clear correlation_film
    elapsed_time(i_mouse) = double(int32(toc));
    fprintf('Finished Analyzing Mouse %s : Elapsed Time = %ds\n\n', Current_MouseName, elapsed_time(i_mouse));
end
fprintf('\nFinished Analisis: Total Elapsed Time = %ds\n\n', nansum(elapsed_time));

% Compute Connectivity Index over time (sessions)
Connectivity_Index_OverTime_perMouse = cmp_ConnectivityIndex_sessionsArray (MeanOfStates_PerSession);
Connectivity_Index_OverTime_Mouse_Average = mean(Connectivity_Index_OverTime_perMouse, 3, "omitnan"); % Average over the 3rd dimension, which is the number of mice
Connectivity_Index_OverTime_Mouse_StE = std(Connectivity_Index_OverTime_perMouse, 0, 3, "omitnan")./sqrt(n_mice); % Average over the 3rd dimension, which is the number of mice
Connectivity_Index_OverTime_perMouse_Shuffled = cmp_ConnectivityIndex_sessionsArray (MeanOfStates_PerSession_Shuffled);
Connectivity_Index_OverTime_Mouse_Average_Shuffled = mean(Connectivity_Index_OverTime_perMouse_Shuffled, 3, "omitnan"); % Average over the 3rd dimension, which is the number of mice
Connectivity_Index_OverTime_Mouse_StE_Shuffled = std(Connectivity_Index_OverTime_perMouse_Shuffled, 0, 3, "omitnan")./sqrt(n_mice); % Average over the 3rd dimension, which is the number of mice

% Remove columns of NaNs
tmp_ste = sum(isnan(Connectivity_Index_OverTime_Mouse_Average), 1);
Connectivity_Index_OverTime_Mouse_Average(:, tmp_ste>=4) = [];
Connectivity_Index_OverTime_Mouse_StE(:, tmp_ste>=4) = [];
tmp_ste = sum(isnan(Connectivity_Index_OverTime_Mouse_Average_Shuffled), 1);
Connectivity_Index_OverTime_Mouse_Average_Shuffled(:, tmp_ste>=4) = [];
Connectivity_Index_OverTime_Mouse_StE_Shuffled(:, tmp_ste>=4) = [];

% Make an array that associates each session with its corresponding mice
% number.
MouseNumber_Array = NaN(n_sessions, 1);
for i_session = 1:n_sessions
    MeanOfStates_CurrentSession = MeanOfStates_PerSession{i_session};
    try
        MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(1).MouseNumber;
    catch
        MouseNumber_Array(i_session) = MeanOfStates_CurrentSession(2).MouseNumber;
    end
end

% keyboard

n_sessions_current = mouse_sessions(1);
CorrVariation_TimeSeries_Avg_tmp = NaN(4, n_sessions_current-1, n_mice);
CorrVariation_TimeSeries_StE_tmp = NaN(4, n_sessions_current-1, n_mice);
for i_mouse = 1:n_mice
    fprintf('Computing Average intra-trace Correlation for Mouse %d...\n', i_mouse)
    MeanOfStates_CurrentMouse = MeanOfStates_PerSession(1, (MouseNumber_Array == i_mouse));
    n_sessions_current = numel(MeanOfStates_CurrentMouse);
    n_current_cells = n_cells(i_mouse);
    % Get the correlation matrix for each state, over every session
    for i_current_session = 1:n_sessions_current
        fprintf('Computing Average intra-trace Correlation for Mouse %d, Session %d...\n', i_mouse, i_current_session)
        MeanOfStates_Current = MeanOfStates_CurrentMouse{i_current_session};
        if numel(MeanOfStates_Current(1).Corr_Matrix_Mean) > 1
            Corr_Matrix_TimeArray_Awake(:, :, i_current_session) = triu(MeanOfStates_Current(1).Corr_Matrix_Mean);
        else
            Corr_Matrix_TimeArray_Awake(:, :, i_current_session) = NaN(n_current_cells, n_current_cells);
        end
        if numel(MeanOfStates_Current(2).Corr_Matrix_Mean) > 1
            Corr_Matrix_TimeArray_NREM(:, :, i_current_session) = triu(MeanOfStates_Current(2).Corr_Matrix_Mean);
        else
            Corr_Matrix_TimeArray_NREM(:, :, i_current_session) = NaN(n_current_cells, n_current_cells);
        end
        if numel(MeanOfStates_Current(4).Corr_Matrix_Mean) > 1
            Corr_Matrix_TimeArray_REM(:, :, i_current_session) = triu(MeanOfStates_Current(4).Corr_Matrix_Mean);
        else
            Corr_Matrix_TimeArray_REM(:, :, i_current_session) = NaN(n_current_cells, n_current_cells);
        end
    end
    
    % Compute the variation over time of the correlation matrices
    Corr_Matrix_TimeArray_Awake(Corr_Matrix_TimeArray_Awake == 0) = NaN;
    CorrMatrixDiff = diff(Corr_Matrix_TimeArray_Awake, 1, 3);
    tmp1 = squeeze(mean(CorrMatrixDiff, 1, 'omitnan'));
    CorrVariation_TimeSeries_Avg_tmp(1, :, i_mouse) = mean(tmp1, 1, 'omitnan');
    CorrVariation_TimeSeries_StE_tmp(1, :, i_mouse) = std(tmp1, 0, 1, 'omitnan')./sqrt(n_current_cells);
    
    Corr_Matrix_TimeArray_NREM(Corr_Matrix_TimeArray_NREM == 0) = NaN;
    CorrMatrixDiff = diff(Corr_Matrix_TimeArray_NREM, 1, 3);
    tmp1 = squeeze(mean(CorrMatrixDiff, 1, 'omitnan'));
    CorrVariation_TimeSeries_Avg_tmp(2, :, i_mouse) = mean(tmp1, 1, 'omitnan');
    CorrVariation_TimeSeries_StE_tmp(2, :, i_mouse) = std(tmp1, 0, 1, 'omitnan')./sqrt(n_current_cells);
    
    Corr_Matrix_TimeArray_REM(Corr_Matrix_TimeArray_REM == 0) = NaN;
    CorrMatrixDiff = diff(Corr_Matrix_TimeArray_REM, 1, 3);
    tmp1 = squeeze(mean(CorrMatrixDiff, 1, 'omitnan'));
    CorrVariation_TimeSeries_Avg_tmp(4, :, i_mouse) = mean(tmp1, 1, 'omitnan');
    CorrVariation_TimeSeries_StE_tmp(4, :, i_mouse) = std(tmp1, 0, 1, 'omitnan')./sqrt(n_current_cells);
    clear Corr_Matrix_TimeArray_Awake; clear Corr_Matrix_TimeArray_NREM; clear Corr_Matrix_TimeArray_REM; 
end
CorrVariation_TimeSeries_Avg = mean(CorrVariation_TimeSeries_Avg_tmp, 3, 'omitnan');
CorrVariation_TimeSeries_StE = std(CorrVariation_TimeSeries_Avg_tmp, 0, 3, 'omitnan')./sqrt(n_mice);



%% Lighten the load of some variables to save the workspace
States = rmfield(States, 'CorrelationFilm');
States_perSession = rmfield(States_perSession, 'CorrelationFilm');


%% Compute the betweenness centrality measure
State_Lenght_Threshold = [(Opts.General.MinStableStateDuration.*Opts.General.FrameRate).*1.5, (Opts.General.MinStableStateDuration.*Opts.General.FrameRate).*10];

Correlation_betweenness_BetweenStates = zeros(3,3,n_mice);
Betweenness_Average_perMouse = NaN(n_mice, 4);
Betweenness_AverageVariation_perMouse = NaN(n_mice, 4);
Mean_overSessions_perCell = cell(n_mice, 1);
MeanVariation_overSessions_perCell = cell(n_mice, 1);
Stable_Cell_Number = NaN(3, n_sessions_current, n_mice);
% Stable_Cell_Fraction = NaN(3, n_sessions_current, n_mice);

for i_mouse = 1:n_mice
    tic
    Current_MouseName = Mouse_Names{i_mouse};
    current_n_cells = n_cells(i_mouse);
    current_N_Sessions = mouse_sessions(i_mouse);
    Current_Mouse_Analysis = Mouse_Analysis(MouseNumber_Array == i_mouse);
    tmp = find(MouseNumber_Array == i_mouse);
    Current_Mouse_Analysis_Shuffled = Mouse_Analysis_Shuffled(tmp(1));
    Current_Mouse_Hypnograms = Hypnogram_AllSessions(MouseNumber_Array == i_mouse);
    fprintf('---Analyzing Mouse %s---\n', Current_MouseName);
    
    % Shuffled analysis
    Current_Session_Shuffled = Current_Mouse_Analysis_Shuffled.States_Analysis;
    Betweenness_Normalized_Average_Shuffled_sessions = nan(current_n_cells, 4, current_N_Sessions);
    Betweenness_Normalized_StE_Shuffled_sessions = nan(current_n_cells, 4, current_N_Sessions);
    n_states = numel(Current_Session_Shuffled);
    Betweenness_Shuffled = nan(current_n_cells, n_states);
    Betweenness_Normalize_Shuffled = nan(current_n_cells, n_states);
    missing_states_shuff = isnan([Current_Session_Shuffled.MouseNumber]);
    for i_state = 1:n_states
        if missing_states_shuff(i_state) == 1
            continue
        end
        n_nodes = numel(Current_Session_Shuffled(i_state).Corr_Graph_Centrality.Betweenness);
        tmp_betweenness = Current_Session_Shuffled(i_state).Corr_Graph_Centrality.Betweenness;
        tmp_nodetags = Current_Session_Shuffled(i_state).Corr_Graph_Centrality.Node_Tag;
        tmp_betweenness_max = max(tmp_betweenness, [], 'omitnan');
        if n_nodes == 0
            continue
        end
        for i_node = 1:n_nodes
            try
                tmp_node_ID = tmp_nodetags(i_node); % Get only the current nodes IDs
                Betweenness_Shuffled(tmp_node_ID, i_state) = tmp_betweenness(i_node);
                Betweenness_Normalize_Shuffled(tmp_node_ID, i_state) = tmp_betweenness(i_node)./tmp_betweenness_max;
            catch
                warning('  Encountered a problem while computing the Betweenness (Shuffled baseline) for node with ID %d. Node #%d/%d, of state #%d. Assigned Betweenness = NaN.\n', tmp_node_ID, i_node, n_nodes, i_state);
            end
        end
    end
    Betweenness_Normalized_Average_Shuffled(:, i_session) = mean(Betweenness_Normalize_Shuffled, 2, 'omitnan');
    Betweenness_Normalized_StE_Shuffled(:, i_session) = std(Betweenness_Normalize_Shuffled, 0, 2, 'omitnan')./sqrt(n_states);
    Betweenness_Shuffled_Avg = sum(mean(Betweenness_Normalized_Average_Shuffled, 1, 'omitnan'));
    Betweenness_Shuffled_Std = sum(std(Betweenness_Normalized_Average_Shuffled, 0, 1, 'omitnan'));
    clear Betweenness_Normalized_Average_Shuffled; clear Betweenness_Normalized_StE_Shuffled;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Scroll sessions.
    Betweenness_Normalized_StateAverage_sessions = nan(current_n_cells, 4, current_N_Sessions);
    Betweenness_Normalized_StateStE_sessions = nan(current_n_cells, 4, current_N_Sessions);
    for i_session = 1:current_N_Sessions
        Current_Session = Current_Mouse_Analysis(i_session).States_Analysis;
        Current_StateIsStable_Array = Current_Mouse_Hypnograms(i_session).StateIsStable;
        Current_n_StableStates = numel(find(Current_StateIsStable_Array));
        fprintf('   Analyzing Session %d (%d stable states):\n', i_session, Current_n_StableStates);
        Current_Session(~Current_StateIsStable_Array) = [];
        
        state_duration = numel(Current_Session);
        for i_state = 1:numel(Current_Session)
            [~, ~, state_duration(i_state)] = size(Current_Session(i_state).CorrelationFilm);
        end
        try
            corr_coeff = corrcoef(state_duration, [Current_Session.Corr_Graph_nEdges]);
            corr_coeff = corr_coeff(1,2);
            fprintf('   Correlation between states duration and measured functional connectivity = %.3f\n', corr_coeff);
        catch
            fprintf('   Correlation between states duration and measured functional connectivity = N/A\n');
        end
        
        % Remove super long and super short states.
        State_ToSkip = logical(zeros(1, numel(Current_Session)));
        State_ToSkip(state_duration < State_Lenght_Threshold(1)) = 1;
        State_ToSkip(state_duration > State_Lenght_Threshold(2)) = 1;
        Current_Session_Compact = Current_Session;
        Current_Session_Compact(State_ToSkip) = [];
        state_duration = numel(Current_Session_Compact);
        for i_state = 1:numel(Current_Session_Compact)
            [~, ~, state_duration(i_state)] = size(Current_Session_Compact(i_state).CorrelationFilm);
        end
        try
            corr_coeff = corrcoef(state_duration, [Current_Session_Compact.Corr_Graph_nEdges]);
            corr_coeff = corr_coeff(1,2);
            fprintf('   Correlation between states duration and measured functional connectivity after correction = %.3f\n', corr_coeff);
        catch
            fprintf('   Correlation between states duration and measured functional connectivity = N/A\n');
        end
        % Compute the betweenness centrality average and StE for all the 
        % states in a session
        StatesTagArray = [Current_Session_Compact.StateTag];

        for i_statetag = 1:4
           if i_statetag == 3
              continue 
           end
           Current_State_Analysis = Current_Session_Compact(StatesTagArray == i_statetag);
           n_states = numel(Current_State_Analysis);
           if n_states > 0
               Betweenness = nan(current_n_cells, n_states);
               Betweenness_Normalized = nan(current_n_cells, n_states);
               for i_state = 1:n_states
                   n_nodes = numel(Current_State_Analysis(i_state).Corr_Graph_Centrality.Betweenness);
                   tmp_betweenness = Current_State_Analysis(i_state).Corr_Graph_Centrality.Betweenness;
                   tmp_nodetags = Current_State_Analysis(i_state).Corr_Graph_Centrality.Node_Tag;
                   tmp_betweenness_max = max(tmp_betweenness, [], 'omitnan');
                   for i_node = 1:n_nodes
                       try
                           tmp_node_ID = tmp_nodetags(i_node); % Get only the current nodes IDs
                           Betweenness(tmp_node_ID, i_state) = tmp_betweenness(i_node);
                           Betweenness_Normalized(tmp_node_ID, i_state) = tmp_betweenness(i_node)./tmp_betweenness_max;
                       catch
                           warning('  Encountered a problem while computing the Betweenness for node with ID %d. Node #%d/%d, of state #%d. Assigned Betweenness = NaN.\n', tmp_node_ID, i_node, n_nodes, i_state);
                       end
                   end
               end
               Betweenness_Normalized_StateAverage_sessions(:, i_statetag, i_session) = mean(Betweenness_Normalized, 2, 'omitnan');
               Betweenness_Normalized_StateStE_sessions(:, i_statetag, i_session) = std(Betweenness_Normalized, 0, 2, 'omitnan')./sqrt(n_states);
           else
               Betweenness_Normalized_StateAverage_sessions(:, i_statetag, i_session) = NaN;
               Betweenness_Normalized_StateStE_sessions(:, i_statetag, i_session) = NaN;
           end
        end
        
    end
    
    
    
    % Check if a cell had stable betweenness within the same session
    tmp = diff(Betweenness_Normalized_StateAverage_sessions, 1, 3);
    avg_Betweenness_longit_diff = mean(abs(tmp), 3, 'omitnan');
    std_Betweenness_longit_diff = std(abs(tmp), 0, 3, 'omitnan');
    std_Betweenness_longit_diff = mean(std_Betweenness_longit_diff, 1, 'omitnan');
    tmp_Stable_Cells = zeros(size(tmp));
    tmp_Stable_Cells(abs(tmp) < avg_Betweenness_longit_diff - 1.5*std_Betweenness_longit_diff) = 1;
    for i_session = 1:current_N_Sessions-1
        for i_state = 1:4
            if i_state == 3
                continue
            end
%             tmp1 = numel(find(tmp_Stable_Cells(:, i_state, i_session) == 1));
            Stable_Cell_Number(i_state, i_session, i_mouse) = numel(find(tmp_Stable_Cells(:, i_state, i_session) == 1));
            Stable_Cell_Fraction = Stable_Cell_Number./current_n_cells;
            
        end
    end
    Stable_Cell_Number(3, :, :) = [];
    Stable_Cell_Fraction(3, :, :) = [];
    
    
    %% Compute the mean over sessions and Plot for each mouse
    figure('units','normalized','outerposition',[0 0 0.36 0.64]);
    subplot (2,1,1);
    clear longitudinal_mean; clear longitudinal_std;
    
    % Subplot 1 and longitudinal quantities (variations over sessions)
    for i_state = 1:4
        if i_state == 3
            continue
        end
        tmp_mean = squeeze(Betweenness_Normalized_StateAverage_sessions(:, i_state, :));
        tmp_ste = squeeze(Betweenness_Normalized_StateStE_sessions(:, i_state, :));
        
        hold on;
        longitudinal_mean(:, i_state) = mean(tmp_mean, 2, "omitnan");
        longitudinal_std(:, i_state) = std(tmp_mean, 0, 2, "omitnan");
        errorbar (longitudinal_mean(:, i_state), longitudinal_std(:, i_state), 'LineWidth', 1.25);
    end
    
    if ~isnan(Betweenness_Shuffled_Avg) && ~isnan(Betweenness_Shuffled_Std)
        yline(Betweenness_Shuffled_Avg, '--k', 'LineWidth', 2)
        yline(Betweenness_Shuffled_Avg + Betweenness_Shuffled_Std, '--k', 'LineWidth', 0.75)
        yline(Betweenness_Shuffled_Avg - Betweenness_Shuffled_Std, '--k', 'LineWidth', 0.75)
        legend({'Awake','NREM','REM','Chance level +- Std'})
    else
        legend({'Awake','NREM','REM'})
    end
    box on; grid on;
    xlabel('Cell ID');
    ylabel('Betweenness (Normalized)')
    title(sprintf('Betweenness Centrality (Normalized) for each Cell\nAverage and Std ("variation") over sessions, Mouse "%s"', Current_MouseName))
    h_axis = gca;
    h_axis.FontSize = 12;
    
    longitudinal_mean_average = mean(longitudinal_mean, 1, "omitnan");
    longitudinal_mean_variation = std(longitudinal_mean, 0, 1, "omitnan")./sqrt(n_current_cells);
    longitudinal_std_average= mean(longitudinal_std, 1, "omitnan");
    longitudinal_std_variation= std(longitudinal_std, 0, 1, "omitnan")./sqrt(n_current_cells);
    Mean_overSessions_perCell{i_mouse} = longitudinal_mean;
    MeanVariation_overSessions_perCell{i_mouse} = longitudinal_std;
    
    % Subplot 2
    tmp_plot1(1:3) = longitudinal_mean_average([1, 2, 4]);
    tmp_plot1_e(1:3) = longitudinal_mean_variation([1, 2, 4]);
    subplot (2,1,2);
    hold on;
    h_bar1 = bar(1:3, tmp_plot1, 'b');
    h_bar1.FaceAlpha = 0.75;
    er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e, 'LineWidth', 1.5);
    er.Color = [0 0 0];
    er.LineStyle = 'none';
    
    tmp_plot1(1:3) = longitudinal_std_average([1, 2, 4]);
    tmp_plot1_e(1:3) = longitudinal_std_variation([1, 2, 4]);
    h_bar2 = bar(1:3, tmp_plot1);
    h_bar2.FaceAlpha = 0.75;
    er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e,'r', 'LineWidth', 1.5);
    er.LineStyle = 'none';
    
    if ~isnan(Betweenness_Shuffled_Avg) && ~isnan(Betweenness_Shuffled_Std)
        h_line1 = yline(Betweenness_Shuffled_Avg, '--b', 'LineWidth', 1);
        h_line2 = yline(Betweenness_Shuffled_Std, '--r', 'LineWidth', 1);
        legend([h_bar1(1) h_bar2(1), h_line1(1), h_line2(1)], 'Average of all Cells','Average variation of all Cells', 'Betweenness (Shuffled Traces)', 'Betweenness Variation (Shuffled Traces)')
    else
        legend([h_bar1(1) h_bar2(1), h_line1(1), h_line2(1)], 'Average of all Cells','Average variation of all Cells')
    end
    box on; grid on;
    
    xticks([1,2,3]);
    xticklabels({'Awake','NREM','REM'})
    ylabel('Betweenness (Normalized)')
    title(sprintf('Betweenness Centrality (Normalized)\nAverage and "Average variation" over sessions and all cells, Mouse "%s"', Current_MouseName))
    h_axis = gca;
    h_axis.FontSize = 12;
    
    if Opts.SaveFiguresAutomatically == 1
        currentfig_path = sprintf('%s\\Betweenness per Mouse', Opts.Dir_Figures);
        if exist(sprintf('%s\\Betweenness per Mouse', Opts.Dir_Figures), 'dir') == 0
            mkdir(currentfig_path);
        end
        if isfield(Opts, 'Celltype')
            FileName = sprintf('%s - Betweenness Plots - %s', Opts.CellType, Current_MouseName);
        else
            FileName = sprintf('Unknown CellType - Betweenness Plots - %s', Current_MouseName);
        end
        FilePath = sprintf('%s\\%s', currentfig_path, FileName);
        print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
        saveas(gcf, strcat(FilePath, '.png'))
        saveas(gcf, strcat(FilePath, '.fig'))
        close gcf
    end
    
    % Compute the correlation between the average centrality signatures 
    % of the network, between different states, per mouse.
    tmp = corrcoef(longitudinal_mean(:,1), longitudinal_mean(:,2));
    Correlation_betweenness_BetweenStates(1,2, i_mouse) = tmp(1,2);
    tmp = corrcoef(longitudinal_mean(:,1), longitudinal_mean(:,4));
    Correlation_betweenness_BetweenStates(1,3, i_mouse) = tmp(1,2);
    tmp = corrcoef(longitudinal_mean(:,2), longitudinal_mean(:,4));
    Correlation_betweenness_BetweenStates(2,3, i_mouse) = tmp(1,2);
    Correlation_betweenness_BetweenStates(1,1, i_mouse) = 1; Correlation_betweenness_BetweenStates(2,2, i_mouse) = 1; Correlation_betweenness_BetweenStates(3,3, i_mouse) = 1;
    
    Betweenness_Average_perMouse(i_mouse, :) = longitudinal_mean_average;
    Betweenness_AverageVariation_perMouse(i_mouse, :) = longitudinal_mean_variation;
    Betweenness_Shuffled_Avg_perMouse(i_mouse) = Betweenness_Shuffled_Avg;
    Betweenness_Shuffled_Std_perMouse(i_mouse) = Betweenness_Shuffled_Std;
end

Betweenness_Average_Mean_AllMice = mean(Betweenness_Average_perMouse, 1, "omitnan");
Betweenness_Average_StE_AllMice = std(Betweenness_Average_perMouse, 0, 1, "omitnan")./sqrt(n_mice);
Betweenness_Variation_Mean_AllMice = mean(Betweenness_AverageVariation_perMouse, 1, "omitnan");
Betweenness_Variation_StE_AllMice = std(Betweenness_AverageVariation_perMouse, 0, 1, "omitnan")./sqrt(n_mice);

Correlation_Average_overMice = mean(Correlation_betweenness_BetweenStates, 3, "omitnan");
Correlation_StE_overMice = std(Correlation_betweenness_BetweenStates, 0, 3, "omitnan")./sqrt(n_mice);
Correlation_AbsAverage_overMice = mean(abs(Correlation_betweenness_BetweenStates), 3, "omitnan");
Correlation_AbsStE_overMice = std(abs(Correlation_betweenness_BetweenStates), 0, 3, "omitnan")./sqrt(n_mice);

% Final result
Betweenness_Result.Betweenness_Average_perMouse = Betweenness_Average_perMouse;
Betweenness_Result.Betweenness_AverageVariation_perMouse = Betweenness_AverageVariation_perMouse;
Betweenness_Result.Correlation_betweenness_BetweenStates = Correlation_betweenness_BetweenStates;
Betweenness_Result.Correlation_Average_overMice = Correlation_Average_overMice;
Betweenness_Result.Correlation_StE_overMice = Correlation_StE_overMice;
Betweenness_Result.Correlation_AbsAverage_overMice = Correlation_AbsAverage_overMice;
Betweenness_Result.Correlation_AbsStE_overMice = Correlation_AbsStE_overMice;
Betweenness_Result.Betweenness_Average_Mean_AllMice = Betweenness_Average_Mean_AllMice;
Betweenness_Result.Betweenness_Average_StE_AllMice = Betweenness_Average_StE_AllMice;
Betweenness_Result.Betweenness_Variation_Mean_AllMice = Betweenness_Variation_Mean_AllMice;
Betweenness_Result.Betweenness_Variation_StE_AllMice = Betweenness_Variation_StE_AllMice;
Betweenness_Result.Mean_overSessions_perCell = Mean_overSessions_perCell;
Betweenness_Result.MeanVariation_overSessions_perCell = MeanVariation_overSessions_perCell;
Betweenness_Result.Stable_Cell_Number = Stable_Cell_Number;
Betweenness_Result.Stable_Cell_Fraction = Stable_Cell_Fraction;
Betweenness_Result.Betweenness_Shuffled_Avg_perMouse = Betweenness_Shuffled_Avg_perMouse;
Betweenness_Result.Betweenness_Shuffled_Std_perMouse = Betweenness_Shuffled_Std_perMouse;


%% Figure for all mice
figure('units','normalized','outerposition',[0 0 0.72 0.64]);

% Average
subplot_num = 4;
subplot (1,subplot_num,1);
hold on;
tmp_plot1(1:3) = Betweenness_Average_Mean_AllMice([1, 2, 4]);
tmp_plot1_e(1:3) = Betweenness_Average_StE_AllMice([1, 2, 4]);
h_line1 = yline(mean(Betweenness_Shuffled_Avg_perMouse), '--k', 'LineWidth', 1.25);
h_line2 = yline(mean(Betweenness_Shuffled_Avg_perMouse) + std(Betweenness_Shuffled_Avg_perMouse)./sqrt(n_mice), '--k', 'LineWidth', 0.5);
h_line3 = yline(mean(Betweenness_Shuffled_Avg_perMouse) - std(Betweenness_Shuffled_Avg_perMouse)./sqrt(n_mice), '--k', 'LineWidth', 0.5);
h_bar1 = bar(1:3, tmp_plot1, 'b');
er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e, 'LineWidth', 1.5);
er.Color = [0 0 0];
er.LineStyle = 'none';
axis square; box on; grid on;
xticks([1,2,3]);
xticklabels({'Awake','NREM','REM'})
h_axis = gca;
h_axis.FontSize = 12;
ylabel('Betweenness (Normalized)')
title(sprintf('Mean Betweenness\nof all Mice'))

% Variation
subplot (1,subplot_num,2);
hold on;
tmp_plot1(1:3) = Betweenness_Variation_Mean_AllMice([1, 2, 4]);
tmp_plot1_e(1:3) = Betweenness_Variation_StE_AllMice([1, 2, 4]);
h_line1 = yline(std(Betweenness_Shuffled_Std_perMouse), '--k', 'LineWidth', 1.25);
h_line2 = yline(std(Betweenness_Shuffled_Std_perMouse) + std(Betweenness_Shuffled_Std_perMouse)./sqrt(n_mice), '--k', 'LineWidth', 0.5);
h_line3 = yline(std(Betweenness_Shuffled_Std_perMouse) - std(Betweenness_Shuffled_Std_perMouse)./sqrt(n_mice), '--k', 'LineWidth', 0.5);
h_bar2 = bar(1:3, tmp_plot1, 'r');
% h_bar2.FaceAlpha = 0.75;
er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e, 'k', 'LineWidth', 1.5);
er.LineStyle = 'none';
axis square; box on; grid on;
xticks([1,2,3]);
xticklabels({'Awake','NREM','REM'})
h_axis = gca;
h_axis.FontSize = 12;
title(sprintf('Mean Betweenness Variation\nof all Mice'))

% Correlation average
subplot (1,subplot_num,3);
hold on;
tmp_plot1(1:3) = Correlation_Average_overMice([4, 7, 8]);
tmp_plot1_e(1:3) = Correlation_StE_overMice([4, 7, 8]);
h_bar1 = bar(1:3, tmp_plot1, 'FaceColor', [0.5, 0.5, 0.5]);
% h_bar1.FaceAlpha = 0.75;
er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e, 'LineWidth', 1.5);
er.Color = [0 0 0];
er.LineStyle = 'none';
axis square; box on; grid on;
xticks([1,2,3]);
xticklabels({'Awake-NREM','Awake-REM','NREM-REM'})
xtickangle(45)
h_axis = gca;
h_axis.FontSize = 12;
title(sprintf('Correlation average (of all Mice)\n of the network centrality measures of each cells\n between different states'))

% Absolute value Correlation average
subplot (1,subplot_num,4);
hold on;
tmp_plot1(1:3) = Correlation_AbsAverage_overMice([4, 7, 8]);
tmp_plot1_e(1:3) = Correlation_AbsStE_overMice([4, 7, 8]);
h_bar1 = bar(1:3, tmp_plot1, 'FaceColor', [0.5, 0.5, 0.5]);
% h_bar1.FaceAlpha = 0.75;
er = errorbar(1:3, tmp_plot1, tmp_plot1_e, tmp_plot1_e, 'LineWidth', 1.5);
er.Color = [0 0 0];
er.LineStyle = 'none';
axis square; box on; grid on;
xticks([1,2,3]);
xticklabels({'Awake-NREM','Awake-REM','NREM-REM'})
xtickangle(45)
h_axis = gca;
h_axis.FontSize = 12;
title(sprintf('(Absolute value) Correlation average (of all Mice)\n of the network centrality measures of each cells\n between different states'))

if Opts.SaveFiguresAutomatically == 1
    if isfield(Opts, 'Celltype')
        FileName = sprintf('%s - Betweenness Plots - All Mice', Opts.CellType);
    else
        FileName = sprintf('Unknown CellType - Betweenness Plots - All Mice');
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

figure;
hold on;
Stable_Cell_Fraction_average = mean(Stable_Cell_Fraction, 3, "omitnan");
Stable_Cell_Fraction_StE = std(Stable_Cell_Fraction, 0, 3, "omitnan")./n_mice;
errorbar(1:n_sessions_current, Stable_Cell_Fraction_average(1, :), Stable_Cell_Fraction_StE(1, :), Stable_Cell_Fraction_StE(1, :), 'b','LineWidth', 1.5);
errorbar(1:n_sessions_current, Stable_Cell_Fraction_average(2, :), Stable_Cell_Fraction_StE(2, :), Stable_Cell_Fraction_StE(3, :), 'r', 'LineWidth', 1.5);
errorbar(1:n_sessions_current, Stable_Cell_Fraction_average(3, :), Stable_Cell_Fraction_StE(3, :), Stable_Cell_Fraction_StE(2, :), 'g','LineWidth', 1.5);
box on; grid on;
h_axis = gca;
h_axis.FontSize = 12;
title(sprintf('Cells with stable betweenness\namong sessions\nAverage of all mice.'))
xlabel('Session')
ylabel(sprintf('Fraction of recorded neurons\nthat keep similar betweenness across sessions'))
legend({'Awake','NREM','REM'})

if Opts.SaveFiguresAutomatically == 1
    if isfield(Opts, 'Celltype')
        FileName = sprintf('%s - Betweenness-Stable cells - Average of Mice', Opts.CellType);
    else
        FileName = sprintf('Unknown CellType - Betweenness-Stable cells - Average of Mice');
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.png'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
