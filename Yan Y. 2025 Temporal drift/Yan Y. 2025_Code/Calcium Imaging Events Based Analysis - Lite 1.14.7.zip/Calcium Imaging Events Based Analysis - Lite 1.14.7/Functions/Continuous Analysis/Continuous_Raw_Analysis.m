function [Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, Mouse_Analysis_CorrOrdered, MeanOfStates_CorrOrdered, CalciumTraces_Noisy_AllSessions, Stats_MeanOfStatesDifferences_PerSession, Stats_MeanOfStatesDifferences_PerMouse] = Continuous_Raw_Analysis (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts)
% This function analyzes the raw calcium traces of a mouse recordings.
% Things like correlation between traces and entropy are computed.
% The analysis and traces are taken either as entire trace per state, or as
% a continuos signal, in the form of a sliding window.
keyboard

%% Options
if nargin < 4
    warning('Options not found for "Continuous_Raw_Analysis": using default values.')
    Opts = set_options;
end

FLAG_AddWhiteNoise = Opts.ContinuousAnalys.FLAG_AddWhiteNoise;
FLAG_Save_Film = Opts.ContinuousAnalys.FLAG_Save_Film;
FLAG_ReorderCorr = Opts.ContinuousAnalys.FLAG_ReorderCorr;
BoxHeight_Multiplier = Opts.ContinuousAnalys.PlotEntropy.BoxHeight_Multiplier;
FontSize_ylabel = Opts.ContinuousAnalys.PlotEntropy.FontSize_ylabel;
FontSize_suptitle = Opts.ContinuousAnalys.PlotEntropy.FontSize_suptitle;
FrameRate = Opts.General.FrameRate;


%% Analysis per Mouse
n_mice = Opts.n_mice;
n_sessions = Opts.n_sessions;
mouse_sessions = Opts.Mouse_Sessions;
MeanOfStates_PerSession = cell(1, n_sessions);
MeanOfStates_PerMouse = cell(1, n_mice);
CalciumTraces_Noisy_AllSessions = cell(1, n_sessions);
elapsed_time = NaN(1, n_mice);
% Scroll each mouse.
i_session_tot = 1;
for i_mouse = 1:n_mice
    tic
    Current_MouseName = Mouse_Names{i_mouse};
    current_N_Sessions = mouse_sessions(i_mouse);
    
    fprintf('---Analyzing Mouse %s---\n', Current_MouseName);
    % Scroll sessions.
    for i_session = 1:current_N_Sessions
        fprintf('   Analyzing Session %d\n', i_session);
        % Get traces
        CalciumTraces = CalciumTraces_Clean_AllSessions{i_session_tot};
        % Further cleaning of too negative values.
        tmp_traces_mean = nanmean(CalciumTraces, 2);
        CalciumTraces(tmp_traces_mean < -2, :) = NaN;
        
        % Compute correlation between entire traces.
        Corr_EntireTraces = corr(CalciumTraces);
        
        Hypnogram_CurrentMouse = Hypnogram_AllSessions(i_session_tot).Hypnogram;
        StateChanges_CurrentMouse = Hypnogram_AllSessions(i_session_tot).StateChanges;
        CalciumTraces_Noisy = InjectNoise2CalciumTraces (CalciumTraces);
        CalciumTraces_Noisy_AllSessions{1, i_session_tot} = CalciumTraces_Noisy;
        if FLAG_AddWhiteNoise == 1
            [correlation_film, entropy_trace] = Analyze_Raw_over_TimeWindow (CalciumTraces_Noisy, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [States, MeanOfStates_tmp] = Analyze_Correlation_Film (CalciumTraces_Noisy, correlation_film, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, Opts);
        else
            [correlation_film, entropy_trace] = Analyze_Raw_over_TimeWindow (CalciumTraces, Hypnogram_CurrentMouse, Current_MouseName, i_session, Opts);
            [States, MeanOfStates_tmp] = Analyze_Correlation_Film (CalciumTraces, correlation_film, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, Opts);
        end
        
        if i_session == 1
            States_perSession = States;
            n_session_states = numel(States);
            i_states = n_session_states;
        else
            n_session_states = numel(States);
            States_perSession(i_states+1:i_states+n_session_states) = States;
            i_states = i_states + n_session_states;
        end
        
        Mouse_Analysis(i_session_tot).Correlation_Film = correlation_film;
        Mouse_Analysis(i_session_tot).Entropy_Trace = entropy_trace;
        Mouse_Analysis(i_session_tot).States_Analysis = States;
        MeanOfStates_PerSession{i_session_tot} = MeanOfStates_tmp;
        i_session_tot = i_session_tot + 1;
    end
    % Compute mean correlation related measures per mouse, including the
    % Graphs, considering all states of the same type of all sessions.
    MeanOfStates_PerMouse{i_mouse} = cmp_MeanCorrPerMouse (States_perSession, Opts);
    
    elapsed_time(i_mouse) = double(int32(toc));
    fprintf('Finished Analyzing Mouse %s : Elapsed Time = %ds\n\n', Current_MouseName, elapsed_time(i_mouse));
end
fprintf('\nFinished Analisis: Total Elapsed Time = %ds\n\n', nansum(elapsed_time));

% Reorder the traces according to the most connected ones in the X state (Awake by default) and re-do analysis
Mouse_Analysis_CorrOrdered = struct('Correlation_Film', [],'States_Analysis', []);
MeanOfStates_CorrOrdered = cell(1);
if FLAG_ReorderCorr == 1
    fprintf('Re-Ordering Calcium Traces according to Connectivity...\n');
    [CorrFilm_ReOrdered_AllSessions, Traces_ReOrdered_AllSessions] = ReOrder_CorrFilm (Mouse_Analysis, CalciumTraces_Noisy_AllSessions, Opts);
    i_session_tot = 1;
    for i_mouse = 1:n_mice
        Current_MouseName = Mouse_Names{i_mouse};
        n_current_sessions = Opts.Mouse_Sessions(i_mouse);
        for i_session = 1:n_current_sessions
            Current_CorrFilm_Ordered = CorrFilm_ReOrdered_AllSessions{i_session_tot};
            Hypnogram_CurrentMouse = Hypnogram_AllSessions(i_session_tot).Hypnogram;
            StateChanges_CurrentMouse = Hypnogram_AllSessions(i_session_tot).StateChanges;
            if FLAG_Save_Film == 1
                fprintf('Saving Re-Ordered Correlation Film: Mouse %s - Session %d\n', Current_MouseName, i_session);
                video_name = sprintf('Correlation Film Ordered - Mouse %s - Session %d', Current_MouseName, i_session);
                save_CorrFilm_avi (Current_CorrFilm_Ordered, Hypnogram_CurrentMouse, video_name)
            end
            [States_CorrOrdered, MeanOfStates_tmp_CorrOrdered] = Analyze_Correlation_Film (Traces_ReOrdered_AllSessions{1, i_session_tot}, Current_CorrFilm_Ordered, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, Current_MouseName, i_session, Opts);
            
            Mouse_Analysis_CorrOrdered(i_session_tot).Correlation_Film = Current_CorrFilm_Ordered;
            Mouse_Analysis_CorrOrdered(i_session_tot).States_Analysis = States_CorrOrdered;
            MeanOfStates_CorrOrdered{i_session_tot} = MeanOfStates_tmp_CorrOrdered;
            i_session_tot = i_session_tot + 1;
        end
    end
    fprintf('Finished reoddering calcium traces according to their connectivity!\n');
end



%% Get Subnetworks
fprintf('Started Sub-Networks Analysis...\n');
SubNetworks_perMouse = cell(n_mice, 1);
cluster_assignment_perMouse = cell(n_mice, 1);
for i_mouse = 1:n_mice
    SubNetworks_perState = cell(4, 1);
    cluster_assignment_perState = cell(4, 1);
    for i_state = 1:4
        if i_state == 3
            continue
        end
        [cluster_assignment, SubNetworks] = get_subnetworks (MeanOfStates_PerMouse{1, i_mouse}(i_state), Mouse_Names{i_mouse}, Opts);
        SubNetworks_perState{i_state, 1} = SubNetworks;
        cluster_assignment_perState{i_state, 1} = cluster_assignment;
    end
    SubNetworks_perMouse{i_mouse, 1} = SubNetworks_perState;
    cluster_assignment_perMouse{i_mouse, 1} = cluster_assignment_perState;
end


%% Plot Graphs for each Mouse
if Opts.CorrAnalysis.FLAG_Plot_Graphs_perMouse == 1
    for i_mouse = 1:n_mice
        Current_MeanOfStates = MeanOfStates_PerMouse{1, i_mouse};
        Current_MouseName = Mouse_Names{i_mouse};
        Current_ClusterAssignment = cluster_assignment_perMouse{i_mouse};
        plot_graph_onProj (Current_MeanOfStates, Current_MouseName, Current_ClusterAssignment ,Opts);
    end
end


%% Plot Results from Mean Correlation per State Analysis.
Opts.FLAG_Session_or_Mouse = 'session';
Stats_MeanOfStatesDifferences_PerSession = plot_StatesMeanCorrMatrix (MeanOfStates_PerSession, Mouse_Names, Opts);
Opts.FLAG_Session_or_Mouse = 'mouse';
Stats_MeanOfStatesDifferences_PerMouse = plot_StatesMeanCorrMatrix (MeanOfStates_PerMouse, Mouse_Names, Opts);


%% Plot Entropy.
str_suptitle = sprintf('Population Entropy (Entropy of the Source), Ca^{2+} Raw Trace');
FileName = 'Continuous Entropy';

% Get global maximum n_events.
tmp_maxX = NaN(n_sessions, 1);
tmp_maxY = NaN(n_sessions, 1);
tmp_minY = NaN(n_sessions, 1);
for i_session_tot = 1:n_sessions
    current_entropy = Mouse_Analysis(i_session_tot).Entropy_Trace;
    current_Hypno = Hypnogram_AllSessions(i_session_tot).Hypnogram;
    tmp_maxX(i_session_tot) = numel(current_Hypno);
    tmp_maxY(i_session_tot) = nanmax(current_entropy);
    tmp_minY(i_session_tot) = nanmin(current_entropy);
    if tmp_minY(i_session_tot) < 0 % Check that Entropy is a positive value.
        warning('Negative entropy detected in session %d/%d.', i_session_tot, n_sessions);
    end
end
maxXglobal = nanmax(tmp_maxX)./FrameRate;
maxYglobal = nanmax(tmp_maxY);
minYglobal = nanmin(tmp_minY);

% Plot all entropy traces
figure(); set(gcf,'position', get(0,'screensize'));
i_session_tot = 1;
for i_mouse = 1:n_mice
    current_N_Sessions = mouse_sessions(i_mouse);
    for i_session = 1:current_N_Sessions
        current_Hypno = Hypnogram_AllSessions(i_session_tot).Hypnogram;
        current_StateChanges = Hypnogram_AllSessions(i_session_tot).StateChanges;
        n_states = numel(current_StateChanges);
        current_entropy = Mouse_Analysis(i_session_tot).Entropy_Trace;
        time_array = (1:1:numel(current_Hypno))./FrameRate;
        
        maxY = nanmax(current_entropy).*BoxHeight_Multiplier;
        minY = nanmin(current_entropy).*BoxHeight_Multiplier;
        minY = -0.2;
        
        h_subplot = subplot(n_sessions, 1, i_session_tot);
        hold on; box on; grid on; % grid minor;
        plot(time_array, current_entropy, 'k');
        for i_state = 1:n_states
            if i_state < n_states
                end_state = (current_StateChanges(i_state+1) - 1)./FrameRate;
            else
                end_state = numel(current_Hypno)./FrameRate;
            end
            boxX = [current_StateChanges(i_state)./FrameRate, current_StateChanges(i_state)./FrameRate, end_state, end_state];
            boxY = [minY, maxYglobal.*BoxHeight_Multiplier, maxYglobal.*BoxHeight_Multiplier, minY];
            switch current_Hypno(current_StateChanges(i_state))
                case 1; BoxColor = [0 0 1];
                case 2; BoxColor = [1 0 0];
                case 4; BoxColor = [0 1 0];
            end
            h_array(i_state) = patch(boxX, boxY, BoxColor, 'FaceAlpha', 0.1);
        end
        % h_subplot.XMinorTick = 'on'; h_subplot.YMinorTick = 'on';
        axis([0, maxXglobal, minYglobal, maxYglobal])
        if i_session_tot ~= n_sessions
            set(gca,'xticklabel',[])
        end
        str_ylabel = sprintf('Entropy - All Mice Sessions');
        if i_session_tot == round(n_sessions/2)
            ylabel(str_ylabel, 'FontSize', FontSize_ylabel)
        end
        i_session_tot = i_session_tot + 1;
    end
end
xlabel('Time [s]');
% Suptitle
h_suptitle = suptitle(str_suptitle);
h_suptitle.FontSize = FontSize_suptitle;
h_suptitle.FontWeight = 'bold';
% Save Figure
if Opts.ContinuousAnalys.PlotEntropy.FLAG_Save == 1
    FileName = 'Continuous Entropy - All Sessions';
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'));
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf;
end
