function [Sync_Stats, n_states_per_session] = sync_point_analysis (Events, Hypnogram_AllMice, Opts)
% This function performs the temporal analysis of the calcium events
% (synchronization), comparing between Awake, REM, Non-REM states.

% Computes the synchrony per single state (interval between 2 state
% changes). States that are too short (see set_options) are excluded from
% the analysis.
% Sync is the mean number of events in sync / #events, basically, it is
% equivalent to the SPIKE-synchronization measure presented here:
% http://www.scholarpedia.org/article/Measures_of_spike_train_synchrony
% The 2nd output of the function returns the number of states of each type,
% for each recording session: it might be useful for statistics or just for
% reference. 

Opts.Max_EventsDistance = 10; % [frames, seconds = frames/3]
Opts.Sync_Normalization = 'Events Rate'; % 'Total Events Number' or 'Events Rate'

Opts.Sync_BinType = 'Weighted'; % 'Weighted' or 'Flat'.
Opts.Sync_BinSize = 1; % A BinSize = 0 will make use of only the central bin to compute the Sync.
Opts.Sync_BinWeights = 'Gauss'; % To use in case of 'Weighted' BinTypes


%% Preliminary operations.
n_sessions = numel(Hypnogram_AllMice);

% Make Binary Traces for Synchro Analysis.
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'. Default is 'StartComposite'.
Binary_Traces_AllSessions = make_binary_point_traces (Events, Hypnogram_AllMice, Opts);

% Max number of states in a mouse session.
states_n_max = 0;
for i_session = 1:n_sessions
    states_n_max = max(numel(Hypnogram_AllMice(i_session).StateChanges), states_n_max);
end


%% Synchronicity analysis.
Sync_Index_matrix = NaN(n_sessions, states_n_max);
state_matrix = NaN(n_sessions, states_n_max); % States will assume a NaN value if they are unstable states, too short to be considered in the sync analysis.
n_events_matrix = NaN(n_sessions, states_n_max);
n_events_overlap_avg_matrix = NaN(n_sessions, states_n_max);
n_events_singlets_matrix = NaN(n_sessions, states_n_max);
state_length = NaN(n_sessions, states_n_max);
n_cells = NaN(1, n_sessions);
for i_session = 1:n_sessions
    % Get quantities for the current mouse.
    current_mouse_traces = (Binary_Traces_AllSessions{i_session})';
    current_Hypnogram = Hypnogram_AllMice(i_session).Hypnogram;
    current_StateChanges = Hypnogram_AllMice(i_session).StateChanges;
    current_traces_matrix = cell2mat(current_mouse_traces);
    n_cells(i_session) = numel(current_mouse_traces);
    current_n_states = numel(current_StateChanges);
    [current_n_cells, current_n_frames] = size(current_traces_matrix);
    
    % Separate each Mouse binary traces by State.
    for i_state = 1:current_n_states-1
        if current_StateChanges(i_state) > 1
            state_matrix(i_session, i_state) = current_Hypnogram(current_StateChanges(i_state));
        elseif current_StateChanges(i_state) == 1
            state_matrix(i_session, i_state) = current_Hypnogram(1);
        end
        current_state_array = current_StateChanges(i_state):current_StateChanges(i_state + 1);
        current_traces_state = current_traces_matrix(:, current_state_array(1):current_state_array(end));
        
        [Sync_Index_matrix(i_session, i_state), n_events_overlap_avg_matrix(i_session, i_state), n_events_matrix(i_session, i_state), n_events_singlets_matrix(i_session, i_state)] = cmp_PointSync (current_traces_state, Opts);
        
        if numel(Sync_Index_matrix(i_session, :)) ~= numel(state_matrix(i_session, :))
            warning('Number of states ~= number of Syncs')
        end
        
        state_length(i_session, i_state) = numel(current_state_array);
        
        % If the state does not last long enough, ignore it.
        if state_length(i_session, i_state) < Opts.General.MinStableStateDuration
            state_matrix(i_session, i_state) = NaN;
            Sync_Index_matrix(i_session, i_state) = NaN;
            n_events_matrix(i_session, i_state) = NaN;
            n_events_overlap_avg_matrix(i_session, i_state) = NaN;
            n_events_singlets_matrix(i_session, i_state) = NaN;
            continue
        end
    end
    clear current*
    clear next*
    clear tmp*
end
% Count number of states of each type per recording session.
n_states_per_session = NaN(n_sessions, 4);
for i = 1:n_sessions
    current_session = state_matrix(i, :);
    n_states_per_session(i, 1) = numel(current_session(current_session == 1));
    n_states_per_session(i, 2) = numel(current_session(current_session == 2));
    n_states_per_session(i, 4) = numel(current_session(current_session == 4));
end

%% Get statistics per state.
% Separate Sync measure by state.
try
    Sync_Awake = Sync_Index_matrix(state_matrix == 1);
catch
    warning('The Sync Matrix does not correspond with the State Matrix.')
    keyboard
end
Sync_Awake(isnan(Sync_Awake)) = [];
Sync_NoNREM = Sync_Index_matrix(state_matrix == 2);
Sync_NoNREM(isnan(Sync_NoNREM)) = [];
Sync_REM = Sync_Index_matrix(state_matrix == 4);
Sync_REM(isnan(Sync_REM)) = [];

state_length_tot_Awake = nansum(state_length(state_matrix == 1));
state_length_avg_Awake = nanmean(state_length(state_matrix == 1));
state_length_std_Awake = nanstd(state_length(state_matrix == 1));
state_length_tot_NoNREM = nansum(state_length(state_matrix == 2));
state_length_avg_NoNREM = nanmean(state_length(state_matrix == 2));
state_length_std_NoNREM = nanstd(state_length(state_matrix == 2));
state_length_tot_REM = nansum(state_length(state_matrix == 4));
state_length_avg_REM = nanmean(state_length(state_matrix == 4));
state_length_std_REM = nanstd(state_length(state_matrix == 4));

% Separate n_events by state.
% Awake
n_events_Awake = n_events_matrix(state_matrix == 1);
n_events_Awake(isnan(n_events_Awake)) = [];
n_cells_avg_Awake = mean(n_cells(any(state_matrix == 1, 2)));
n_events_overlap_avg_Awake = n_events_overlap_avg_matrix(state_matrix == 1);
n_events_overlap_avg_Awake(isnan(n_events_overlap_avg_Awake)) = [];
n_events_singlets_Awake = n_events_singlets_matrix(state_matrix == 1);
n_events_singlets_Awake(isnan(n_events_singlets_Awake)) = [];
% NoN-REM
n_events_NoNREM = n_events_matrix(state_matrix == 2);
n_events_NoNREM(isnan(n_events_NoNREM)) = [];
n_cells_avg_NoNREM = mean(n_cells(any(state_matrix == 2, 2)));
n_events_overlap_avg_NoNREM = n_events_overlap_avg_matrix(state_matrix == 2);
n_events_overlap_avg_NoNREM(isnan(n_events_overlap_avg_NoNREM)) = [];
n_events_singlets_NoNREM = n_events_singlets_matrix(state_matrix == 2);
n_events_singlets_NoNREM(isnan(n_events_singlets_NoNREM)) = [];
% REM
n_events_REM = n_events_matrix(state_matrix == 4);
n_events_REM(isnan(n_events_REM)) = [];
n_cells_avg_REM = mean(n_cells(any(state_matrix == 4, 2)));
n_events_overlap_avg_REM = n_events_overlap_avg_matrix(state_matrix == 4);
n_events_overlap_avg_REM(isnan(n_events_overlap_avg_REM)) = [];
n_events_singlets_REM = n_events_singlets_matrix(state_matrix == 4);
n_events_singlets_REM(isnan(n_events_singlets_REM)) = [];
% Awake
Sync_Stats.Awake.n_states = numel(Sync_Awake);
Sync_Stats.Awake.state_length_tot = state_length_tot_Awake;
Sync_Stats.Awake.state_length_avg = state_length_avg_Awake;
Sync_Stats.Awake.state_length_std = state_length_std_Awake;
Sync_Stats.Awake.n_cells_avg = n_cells_avg_Awake;
Sync_Stats.Awake.n_events = nansum(n_events_Awake);
Sync_Stats.Awake.events_rate = Sync_Stats.Awake.n_events/Sync_Stats.Awake.state_length_tot;
Sync_Stats.Awake.n_events_overlap_avg = nanmean(n_events_overlap_avg_Awake);
Sync_Stats.Awake.n_events_overlap_std = nanstd(n_events_overlap_avg_Awake);
Sync_Stats.Awake.n_events_singlets = nansum(n_events_singlets_Awake);
Sync_Stats.Awake.Sync_Mean = nanmean(Sync_Awake);
Sync_Stats.Awake.Sync_Std = nanstd(Sync_Awake);
Sync_Stats.Awake.Normalization = Opts.Sync_Normalization;
if strcmpi(Opts.Sync_Normalization, 'Total Events Number')
    Sync_Stats.Awake.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_Awake./Sync_Stats.Awake.n_events);
    Sync_Stats.Awake.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_Awake./Sync_Stats.Awake.n_events);
    Sync_Stats.Awake.Sync_Mean_Norm = nanmean(Sync_Awake./Sync_Stats.Awake.n_events);
    Sync_Stats.Awake.Sync_Mean_Std = nanstd(Sync_Awake./Sync_Stats.Awake.n_events);
elseif strcmpi(Opts.Sync_Normalization, 'Events Rate')
    Sync_Stats.Awake.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_Awake./Sync_Stats.Awake.events_rate);
    Sync_Stats.Awake.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_Awake./Sync_Stats.Awake.events_rate);
    Sync_Stats.Awake.Sync_Mean_Norm = nanmean(Sync_Awake./Sync_Stats.Awake.events_rate);
    Sync_Stats.Awake.Sync_Mean_Std = nanstd(Sync_Awake./Sync_Stats.Awake.events_rate);
end
% NoNREM
Sync_Stats.NoNREM.n_states = numel(Sync_NoNREM);
Sync_Stats.NoNREM.state_length_tot = state_length_tot_NoNREM;
Sync_Stats.NoNREM.state_length_avg = state_length_avg_NoNREM;
Sync_Stats.NoNREM.state_length_std = state_length_std_NoNREM;
Sync_Stats.NoNREM.n_cells_avg = n_cells_avg_NoNREM;
Sync_Stats.NoNREM.n_events = nansum(n_events_NoNREM);
Sync_Stats.NoNREM.events_rate = Sync_Stats.NoNREM.n_events/Sync_Stats.NoNREM.state_length_tot;
Sync_Stats.NoNREM.n_events_overlap_avg = nanmean(n_events_overlap_avg_NoNREM);
Sync_Stats.NoNREM.n_events_overlap_std = nanstd(n_events_overlap_avg_NoNREM);
Sync_Stats.NoNREM.n_events_singlets = nansum(n_events_singlets_NoNREM);
Sync_Stats.NoNREM.Sync_Mean = nanmean(Sync_NoNREM);
Sync_Stats.NoNREM.Sync_Std = nanstd(Sync_NoNREM);
Sync_Stats.NoNREM.Normalization = Opts.Sync_Normalization;
if strcmpi(Opts.Sync_Normalization, 'Total Events Number')
    Sync_Stats.NoNREM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.n_events);
    Sync_Stats.NoNREM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.n_events);
    Sync_Stats.NoNREM.Sync_Mean_Norm = nanmean(Sync_NoNREM./Sync_Stats.NoNREM.n_events);
    Sync_Stats.NoNREM.Sync_Mean_Std = nanstd(Sync_NoNREM./Sync_Stats.NoNREM.n_events);
elseif strcmpi(Opts.Sync_Normalization, 'Events Rate')
    Sync_Stats.NoNREM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.events_rate);
    Sync_Stats.NoNREM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.events_rate);
    Sync_Stats.NoNREM.Sync_Mean_Norm = nanmean(Sync_NoNREM./Sync_Stats.NoNREM.events_rate);
    Sync_Stats.NoNREM.Sync_Mean_Std = nanstd(Sync_NoNREM./Sync_Stats.NoNREM.events_rate);
end
% REM
Sync_Stats.REM.n_states = numel(Sync_REM);
Sync_Stats.REM.state_length_tot = state_length_tot_REM;
Sync_Stats.REM.state_length_avg = state_length_avg_REM;
Sync_Stats.REM.state_length_std = state_length_std_REM;
Sync_Stats.REM.n_cells_avg = n_cells_avg_REM;
Sync_Stats.REM.n_events = nansum(n_events_REM);
Sync_Stats.REM.events_rate = Sync_Stats.REM.n_events/Sync_Stats.REM.state_length_tot;
Sync_Stats.REM.n_events_overlap_avg = nanmean(n_events_overlap_avg_REM);
Sync_Stats.REM.n_events_overlap_std = nanstd(n_events_overlap_avg_REM);
Sync_Stats.REM.n_events_singlets = nansum(n_events_singlets_REM);
Sync_Stats.REM.Sync_Mean = nanmean(Sync_REM);
Sync_Stats.REM.Sync_Std = nanstd(Sync_REM);
Sync_Stats.REM.Normalization = Opts.Sync_Normalization;
if strcmpi(Opts.Sync_Normalization, 'Total Events Number')
    Sync_Stats.REM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.Sync_Mean_Norm = nanmean(Sync_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.Sync_Mean_Std = nanstd(Sync_REM./Sync_Stats.REM.n_events);
elseif strcmpi(Opts.Sync_Normalization, 'Events Rate')
    Sync_Stats.REM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.Sync_Mean_Norm = nanmean(Sync_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.Sync_Mean_Std = nanstd(Sync_REM./Sync_Stats.REM.events_rate);
else
    warning('Unrecognized Normalization type "%s"', Opts.Sync_Normalization)
end


%% Comparisons
% --- Sync Norm --- %
if strcmpi(Opts.Sync_Normalization, 'Total Events Number')
    % Awake vs NoNREM
    Sync_Stats.Comparisons.Sync_Norm.Awake_vs_NoNREM = cmp_sync_stats (Sync_Awake./Sync_Stats.Awake.n_events, Sync_NoNREM./Sync_Stats.NoNREM.n_events);
    % NoNREM vs REM
    Sync_Stats.Comparisons.Sync_Norm.NoNREM_vs_REM = cmp_sync_stats (Sync_NoNREM./Sync_Stats.NoNREM.n_events, Sync_REM./Sync_Stats.REM.n_events);
    % Awake vs REM
    Sync_Stats.Comparisons.Sync_Norm.Awake_vs_REM = cmp_sync_stats (Sync_Awake./Sync_Stats.Awake.n_events, Sync_REM./Sync_Stats.REM.n_events);
    
    % --- # of Overlapping Events Norm --- %
    % Awake vs NoNREM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.Awake_vs_NoNREM = cmp_sync_stats (n_events_overlap_avg_Awake./Sync_Stats.Awake.n_events, n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.n_events);
    % NoNREM vs REM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.NoNREM_vs_REM = cmp_sync_stats (n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.n_events, n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
    % Awake vs REM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.Awake_vs_REM = cmp_sync_stats (n_events_overlap_avg_Awake./Sync_Stats.Awake.n_events, n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
elseif strcmpi(Opts.Sync_Normalization, 'Events Rate')
    % Awake vs NoNREM
    Sync_Stats.Comparisons.Sync_Norm.Awake_vs_NoNREM = cmp_sync_stats (Sync_Awake./Sync_Stats.Awake.events_rate, Sync_NoNREM./Sync_Stats.NoNREM.events_rate);
    % NoNREM vs REM
    Sync_Stats.Comparisons.Sync_Norm.NoNREM_vs_REM = cmp_sync_stats (Sync_NoNREM./Sync_Stats.NoNREM.events_rate, Sync_REM./Sync_Stats.REM.events_rate);
    % Awake vs REM
    Sync_Stats.Comparisons.Sync_Norm.Awake_vs_REM = cmp_sync_stats (Sync_Awake./Sync_Stats.Awake.events_rate, Sync_REM./Sync_Stats.REM.events_rate);
    
    % --- # of Overlapping Events Norm --- %
    % Awake vs NoNREM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.Awake_vs_NoNREM = cmp_sync_stats (n_events_overlap_avg_Awake./Sync_Stats.Awake.events_rate, n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.events_rate);
    % NoNREM vs REM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.NoNREM_vs_REM = cmp_sync_stats (n_events_overlap_avg_NoNREM./Sync_Stats.NoNREM.events_rate, n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
    % Awake vs REM
    Sync_Stats.Comparisons.N_EventsOverlapAvg.Awake_vs_REM = cmp_sync_stats (n_events_overlap_avg_Awake./Sync_Stats.Awake.events_rate, n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
end


%% Plot
plot_Sync_Stats (Sync_Stats, Sync_Awake, Sync_NoNREM, Sync_REM);





% To do: Compute covariance, information, G.Causality matricex between traces,
% both in the case of the whole trace, and for long.

