function [Lag_per_State, Events_per_State] = get_EventsLags_per_State (Events, MouseName, n_states)
% This function gets the Events Lags after a state change in a more
% readable format, giving as output a matrix where each raw corresponds to 
% a state, and each element of the raws is an event lag.
% The function is intended as a sub-function to "Sync2StateChange".


% Get only the events of the current mouse.
Current_Mouse_Events = separate_events_per_mouse (Events, MouseName);

Lag_per_State = cell(n_states, 1);
Events_per_State = cell(1, n_states);

% Separate the events of each state.
for i_state = 1:n_states
    try
        [tmp_Events_per_State] = separate_events_per_state (Current_Mouse_Events, i_state);
    catch
        tmp_Events_per_State = Current_Mouse_Events;
    end
    if ~isempty(tmp_Events_per_State)
        Lag_per_State{i_state}  = [tmp_Events_per_State.Dist_PreState];
    end
    Events_per_State{1, i_state} = tmp_Events_per_State;
end

% Remove empty cell elements
Lag_per_State = Lag_per_State(~cellfun('isempty', Lag_per_State'));
% Set to equal length, filling with NaNs
tmp_max_dim = NaN(1, numel(Lag_per_State));
for i_tmp = 1:numel(Lag_per_State)
    tmp_max_dim(i_tmp) = numel(Lag_per_State{i_tmp});
end
tmp_max_dim = nanmax(tmp_max_dim);
for i_tmp = 1:numel(Lag_per_State)
    tmp = NaN(1, tmp_max_dim);
    tmp(1:numel(Lag_per_State{i_tmp})) = Lag_per_State{i_tmp};
    Lag_per_State{i_tmp} = tmp;
end
Lag_per_State = cell2mat(Lag_per_State);

