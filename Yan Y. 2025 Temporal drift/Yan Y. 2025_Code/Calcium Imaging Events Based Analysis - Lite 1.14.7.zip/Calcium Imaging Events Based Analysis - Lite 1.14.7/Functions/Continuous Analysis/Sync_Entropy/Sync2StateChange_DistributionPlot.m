function Sync2StateChange_DistributionPlot (N_Events_perBinStats, N_States, bins_duration, Opts)
% This function is a sub-function of "Sync2StateChange", it is used to plot
% the distribution of events between the interval of lags (lags intended to
% be between the event and the previous state change)

%% Plot - Distribution of events between lag intervals.
bins = 1:Opts.Sync.NLagBins;
subplot_rows = 2;
subplot_columns = 3;
figure(); set(gcf,'position', get(0,'screensize'));

% Non-normalized version
subplot(subplot_rows, subplot_columns, 1);
hold on; grid on; box on; axis square;
h_avg_Awake = plot(bins, N_Events_perBinStats.Awake.Mean, 'b', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.Awake.Mean-N_Events_perBinStats.Awake.StE)'; flipud((N_Events_perBinStats.Awake.Mean+N_Events_perBinStats.Awake.StE)')], [0, 0, 1], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_NoNREM = plot(bins, N_Events_perBinStats.NoNREM.Mean, 'r', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.NoNREM.Mean-N_Events_perBinStats.NoNREM.StE)'; flipud((N_Events_perBinStats.NoNREM.Mean+N_Events_perBinStats.NoNREM.StE)')], [1, 0, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_REM = plot(bins, N_Events_perBinStats.REM.Mean, 'g', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.REM.Mean-N_Events_perBinStats.REM.StE)'; flipud((N_Events_perBinStats.REM.Mean+N_Events_perBinStats.REM.StE)')], [0, 1, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
if Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates == 1
    h_avg_AwakeANoNREM = plot(bins, N_Events_perBinStats.AwakeANoNREM.Mean, 'Color', [0.33, 0.33, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeANoNREM.Mean-N_Events_perBinStats.AwakeANoNREM.StE)'; flipud((N_Events_perBinStats.AwakeANoNREM.Mean+N_Events_perBinStats.AwakeANoNREM.StE)')], [0.33, 0.33, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
    h_avg_AwakeAREM = plot(bins, N_Events_perBinStats.AwakeAREM.Mean, 'Color', [0.66, 0.66, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeAREM.Mean-N_Events_perBinStats.AwakeAREM.StE)'; flipud((N_Events_perBinStats.AwakeAREM.Mean+N_Events_perBinStats.AwakeAREM.StE)')], [0.66, 0.66, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
end
xticks(bins);
ylabel('Average #Events');
xlabel('Lags Intervals');
xticklabels({sprintf('%.1f to %.1f', 0*bins_duration, bins(1)*bins_duration), sprintf('%.1f to %.1f', bins(1)*bins_duration, bins(2)*bins_duration), sprintf('%.1f to %.1f', bins(2)*bins_duration, bins(3)*bins_duration), sprintf('%.1f to %.1f', bins(3)*bins_duration, bins(4)*bins_duration), sprintf('%.1f to %.1f', bins(4)*bins_duration, bins(5)*bins_duration)});
title('Raw #Events per bin');
lg.str1 = sprintf('Awake (#States = %.0f)', N_States.Awake);
lg.str2 = sprintf('NoNREM (#States = %.0f)', N_States.NoNREM);
lg.str3 = sprintf('REM (#States = %.0f)', N_States.REM);
lg.str4 = sprintf('Awake after NoNREM (#States = %.0f)', N_States.AwakeANoNREM);
lg.str5 = sprintf('Awake after REM (#States = %.0f)', N_States.AwakeAREM);
if Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates == 1
    legend([h_avg_Awake, h_avg_NoNREM, h_avg_REM, h_avg_AwakeANoNREM, h_avg_AwakeAREM], {lg.str1, lg.str2, lg.str3, lg.str4, lg.str5}, 'location', 'best')
else
    legend([h_avg_Awake, h_avg_NoNREM, h_avg_REM], {lg.str1, lg.str2, lg.str3}, 'location', 'best')
end

% Normalization 1: divide by the total number of events (counting all states of the same type, in all mice)
subplot(subplot_rows, subplot_columns, 2);
hold on; grid on; box on; axis square;
h_avg_Awake = plot(bins, N_Events_perBinStats.Awake.Mean_Norm_1, 'b', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.Awake.Mean_Norm_1-N_Events_perBinStats.Awake.StE_Norm_1)'; flipud((N_Events_perBinStats.Awake.Mean_Norm_1+N_Events_perBinStats.Awake.StE_Norm_1)')], [0, 0, 1], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_NoNREM = plot(bins, N_Events_perBinStats.NoNREM.Mean_Norm_1, 'r', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.NoNREM.Mean_Norm_1-N_Events_perBinStats.NoNREM.StE_Norm_1)'; flipud((N_Events_perBinStats.NoNREM.Mean_Norm_1+N_Events_perBinStats.NoNREM.StE_Norm_1)')], [1, 0, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_REM = plot(bins, N_Events_perBinStats.REM.Mean_Norm_1, 'g', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.REM.Mean_Norm_1-N_Events_perBinStats.REM.StE_Norm_1)'; flipud((N_Events_perBinStats.REM.Mean_Norm_1+N_Events_perBinStats.REM.StE_Norm_1)')], [0, 1, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
if Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates == 1
    h_avg_AwakeANoNREM = plot(bins, N_Events_perBinStats.AwakeANoNREM.Mean_Norm_1, 'Color', [0.33, 0.33, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeANoNREM.Mean_Norm_1-N_Events_perBinStats.AwakeANoNREM.StE_Norm_1)'; flipud((N_Events_perBinStats.AwakeANoNREM.Mean_Norm_1+N_Events_perBinStats.AwakeANoNREM.StE_Norm_1)')], [0.33, 0.33, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
    h_avg_AwakeAREM = plot(bins, N_Events_perBinStats.AwakeAREM.Mean_Norm_1, 'Color', [0.66, 0.66, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeAREM.Mean_Norm_1-N_Events_perBinStats.AwakeAREM.StE_Norm_1)'; flipud((N_Events_perBinStats.AwakeAREM.Mean_Norm_1+N_Events_perBinStats.AwakeAREM.StE_Norm_1)')], [0.66, 0.66, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
end
xticks(bins);
ylabel('Average #Events / Total # Events of entire State.');
xlabel('Lags Intervals');
xticklabels({sprintf('%.1f to %.1f', 0*bins_duration, bins(1)*bins_duration), sprintf('%.1f to %.1f', bins(1)*bins_duration, bins(2)*bins_duration), sprintf('%.1f to %.1f', bins(2)*bins_duration, bins(3)*bins_duration), sprintf('%.1f to %.1f', bins(3)*bins_duration, bins(4)*bins_duration), sprintf('%.1f to %.1f', bins(4)*bins_duration, bins(5)*bins_duration)});
title(sprintf('Normalization 1:\n Average(#Events per Bin) / \\Sigma (#Events of all States of the same kind)'));

% Normalization 2: divide each state separately by its total number of
% events in each bin. (NOTE: not advisable as it destroys the dynamics of the changes: a change 0 -> 12 becomes the same as 0 -> 1)
subplot(subplot_rows, subplot_columns, 3);
hold on; grid on; box on; axis square;
h_avg_Awake = plot(bins, N_Events_perBinStats.Awake.Mean_Norm_2, 'b', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.Awake.Mean_Norm_2-N_Events_perBinStats.Awake.StE_Norm_2)'; flipud((N_Events_perBinStats.Awake.Mean_Norm_2+N_Events_perBinStats.Awake.StE_Norm_2)')], [0, 0, 1], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_NoNREM = plot(bins, N_Events_perBinStats.NoNREM.Mean_Norm_2, 'r', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.NoNREM.Mean_Norm_2-N_Events_perBinStats.NoNREM.StE_Norm_2)'; flipud((N_Events_perBinStats.NoNREM.Mean_Norm_2+N_Events_perBinStats.NoNREM.StE_Norm_2)')], [1, 0, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_REM = plot(bins, N_Events_perBinStats.REM.Mean_Norm_2, 'g', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.REM.Mean_Norm_2-N_Events_perBinStats.REM.StE_Norm_2)'; flipud((N_Events_perBinStats.REM.Mean_Norm_2+N_Events_perBinStats.REM.StE_Norm_2)')], [0, 1, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
if Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates == 1
    h_avg_AwakeANoNREM = plot(bins, N_Events_perBinStats.AwakeANoNREM.Mean_Norm_2, 'Color', [0.33, 0.33, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeANoNREM.Mean_Norm_2-N_Events_perBinStats.AwakeANoNREM.StE_Norm_2)'; flipud((N_Events_perBinStats.AwakeANoNREM.Mean_Norm_2+N_Events_perBinStats.AwakeANoNREM.StE_Norm_2)')], [0.33, 0.33, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
    h_avg_AwakeAREM = plot(bins, N_Events_perBinStats.AwakeAREM.Mean_Norm_2, 'Color', [0.66, 0.66, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeAREM.Mean_Norm_2-N_Events_perBinStats.AwakeAREM.StE_Norm_2)'; flipud((N_Events_perBinStats.AwakeAREM.Mean_Norm_2+N_Events_perBinStats.AwakeAREM.StE_Norm_2)')], [0.66, 0.66, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
end
xticks(bins);
ylabel('Average (#Events per Bin / #Events of each State).');
xlabel('Lags Intervals');
xticklabels({sprintf('%.1f to %.1f', 0*bins_duration, bins(1)*bins_duration), sprintf('%.1f to %.1f', bins(1)*bins_duration, bins(2)*bins_duration), sprintf('%.1f to %.1f', bins(2)*bins_duration, bins(3)*bins_duration), sprintf('%.1f to %.1f', bins(3)*bins_duration, bins(4)*bins_duration), sprintf('%.1f to %.1f', bins(4)*bins_duration, bins(5)*bins_duration)});
title(sprintf('Normalization 2:\nAverage (#Events in time bin / #Events in whole State)'));

% Normalization 3: divide each state separately the number of cells measured in the corresponding mouse.
subplot(subplot_rows, subplot_columns, 4);
hold on; grid on; box on; axis square;
h_avg_Awake = plot(bins, N_Events_perBinStats.Awake.Mean_Norm_3, 'b', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.Awake.Mean_Norm_3-N_Events_perBinStats.Awake.StE_Norm_3)'; flipud((N_Events_perBinStats.Awake.Mean_Norm_3+N_Events_perBinStats.Awake.StE_Norm_3)')], [0, 0, 1], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_NoNREM = plot(bins, N_Events_perBinStats.NoNREM.Mean_Norm_3, 'r', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.NoNREM.Mean_Norm_3-N_Events_perBinStats.NoNREM.StE_Norm_3)'; flipud((N_Events_perBinStats.NoNREM.Mean_Norm_3+N_Events_perBinStats.NoNREM.StE_Norm_3)')], [1, 0, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
h_avg_REM = plot(bins, N_Events_perBinStats.REM.Mean_Norm_3, 'g', 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.REM.Mean_Norm_3-N_Events_perBinStats.REM.StE_Norm_3)'; flipud((N_Events_perBinStats.REM.Mean_Norm_3+N_Events_perBinStats.REM.StE_Norm_3)')], [0, 1, 0], 'EdgeColor', 'none');
alpha(Opts.Sync.Plot.StE_alpha);
if Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates == 1
    h_avg_AwakeANoNREM = plot(bins, N_Events_perBinStats.AwakeANoNREM.Mean_Norm_3, 'Color', [0.33, 0.33, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeANoNREM.Mean_Norm_3-N_Events_perBinStats.AwakeANoNREM.StE_Norm_3)'; flipud((N_Events_perBinStats.AwakeANoNREM.Mean_Norm_3+N_Events_perBinStats.AwakeANoNREM.StE_Norm_3)')], [0.33, 0.33, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
    h_avg_AwakeAREM = plot(bins, N_Events_perBinStats.AwakeAREM.Mean_Norm_3, 'Color', [0.66, 0.66, 1], 'LineWidth', Opts.Sync.Plot.Avg_LineWidth);
    h_fill = fill([bins'; flipud(bins')], [(N_Events_perBinStats.AwakeAREM.Mean_Norm_3-N_Events_perBinStats.AwakeAREM.StE_Norm_3)'; flipud((N_Events_perBinStats.AwakeAREM.Mean_Norm_3+N_Events_perBinStats.AwakeAREM.StE_Norm_3)')], [0.66, 0.66, 1], 'EdgeColor', 'none');
    alpha(Opts.Sync.Plot.StE_alpha);
end
xticks(bins);
ylabel('Average (#Events per Bin / #Cells of Mouse).');
xlabel('Lags Intervals');
xticklabels({sprintf('%.1f to %.1f', 0*bins_duration, bins(1)*bins_duration), sprintf('%.1f to %.1f', bins(1)*bins_duration, bins(2)*bins_duration), sprintf('%.1f to %.1f', bins(2)*bins_duration, bins(3)*bins_duration), sprintf('%.1f to %.1f', bins(3)*bins_duration, bins(4)*bins_duration), sprintf('%.1f to %.1f', bins(4)*bins_duration, bins(5)*bins_duration)});
title(sprintf('Normalization 3:\nAverage (#Events in time bin / #Cells measured in corresponding mouse)'));

h_suptitle = suptitle('Number of events after state change, per lag interval.');
h_suptitle.FontSize = 24; h_suptitle.FontWeight = 'bold';

% Save
if Opts.Sync.Plot.FLAG_Save == 1
    FileName = 'Lag2StateChange - Distribution of Events';
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end
