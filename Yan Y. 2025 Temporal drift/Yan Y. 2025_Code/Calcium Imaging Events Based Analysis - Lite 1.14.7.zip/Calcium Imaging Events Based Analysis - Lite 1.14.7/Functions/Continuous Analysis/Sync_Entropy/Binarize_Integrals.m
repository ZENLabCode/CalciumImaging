function Binary_Traces_Integrals_AllSessions = Binarize_Integrals (Events_AllSessions, Hypnogram_AllSessions, Opts)
% This function associates to each binarized point event, its corresponding
% integral value.

FLAG_include_integral = 1;

fprintf('Binarizing Calcium Traces...\n');
n_sessions = Opts.n_sessions;
n_mice = Opts.n_mice;
Mouse_Sessions = Opts.Mouse_Sessions;

n_Events_Tot = numel(Events_AllSessions);

% Get Mouse Tag.
Current_Mouse = Events_AllSessions(1).MouseTag;
Binary_Traces_Integrals_AllSessions = cell(1, n_sessions);
i2_event = 1;
i_event = 1;
i_session_cumulative = 1;
if exist('Current_Mouse_Events' , 'var') ~= 0
   clear Current_Mouse_Events
end

for i_mouse = 1:n_mice
    % Get Current Mouse
    Current_Mouse = Events_AllSessions(i_event).MouseTag;

    counter_event_binarized = 0;
    % Get current Mouse # sessions.
    Current_N_Sessions = Mouse_Sessions(i_mouse);
    % Scroll all sessions.
    for i_session = 1:Current_N_Sessions
        % Get Hypnogram
        Current_Hypnogram = Hypnogram_AllSessions(i_session_cumulative).Hypnogram;
        n_DataPoints = numel(Current_Hypnogram);
        
        % Get events from a single mouse & recording
        while i_event <= n_Events_Tot && strcmpi(Events_AllSessions(i_event).MouseTag, Current_Mouse) == 1 && Events_AllSessions(i_event).Session == i_session
            Current_Mouse_Events(i2_event) = Events_AllSessions(i_event);
            i2_event = i2_event + 1;
            i_event = i_event + 1;
        end
        
        fprintf('Current Mouse: %s, Session %d (# Events = %d)\n', Current_Mouse, i_session, numel(Current_Mouse_Events))
        
        % Get Events from a single trace.
        n_current_traces = nanmax([Current_Mouse_Events.TraceNumber]);
        Binary_Traces = cell(1, n_current_traces);
        for i_trace = 1:n_current_traces
            current_trace_Events = Current_Mouse_Events([Current_Mouse_Events.TraceNumber] == i_trace);
            % Make a binary trace, Event / NoN-Event.
            current_trace_Binary = zeros(1, n_DataPoints);
            current_trace_Binary_Integral = NaN(1, n_DataPoints);
            for j_event = 1:numel(current_trace_Events)
                if strcmpi(Opts.MakeBinary.EventIdentifier, 'PeakComposite') % Takes only the main peak of a composite as 1
                    tmp_compositeTag = current_trace_Events(j_event).Composite.CompositeTag;
                    tmp_event_loc = current_trace_Events(j_event).Composite.PeakLoc;
                    if tmp_compositeTag == 0 || isnan(tmp_event_loc)
                        tmp_event_loc = current_trace_Events(j_event).PeakLoc;
                    end
                    current_trace_Binary(tmp_event_loc) = 1;
                    current_trace_Binary_Integral(tmp_event_loc) = current_trace_Events(j_event).Integral;
                    counter_event_binarized = counter_event_binarized + 1;
                elseif strcmpi(Opts.MakeBinary.EventIdentifier, 'StartComposite') % Takes the start of a composite event as 1
                    tmp_compositeTag = current_trace_Events(j_event).Composite.CompositeTag;
                    tmp_event_loc = current_trace_Events(j_event).Composite.Start;
                    if tmp_compositeTag == 0 || isnan(tmp_event_loc)
                        tmp_event_loc = current_trace_Events(j_event).Start;
                    end
                    current_trace_Binary(tmp_event_loc) = 1;
                    current_trace_Binary_Integral(tmp_event_loc) = current_trace_Events(j_event).Integral;
                    counter_event_binarized = counter_event_binarized + 1;
                elseif strcmpi(Opts.MakeBinary.EventIdentifier, 'MidPointComposite') % Takes the mid-point of a composite event as 1
                    tmp_compositeTag = current_trace_Events(j_event).Composite.CompositeTag;
                    tmp_event_loc = double(int32(abs(current_trace_Events(j_event).Composite.Start + current_trace_Events(j_event).Composite.End)/2));
                    if tmp_compositeTag == 0 || isnan(tmp_event_loc)
                        tmp_event_loc = double(int32(abs(current_trace_Events(j_event).Start + current_trace_Events(j_event).End)/2));
                    end
                    current_trace_Binary(tmp_event_loc) = 1;
                    current_trace_Binary_Integral(tmp_event_loc) = current_trace_Events(j_event).Integral;
                    counter_event_binarized = counter_event_binarized + 1;
                elseif strcmpi(Opts.MakeBinary.EventIdentifier, 'PeakSingle')
                    error('Opts.MakeBinary.EventIdentifier = PeakSingle not implemented yet.')
                end
            end
            if FLAG_include_integral == 1
                current_trace_Binary = [current_trace_Binary; current_trace_Binary_Integral];
                Binary_Traces{i_trace} = current_trace_Binary;
            end
        end        
        % Save all traces for a recording session.
        Binary_Traces_Integrals_AllSessions{i_session_cumulative} = Binary_Traces;
        
        % Break if reaching the very last event.
        if i_event >= n_Events_Tot
            break
        end
        % Empty tmp variable
        if i_session_cumulative ~= n_sessions
            clear Current_Mouse_Events
            clear Binary_Traces
            clear current_trace_Binary
        end
        i_session_cumulative = i_session_cumulative + 1;
        i2_event = 1;
    end
    fprintf('Events correctly represented in the binary traces for mouse "%s": %d.\n', Current_Mouse, counter_event_binarized);
    clear Current_Mouse
    i2_event = 1;
end

fprintf('\n---Binarization done!---\n\n');