function [Sync_Index, n_events_overlap_avg, n_events, n_events_singlets] = cmp_PointSync (traces_matrix, Opts)
% This function computes the point Sync measures.
% traces_matrix is a matrix where each row represents the activity of a
% single cell in a binary form.


if nargin < 2 % Set Defaults in case Opts is not specified.
    warning('Options not found for "cmp_PointSync": using default values.')
    Opts = set_options ();
end

[~, n_frames] = size(traces_matrix);
bins_in_interval = 1 + (Opts.SingleStateAnalysis.Sync_BinSize)*2;

% Compute Sync Indexes.
tmp_sync = NaN(1, n_frames);
tmp_n_frames = NaN(1, n_frames);
tmp_n_cells = NaN(1, n_frames);

if Opts.SingleStateAnalysis.Sync_BinSize == 0
    tmp_sync = nansum(traces_matrix, 1);
    
elseif Opts.SingleStateAnalysis.Sync_BinSize > 0 && strcmpi(Opts.SingleStateAnalysis.Sync_BinType, 'Flat') == 1 % Assign each event the same weigth = 1
    for i_frame = 1:n_frames
        if (i_frame > (Opts.SingleStateAnalysis.Sync_BinSize)) && (i_frame <= n_frames - (Opts.SingleStateAnalysis.Sync_BinSize))
            % Get matrix of only the current frames.
            tmp = traces_matrix(:, (i_frame - (Opts.SingleStateAnalysis.Sync_BinSize)):(i_frame + (Opts.SingleStateAnalysis.Sync_BinSize) ));
            [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
        elseif i_frame <= (Opts.SingleStateAnalysis.Sync_BinSize) % Same, for early frames.
            tmp = traces_matrix(:, (i_frame):(i_frame + (Opts.SingleStateAnalysis.Sync_BinSize) ));
            [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
        elseif i_frame > n_frames - (Opts.SingleStateAnalysis.Sync_BinSize)% Same, for late frames.
            tmp = traces_matrix(:, (i_frame - (Opts.SingleStateAnalysis.Sync_BinSize)):(i_frame));
            [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
        end
        % Get the sum of the activation of each cell over the interval.
        tmp = nansum(tmp, 2);
        % Count multiple activations as one single activation.
        tmp(tmp > 1) = 1;
        % Sum the activation to find the number of contemporary events for
        % the current time bin.
        tmp_sync(i_frame) = nansum(tmp);
    end
    
elseif Opts.SingleStateAnalysis.Sync_BinSize > 0 && strcmpi(Opts.SingleStateAnalysis.Sync_BinType, 'Weighted') == 1 % Assign each event different weight
        for i_frame = 1:n_frames
            if (i_frame > (Opts.SingleStateAnalysis.Sync_BinSize)) && (i_frame <= n_frames - (Opts.SingleStateAnalysis.Sync_BinSize))
                % Get matrix of only the current frames.
                tmp = traces_matrix(:, (i_frame - (Opts.SingleStateAnalysis.Sync_BinSize)):(i_frame + (Opts.SingleStateAnalysis.Sync_BinSize) ));
                [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
                tmp_x = 1:tmp_n_frames(i_frame); mu = double(mean(tmp_x));
            elseif i_frame <= (Opts.SingleStateAnalysis.Sync_BinSize) % Same, for early frames.
                tmp = traces_matrix(:, (i_frame):(i_frame + (Opts.SingleStateAnalysis.Sync_BinSize) ));
                [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
                tmp_x = 1:tmp_n_frames(i_frame); mu = double(floor(mean(tmp_x)));
            elseif i_frame > n_frames - (Opts.SingleStateAnalysis.Sync_BinSize)% Same, for late frames.
                tmp = traces_matrix(:, (i_frame - (Opts.SingleStateAnalysis.Sync_BinSize)):(i_frame));
                [tmp_n_cells(i_frame), tmp_n_frames(i_frame)] = size(tmp);
                tmp_x = 1:tmp_n_frames(i_frame); mu = double(ceil(mean(tmp_x)));
            end
            % Get Gaussian for these frames.
            if strcmpi(Opts.SingleStateAnalysis.Sync_BinWeights, 'Gauss') == 1
                sigma = 1;
                tmp_gauss = normpdf(tmp_x, mu, sigma);
                tmp_weights = tmp_gauss./nanmax(tmp_gauss);
                if tmp_n_frames(i_frame) ~= bins_in_interval
                    tmp_frame_lack = (bins_in_interval - tmp_n_frames(i_frame))/bins_in_interval;
                    tmp_weights(tmp_weights < 1) = tmp_weights(tmp_weights < 1) + tmp_weights(tmp_weights < 1).*tmp_frame_lack;
                end
            end
            % Multiply each time point by its weight.
            tmp = tmp.*tmp_weights;
            % Get the sum of the activation of each cell over the interval.
            tmp = nansum(tmp, 2);
            % Count multiple activations as one single activation.
            tmp(tmp > 1) = 1;
            % Sum the activation to find the number of contemporary events for
            % the current time bin.
            tmp_sync(i_frame) = nansum(tmp);
        end
else
    error ('Opts.SingleStateAnalysis.Sync_BinSize must be either "Weighted" or "Flat", and Opts.SingleStateAnalysis.Sync_BinSize must be a positive number.')
end

tmp_sync(tmp_sync == 0) = NaN; % Set NaN where there are no events.
n_events_singlets = numel(tmp_sync(tmp_sync == 1)); % Count Singlet Events
n_events = nansum(tmp_sync);
tmp_sync(tmp_sync == 1) = 0; % Remove Singlets, isolating only the events that are overlapping with others
n_events_overlap = nansum(tmp_sync);
n_events_overlap_avg = nanmean(tmp_sync); % The average # of overlapping events in a time bin, independent from the total number of cells (will be presented as a normalized quantity below)
% Synchronicity
tmp_sync = tmp_sync./tmp_n_cells; % Sync does take into account the total number of cells, both active and silent ones
Sync_Index = nanmean(tmp_sync);




