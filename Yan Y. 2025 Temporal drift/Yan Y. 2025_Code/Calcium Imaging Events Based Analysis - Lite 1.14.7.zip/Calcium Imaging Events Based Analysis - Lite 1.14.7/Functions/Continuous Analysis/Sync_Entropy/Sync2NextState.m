function Sync2NextState (Events_AllMice, Opts)
% This function plots the events distributions time locked to the next
% change of brain state.

% Options.
if nargin < 2
    Opts.n_bins = 50;
    Opts.marker_size = 10;
    Opts.dist_grid = 'on';
    Opts.FLAG_Save = 0;
    
    Opts.General.MinStableStateDuration = 45; % [Frames]
end
if isempty(Opts)
    Opts.n_bins = 50;
    Opts.marker_size = 10;
    Opts.dist_grid = 'on';
    Opts.FLAG_Save = 0;
    
    Opts.General.MinStableStateDuration = 45; % [Frames]
end
if ~isfield(Opts.General, 'MinStableStateDuration')
    Opts.General.MinStableStateDuration = 45;
end


%% Initialize variables.
tmp_StateChangeAdvs_All = [Events_AllMice.Dist_NextState];
Events_Awake = Events_AllMice([Events_AllMice.StateTag] == 1);
Events_NoNREM = Events_AllMice([Events_AllMice.StateTag] == 2);
Events_REM = Events_AllMice([Events_AllMice.StateTag] == 4);

tmp_StateChangeAdv_Awake = [Events_Awake.Dist_NextState];
tmp_StateChangeAdv_NoNREM = [Events_NoNREM.Dist_NextState];
tmp_StateChangeAdv_REM = [Events_REM.Dist_NextState];

% Transition States.
Events_Unstable_Awake = Events_Awake([Events_Awake.StateLength] < Opts.General.MinStableStateDuration);
Events_Unstable_NoNREM = Events_NoNREM([Events_NoNREM.StateLength] < Opts.General.MinStableStateDuration);
Events_Stable_Awake = Events_Awake([Events_Awake.StateLength] > Opts.General.MinStableStateDuration);
Events_Stable_NoNREM = Events_NoNREM([Events_NoNREM.StateLength] > Opts.General.MinStableStateDuration);
tmp_StateChangeAdv_AwakeUnstable = [Events_Unstable_Awake.Dist_NextState];
tmp_StateChangeAdv_NoNREMUnstable = [Events_Unstable_NoNREM.Dist_NextState];
tmp_StateChangeAdv_AwakeStable = [Events_Stable_Awake.Dist_NextState];
tmp_StateChangeAdv_NoNREMStable = [Events_Stable_NoNREM.Dist_NextState];


% Transition Types.
Events_Awake2NoNREM = Events_Awake([Events_Awake.NextStateTag] == 2);
Events_NoNREM2REM = Events_NoNREM([Events_NoNREM.NextStateTag] == 4); 
Events_NoNREM2Awake = Events_NoNREM([Events_NoNREM.NextStateTag] == 1); 
Events_REM2Awake = Events_REM([Events_REM.NextStateTag] == 1);

tmp_StateChangeAdv_NoNREM2REM = [Events_NoNREM2REM.Dist_NextState];
tmp_StateChangeAdv_NoNREM2Awake = [Events_NoNREM2Awake.Dist_NextState];
tmp_StateChangeAdv_Awake2NoNREM = [Events_Awake2NoNREM.Dist_NextState];
tmp_StateChangeAdv_REM2Awake = [Events_REM2Awake.Dist_NextState];


%% Scatter Histograms
str_suptitle = 'Events Advance time before State Change';
str_xlabel = 'Advance time to State Change [s]';

% Awake vs Non-REM vs REM (All)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeAdv_Awake)), 2*ones(1, numel(tmp_StateChangeAdv_NoNREM)), 3*ones(1, numel(tmp_StateChangeAdv_REM))];
Data_tmp = [tmp_StateChangeAdv_Awake, tmp_StateChangeAdv_NoNREM, tmp_StateChangeAdv_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake'; str_legend{2} = 'Non-REM'; str_legend{3} = 'REM';
FileName = 'Figure Adv2StateChange 1';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% NoN-REM before REM vs NoN-REM before Awake
Data_Conditions = [1*ones(1, numel(tmp_StateChangeAdv_NoNREM2REM)), 2*ones(1, numel(tmp_StateChangeAdv_NoNREM2Awake))];
Data_tmp = [tmp_StateChangeAdv_NoNREM2REM, tmp_StateChangeAdv_NoNREM2Awake];
Opts.Sync.Plot.Color = [1, 0, 0; 1, 0.5, 0];
str_legend{1} = 'Non-REM before REM'; str_legend{2} = 'Non-REM before Awake';
FileName = 'Figure Adv2StateChange 2';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% Awake vs Non-REM vs REM (No Unstable States)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeAdv_AwakeStable)), 2*ones(1, numel(tmp_StateChangeAdv_NoNREMStable)), 3*ones(1, numel(tmp_StateChangeAdv_REM))];
Data_tmp = [tmp_StateChangeAdv_AwakeStable, tmp_StateChangeAdv_NoNREMStable, tmp_StateChangeAdv_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake (Stable)'; str_legend{2} = 'Non-REM (Stable)'; str_legend{3} = 'REM';
FileName = 'Figure Adv2StateChange 3';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% REM vs Non-REM before REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeAdv_REM)), 2*ones(1, numel(tmp_StateChangeAdv_NoNREM2REM))];
Data_tmp = [tmp_StateChangeAdv_REM, tmp_StateChangeAdv_NoNREM2REM];
Opts.Sync.Plot.Color = [0, 1, 0; 1, 0, 0];
str_legend{1} = 'REM'; str_legend{2} = 'Non-REM before REM';
FileName = 'Figure Adv2StateChange 4';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);