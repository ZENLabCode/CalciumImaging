function ContinuousResults = SyncPoint_Analysis_Continuous (Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts)
% Computes event based measures in a "continuous" way across the signal,  
% binarizing the signal, and computing quantities across a sliding time 
% window.
% Quantities such as the Average Sync, Events Rate, Source Entropy, N of
% overlapping events, N of event singlets are computed.

% Options.
FrameRate = Opts.General.FrameRate;
Window_Length = Opts.ContinuousPointAnalysis.Window_Length;

n_mice = Opts.n_mice;
n_sessions = Opts.n_sessions;
mouse_sessions = Opts.Mouse_Sessions;

%% Initialization.
% Make sliding window.
sliding_window = ones(1, Window_Length);

% Binarize Traces.
Binary_Traces_AllSessions = make_binary_point_traces (Events_AllSessions, Hypnogram_AllSessions, Opts);
Binary_Traces_Integrals_AllSessions = Binarize_Integrals (Events_AllSessions, Hypnogram_AllSessions, Opts);

% Get max n of time points
n_time = NaN(1, n_sessions);
for i_session = 1:n_sessions
    current_session_traces = Binary_Traces_AllSessions{i_session}';
    n_time(i_session) = numel(current_session_traces{1});
end
n_max_time_points = nanmax(n_time);


%% Continuous Analysis
Sync_Index = NaN(n_sessions, n_max_time_points);
n_events_overlap_avg = NaN(n_sessions, n_max_time_points);
n_events = NaN(n_sessions, n_max_time_points);
n_events_singlets = NaN(n_sessions, n_max_time_points);
Entropy_Matrix = NaN(n_sessions, n_max_time_points);
EventsIntegralSumArray = NaN(n_sessions, n_max_time_points);
% Scroll mice.
i_session_tot = 1;
for i_mouse = 1:n_mice
    current_MouseName = Mouse_Names{i_mouse};
    current_N_Sessions = mouse_sessions(i_mouse);
    fprintf('\n-- >> Analyzing Mouse %s << --\n', current_MouseName);
    tic
    % Scroll sessions
    for i_session = 1:current_N_Sessions
        fprintf(' - Session %d \n', i_session);
        current_session_traces = Binary_Traces_AllSessions{i_session_tot}';
        current_session_integral = Binary_Traces_Integrals_AllSessions{i_session_tot}';
        current_traces_matrix_integral = cell2mat(current_session_integral);
        current_traces_matrix_integral = current_traces_matrix_integral(2:2:end, :);
        current_traces_matrix = cell2mat(current_session_traces);
        [n_states, n_time_points] = size(current_traces_matrix);
        
        % Scroll data points with the moving window.
        for i_time = 1:n_time_points - Window_Length + 1
            % Set time window.
            current_traces_matrix_tmp = current_traces_matrix;
            current_traces_matrix_integral_tmp = current_traces_matrix_integral;
            current_window = zeros(1, n_time_points);
            current_window(1, i_time:i_time + Window_Length - 1) = sliding_window;
            try
                current_traces_matrix_tmp(:, current_window == 0) = [];
                current_traces_matrix_integral_tmp(:, current_window == 0) = [];
            catch
                keyboard
            end
            current_traces_matrix_log = logical(current_traces_matrix_tmp);

            % Compute Sync in the current time window.
            [Sync_Index(i_session_tot, i_time), n_events_overlap_avg(i_session_tot, i_time), n_events(i_session_tot, i_time), n_events_singlets(i_session_tot, i_time)] = cmp_PointSync (current_traces_matrix_tmp, Opts);
            
            % Compute Entropy.
            Entropy_Matrix(i_session_tot, i_time) = entropy(current_traces_matrix_log);
            
            % Compute Events Integral Density
            EventsIntegralSumArray(i_session_tot, i_time) = nansum(nansum(current_traces_matrix_integral_tmp, 1));
            
            % Compute CumSum in current
            
        end
%         fprintf('   NaN in Sync: %d\n', numel(Sync_Index(isnan(Sync_Index(i_session_tot, :)))));
%         fprintf('   Zeros in Sync: %d\n', numel(Sync_Index(i_session_tot, (Sync_Index(i_session_tot, :) == 0))));
        i_session_tot = i_session_tot + 1;
    end
    time_clock = toc;
    fprintf('Mouse %s Analyzed. Time elapsed: %.1f s\n', current_MouseName, time_clock);
end

% Data Shift Correction.
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = Sync_Index(:, 1:end-Window_Length+1);
Sync_Index = tmp;
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = n_events_overlap_avg(:, 1:end-Window_Length+1);
n_events_overlap_avg = tmp;
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = n_events(:, 1:end-Window_Length+1);
n_events = tmp;
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = n_events_singlets(:, 1:end-Window_Length+1);
n_events_singlets = tmp;
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = Entropy_Matrix(:, 1:end-Window_Length+1);
Entropy_Matrix = tmp;
tmp = NaN(n_sessions, n_max_time_points);
tmp(:, Window_Length:end) = EventsIntegralSumArray(:, 1:end-Window_Length+1);
EventsIntegralSumArray = tmp;

EventsIntegralDensity = EventsIntegralSumArray./(Window_Length/FrameRate);
EventsRate = n_events./(Window_Length/FrameRate);

% Compute entropy.
% entropy_array = compute_Pop_Entropy (Events_AllSessions, Hypnogram_AllSessions, Opts);

% Save Output Variables.
ContinuousResults.Sync_Index = Sync_Index;
ContinuousResults.n_events_overlap_avg = n_events_overlap_avg;
ContinuousResults.n_events = n_events;
ContinuousResults.n_events_singlets = n_events_singlets;
ContinuousResults.PopulationEntropy = Entropy_Matrix;
ContinuousResults.EventsRate = EventsRate;
ContinuousResults.EventsIntegralSumArray = EventsIntegralSumArray;
ContinuousResults.EventsIntegralDensity = EventsIntegralDensity;


%% Plots.
if Opts.ContinuousPointAnalysis.FLAG_Plot == 1
    PlotsPath = sprintf('%s\\Binarized Signal Analysis', Opts.Dir_Figures);
    if exist(PlotsPath, 'dir') == 0
        mkdir(PlotsPath);
        addpath(genpath(PlotsPath));
    end
    % Entropy
    PlotStrings.suptitle = sprintf('Population Entropy (Entropy of the Source, Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Entropy - All Mice Sessions');
    PlotStrings.FileName = 'Continuous Entropy (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.PopulationEntropy, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
    % N Events
    PlotStrings.suptitle = sprintf('Events Number (Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Events Number - All Mice Sessions');
    PlotStrings.FileName = 'Events Number (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.n_events, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
    % Events Rate
    PlotStrings.suptitle = sprintf('Events Rate (Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Events Rate - All Mice Sessions');
    PlotStrings.FileName = 'Events Rate (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.EventsRate, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
    % Average N Overlapping Events
    PlotStrings.suptitle = sprintf('Average Number of Contemporaneous Events (Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Average Number of Contemporaneous Events - All Mice Sessions');
    PlotStrings.FileName = 'Continuous AvgNOverlappingEvents (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.n_events_overlap_avg, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
    % Events Integrals Density
    PlotStrings.suptitle = sprintf('Events Integrals Density (\\Sigma Events Integrals / Time  , Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Events Integrals Density - All Mice Sessions');
    PlotStrings.FileName = 'Events Integrals Density (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.EventsIntegralDensity, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
    % Sync
    PlotStrings.suptitle = sprintf('Events (point-)Sync (Binary Signal)');
    PlotStrings.str_ylabel = sprintf('Point Sync - All Mice Sessions');
    PlotStrings.FileName = 'Continuous Sync (Binary Signal)';
    SyncPoint_Analysis_Continuous_Plot (ContinuousResults.Sync_Index, Hypnogram_AllSessions, PlotStrings, PlotsPath, Opts)
end