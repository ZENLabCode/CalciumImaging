function entropy_array = compute_Pop_Entropy (Events, Hypnogram_AllSessions, Opts)
% This function computes the entropy of the signal source, intended as the
% ensemble of measured neurons, activated in a specific time window,
% sliding over the entire recordings. This will be a measure of the entropy
% of the source, or in other words, of the statistical texture of the
% neuronal activity.

%% --------- THIS FUNCTION IS UNUSED ATM, AND TO BE FIXED TO INCLUDE ALL THE SESSIONS (instead of the per mouse analysis)

%% Initialize
window_length = Opts.ContinuousPointAnalysis.Entropy.Window_Length;
n_mice = Opts.n_mice;
n_sessions = Opts.n_sessions;

% Make Binary Traces for Synchro Analysis.
Binary_Traces_AllMice = make_binary_point_traces (Events, Hypnogram_AllSessions, Opts);

% Set sliding time window.
tmp_window = ones(1, window_length);

% Get max n of time points
n_time = NaN(1, n_sessions);
for i_session = 1:n_sessions
    current_mouse_traces = Binary_Traces_AllMice{i_session}';
    n_time(i_session) = numel(current_mouse_traces{1});
end
n_max_time_points = nanmax(n_time);


%% Analyze all mice.
entropy_array = NaN(n_mice, n_max_time_points);
for i_mouse = 1:n_mice 
    % Get activity matrix of current mouse
    tmp = Binary_Traces_AllMice{i_mouse};
    current_activity_matrix = cell2mat(tmp');
    current_activity_matrix = logical(current_activity_matrix);
    
    [n_cells, n_time_points] = size(current_activity_matrix);
    
    % Compute entropy on sliding window.
    for i_time = 1:n_time_points - window_length + 1
        current_window = zeros(1, n_time_points);
        current_window(1, i_time:i_time + window_length - 1) = tmp_window;
        current_activity_matrix_cut = current_activity_matrix;
        current_activity_matrix_cut(:, current_window == 0) = [];
        
        entropy_array(i_mouse, i_time) = entropy(current_activity_matrix_cut);
    end
end

% Shift the data correctly.
tmp = NaN(n_mice, n_max_time_points);
tmp(:, window_length:end) = entropy_array(:, 1:end-window_length+1);

entropy_array = tmp;


