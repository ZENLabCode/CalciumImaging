function Sync2StateChange (Events_AllMice, Mouse_Names, State_Info_perSession, Opts)
% This function runs the main analysis for the events lag time to the
% previous state change, and plots the results.
% The actual lags are computed in the main analysis function and are saved
% in the struct variable "Events_AllMice".


% Options.
if nargin < 2
    Opts = set_options;
end
if isempty(Opts)
    Opts = set_options;
end

n_max_states = 1000; % Maximum numeber of hypothesised states in the whole recordings (for array initialization purpose: keep this number higher than actual number of states)
n_events = numel(Events_AllMice); % Maximum number of events in a state (for array initialization: ok vastly overestimated)

minimum_state_length = Opts.General.MinStableStateDuration;
TagAWAKE = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;


%% Initialize variables.
% Remove 1st State of recordings (as its duration is unknown, together with the state that comes before it)
Events_AllMice(isnan([Events_AllMice.PreStateTag])) = [];

% Isolate Events per State
[Events_Awake, tmp_StateChangeLag_Awake, Events_Unstable_Awake, Events_Stable_Awake, StateLength_min_Awake] = get_EventsPerStates (Events_AllMice, TagAWAKE, Opts);
[Events_NoNREM, tmp_StateChangeLag_NoNREM, Events_Unstable_NoNREM, Events_Stable_NoNREM, StateLength_min_NoNREM] = get_EventsPerStates (Events_AllMice, TagNoNREM, Opts);
[Events_REM, tmp_StateChangeLag_REM, Events_Unstable_REM, Events_Stable_REM, StateLength_min_REM] = get_EventsPerStates (Events_AllMice, TagREM, Opts);

% Separate Awake after NoN-REM vs Awake after REM
Events_AwakeANoNREM = Events_Awake([Events_Awake.PreStateTag] == TagNoNREM);
Events_AwakeAREM = Events_Awake([Events_Awake.PreStateTag] == TagREM);
[~, tmp_StateChangeLag_AwakeANoNREM, Events_Unstable_AwakeANoNREM, Events_Stable_AwakeANoNREM, StateLength_min_AwakeANoNREM] = get_EventsPerStates (Events_AwakeANoNREM, TagAWAKE, Opts);
[~, tmp_StateChangeLag_AwakeAREM, Events_Unstable_AwakeAREM, Events_Stable_AwakeAREM, StateLength_min_AwakeAREM] = get_EventsPerStates (Events_AwakeAREM, TagAWAKE, Opts);
tmp_StateChangeLags_All = [Events_AllMice.Dist_PreState];

% Get Minimum State Length
StateLength_min = nanmin([StateLength_min_Awake, StateLength_min_NoNREM, StateLength_min_REM, StateLength_min_AwakeANoNREM]);
% For a fair comparison, do not take events with too much lag, as some states are shorter than that.
Events_Stable_Cut2Compare_Awake = Events_Stable_Awake([Events_Stable_Awake.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_NoNREM = Events_Stable_NoNREM([Events_Stable_NoNREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_REM = Events_Stable_REM([Events_Stable_REM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_AwakeANoNREM = Events_Stable_AwakeANoNREM([Events_Stable_AwakeANoNREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_AwakeAREM = Events_Stable_AwakeAREM([Events_Stable_AwakeAREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);


%% Get Lag2State Variables.
% Initialize Lag2States Variables
[StateChangeLag_Stable_Awake, StateChangeLag_Unstable_Awake, StateChangeLag_Stable_Cut2Compare_Awake, tmp_Lag_per_State_Awake, tmp_dim1_pre_Awake] = Sync2StateChange_Sub_1 (Events_Stable_Awake, Events_Unstable_Awake, Events_Stable_Cut2Compare_Awake, n_max_states, n_events);
[StateChangeLag_Stable_NoNREM, StateChangeLag_Unstable_NoNREM, StateChangeLag_Stable_Cut2Compare_NoNREM, tmp_Lag_per_State_NoNREM, tmp_dim1_pre_NoNREM] = Sync2StateChange_Sub_1 (Events_Stable_NoNREM, Events_Unstable_NoNREM, Events_Stable_Cut2Compare_NoNREM, n_max_states, n_events);
[StateChangeLag_Stable_REM, StateChangeLag_Unstable_REM, StateChangeLag_Stable_Cut2Compare_REM, tmp_Lag_per_State_REM, tmp_dim1_pre_REM] = Sync2StateChange_Sub_1 (Events_Stable_REM, Events_Unstable_REM, Events_Stable_Cut2Compare_REM, n_max_states, n_events);
[StateChangeLag_Stable_AwakeANoNREM, StateChangeLag_Unstable_AwakeANoNREM, StateChangeLag_Stable_Cut2Compare_AwakeANoNREM, tmp_Lag_per_State_AwakeANoNREM, tmp_dim1_pre_AwakeANoNREM] = Sync2StateChange_Sub_1 (Events_Stable_AwakeANoNREM, Events_Unstable_AwakeANoNREM, Events_Stable_Cut2Compare_AwakeANoNREM, n_max_states, n_events);
[StateChangeLag_Stable_AwakeAREM, StateChangeLag_Unstable_AwakeAREM, StateChangeLag_Stable_Cut2Compare_AwakeAREM, tmp_Lag_per_State_AwakeAREM, tmp_dim1_pre_AwakeAREM] = Sync2StateChange_Sub_1 (Events_Stable_AwakeAREM, Events_Unstable_AwakeAREM, Events_Stable_Cut2Compare_AwakeAREM, n_max_states, n_events);

n_mice = Opts.n_mice;
N_Cells = nan(1, n_mice);
% StateMouseMatrix = NaN (numel(tmp_Events_per_State_Awake), 1);

tmp_N_States_previous_Awake = 1;
tmp_N_States_previous_NoNREM = 1;
tmp_N_States_previous_REM = 1;
tmp_N_States_previous_AwakeANoNREM = 1;
tmp_N_States_previous_AwakeAREM = 1;
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    Current_Mouse_Events = separate_events_per_mouse (Events_AllMice, MouseName);
    n_states = numel(find([State_Info_perSession.MouseNumber] == i_mouse));

    N_Cells(i_mouse) = nanmax([Current_Mouse_Events.TraceNumber]);
    fprintf('Getting Event Lags for Mouse %s: %d Sleep States detected.\n', MouseName, n_states);
    
    % Gets selected State events (and lags) for the current mouse
    [tmp_Lag_per_State_Awake, tmp_Events_per_State_Awake, tmp_dim1_pre_Awake, tmp_N_States_Awake] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_Awake, tmp_Lag_per_State_Awake, MouseName, n_states, tmp_dim1_pre_Awake);
    Mouse_State_Matrix.Awake(1, tmp_N_States_previous_Awake:tmp_N_States_previous_Awake+tmp_N_States_Awake-1) = i_mouse;
    Mouse_State_Matrix.Awake(2, tmp_N_States_previous_Awake:tmp_N_States_previous_Awake+tmp_N_States_Awake-1) = N_Cells(i_mouse);
    tmp_N_States_previous_Awake = tmp_N_States_previous_Awake+tmp_N_States_Awake;
    [tmp_Lag_per_State_NoNREM, tmp_Events_per_State_NoNREM, tmp_dim1_pre_NoNREM, tmp_N_States_NoNREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_NoNREM, tmp_Lag_per_State_NoNREM, MouseName, n_states, tmp_dim1_pre_NoNREM);
    Mouse_State_Matrix.NoNREM(1, tmp_N_States_previous_NoNREM:tmp_N_States_previous_NoNREM+tmp_N_States_NoNREM-1) = i_mouse;
    Mouse_State_Matrix.NoNREM(2, tmp_N_States_previous_NoNREM:tmp_N_States_previous_NoNREM+tmp_N_States_NoNREM-1) = N_Cells(i_mouse);
    tmp_N_States_previous_NoNREM = tmp_N_States_previous_NoNREM+tmp_N_States_NoNREM;
    [tmp_Lag_per_State_REM, tmp_Events_per_State_REM, tmp_dim1_pre_REM, tmp_N_States_REM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_REM, tmp_Lag_per_State_REM, MouseName, n_states, tmp_dim1_pre_REM);
    Mouse_State_Matrix.REM(1, tmp_N_States_previous_REM:tmp_N_States_previous_REM+tmp_N_States_REM-1) = i_mouse;
    Mouse_State_Matrix.REM(2, tmp_N_States_previous_REM:tmp_N_States_previous_REM+tmp_N_States_REM-1) = N_Cells(i_mouse);
    tmp_N_States_previous_REM = tmp_N_States_previous_REM+tmp_N_States_REM;
    [tmp_Lag_per_State_AwakeANoNREM, tmp_Events_per_State_AwakeANoNREM, tmp_dim1_pre_AwakeANoNREM, tmp_N_States_AwakeANoNREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_AwakeANoNREM, tmp_Lag_per_State_AwakeANoNREM, MouseName, n_states, tmp_dim1_pre_AwakeANoNREM);
    Mouse_State_Matrix.AwakeANoNREM(1, tmp_N_States_previous_AwakeANoNREM:tmp_N_States_previous_AwakeANoNREM+tmp_N_States_AwakeANoNREM-1) = i_mouse;
    Mouse_State_Matrix.AwakeANoNREM(2, tmp_N_States_previous_AwakeANoNREM:tmp_N_States_previous_AwakeANoNREM+tmp_N_States_AwakeANoNREM-1) = N_Cells(i_mouse);
    tmp_N_States_previous_AwakeANoNREM = tmp_N_States_previous_AwakeANoNREM+tmp_N_States_AwakeANoNREM;
    [tmp_Lag_per_State_AwakeAREM, tmp_Events_per_State_AwakeAREM, tmp_dim1_pre_AwakeAREM, tmp_N_States_AwakeAREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_AwakeAREM, tmp_Lag_per_State_AwakeAREM, MouseName, n_states, tmp_dim1_pre_AwakeAREM);
    Mouse_State_Matrix.AwakeAREM(1, tmp_N_States_previous_AwakeAREM:tmp_N_States_previous_AwakeAREM+tmp_N_States_AwakeAREM-1) = i_mouse;
    Mouse_State_Matrix.AwakeAREM(2, tmp_N_States_previous_AwakeAREM:tmp_N_States_previous_AwakeAREM+tmp_N_States_AwakeAREM-1) = N_Cells(i_mouse);
    tmp_N_States_previous_AwakeAREM = tmp_N_States_previous_AwakeAREM+tmp_N_States_AwakeAREM;
end

% Remove extra columns (columns of NaNs only).
tmp_Lag_per_State_Awake(~any(~isnan(tmp_Lag_per_State_Awake), 2),:) = [];
tmp_Lag_per_State_NoNREM(~any(~isnan(tmp_Lag_per_State_NoNREM), 2),:) = [];
tmp_Lag_per_State_REM(~any(~isnan(tmp_Lag_per_State_REM), 2),:) = [];
tmp_Lag_per_State_AwakeANoNREM(~any(~isnan(tmp_Lag_per_State_AwakeANoNREM), 2),:) = [];
tmp_Lag_per_State_AwakeAREM(~any(~isnan(tmp_Lag_per_State_AwakeAREM), 2),:) = [];

% Remove extra raws (raws of NaNs only).
tmp_Lag_per_State_Awake(:, ~any(~isnan(tmp_Lag_per_State_Awake), 1)) = [];
tmp_Lag_per_State_NoNREM(:, ~any(~isnan(tmp_Lag_per_State_NoNREM), 1)) = [];
tmp_Lag_per_State_REM(:, ~any(~isnan(tmp_Lag_per_State_REM), 1)) = [];
tmp_Lag_per_State_AwakeANoNREM(:, ~any(~isnan(tmp_Lag_per_State_AwakeANoNREM), 1)) = [];
tmp_Lag_per_State_AwakeAREM(:, ~any(~isnan(tmp_Lag_per_State_AwakeAREM), 1)) = [];

% Divide the Lags in bins of fixed duration for each state.
bins_max = StateLength_min/Opts.General.FrameRate; % [s]
bins_duration = bins_max/Opts.Sync.NLagBins; % [s]

% Remove States with less than N events, as they confund the analysis in the Means/StE (especially Normalization 2).
[~, tmp_N_Events_perBinStats.Awake, tmp_Event_N_perState.Awake, tmp_Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (tmp_Lag_per_State_Awake, Mouse_State_Matrix.Awake, StateLength_min, Opts);
Lag_per_State_Awake = tmp_Lag_per_State_Awake;
Lag_per_State_Awake(~(tmp_Event_N_perState.Awake > tmp_Event_N_perStateStats_Awake.Thr), :) = [];
Mouse_State_Matrix.Awake(:, ~(tmp_Event_N_perState.Awake > tmp_Event_N_perStateStats_Awake.Thr)) = [];
[~, tmp_N_Events_perBinStats.NoNREM, tmp_Event_N_perState.NoNREM, tmp_Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_NoNREM, Mouse_State_Matrix.NoNREM, StateLength_min, Opts);
Lag_per_State_NoNREM = tmp_Lag_per_State_NoNREM;
Lag_per_State_NoNREM(~(tmp_Event_N_perState.NoNREM > tmp_Event_N_perStateStats_NoNREM.Thr), :) = [];
Mouse_State_Matrix.NoNREM(:, ~(tmp_Event_N_perState.NoNREM > tmp_Event_N_perStateStats_NoNREM.Thr)) = [];
[~, tmp_N_Events_perBinStats.REM, tmp_Event_N_perState.REM, tmp_Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_REM, Mouse_State_Matrix.REM, StateLength_min, Opts);
Lag_per_State_REM = tmp_Lag_per_State_REM;
Lag_per_State_REM(~(tmp_Event_N_perState.REM > tmp_Event_N_perStateStats_REM.Thr), :) = [];
Mouse_State_Matrix.REM(:, ~(tmp_Event_N_perState.REM > tmp_Event_N_perStateStats_REM.Thr)) = [];
[~, tmp_N_Events_perBinStats.AwakeANoNREM, tmp_Event_N_perState.AwakeANoNREM, tmp_Event_N_perStateStats_AwakeANoNREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_AwakeANoNREM, Mouse_State_Matrix.AwakeANoNREM, StateLength_min, Opts);
Lag_per_State_AwakeANoNREM = tmp_Lag_per_State_AwakeANoNREM;
Lag_per_State_AwakeANoNREM(~(tmp_Event_N_perState.AwakeANoNREM > tmp_Event_N_perStateStats_AwakeANoNREM.Thr), :) = [];
Mouse_State_Matrix.AwakeANoNREM(:, ~(tmp_Event_N_perState.AwakeANoNREM > tmp_Event_N_perStateStats_AwakeANoNREM.Thr)) = [];
[~, tmp_N_Events_perBinStats.AwakeAREM, tmp_Event_N_perState.AwakeAREM, tmp_Event_N_perStateStats_AwakeAREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_AwakeAREM, Mouse_State_Matrix.AwakeAREM, StateLength_min, Opts);
Lag_per_State_AwakeAREM = tmp_Lag_per_State_AwakeAREM;
Lag_per_State_AwakeAREM(~(tmp_Event_N_perState.AwakeAREM > tmp_Event_N_perStateStats_AwakeAREM.Thr), :) = [];
Mouse_State_Matrix.AwakeAREM(:, ~(tmp_Event_N_perState.AwakeAREM > tmp_Event_N_perStateStats_AwakeAREM.Thr)) = [];

% Get States Numbers
[N_States.Awake, LagsDim2_Awake] = size(Lag_per_State_Awake);
[N_States.NoNREM, LagsDim2_NoNREM] = size(Lag_per_State_NoNREM);
[N_States.REM, LagsDim2_REM] = size(Lag_per_State_REM);
[N_States.AwakeANoNREM, LagsDim2_AwakeANoNREM] = size(Lag_per_State_AwakeANoNREM);
[N_States.AwakeAREM, LagsDim2_AwakeAREM] = size(Lag_per_State_AwakeAREM);

% Get States and Bins separation, means, StEs.
[N_Events_perBin.Awake, N_Events_perBinStats.Awake, Event_N_perState.Awake, Event_N_perStateStats.Awake] = get_NEvents_PerTimeBin (Lag_per_State_Awake, Mouse_State_Matrix.Awake, StateLength_min, Opts);
[N_Events_perBin.NoNREM, N_Events_perBinStats.NoNREM, Event_N_perState.NoNREM, Event_N_perStateStats.NoNREM] = get_NEvents_PerTimeBin (Lag_per_State_NoNREM, Mouse_State_Matrix.NoNREM, StateLength_min, Opts);
[N_Events_perBin.REM, N_Events_perBinStats.REM, Event_N_perState.REM, Event_N_perStateStats.REM] = get_NEvents_PerTimeBin (Lag_per_State_REM, Mouse_State_Matrix.REM, StateLength_min, Opts);
[N_Events_perBin.AwakeANoNREM, N_Events_perBinStats.AwakeANoNREM, Event_N_perState.AwakeANoNREM, Event_N_perStateStats.AwakeANoNREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeANoNREM, Mouse_State_Matrix.AwakeANoNREM, StateLength_min, Opts);
[N_Events_perBin.AwakeAREM, N_Events_perBinStats.AwakeAREM, Event_N_perState.AwakeAREM, Event_N_perStateStats.AwakeAREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeAREM, Mouse_State_Matrix.AwakeAREM, StateLength_min, Opts);

% Compare differences between time bins, for different states.
N_Events_Diff_perBin_Awake = diff(N_Events_perBin.Awake, 1, 2);
N_Events_Diff_perBin_NoNREM = diff(N_Events_perBin.NoNREM, 1, 2);
N_Events_Diff_perBin_REM = diff(N_Events_perBin.REM, 1, 2);
N_Events_Diff_perBin_AwakeANoNREM = diff(N_Events_perBin.AwakeANoNREM, 1, 2);
N_Events_Diff_perBin_AwakeAREM = diff(N_Events_perBin.AwakeAREM, 1, 2);


%% Statistics
% Compute Statistics: Differences between states across the bins)
for i_bin = 1:Opts.Sync.NLagBins
    Stats.Bins(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.Bins(i_bin).NEvents_Mean_Awake = N_Events_perBinStats.Awake.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_NoNREM = N_Events_perBinStats.NoNREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_REM = N_Events_perBinStats.REM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_AwakeANoNREM = N_Events_perBinStats.AwakeANoNREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_AwakeAREM = N_Events_perBinStats.AwakeAREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_StE_Awake = N_Events_perBinStats.Awake.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_NoNREM = N_Events_perBinStats.NoNREM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_REM = N_Events_perBinStats.REM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_AwakeANoNREM = N_Events_perBinStats.AwakeANoNREM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_AwakeAREM = N_Events_perBinStats.AwakeAREM.StE(i_bin);
    [Stats.Bins(i_bin).AwakeVSNoNREM.h, Stats.Bins(i_bin).AwakeVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSNoNREM.Stats] = ttest2(N_Events_perBin.Awake(:, i_bin), N_Events_perBin.NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeVSREM.h, Stats.Bins(i_bin).AwakeVSREM.P_Value, Stats.Bins(i_bin).AwakeVSREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSREM.Stats] = ttest2(N_Events_perBin.Awake(:, i_bin), N_Events_perBin.REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).NoNREMVSREM.h, Stats.Bins(i_bin).NoNREMVSREM.P_Value, Stats.Bins(i_bin).NoNREMVSREM.Confidence_Interval, Stats.Bins(i_bin).NoNREMVSREM.Stats] = ttest2(N_Events_perBin.NoNREM(:, i_bin), N_Events_perBin.REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.h, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.Stats] = ttest2(N_Events_perBin.AwakeANoNREM(:, i_bin), N_Events_perBin.NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeAREMVSNoNREM.h, Stats.Bins(i_bin).AwakeAREMVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeAREMVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeAREMVSNoNREM.Stats] = ttest2(N_Events_perBin.AwakeAREM(:, i_bin), N_Events_perBin.NoNREM(:, i_bin), 'Vartype', 'unequal');
end

% Compute Statistics: Differences between bins of the same states
for i_bin = 1:Opts.Sync.NLagBins
    for j_bin = 1:Opts.Sync.NLagBins
        [Stats.BinsComparison.Awake.h(i_bin, j_bin), Stats.BinsComparison.Awake.P_Value(i_bin, j_bin), Stats.BinsComparison.Awake.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.Awake.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin.Awake(:, i_bin), N_Events_perBin.Awake(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.NoNREM.h(i_bin, j_bin), Stats.BinsComparison.NoNREM.P_Value(i_bin, j_bin), Stats.BinsComparison.NoNREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.NoNREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin.NoNREM(:, i_bin), N_Events_perBin.NoNREM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.REM.h(i_bin, j_bin), Stats.BinsComparison.REM.P_Value(i_bin, j_bin), Stats.BinsComparison.REM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.REM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin.REM(:, i_bin), N_Events_perBin.REM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.AwakeANoNREM.h(i_bin, j_bin), Stats.BinsComparison.AwakeANoNREM.P_Value(i_bin, j_bin), Stats.BinsComparison.AwakeANoNREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.AwakeANoNREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin.AwakeANoNREM(:, i_bin), N_Events_perBin.AwakeANoNREM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.AwakeAREM.h(i_bin, j_bin), Stats.BinsComparison.AwakeAREM.P_Value(i_bin, j_bin), Stats.BinsComparison.AwakeAREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.AwakeAREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin.AwakeAREM(:, i_bin), N_Events_perBin.AwakeAREM(:, j_bin), 'Vartype', 'unequal');
    end
end

% Compute Statistics: Differences between derivative(#N Events per bin)
for i_bin = 1:(Opts.Sync.NLagBins - 1)
    Stats.BinsDiff(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.BinsDiff(i_bin).NEvents_DiffMean_Awake = nanmean(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_NoNREM = nanmean(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_REM = nanmean(N_Events_Diff_perBin_REM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_AwakeANoNREM = nanmean(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_AwakeAREM = nanmean(N_Events_Diff_perBin_AwakeAREM(:, i_bin));

    tmp = size(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_Awake = nanstd(N_Events_Diff_perBin_Awake(:, i_bin))/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_NoNREM = N_Events_Diff_perBin_NoNREM(:, i_bin)/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_REM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_REM = N_Events_Diff_perBin_REM(:, i_bin)/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_AwakeANoNREM = nanstd(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin))/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_AwakeAREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_AwakeAREM = nanstd(N_Events_Diff_perBin_AwakeAREM(:, i_bin))/sqrt(tmp(1));

    [Stats.BinsDiff(i_bin).Awake_vs_NoNREM.h, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).Awake_vs_REM.h, Stats.BinsDiff(i_bin).Awake_vs_REM.P_Value, Stats.BinsDiff(i_bin).Awake_vs_REM.Confidence_Interval, Stats.BinsDiff(i_bin).Awake_vs_REM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).NoNREM_vs_REM.h, Stats.BinsDiff(i_bin).NoNREM_vs_REM.P_Value, Stats.BinsDiff(i_bin).NoNREM_vs_REM.Confidence_Interval, Stats.BinsDiff(i_bin).NoNREM_vs_REM.Stats] = ttest2(N_Events_Diff_perBin_NoNREM(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeAREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeAREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_AwakeAREM(:, i_bin), 'Vartype', 'unequal');
end

clear tmp


%% Transition Types.
Events_REM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagREM);
Events_NoNREM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagNoNREM);
tmp_StateChangeLag_REM2Awake = [Events_REM2Awake.Dist_PreState];
tmp_StateChangeLag_NoNREM2Awake = [Events_NoNREM2Awake.Dist_PreState];

N_Events_StableCut_Awake = numel(StateChangeLag_Stable_Cut2Compare_Awake);
N_Events_StableCut_NoNREM = numel(StateChangeLag_Stable_Cut2Compare_NoNREM);
N_Events_StableCut_REM = numel(StateChangeLag_Stable_Cut2Compare_REM);


%% Plot - Distribution of events between lag intervals.
Sync2StateChange_DistributionPlot (N_Events_perBinStats, N_States, bins_duration, Opts)


%% Scatter Histograms
str_suptitle = 'Events Lag after State Change';
str_xlabel = 'Lag to State Change [s]';

% Awake vs Non-REM vs REM (All)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [tmp_StateChangeLag_Awake, tmp_StateChangeLag_NoNREM, tmp_StateChangeLag_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake'; str_legend{2} = 'NREM'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 1';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);
clear str_legend

% Awake (both post-REM and post-Opts.Sync.Plot.Color) vs Non-REM vs REM (All)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM2Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM2Awake)), 3*ones(1, numel(tmp_StateChangeLag_NoNREM)), 4*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [tmp_StateChangeLag_REM2Awake, tmp_StateChangeLag_NoNREM2Awake, tmp_StateChangeLag_NoNREM, tmp_StateChangeLag_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 0, 0, 0.5; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake post REM)'; str_legend{2} = 'Awake post NREM)'; str_legend{3} = 'NREM'; str_legend{4} = 'REM';
FileName = 'Figure Lag2StateChange 2';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);
clear str_legend

% Awake post REM vs Awake post Non-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM2Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM2Awake, tmp_StateChangeLag_NoNREM2Awake];
Opts.Sync.Plot.Color = [0, 0, 1; 0, 0, 0.5];
str_legend{1} = 'Awake post REM'; str_legend{2} = 'Awake post NREM';
FileName = 'Figure Lag2StateChange 3';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);
clear str_legend

% Awake vs Non-REM vs REM (Stable States)
Data_Conditions = [1*ones(1, numel(StateChangeLag_Stable_Awake)), 2*ones(1, numel(StateChangeLag_Stable_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [StateChangeLag_Stable_Awake, StateChangeLag_Stable_NoNREM, StateChangeLag_Stable_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake (Stable)'; str_legend{2} = 'Non-REM (Stable)'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 4';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);
clear str_legend

% REM vs Awake Post-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM)), 2*ones(1, numel(tmp_StateChangeLag_REM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM, tmp_StateChangeLag_REM2Awake];
Opts.Sync.Plot.Color = [0, 1, 0; 0, 0, 1];
str_legend{1} = 'REM'; str_legend{2} = 'Awake (after REM)';
FileName = 'Figure Lag2StateChange 5';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);
clear str_legend




%%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %%
%   ~~~~~~~~~~~~~~~~~~~~~~~~ Sub-Functions ~~~~~~~~~~~~~~~~~~~~~~~~  %
%   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  % 

    function [StateChangeLag_Stable, StateChangeLag_Unstable, StateChangeLag_Stable_Cut2Compare, tmp_Lag_per_State, tmp_dim1_pre] = Sync2StateChange_Sub_1 (Events_Stable, Events_Unstable, Events_Stable_Cut2Compare, n_max_states, n_events)
        % This function is used in a loop to increase readibility, and to
        % make it easier to repeat operations for different states.
        % It initializes the Event Lags for each State.
        
        %  Get lags for Stable/Unstable/StableCut States
        StateChangeLag_Unstable = [Events_Unstable.Dist_PreState];
        StateChangeLag_Stable = [Events_Stable.Dist_PreState];
        StateChangeLag_Stable_Cut2Compare = [Events_Stable_Cut2Compare.Dist_PreState];
        
        % Separate the Events and Events Lags per State for each mouse.
        tmp_Lag_per_State = NaN(n_max_states, n_events);
        tmp_dim1_pre = 0;
    end


    function [tmp_Lag_per_State, tmp_Events_per_State, tmp_dim1_pre, tmp_N_States] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare, tmp_Lag_per_State, MouseName, n_states, tmp_dim1_pre)
        % This function is used in a loop to increase readibility, and to
        % make it easier to repeat operations for different states.
        % It gets the Event Lags for each State.
        
        [tmp1_Lag_per_State, tmp_Events_per_State] = get_EventsLags_per_State (Events_Stable_Cut2Compare, MouseName, n_states);
        [tmp_dim1, tmp_dim2] = size(tmp1_Lag_per_State);
        tmp_Lag_per_State((tmp_dim1_pre + 1):(tmp_dim1_pre + tmp_dim1), 1:tmp_dim2) = tmp1_Lag_per_State;
        
        tmp_dim1_pre = tmp_dim1_pre + tmp_dim1;        
        
        
        tmp_N_States = 0;
        for i_tmp = 1:numel(tmp_Events_per_State)
            if ~isempty(tmp_Events_per_State{i_tmp})
                tmp_N_States = tmp_N_States + 1;
            end
        end
    
    end

end
