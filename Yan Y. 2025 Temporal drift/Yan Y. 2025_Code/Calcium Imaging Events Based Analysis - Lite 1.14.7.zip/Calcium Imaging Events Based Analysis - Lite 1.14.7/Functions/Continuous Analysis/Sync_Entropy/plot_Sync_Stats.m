function plot_Sync_Stats (Sync_Stats, Sync_Awake, Sync_NoNREM, Sync_REM)
% This function plots the results from the Point Sync analysis.
% The synchronicity value here represents the number of "contemporary"
% calcium events between all traces of a recording. The values plotted are
% averages between all states.

grp_Awake = 1.*ones(1, numel(Sync_Awake));
grp_NoNREM = 2.*ones(1, numel(Sync_NoNREM));
grp_REM = 3.*ones(1, numel(Sync_REM));
groups = [grp_Awake, grp_NoNREM, grp_REM];
str_suptitle = 'Synchronicity of Calcium Events per State.';
str_title1 = sprintf('Sync between States (Normalized by events rate)\n(Events Rate = #Events/State Duration)');

figure(); set(gcf,'position', get(0,'screensize'));

dist1 = (Sync_Awake./Sync_Stats.Awake.events_rate)';
dist2 = (Sync_NoNREM./Sync_Stats.NoNREM.events_rate)';
dist3 = (Sync_REM./Sync_Stats.REM.events_rate)';
groups_vars = [dist1, dist2, dist3];
subplot(1, 3, 1);
hold on; box on; grid on; axis square;
h_boxplot = boxplot(groups_vars, groups);
ylabel('Synchronicity Index')
xticklabels({'Awake', 'Non-REM', 'REM'})
title(str_title1)

dist1 = (Sync_Awake./Sync_Stats.Awake.n_events)';
dist2 = (Sync_NoNREM./Sync_Stats.NoNREM.n_events)';
dist3 = (Sync_REM./Sync_Stats.REM.n_events)';
groups_vars = [dist1, dist2, dist3];
subplot(1, 3, 2);
hold on; box on; grid on; axis square;
h_boxplot = boxplot(groups_vars, groups);
ylabel('Synchronicity Index')
xticklabels({'Awake', 'Non-REM', 'REM'})
title('Sync between States (Normalized by events number)')

dist1 = (Sync_Awake)';
dist2 = (Sync_NoNREM)';
dist3 = (Sync_REM)';
groups_vars = [dist1, dist2, dist3];
subplot(1, 3, 3);
hold on; box on; grid on;  axis square;
h_boxplot = boxplot(groups_vars, groups);
ylabel('Synchronicity Index')
xticklabels({'Awake', 'Non-REM', 'REM'})
title('Sync between States (Non-Normalized)')

h_suptitle = suptitle(str_suptitle);
h_suptitle.FontSize = 18;
h_suptitle.FontWeight = 'bold';