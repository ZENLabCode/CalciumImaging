function plot_ScatterHist_StateChangeLags(Data, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts)
% This function is intended as plot subfunction to the "Sync2StateChange" 
% and "Sync2NextState" function. It plots the Scatter + Hist figure.

figure();
h = scatterhist(Data, 1:numel(Data), 'Kernel', 'on', 'Group', Data_Conditions, 'LineWidth', 2, 'Marker', '.', 'MarkerSize', Opts.Sync.Plot.marker_size, 'Color', Opts.Sync.Plot.Color);
grid on; axis tight;
ylabel('Data Points')
xlabel(str_xlabel);
delete(h(3));

[msg, warnID] = lastwarn('', '');
warning('off', 'MATLAB:callback:error'); % Ignore a warning message about the position of the suptitle & something about the legend..
warning('off', 'MATLAB:class:InvalidHandle');

% Legend
[hLegend] = findobj(gcf, 'Type', 'Legend');
tmp = hLegend.Position;
if numel(str_legend) == 2
    [~, h_legend_obj] = legend({str_legend{1}, str_legend{2}}, 'Position', tmp);
elseif numel(str_legend) == 3
    [~, h_legend_obj] = legend({str_legend{1}, str_legend{2}, str_legend{3}}, 'Position', tmp);
elseif numel(str_legend) == 4
    [~, h_legend_obj] = legend({str_legend{1}, str_legend{2}, str_legend{3}, str_legend{4}}, 'Position', tmp);
end
h_Lines = findobj(h_legend_obj, 'Type', 'Line');
for i = 1:numel(h_Lines); h_Lines(i).MarkerSize = 14; end 
% Legend Fix - End
h(2).Visible = 'on'; h(2).XGrid = Opts.Sync.Plot.dist_grid; h(2).YGrid = Opts.Sync.Plot.dist_grid;
h(2).YAxisLocation = 'right'; h(2).Box = 'on';
h(2).XMinorTick = 'on'; h(2).YMinorTick = 'on';

test = h(2).Children(2).YData;

% [msg, warnID] = lastwarn
h_suptitle = suptitle(str_suptitle);
h_suptitle.FontSize = 14; h_suptitle.FontWeight = 'bold'; 

% Save and close
if Opts.Sync.Plot.FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

[~, warnID] = lastwarn;
if ~isempty(warnID)
    warning('There was a warning about the position of the Suptitle or Legend: make sure they are ok.')
end
warning('on', 'MATLAB:callback:error'); % Turn on that warning again.
warning('on', 'MATLAB:class:InvalidHandle'); % Turn on that warning again.