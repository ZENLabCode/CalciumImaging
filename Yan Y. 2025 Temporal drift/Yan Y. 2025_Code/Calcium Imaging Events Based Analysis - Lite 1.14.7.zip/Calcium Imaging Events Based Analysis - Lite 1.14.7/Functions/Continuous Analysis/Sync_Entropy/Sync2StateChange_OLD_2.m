function Sync2StateChange (Events_AllMice, Mouse_Names, Opts)
% This function runs the main analysis for the events lag time to the
% previous state change, and plots the results.
% The actual lags are computed in the main analysis function and are saved
% in the struct variable "Events_AllMice".


% Options.
if nargin < 3
    Opts = set_options;
end
if isempty(Opts)
    Opts = set_options;
end

Opts.General.MinStableStateDuration = 20*Opts.General.FrameRate;
n_max_states = 1000; % Maximum numeber of hypothesised states in the whole recordings (for array initialization purpose: keep this number higher than actual number of states)
n_events = numel(Events_AllMice); % Maximum number of events in a state (for array initialization: ok vastly overestimated)

minimum_state_length = Opts.General.MinStableStateDuration;
TagAWAKE = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;


%% Initialize variables.
% Remove 1st State of recordings (as its duration is unknown, together with the state that comes before it)
Events_AllMice(isnan([Events_AllMice.PreStateTag])) = [];

% Isolate Events per State
[Events_Awake, tmp_StateChangeLag_Awake, Events_Unstable_Awake, Events_Stable_Awake, StateLength_min_Awake] = get_EventsPerStates (Events_AllMice, TagAWAKE, Opts);
[Events_NoNREM, tmp_StateChangeLag_NoNREM, Events_Unstable_NoNREM, Events_Stable_NoNREM, StateLength_min_NoNREM] = get_EventsPerStates (Events_AllMice, TagNoNREM, Opts);
[Events_REM, tmp_StateChangeLag_REM, Events_Unstable_REM, Events_Stable_REM, StateLength_min_REM] = get_EventsPerStates (Events_AllMice, TagREM, Opts);

% Separate Awake after NoN-REM vs Awake after REM
Events_AwakeANoNREM = Events_Awake([Events_Awake.PreStateTag] == TagNoNREM);
Events_AwakeAREM = Events_Awake([Events_Awake.PreStateTag] == TagREM);
[~, tmp_StateChangeLag_AwakeANoNREM, Events_Unstable_AwakeANoNREM, Events_Stable_AwakeANoNREM, StateLength_min_AwakeANoNREM] = get_EventsPerStates (Events_AwakeANoNREM, TagAWAKE, Opts);
[~, tmp_StateChangeLag_AwakeAREM, Events_Unstable_AwakeAREM, Events_Stable_AwakeAREM, StateLength_min_AwakeAREM] = get_EventsPerStates (Events_AwakeAREM, TagAWAKE, Opts);

tmp_StateChangeLags_All = [Events_AllMice.Dist_PreState];

% Get Minimum State Length
StateLength_min = nanmin([StateLength_min_Awake, StateLength_min_NoNREM, StateLength_min_REM, StateLength_min_AwakeANoNREM]);
% For a fair comparison, do not take events with too much lag, as some states are shorter than that.
Events_Stable_Cut2Compare_Awake = Events_Stable_Awake([Events_Stable_Awake.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_NoNREM = Events_Stable_NoNREM([Events_Stable_NoNREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_REM = Events_Stable_REM([Events_Stable_REM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_AwakeANoNREM = Events_Stable_AwakeANoNREM([Events_Stable_AwakeANoNREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_AwakeAREM = Events_Stable_AwakeAREM([Events_Stable_AwakeAREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);


%% Get Lag2State Variables.
% Initialize Lag2States Variables
[StateChangeLag_Stable_Awake, StateChangeLag_Unstable_Awake, StateChangeLag_Stable_Cut2Compare_Awake, tmp_Lag_per_State_Awake, tmp_dim1_pre_Awake] = Sync2StateChange_Sub_1 (Events_Stable_Awake, Events_Unstable_Awake, Events_Stable_Cut2Compare_Awake, n_max_states, n_events);
[StateChangeLag_Stable_NoNREM, StateChangeLag_Unstable_NoNREM, StateChangeLag_Stable_Cut2Compare_NoNREM, tmp_Lag_per_State_NoNREM, tmp_dim1_pre_NoNREM] = Sync2StateChange_Sub_1 (Events_Stable_NoNREM, Events_Unstable_NoNREM, Events_Stable_Cut2Compare_NoNREM, n_max_states, n_events);
[StateChangeLag_Stable_REM, StateChangeLag_Unstable_REM, StateChangeLag_Stable_Cut2Compare_REM, tmp_Lag_per_State_REM, tmp_dim1_pre_REM] = Sync2StateChange_Sub_1 (Events_Stable_REM, Events_Unstable_REM, Events_Stable_Cut2Compare_REM, n_max_states, n_events);
[StateChangeLag_Stable_AwakeANoNREM, StateChangeLag_Unstable_AwakeANoNREM, StateChangeLag_Stable_Cut2Compare_AwakeANoNREM, tmp_Lag_per_State_AwakeANoNREM, tmp_dim1_pre_AwakeANoNREM] = Sync2StateChange_Sub_1 (Events_Stable_AwakeANoNREM, Events_Unstable_AwakeANoNREM, Events_Stable_Cut2Compare_AwakeANoNREM, n_max_states, n_events);
[StateChangeLag_Stable_AwakeAREM, StateChangeLag_Unstable_AwakeAREM, StateChangeLag_Stable_Cut2Compare_AwakeAREM, tmp_Lag_per_State_AwakeAREM, tmp_dim1_pre_AwakeAREM] = Sync2StateChange_Sub_1 (Events_Stable_AwakeAREM, Events_Unstable_AwakeAREM, Events_Stable_Cut2Compare_AwakeAREM, n_max_states, n_events);

n_mice = numel(Mouse_Names);
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    Current_Mouse_Events = separate_events_per_mouse (Events_AllMice, MouseName);
    n_states = nanmax([Current_Mouse_Events.StateNumber]);
    fprintf('Getting Event Lags for Mouse %s: %d Sleep States detected.\n', MouseName, n_states);
    
    [tmp_Lag_per_State_Awake, tmp_Events_per_State_Awake, tmp_dim1_pre_Awake] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_Awake, tmp_Lag_per_State_Awake, MouseName, n_states, tmp_dim1_pre_Awake);
    [tmp_Lag_per_State_NoNREM, tmp_Events_per_State_NoNREM, tmp_dim1_pre_NoNREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_NoNREM, tmp_Lag_per_State_NoNREM, MouseName, n_states, tmp_dim1_pre_NoNREM);
    [tmp_Lag_per_State_REM, tmp_Events_per_State_REM, tmp_dim1_pre_REM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_REM, tmp_Lag_per_State_REM, MouseName, n_states, tmp_dim1_pre_REM);
    [tmp_Lag_per_State_AwakeANoNREM, tmp_Events_per_State_AwakeANoNREM, tmp_dim1_pre_AwakeANoNREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_AwakeANoNREM, tmp_Lag_per_State_AwakeANoNREM, MouseName, n_states, tmp_dim1_pre_AwakeANoNREM);
    [tmp_Lag_per_State_AwakeAREM, tmp_Events_per_State_AwakeAREM, tmp_dim1_pre_AwakeAREM] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare_AwakeAREM, tmp_Lag_per_State_AwakeAREM, MouseName, n_states, tmp_dim1_pre_AwakeAREM);
end

% Remove extra columns (columns of NaNs only).
tmp_Lag_per_State_Awake(~any(~isnan(tmp_Lag_per_State_Awake), 2),:) = [];
tmp_Lag_per_State_NoNREM(~any(~isnan(tmp_Lag_per_State_NoNREM), 2),:) = [];
tmp_Lag_per_State_REM(~any(~isnan(tmp_Lag_per_State_REM), 2),:) = [];
tmp_Lag_per_State_AwakeANoNREM(~any(~isnan(tmp_Lag_per_State_AwakeANoNREM), 2),:) = [];
tmp_Lag_per_State_AwakeAREM(~any(~isnan(tmp_Lag_per_State_AwakeAREM), 2),:) = [];

% Remove extra raws (raws of NaNs only).
tmp_Lag_per_State_Awake(:, ~any(~isnan(tmp_Lag_per_State_Awake), 1)) = [];
tmp_Lag_per_State_NoNREM(:, ~any(~isnan(tmp_Lag_per_State_NoNREM), 1)) = [];
tmp_Lag_per_State_REM(:, ~any(~isnan(tmp_Lag_per_State_REM), 1)) = [];
tmp_Lag_per_State_AwakeANoNREM(:, ~any(~isnan(tmp_Lag_per_State_AwakeANoNREM), 1)) = [];
tmp_Lag_per_State_AwakeAREM(:, ~any(~isnan(tmp_Lag_per_State_AwakeAREM), 1)) = [];


[LagsDim1_Awake, LagsDim2_Awake] = size(tmp_Lag_per_State_Awake);
[LagsDim1_NoNREM, LagsDim2_NoNREM] = size(tmp_Lag_per_State_NoNREM);
[LagsDim1_REM, LagsDim2_REM] = size(tmp_Lag_per_State_REM);
[LagsDim1_AwakeANoNREM, LagsDim2_AwakeANoNREM] = size(tmp_Lag_per_State_AwakeANoNREM);
[LagsDim1_AwakeAREM, LagsDim2_AwakeAREM] = size(tmp_Lag_per_State_AwakeAREM);


% Divide the Lags in bins of fixed duration for each state.
bins_max = StateLength_min/Opts.General.FrameRate; % [s]
bins_duration = bins_max/Opts.Sync.NLagBins; % [s]

% Remove States with less than N events, as they confund the analysis in the Means/StE (especially Normalization 2).
[~, tmp_N_Events_perBinStats_Awake, tmp_Event_N_perState_Awake, tmp_Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (tmp_Lag_per_State_Awake, StateLength_min, Opts);
Lag_per_State_Awake = tmp_Lag_per_State_Awake;
Lag_per_State_Awake(~(tmp_Event_N_perState_Awake > tmp_Event_N_perStateStats_Awake.Thr), :) = [];
[~, tmp_N_Events_perBinStats_NoNREM, tmp_Event_N_perState_NoNREM, tmp_Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_NoNREM, StateLength_min, Opts);
Lag_per_State_NoNREM = tmp_Lag_per_State_NoNREM;
Lag_per_State_NoNREM(~(tmp_Event_N_perState_NoNREM > tmp_Event_N_perStateStats_NoNREM.Thr), :) = [];
[~, tmp_N_Events_perBinStats_REM, tmp_Event_N_perState_REM, tmp_Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_REM, StateLength_min, Opts);
Lag_per_State_REM = tmp_Lag_per_State_REM;
Lag_per_State_REM(~(tmp_Event_N_perState_REM > tmp_Event_N_perStateStats_REM.Thr), :) = [];
[~, tmp_N_Events_perBinStats_AwakeANoNREM, tmp_Event_N_perState_AwakeANoNREM, tmp_Event_N_perStateStats_AwakeANoNREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_AwakeANoNREM, StateLength_min, Opts);
Lag_per_State_AwakeANoNREM = tmp_Lag_per_State_AwakeANoNREM;
Lag_per_State_AwakeANoNREM(~(tmp_Event_N_perState_AwakeANoNREM > tmp_Event_N_perStateStats_AwakeANoNREM.Thr), :) = [];
[~, tmp_N_Events_perBinStats_AwakeAREM, tmp_Event_N_perState_AwakeAREM, tmp_Event_N_perStateStats_AwakeAREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_AwakeAREM, StateLength_min, Opts);
Lag_per_State_AwakeAREM = tmp_Lag_per_State_AwakeAREM;
Lag_per_State_AwakeAREM(~(tmp_Event_N_perState_AwakeAREM > tmp_Event_N_perStateStats_AwakeAREM.Thr), :) = [];

% Get States and Bins separation, means, StEs.
[N_Events_perBin_Awake, N_Events_perBinStats_Awake, Event_N_perState_Awake, Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (Lag_per_State_Awake, StateLength_min, Opts);
[N_Events_perBin_NoNREM, N_Events_perBinStats_NoNREM, Event_N_perState_NoNREM, Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (Lag_per_State_NoNREM, StateLength_min, Opts);
[N_Events_perBin_REM, N_Events_perBinStats_REM, Event_N_perState_REM, Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (Lag_per_State_REM, StateLength_min, Opts);
[N_Events_perBin_AwakeANoNREM, N_Events_perBinStats_AwakeANoNREM, Event_N_perState_AwakeANoNREM, Event_N_perStateStats_AwakeANoNREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeANoNREM, StateLength_min, Opts);
[N_Events_perBin_AwakeAREM, N_Events_perBinStats_AwakeAREM, Event_N_perState_AwakeAREM, Event_N_perStateStats_AwakeAREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeAREM, StateLength_min, Opts);

% [N_Events_perBin_Awake, N_Events_perBinStats.Awake, Event_N_perState_Awake, Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (Lag_per_State_Awake, StateLength_min, Opts);
% [N_Events_perBin_NoNREM, N_Events_perBinStats.NoNREM, Event_N_perState_NoNREM, Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (Lag_per_State_NoNREM, StateLength_min, Opts);
% [N_Events_perBin_REM, N_Events_perBinStats.REM, Event_N_perState_REM, Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (Lag_per_State_REM, StateLength_min, Opts);
% [N_Events_perBin_AwakeANoNREM, N_Events_perBinStats.AwakeANoNREM, Event_N_perState_AwakeANoNREM, Event_N_perStateStats_AwakeANoNREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeANoNREM, StateLength_min, Opts);
% [N_Events_perBin_AwakeAREM, N_Events_perBinStats.AwakeAREM, Event_N_perState_AwakeAREM, Event_N_perStateStats_AwakeAREM] = get_NEvents_PerTimeBin (Lag_per_State_AwakeAREM, StateLength_min, Opts);


% Compare differences between time bins, for different states.
N_Events_Diff_perBin_Awake = diff(N_Events_perBin_Awake, 1, 2);
N_Events_Diff_perBin_NoNREM = diff(N_Events_perBin_NoNREM, 1, 2);
N_Events_Diff_perBin_REM = diff(N_Events_perBin_REM, 1, 2);
N_Events_Diff_perBin_AwakeANoNREM = diff(N_Events_perBin_AwakeANoNREM, 1, 2);
N_Events_Diff_perBin_AwakeAREM = diff(N_Events_perBin_AwakeAREM, 1, 2);


%% Statistics
% Compute Statistics: Differences between states across the bins)
for i_bin = 1:Opts.Sync.NLagBins
    Stats.Bins(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.Bins(i_bin).NEvents_Mean_Awake = N_Events_perBinStats_Awake.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_NoNREM = N_Events_perBinStats_NoNREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_REM = N_Events_perBinStats_REM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_AwakeANoNREM = N_Events_perBinStats_AwakeANoNREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_AwakeAREM = N_Events_perBinStats_AwakeAREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_StE_Awake = N_Events_perBinStats_Awake.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_NoNREM = N_Events_perBinStats_NoNREM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_REM = N_Events_perBinStats_REM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_AwakeANoNREM = N_Events_perBinStats_AwakeANoNREM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_AwakeAREM = N_Events_perBinStats_AwakeAREM.StE(i_bin);
    [Stats.Bins(i_bin).AwakeVSNoNREM.h, Stats.Bins(i_bin).AwakeVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSNoNREM.Stats] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeVSREM.h, Stats.Bins(i_bin).AwakeVSREM.P_Value, Stats.Bins(i_bin).AwakeVSREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSREM.Stats] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).NoNREMVSREM.h, Stats.Bins(i_bin).NoNREMVSREM.P_Value, Stats.Bins(i_bin).NoNREMVSREM.Confidence_Interval, Stats.Bins(i_bin).NoNREMVSREM.Stats] = ttest2(N_Events_perBin_NoNREM(:, i_bin), N_Events_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.h, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeANoNREMVSNoNREM.Stats] = ttest2(N_Events_perBin_AwakeANoNREM(:, i_bin), N_Events_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeAREMVSNoNREM.h, Stats.Bins(i_bin).AwakeAREMVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeAREMVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeAREMVSNoNREM.Stats] = ttest2(N_Events_perBin_AwakeAREM(:, i_bin), N_Events_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
end

% Compute Statistics: Differences between bins of the same states
for i_bin = 1:Opts.Sync.NLagBins
    for j_bin = 1:Opts.Sync.NLagBins
        [Stats.BinsComparison.Awake.h(i_bin, j_bin), Stats.BinsComparison.Awake.P_Value(i_bin, j_bin), Stats.BinsComparison.Awake.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.Awake.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_Awake(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.NoNREM.h(i_bin, j_bin), Stats.BinsComparison.NoNREM.P_Value(i_bin, j_bin), Stats.BinsComparison.NoNREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.NoNREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_NoNREM(:, i_bin), N_Events_perBin_NoNREM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.REM.h(i_bin, j_bin), Stats.BinsComparison.REM.P_Value(i_bin, j_bin), Stats.BinsComparison.REM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.REM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_REM(:, i_bin), N_Events_perBin_REM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.AwakeANoNREM.h(i_bin, j_bin), Stats.BinsComparison.AwakeANoNREM.P_Value(i_bin, j_bin), Stats.BinsComparison.AwakeANoNREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.AwakeANoNREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_AwakeANoNREM(:, i_bin), N_Events_perBin_AwakeANoNREM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.AwakeAREM.h(i_bin, j_bin), Stats.BinsComparison.AwakeAREM.P_Value(i_bin, j_bin), Stats.BinsComparison.AwakeAREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.AwakeAREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_AwakeAREM(:, i_bin), N_Events_perBin_AwakeAREM(:, j_bin), 'Vartype', 'unequal');
    end
end

% Compute Statistics: Differences between derivative(#N Events per bin)
for i_bin = 1:(Opts.Sync.NLagBins - 1)
    Stats.BinsDiff(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.BinsDiff(i_bin).NEvents_DiffMean_Awake = nanmean(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_NoNREM = nanmean(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_REM = nanmean(N_Events_Diff_perBin_REM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_AwakeANoNREM = nanmean(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_AwakeAREM = nanmean(N_Events_Diff_perBin_AwakeAREM(:, i_bin));

    tmp = size(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_Awake = nanstd(N_Events_Diff_perBin_Awake(:, i_bin))/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_NoNREM = N_Events_Diff_perBin_NoNREM(:, i_bin)/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_REM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_REM = N_Events_Diff_perBin_REM(:, i_bin)/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_Awake = nanstd(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin))/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_AwakeAREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_Awake = nanstd(N_Events_Diff_perBin_AwakeAREM(:, i_bin))/sqrt(tmp(1));

    [Stats.BinsDiff(i_bin).Awake_vs_NoNREM.h, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).Awake_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).Awake_vs_REM.h, Stats.BinsDiff(i_bin).Awake_vs_REM.P_Value, Stats.BinsDiff(i_bin).Awake_vs_REM.Confidence_Interval, Stats.BinsDiff(i_bin).Awake_vs_REM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).NoNREM_vs_REM.h, Stats.BinsDiff(i_bin).NoNREM_vs_REM.P_Value, Stats.BinsDiff(i_bin).NoNREM_vs_REM.Confidence_Interval, Stats.BinsDiff(i_bin).NoNREM_vs_REM.Stats] = ttest2(N_Events_Diff_perBin_NoNREM(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeAREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.h, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeAREM_vs_NoNREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeAREM(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.h, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.P_Value, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeANoNREM_vs_AwakeAREM.Stats] = ttest2(N_Events_Diff_perBin_AwakeANoNREM(:, i_bin), N_Events_Diff_perBin_AwakeAREM(:, i_bin), 'Vartype', 'unequal');
end

clear tmp*



%% Transition Types.
Events_REM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagREM);
Events_NoNREM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagNoNREM);
tmp_StateChangeLag_REM2Awake = [Events_REM2Awake.Dist_PreState];
tmp_StateChangeLag_NoNREM2Awake = [Events_NoNREM2Awake.Dist_PreState];

N_Events_StableCut_Awake = numel(StateChangeLag_Stable_Cut2Compare_Awake);
N_Events_StableCut_NoNREM = numel(StateChangeLag_Stable_Cut2Compare_NoNREM);
N_Events_StableCut_REM = numel(StateChangeLag_Stable_Cut2Compare_REM);


keyboard
%% Plot - Distribution of events between lag intervals.
Sync2StateChange_DistributionPlot (N_Events_perBinStats_Awake, N_Events_perBinStats_NoNREM, N_Events_perBinStats_REM, bins_duration, Opts)
Sync2StateChange_DistributionPlot (N_Events_perBinStats, bins_duration, Opts)

%% Scatter Histograms
str_suptitle = 'Events Lag after State Change';
str_xlabel = 'Lag to State Change [s]';

% Awake vs Non-REM vs REM (All)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [tmp_StateChangeLag_Awake, tmp_StateChangeLag_NoNREM, tmp_StateChangeLag_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake'; str_legend{2} = 'Non-REM'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 1';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% Awake post REM vs Awake post Non-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM2Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM2Awake, tmp_StateChangeLag_NoNREM2Awake];
Opts.Sync.Plot.Color = [0, 0, 1; 0, 0, 0.5];
str_legend{1} = 'Awake post REM'; str_legend{2} = 'Awake post Non-REM';
FileName = 'Figure Lag2StateChange 2';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% Awake vs Non-REM vs REM (Stable States)
Data_Conditions = [1*ones(1, numel(StateChangeLag_Stable_Awake)), 2*ones(1, numel(StateChangeLag_Stable_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [StateChangeLag_Stable_Awake, StateChangeLag_Stable_NoNREM, StateChangeLag_Stable_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake (Stable)'; str_legend{2} = 'Non-REM (Stable)'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 3';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% REM vs Awake Post-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM)), 2*ones(1, numel(tmp_StateChangeLag_REM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM, tmp_StateChangeLag_REM2Awake];
Opts.Sync.Plot.Color = [0, 1, 0; 0, 0, 1];
str_legend{1} = 'REM'; str_legend{2} = 'Awake (after REM)';
FileName = 'Figure Lag2StateChange 4';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);





%%  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ %%
%   ~~~~~~~~~~~~~~~~~~~~~~~~ Sub-Functions ~~~~~~~~~~~~~~~~~~~~~~~~  %
%   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  % 

    function [StateChangeLag_Stable, StateChangeLag_Unstable, StateChangeLag_Stable_Cut2Compare, tmp_Lag_per_State, tmp_dim1_pre] = Sync2StateChange_Sub_1 (Events_Stable, Events_Unstable, Events_Stable_Cut2Compare, n_max_states, n_events)
        % This function is used in a loop to increase readibility, and to
        % make it easier to repeat operations for different states.
        % It initializes the Event Lags for each State.
        
        %  Get lags for Stable/Unstable/StableCut States
        StateChangeLag_Unstable = [Events_Unstable.Dist_PreState];
        StateChangeLag_Stable = [Events_Stable.Dist_PreState];
        StateChangeLag_Stable_Cut2Compare = [Events_Stable_Cut2Compare.Dist_PreState];
        
        % Separate the Events and Events Lags per State for each mouse.
        tmp_Lag_per_State = NaN(n_max_states, n_events);
        tmp_dim1_pre = 0;
    end


    function [tmp_Lag_per_State, tmp_Events_per_State, tmp_dim1_pre] = Sync2StateChange_Sub_2 (Events_Stable_Cut2Compare, tmp_Lag_per_State, MouseName, n_states, tmp_dim1_pre)
        % This function is used in a loop to increase readibility, and to
        % make it easier to repeat operations for different states.
        % It gets the Event Lags for each State.
        
        [tmp1_Lag_per_State, tmp_Events_per_State] = get_EventsLags_per_State (Events_Stable_Cut2Compare, MouseName, n_states);
        [tmp_dim1, tmp_dim2] = size(tmp1_Lag_per_State);
        tmp_Lag_per_State((tmp_dim1_pre + 1):(tmp_dim1_pre + tmp_dim1), 1:tmp_dim2) = tmp1_Lag_per_State;
        
        tmp_dim1_pre = tmp_dim1_pre + tmp_dim1;        
    end

end
