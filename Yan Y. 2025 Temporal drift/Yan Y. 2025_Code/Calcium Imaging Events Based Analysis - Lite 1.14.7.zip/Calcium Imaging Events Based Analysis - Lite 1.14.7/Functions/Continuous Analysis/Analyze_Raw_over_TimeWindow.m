function [correlation_film, entropy_trace] = Analyze_Raw_over_TimeWindow (CalciumTraces, Hypnogram_CurrentMouse, MouseName, i_Session, Opts)
% This function computes the correlation coefficients between each traces,
% over a sliding time window.


%% Options.
if nargin < 4
    warning('Options not found for "Analyze_Raw_over_TimeWindow": using default values.')
    Opts = set_options();
end
FrameRate = Opts.General.FrameRate;
Window_Length = Opts.CorrAnalysis.Window_Length;
FLAG_Save_Film = Opts.CorrAnalysis.FLAG_Save_Film;
% Granger Causality (not implemented)
FLAG_Granger = 0;
maxlag1 = 3;
maxlag2 = 3;
minlag2 = 0; % either 1 or 0
significance_thr = 0.01;


%% Computations
% Sliding Window.
sliding_window = ones(1, Window_Length);

[n_time_points, n_traces] = size(CalciumTraces);
Combinations = nchoosek(1:1:n_traces, 2);
[n_combinations, ~] = size(Combinations);
film_length = n_time_points - Window_Length + 1;

% correlation_film = NaN(n_traces, n_traces, film_length);
correlation_film = NaN(n_traces, n_traces, film_length + (Window_Length-1));
entropy_trace = NaN(1, film_length);
for i_time = 1:film_length
    % Prepare time window
    current_window = zeros(1, n_time_points);
    current_window(1, i_time:i_time + Window_Length - 1) = sliding_window;
    current_traces = CalciumTraces;
    current_traces(current_window == 0, :) = [];
    
    % Correlation
    [current_corr_matrix, p_val_matrix] = corr(current_traces);
    correlation_film(1:n_traces, 1:n_traces, i_time + (Window_Length-1)) = current_corr_matrix;
   
    % Entropy
    entropy_trace(1, i_time) = entropy(current_traces);
end
clear CalciumTraces; clear current_traces; clear current_corr_matrix; clear current_window;

% Shift the data correctly.
tmp = NaN(1, n_time_points);
tmp(1, Window_Length:end) = entropy_trace;
entropy_trace = tmp;
clear tmp;
% NaN_Matrix = NaN(n_traces, n_traces, Window_Length-1);
% try
%     correlation_film = cat(3, NaN_Matrix, correlation_film);
% catch
%     keyboard
% end
% Max and Min of Correlation.
CorrMax = max(max(nanmax(correlation_film)));
CorrMin = min(min(nanmin(correlation_film)));


%% Save .avi correlation Film.
if FLAG_Save_Film == 1
    video_name = sprintf('Correlation Film - Mouse %s - Session %d', MouseName, i_Session);
    save_CorrFilm_avi (correlation_film, Hypnogram_CurrentMouse, video_name);
end