function [States, MeanOfStates] = Analyze_Correlation_Film (CalciumTraces, correlation_film, Hypnogram_CurrentMouse, StateChanges_CurrentMouse, MouseName, i_session, i_mouse, Opts)
% This function runs some analysis on the Continuous Correlation Film:
% - Taking the average time projection of the film for each state 
% separately, the function computes a threshold for meaningful
% correlations and a corresponding Adjacency Matrix, weighted with the
% correlation coefficients. The Adjacency Matrix is used to compute Graphs
% of the inferred functional connectivity between cells 
% (each trace is a cell).
% - Taking the average of every connectivity matrix over every stable state
% of the same kind, the function attempts to build a "state-typical"
% functional connectivity.


%% Options
if nargin < 7
    warning('Options not found for "Analyze_Correlation_Film": using default values.')
    Opts = set_options;
end
n_shuffle_iterations = Opts.CorrAnalysis.n_shuffle_iterations;
FLAG_Plot_Graphs_All = Opts.CorrAnalysis.FLAG_Plot_Graphs_All;
FLAG_Save_Plots = Opts.CorrAnalysis.FLAG_Save_Plots;
Corr_Thr_Criterion = Opts.CorrAnalysis.Corr_Thr_Criterion;
Corr_Thr_Std_Multiplier = Opts.CorrAnalysis.Corr_Thr_Std_Multiplier;
Corr_Thr_Std_Multiplier_Mean = Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean;
Opts_GraphPlot.Centrality_Displayed = Opts.CorrAnalysis.Opts_GraphPlot.Centrality_Displayed;
Opts_GraphPlot.Marker_Thickness_Mult = Opts.CorrAnalysis.Opts_GraphPlot.Marker_Thickness_Mult;
FrameRate = Opts.General.FrameRate;
MinStableStateDuration = Opts.General.MinStableStateDuration;
[n_cells, ~, ~] = size(correlation_film);
n_states = numel(StateChanges_CurrentMouse);


%% Create Folder Structure for Graph Plots.
if FLAG_Plot_Graphs_All == 1
    if FLAG_Save_Plots == 1 % Check folder existence, or create folder structure.
        main_program_directory = pwd;
        addpath(genpath(main_program_directory));
        Dir_Figures = Opts.Dir_Figures;
        Dir_Corr_Graph_Main = sprintf('%s\\Correlation Connectivity Graphs', Dir_Figures);
        Dir_Corr_Graph_Current_Mouse = sprintf('%s\\%s', Dir_Corr_Graph_Main, MouseName);
        Dir_Corr_Graph_Current_Session = sprintf('%s\\Session %d', Dir_Corr_Graph_Current_Mouse, i_session);
        if exist(Dir_Corr_Graph_Main, 'dir') == 0
            cd(Dir_Figures)
            mkdir(Dir_Corr_Graph_Main)
            addpath(genpath(Dir_Corr_Graph_Main));
            pause(0.5)
            cd(main_program_directory)
        end
        if exist(Dir_Corr_Graph_Current_Mouse, 'dir') == 0
            cd(Dir_Corr_Graph_Main)
            mkdir(Dir_Corr_Graph_Current_Mouse)
            addpath(genpath(Dir_Corr_Graph_Current_Mouse));
            pause(0.5)
            cd(main_program_directory)
        end
        if exist(Dir_Corr_Graph_Current_Session, 'dir') == 0
            cd(Dir_Corr_Graph_Main)
            mkdir(Dir_Corr_Graph_Current_Session)
            addpath(genpath(Dir_Corr_Graph_Current_Session));
            pause(0.5)
            cd(main_program_directory)
        end
        number_of_zeros = 3;
        tmp_str = strcat('%0', num2str(number_of_zeros), 'd');
    end
end


%% Analyze per State.
% Initialize States Structure
StatesDummy(1).StartEnd = NaN;
StatesDummy(1).StateTag = NaN;
StatesDummy(1).StateNumber = NaN;
StatesDummy(1).MouseName = '';
StatesDummy(1).MouseNumber = NaN;
StatesDummy(1).SessionNumber = NaN;
StatesDummy(1).CorrFilmLength = NaN;
if Opts.FLAG_Memory_Saving ~= 1
    StatesDummy(1).CorrelationFilm = NaN;
end
StatesDummy(1).Corr_Graph = NaN;
StatesDummy(1).Corr_Graph_Abs = NaN;
StatesDummy(1).Corr_Graph_nEdges = NaN;
StatesDummy(1).Corr_Graph_Centrality = NaN;
StatesDummy(1).Corr_Graph_Connectivity_Index = NaN;
StatesDummy(1).Corr_Graph_Connectivity_Index_StE = NaN;
StatesDummy(1).FunctionalNetworkDensity = NaN;
StatesDummy(1).AjdacencyMatrixWeighted = NaN;
StatesDummy(1).SignificantPairs_Pos = NaN;
StatesDummy(1).SignificantPairs_Neg = NaN;
StatesDummy(1).Corr_Thr_Criterion = NaN;
StatesDummy(1).ShuffleCorr_Mean = NaN;
StatesDummy(1).ShuffleCorr_Std = NaN;
StatesDummy(1).CorrMeanTimeProjection.CorrMeanTimeProjection = NaN;
StatesDummy(1).CorrMeanTimeProjection.Projection_Max = NaN;
StatesDummy(1).CorrMeanTimeProjection.Projection_Min = NaN;
StatesDummy(1).CorrMeanTimeProjection.Projection_Mean = NaN;
StatesDummy(1).CorrMeanTimeProjection.Projection_Std = NaN;
StatesDummy(1).CorrWholeState.CorrWholeState = NaN;
StatesDummy(1).CorrWholeState.State_Max = NaN;
StatesDummy(1).CorrWholeState.State_Min = NaN;
StatesDummy(1).CorrWholeState.State_Mean = NaN;
StatesDummy(1).CorrWholeState.State_Std = NaN;
StatesDummy(1).CorrWholeState.Thr_Criterion = NaN;
StatesDummy(1).CorrWholeState.Thr_Pos_Corr = NaN;
StatesDummy(1).CorrWholeState.Thr_Neg_Corr = NaN;

CurrentState_StartEnd = NaN(n_states, 2);
for i_state = 1:n_states
    % Get States Start-End Points.
    if i_state == 1
        try
            CurrentState_StartEnd(i_state, :) = [1, StateChanges_CurrentMouse(i_state + 1) - 1];
        catch
            keyboard
        end
    elseif i_state == n_states
        CurrentState_StartEnd(i_state, :) = [StateChanges_CurrentMouse(i_state), numel(Hypnogram_CurrentMouse)];
    else
        CurrentState_StartEnd(i_state, :) = [StateChanges_CurrentMouse(i_state), StateChanges_CurrentMouse(i_state + 1) - 1];
    end
    
    % Skip unstable states?
    if Opts.CorrAnalysis.FLAG_SkipUnstableStates == 1
        if CurrentState_StartEnd(i_state, 2) - CurrentState_StartEnd(i_state, 1) < MinStableStateDuration
            try
                States(i_state) = StatesDummy;
            catch
                keyboard
            end
            continue
        end
    end
    
    % Get the current segment of the Correlation Film & of Calcium Traces.

    Current_CalciumTraces = CalciumTraces( CurrentState_StartEnd(i_state, 1):CurrentState_StartEnd(i_state, 2), : );
%     Current_CorrFilm = correlation_film(:, :, CurrentState_StartEnd(i_state, 1):CurrentState_StartEnd(i_state, 2) );

    % Get the average projection of the correlation film, over the state
    % frames.
    CurrentState_CorrMean = nanmean(correlation_film(:, :, CurrentState_StartEnd(i_state, 1):CurrentState_StartEnd(i_state, 2) ), 3);
    for i_row = 1:n_cells
        CurrentState_CorrMean(i_row, i_row) = NaN;
    end
    CorrMean_Max = max(nanmax(CurrentState_CorrMean));
    CorrMean_Min = min(nanmin(CurrentState_CorrMean));
    CorrMean_Mean = nanmean(reshape(CurrentState_CorrMean, 1, numel(CurrentState_CorrMean)));
    CorrMean_Std = nanstd(reshape(CurrentState_CorrMean, 1, numel(CurrentState_CorrMean)));
    
    % Get correlation of whole state-traces.
    [CorrWholeState, CorrWholeState_p] = corr(Current_CalciumTraces, 'rows', 'complete');
    for i_row = 1:n_cells
        CorrWholeState(i_row, i_row) = NaN;
        CorrWholeState_p(i_row, i_row) = NaN;
    end
    CorrWholeState_Max = max(nanmax(CorrWholeState));
    CorrWholeState_Min = min(nanmin(CorrWholeState));
    CorrWholeState_Mean = nanmean(reshape(CorrWholeState, 1, numel(CorrWholeState)));
    CorrWholeState_Std = nanstd(reshape(CorrWholeState, 1, numel(CorrWholeState)));
    
    % Shuffle Correlation
    ShuffledTraces_MaxCorr = NaN(1, n_shuffle_iterations);
    ShuffledTraces_MeanCorr = NaN(1, n_shuffle_iterations);
    ShuffledTraces_StdCorr = NaN(1, n_shuffle_iterations);
    
    for i_shuffling = 1:n_shuffle_iterations
        ShuffledTraces = shuffle_matrix(Current_CalciumTraces, 1);
        [ShuffledTraces_CorrWholeState, ShuffledTraces_CorrWholeState_p] = corr(ShuffledTraces, 'rows', 'complete');
        for i_row = 1:n_cells
            ShuffledTraces_CorrWholeState(i_row, i_row) = NaN;
            ShuffledTraces_CorrWholeState_p(i_row, i_row) = NaN;
        end
        ShuffledTraces_MaxCorr(1, i_shuffling) = max(nanmax(ShuffledTraces_CorrWholeState));
        ShuffledTraces_MeanCorr(1, i_shuffling) = nanmean(reshape(ShuffledTraces_CorrWholeState, 1, numel(ShuffledTraces_CorrWholeState)));
        ShuffledTraces_StdCorr(1, i_shuffling) = nanstd(reshape(ShuffledTraces_CorrWholeState, 1, numel(ShuffledTraces_CorrWholeState)));
    end
    if Opts.FLAG_Memory_Saving == 1
        clear Current_CalciumTraces
    end
    ShuffleCorr_Mean = nanmean(ShuffledTraces_MeanCorr);
    ShuffleCorr_Std = nanmean(ShuffledTraces_StdCorr);
    
    % Correlation Significance Threshold.
    if strcmpi(Corr_Thr_Criterion, 'Shuffle Mean')
        CorrWholeState_ThrP = ShuffleCorr_Mean + Corr_Thr_Std_Multiplier*ShuffleCorr_Std;
        CorrWholeState_ThrN = ShuffleCorr_Mean - Corr_Thr_Std_Multiplier*ShuffleCorr_Std;
        Corr_Thr_Criterion_tmp = sprintf('%s +- %01g Std', Corr_Thr_Criterion, Corr_Thr_Std_Multiplier);
    elseif strcmpi(Corr_Thr_Criterion, 'Mean')
        CorrWholeState_ThrP = CorrMean_Mean + Corr_Thr_Std_Multiplier*CorrMean_Std;
        CorrWholeState_ThrN = CorrMean_Mean - Corr_Thr_Std_Multiplier*CorrMean_Std;
        Corr_Thr_Criterion_tmp = sprintf('%s +- %01g Std', Corr_Thr_Criterion, Corr_Thr_Std_Multiplier);
    elseif strcmpi(Corr_Thr_Criterion, 'pValue')
        Corr_Thr_Criterion_tmp = 'pValue';
    end
    
    % Get significantly correlated traces.
    CorrWholeState_Significant = triu(CorrWholeState);
    if strcmpi(Corr_Thr_Criterion, 'pValue')
        for i = 1:n_cells
            for j = 1:n_cells
                if CorrWholeState_p(i, j) > 0.05
                    CorrWholeState_Significant(i, j) = NaN;
                end
            end
        end
        CorrWholeState_Significant(CorrWholeState_Significant == 0) = NaN;
        CorrWholeState_SignificantPos = CorrWholeState_Significant;
        CorrWholeState_SignificantPos(CorrWholeState_Significant < 0) = NaN;
        CorrWholeState_SignificantNeg = CorrWholeState_Significant;
        CorrWholeState_SignificantNeg(CorrWholeState_Significant > 0) = NaN;
    else
        CorrWholeState_SignificantPos = CorrWholeState_Significant;
        CorrWholeState_SignificantPos(CorrWholeState_SignificantPos < CorrWholeState_ThrP) = NaN;
        CorrWholeState_SignificantNeg = CorrWholeState_Significant;
        CorrWholeState_SignificantNeg(CorrWholeState_SignificantNeg > CorrWholeState_ThrN) = NaN;
    end
    [SignificantPairs_Pos(:, 1), SignificantPairs_Pos(:, 2)] = find(~isnan(CorrWholeState_SignificantPos));
    [SignificantPairs_Neg(:, 1), SignificantPairs_Neg(:, 2)] = find(~isnan(CorrWholeState_SignificantNeg));
    
    % Build Adjacency Matrix.
    tmp_CorrMatrix = CorrWholeState_SignificantPos;
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AjdacencyMatrixWeighted = tmp_CorrMatrix;
    tmp_CorrMatrix = CorrWholeState_SignificantNeg; % Get the negative correlations too.
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AjdacencyMatrixWeighted = AjdacencyMatrixWeighted + tmp_CorrMatrix;
    
    % Build Graph
    Corr_Graph = graph(AjdacencyMatrixWeighted, 'upper');
    
    % Remove Autoconnections and Lonely nodes.
    [Corr_Graph, Corr_Graph_Abs] = Graph_remove_singlets (Corr_Graph);
    
    % Functional Network Density (#Functional Edges / #Potential Edges)
    if isempty(Corr_Graph_Abs)
        n_Edges = 0;
    else
        n_Edges = numel(Corr_Graph_Abs.Edges);
    end
    FunctionalNetworkDensity = n_Edges/n_cells;

    % Centrality measures.
    Corr_Graph_Centrality = compute_centrality (Corr_Graph_Abs);
    
    % Connectivity Index
    [Corr_Graph_Connectivity_Index, Corr_Graph_Connectivity_Index_StE, ~] = compute_Connectivity_Index (CorrWholeState, CorrWholeState_ThrP, CorrWholeState_ThrN);
    
    % Save data in structure.
    States(i_state).StartEnd = CurrentState_StartEnd(i_state, :);
    States(i_state).StateTag = Hypnogram_CurrentMouse(CurrentState_StartEnd(i_state, 1) + 1);
    States(i_state).StateNumber = i_state;
    States(i_state).MouseName = MouseName;
    States(i_state).MouseNumber = i_mouse;
    States(i_state).SessionNumber = i_session;
    [~, ~, States(i_state).CorrFilmLength] = size(correlation_film);
    if Opts.FLAG_Memory_Saving ~= 1
        States(i_state).CorrelationFilm = correlation_film(:, :, CurrentState_StartEnd(i_state, 1):CurrentState_StartEnd(i_state, 2) );
    end
    States(i_state).Corr_Graph = Corr_Graph;
    States(i_state).Corr_Graph_Abs = Corr_Graph_Abs;
    States(i_state).Corr_Graph_nEdges = n_Edges;
    States(i_state).Corr_Graph_Centrality = Corr_Graph_Centrality;
    States(i_state).Corr_Graph_Connectivity_Index = Corr_Graph_Connectivity_Index;
    States(i_state).Corr_Graph_Connectivity_Index_StE = Corr_Graph_Connectivity_Index_StE;
    States(i_state).FunctionalNetworkDensity = FunctionalNetworkDensity;
    States(i_state).AjdacencyMatrixWeighted = AjdacencyMatrixWeighted;
    States(i_state).SignificantPairs_Pos = SignificantPairs_Pos;
    States(i_state).SignificantPairs_Neg = SignificantPairs_Neg;
    States(i_state).Corr_Thr_Criterion = Corr_Thr_Criterion_tmp;
    States(i_state).ShuffleCorr_Mean = ShuffleCorr_Mean;
    States(i_state).ShuffleCorr_Std = ShuffleCorr_Std;
    States(i_state).CorrMeanTimeProjection.CorrMeanTimeProjection = CurrentState_CorrMean;
    States(i_state).CorrMeanTimeProjection.Projection_Max = CorrMean_Max;
    States(i_state).CorrMeanTimeProjection.Projection_Min = CorrMean_Min;
    States(i_state).CorrMeanTimeProjection.Projection_Mean = CorrMean_Mean;
    States(i_state).CorrMeanTimeProjection.Projection_Std = CorrMean_Std;
    
    States(i_state).CorrWholeState.CorrWholeState = CorrWholeState;
    States(i_state).CorrWholeState.State_Max = CorrWholeState_Max;
    States(i_state).CorrWholeState.State_Min = CorrWholeState_Min;
    States(i_state).CorrWholeState.State_Mean = CorrWholeState_Mean;
    States(i_state).CorrWholeState.State_Std = CorrWholeState_Std;
    States(i_state).CorrWholeState.Thr_Criterion = Corr_Thr_Criterion_tmp;
    States(i_state).CorrWholeState.Thr_Pos_Corr = CorrWholeState_ThrP;
    States(i_state).CorrWholeState.Thr_Neg_Corr = CorrWholeState_ThrN;
    
    Opts_GraphPlot.state_info.StateNumber = num2str(States(i_state).StateNumber);
    Opts_GraphPlot.state_info.StateTagNum = Hypnogram_CurrentMouse(States(i_state).StartEnd(1) + 1);
    switch Opts_GraphPlot.state_info.StateTagNum
        case 1
            Opts_GraphPlot.label_color = 'b';
            Opts_GraphPlot.state_info.StateTag = 'Awake';
        case 2
            Opts_GraphPlot.label_color = 'r';
            Opts_GraphPlot.state_info.StateTag = 'NoN-REM';
        case 4
            Opts_GraphPlot.label_color = 'g';
            Opts_GraphPlot.state_info.StateTag = 'REM';
    end
    Opts_GraphPlot.state_info.Duration = (States(i_state).StartEnd(2) - States(i_state).StartEnd(1))/FrameRate;
    
    % Plot Graph
    if FLAG_Plot_Graphs_All == 1
        figure(); set(gcf,'position', get(0,'screensize'));
        [h_graph] = plot_graph (Corr_Graph, Corr_Graph_Centrality, Corr_Graph_Connectivity_Index, Opts_GraphPlot);
        if FLAG_Save_Plots == 1 % Save Plots.
           image_name_index = sprintf(tmp_str, i_state);
           FilePath = strcat(Dir_Corr_Graph_Current_Session, '\\Graph - State ', image_name_index);
           print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
           saveas(gcf, strcat(FilePath, '.jpg')); 
           saveas(gcf, strcat(FilePath, '.fig'))
           close gcf;
        end
    end
    
    % Plot CorrSum for each state.
    CurrentState_CorrMean_Norm = CurrentState_CorrMean./CorrMean_Max;
    
    % Clear for each iter
    clear SignificantPairs_Pos; clear SignificantPairs_Neg; 
end


%% Mean of same state-types analysis.
for i_state_type = 1:4 % (1 Awake, 2 Non-REM, 4 REM)
    if i_state_type == 3
        continue
    end
    % Get States of the current Type.
    CurrentStates = States([States.StateTag] == i_state_type);
    % Save the state type, mouse number, session number
    switch i_state_type
        case 1
            MeanOfStates(i_state_type).StateTag = 'Awake';
        case 2
            MeanOfStates(i_state_type).StateTag = 'NREM';
        case 3
            MeanOfStates(i_state_type).StateTag = [];
        case 4
            MeanOfStates(i_state_type).StateTag = 'REM';
    end
    MeanOfStates(i_state_type).MouseNumber = i_mouse;
    MeanOfStates(i_state_type).MouseName = MouseName;
    MeanOfStates(i_state_type).SessionNumber = i_session;
    
    tmp = [CurrentStates.StartEnd];
    StatesDuration = tmp(2:2:end) - tmp(1:2:end) + 1;
    
    % Exclude Unstable States.
    CurrentStates(StatesDuration < MinStableStateDuration) = [];
    StatesDuration(StatesDuration < MinStableStateDuration) = [];
    MeanStatesLength = nanmean(StatesDuration);
    
    if isempty(CurrentStates) % In case there are no states of this type, assign NaN values.
        MeanOfStates(i_state_type).N_States = NaN;
        MeanOfStates(i_state_type).MeanStatesLength = NaN;
        MeanOfStates(i_state_type).Corr_Thr_Criterion = NaN;
        MeanOfStates(i_state_type).CorrStatesMean_ThrP = NaN;
        MeanOfStates(i_state_type).CorrStatesMean_ThrN = NaN;
        MeanOfStates(i_state_type).CorrWholeState_SignificantPos = NaN;
        MeanOfStates(i_state_type).CorrWholeState_SignificantNeg = NaN;
        MeanOfStates(i_state_type).Corr_Matrix_Mean = NaN;
        MeanOfStates(i_state_type).AdjacencyMatrix_MeanOfStates = NaN;
        MeanOfStates(i_state_type).Corr_Graph_MeanOfStates = NaN;
        MeanOfStates(i_state_type).Corr_Graph_Centrality = NaN;
        MeanOfStates(i_state_type).Corr_Graph_Connectivity_Index = NaN;
        fprintf('States of type %d were missing.\n', i_state_type)
        continue
    end
    
    % Mean Correlation Matrix
    n_states = numel(CurrentStates);
    tmp = zeros(size(CurrentStates(1).CorrWholeState.CorrWholeState));
    
    for i_state = 1:n_states
        try
            tmp = tmp + CurrentStates(i_state).CorrWholeState.CorrWholeState;
        catch
            warning('Problem with mismatching dimensions. CurrentStates(i_state).CorrWholeState.CorrWholeState, for state %d, should have dimensions = [%d,%d]. State was ignored.', i_state, length(tmp), length(tmp))
        end
    end
    Corr_Matrix_Mean = tmp./n_states;
    if strcmpi(Corr_Thr_Criterion, 'Shuffle Mean') % Correlation Significance Threshold.
        CorrStatesMean_ThrP = CurrentStates(i_state).ShuffleCorr_Mean + Corr_Thr_Std_Multiplier_Mean*CurrentStates(i_state).ShuffleCorr_Std;
        CorrStatesMean_ThrN = CurrentStates(i_state).ShuffleCorr_Mean - Corr_Thr_Std_Multiplier_Mean*CurrentStates(i_state).ShuffleCorr_Std;
    elseif strcmpi(Corr_Thr_Criterion, 'Shuffle Mean Uniform')
        ShuffleStdAvg = nanmean([CurrentStates.ShuffleCorr_Std]);
        CorrStatesMean_ThrP = CurrentStates(i_state).ShuffleCorr_Mean + Corr_Thr_Std_Multiplier_Mean*ShuffleStdAvg;
        CorrStatesMean_ThrN = CurrentStates(i_state).ShuffleCorr_Mean - Corr_Thr_Std_Multiplier_Mean*ShuffleStdAvg;
    elseif strcmpi(Corr_Thr_Criterion, 'Mean')
        CorrStatesMean_ThrP = CurrentStates(i_state).CorrMeanTimeProjection.Projection_Mean + Corr_Thr_Std_Multiplier_Mean*CurrentStates(i_state).CorrMeanTimeProjection.Projection_Std;
        CorrStatesMean_ThrN = CurrentStates(i_state).CorrMeanTimeProjection.Projection_Mean - Corr_Thr_Std_Multiplier_Mean*CurrentStates(i_state).CorrMeanTimeProjection.Projection_Std;
    elseif strcmpi(Corr_Thr_Criterion, 'pValue')
        Corr_Thr_Criterion_tmp = 'pValue';
    end
    
    Corr_Thr_Criterion_tmp = sprintf('%s +- %01g Std', Corr_Thr_Criterion, Corr_Thr_Std_Multiplier_Mean);
    
    CorrWholeState_SignificantPos = triu(Corr_Matrix_Mean);
    CorrWholeState_SignificantPos(CorrWholeState_SignificantPos < CorrStatesMean_ThrP) = NaN;
    [SignificantPairs_Pos(:, 1), SignificantPairs_Pos(:, 2)] = find(~isnan(CorrWholeState_SignificantPos));

    CorrWholeState_SignificantNeg = triu(Corr_Matrix_Mean);
    CorrWholeState_SignificantNeg(CorrWholeState_SignificantNeg > CorrStatesMean_ThrN) = NaN;
    [SignificantPairs_Neg(:, 1), SignificantPairs_Neg(:, 2)] = find(~isnan(CorrWholeState_SignificantNeg));
    
    % Build Adjacency Matrix.
    tmp_CorrMatrix = CorrWholeState_SignificantPos;
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AdjacencyMatrix_MeanOfStates = tmp_CorrMatrix;
    tmp_CorrMatrix = CorrWholeState_SignificantNeg; % Get the negative correlations too.
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AdjacencyMatrix_MeanOfStates = AdjacencyMatrix_MeanOfStates + tmp_CorrMatrix;
    
    % Build Graph
    Corr_Graph_MeanOfStates = graph(AdjacencyMatrix_MeanOfStates, 'upper');
    
    % Remove Autoconnections and Lonely nodes.
    [Corr_Graph_MeanOfStates, Corr_Graph_Abs] = Graph_remove_singlets (Corr_Graph_MeanOfStates);
    
    % Centrality measures.
    Corr_Graph_Centrality = compute_centrality (Corr_Graph_Abs);
    
    % Connectivity Index
    [Corr_Graph_Connectivity_Index, Corr_Graph_Connectivity_Index_StE, ~] = compute_Connectivity_Index (Corr_Matrix_Mean, CorrStatesMean_ThrP, CorrStatesMean_ThrN);

    % Plot Graph
    Opts_GraphPlot.state_info.StateNumber = 0;
    Opts_GraphPlot.state_info.StateTagNum = i_state_type;
    switch Opts_GraphPlot.state_info.StateTagNum
        case 1
            Opts_GraphPlot.label_color = 'b';
            Opts_GraphPlot.state_info.StateTag = 'Awake';
        case 2
            Opts_GraphPlot.label_color = 'r';
            Opts_GraphPlot.state_info.StateTag = 'NoN-REM';
        case 4
            Opts_GraphPlot.label_color = 'g';
            Opts_GraphPlot.state_info.StateTag = 'REM';
    end
    if FLAG_Plot_Graphs_All == 1
        figure(); set(gcf,'position', get(0,'screensize'));
        [h_graph] = plot_graph (Corr_Graph_MeanOfStates, Corr_Graph_Centrality, Corr_Graph_Connectivity_Index, Opts_GraphPlot);
        if FLAG_Save_Plots == 1 % Save Plots.
           FilePath = strcat(Dir_Corr_Graph_Current_Session, '\\Graph - State Mean ', Opts_GraphPlot.state_info.StateTag);
           print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
           saveas(gcf, strcat(FilePath, '.jpg')); 
           saveas(gcf, strcat(FilePath, '.fig'))
           close gcf;
        end
    end
    MeanOfStates(i_state_type).N_States = n_states;
    MeanOfStates(i_state_type).MeanStatesLength = MeanStatesLength;
    MeanOfStates(i_state_type).Corr_Thr_Criterion = Corr_Thr_Criterion_tmp;
    MeanOfStates(i_state_type).CorrStatesMean_ThrP = CorrStatesMean_ThrP;
    MeanOfStates(i_state_type).CorrStatesMean_ThrN = CorrStatesMean_ThrN;
    MeanOfStates(i_state_type).CorrWholeState_SignificantPos = CorrWholeState_SignificantPos;
    MeanOfStates(i_state_type).CorrWholeState_SignificantNeg = CorrWholeState_SignificantNeg;
    MeanOfStates(i_state_type).Corr_Matrix_Mean = Corr_Matrix_Mean;
    MeanOfStates(i_state_type).AdjacencyMatrix_MeanOfStates = AdjacencyMatrix_MeanOfStates;
    MeanOfStates(i_state_type).Corr_Graph_MeanOfStates = Corr_Graph_MeanOfStates;
    MeanOfStates(i_state_type).Corr_Graph_Centrality = Corr_Graph_Centrality;
    MeanOfStates(i_state_type).Corr_Graph_Connectivity_Index = Corr_Graph_Connectivity_Index;

    clear SignificantPairs_Pos;
    clear SignificantPairs_Neg;
end
