function [StatesChange_Output] = StatesMeanCorrMatrix_CorrStableAtTransition (Current_MeanCorrMatrixDiff, CorrThr_Diff, N_Corrs)
% This function computes relevant informations for the stability of the
% correlations between different states.
% For instance the number of stable correlations and unstable correlations
% between 2 states, the threshold used to decide whether a correlation is
% stable or not, and mean correlation matrices filtered for only the
% relevant correlations.

% Basic quantities (max, min, mean, mean abs)
StatesChange_Output.MeanCorrMatrixDiff = Current_MeanCorrMatrixDiff;
StatesChange_Output.MeanCorrMatrixDiff_Max = nanmax(nanmax(Current_MeanCorrMatrixDiff));
StatesChange_Output.MeanCorrMatrixDiff_Min = nanmin(nanmin(Current_MeanCorrMatrixDiff));
StatesChange_Output.MeanCorrMatrixDiff_Mean = nanmean(nanmean(Current_MeanCorrMatrixDiff));
StatesChange_Output.MeanCorrMatrixDiff_Mean_Abs = nanmean(nanmean(abs(Current_MeanCorrMatrixDiff)));

% Mean(abs(Matrix of Relevant correlations))
Current_MeanCorrMatrixRelavant = Current_MeanCorrMatrixDiff;
Current_MeanCorrMatrixRelavant(Current_MeanCorrMatrixRelavant < CorrThr_Diff) = NaN;
StatesChange_Output.MeanCorrMatrixDiff_Mean_Abs_Relevant = nanmean(nanmean(abs(Current_MeanCorrMatrixRelavant)));

% Mean(Matrix of Relevant Positive correlations))
% Mean(Matrix of Relevant Negative correlations))
tmp = zeros(size(Current_MeanCorrMatrixDiff));
tmp(Current_MeanCorrMatrixDiff > CorrThr_Diff) = 1;
tmp(Current_MeanCorrMatrixDiff < -CorrThr_Diff) = 1;
Current_MeanCorrMatrixDiff(~tmp) = 0;
StatesChange_Output.MeanCorrMatrixDiff_Mean_Pos_Relevant = nanmean(nanmean(Current_MeanCorrMatrixDiff(Current_MeanCorrMatrixDiff > CorrThr_Diff)));
StatesChange_Output.MeanCorrMatrixDiff_Mean_Neg_Relevant = nanmean(nanmean(Current_MeanCorrMatrixDiff(Current_MeanCorrMatrixDiff < - CorrThr_Diff)));
StatesChange_Output.Current_MeanCorrMatrixDiff_Relevant = Current_MeanCorrMatrixDiff;

% Number of Pos/Neg Changing Correlations (and normalized versions)
StatesChange_Output.N_PosChangingCorr = numel(Current_MeanCorrMatrixDiff(Current_MeanCorrMatrixDiff > CorrThr_Diff))./2;
StatesChange_Output.N_NegChangingCorr = numel(Current_MeanCorrMatrixDiff(Current_MeanCorrMatrixDiff < - CorrThr_Diff))./2;
StatesChange_Output.N_PosChangingCorrNorm = StatesChange_Output.N_PosChangingCorr./N_Corrs;
StatesChange_Output.N_NegChangingCorrNorm = StatesChange_Output.N_NegChangingCorr./N_Corrs;
% N_StableCorr = (MeanNPosCorrThrHard + MeanNNegCorrThrHard) - (N_PosChangingCorr + N_NegChangingCorr);
