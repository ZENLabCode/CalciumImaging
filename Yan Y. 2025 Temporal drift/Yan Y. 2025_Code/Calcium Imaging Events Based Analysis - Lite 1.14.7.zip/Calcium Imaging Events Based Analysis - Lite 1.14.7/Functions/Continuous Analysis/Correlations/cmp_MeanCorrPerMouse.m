function MeanOfStates_tmp = cmp_MeanCorrPerMouse (States_perSession, Opts)
% This function is a sub-function to Continuous_Raw_Analysis.
% Compute mean correlation related measures per mouse, including the
% Graphs, considering all states of the same type of all sessions.
% The input States_perSession is a struct variable containing info about
% the correlation measures of all the states present in a mouse recordings
% (all sessions)


for i_state_type = 1:4 % (1 Awake, 2 Non-REM, 4 REM)
    if i_state_type == 3
        continue
    end
    CurrentStates_perSession = States_perSession([States_perSession.StateTag] == i_state_type); % Has only stable states of the selected type
    n_states = numel(CurrentStates_perSession);
    tmp_length = NaN(1, n_states);
    for i_state = 1:n_states
        tmp_length(i_state) = CurrentStates_perSession(i_state).StartEnd(2) - CurrentStates_perSession(i_state).StartEnd(1) + 1;
    end

    % Mean Correlation Matrix
    if isempty(CurrentStates_perSession)
        Corr_Matrix_Mean = NaN;
        MeanOfStates_tmp(i_state_type).N_States = NaN;
        MeanOfStates_tmp(i_state_type).MeanStatesLength = NaN;
        MeanOfStates_tmp(i_state_type).Corr_Thr_Criterion = NaN;
        MeanOfStates_tmp(i_state_type).CorrStatesMean_ThrP = NaN;
        MeanOfStates_tmp(i_state_type).CorrStatesMean_ThrN = NaN;
        MeanOfStates_tmp(i_state_type).CorrWholeState_SignificantPos = NaN;
        MeanOfStates_tmp(i_state_type).CorrWholeState_SignificantNeg = NaN;
        MeanOfStates_tmp(i_state_type).Corr_Matrix_Mean = NaN;
        MeanOfStates_tmp(i_state_type).AdjacencyMatrix_MeanOfStates = NaN;
        MeanOfStates_tmp(i_state_type).Corr_Graph_MeanOfStates = NaN;
        MeanOfStates_tmp(i_state_type).Corr_Graph_Centrality = NaN;
        MeanOfStates_tmp(i_state_type).Corr_Graph_Connectivity_Index = NaN;
        continue
    end
    
    tmp = zeros(size(CurrentStates_perSession(1).CorrWholeState.CorrWholeState));
    for i_state = 1:n_states
        try
            tmp = tmp + CurrentStates_perSession(i_state).CorrWholeState.CorrWholeState;
        catch
            keyboard
        end
    end
    Corr_Matrix_Mean = tmp./n_states;
    
    % Take the mean Std as threshold for significance, to uniform your
    % criterion
    Opts.CorrAnalysis.Corr_Thr_Criterion = 'Shuffle Mean Uniform';
    if strcmpi(Opts.CorrAnalysis.Corr_Thr_Criterion, 'Shuffle Mean') % Correlation Significance Threshold.
        CorrStatesMean_ThrP = CurrentStates_perSession(i_state).ShuffleCorr_Mean + Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*CurrentStates_perSession(i_state).ShuffleCorr_Std;
        CorrStatesMean_ThrN = CurrentStates_perSession(i_state).ShuffleCorr_Mean - Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*CurrentStates_perSession(i_state).ShuffleCorr_Std;
    elseif strcmpi(Opts.CorrAnalysis.Corr_Thr_Criterion, 'Shuffle Mean Uniform')
        ShuffleStdAvg = nanmean([CurrentStates_perSession.ShuffleCorr_Std]);
        CorrStatesMean_ThrP = CurrentStates_perSession(i_state).ShuffleCorr_Mean + Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*ShuffleStdAvg;
        CorrStatesMean_ThrN = CurrentStates_perSession(i_state).ShuffleCorr_Mean - Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*ShuffleStdAvg;
    elseif strcmpi(Opts.CorrAnalysis.Corr_Thr_Criterion, 'Mean')
        CorrStatesMean_ThrP = CurrentStates_perSession(i_state).CorrMeanTimeProjection.Projection_Mean + Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*CurrentStates_perSession(i_state).CorrMeanTimeProjection.Projection_Std;
        CorrStatesMean_ThrN = CurrentStates_perSession(i_state).CorrMeanTimeProjection.Projection_Mean - Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean*CurrentStates_perSession(i_state).CorrMeanTimeProjection.Projection_Std;
    end
    Corr_Thr_Criterion_tmp = sprintf('%s +- %d Std', Opts.CorrAnalysis.Corr_Thr_Criterion, Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean);
    
    CorrWholeState_SignificantPos = triu(Corr_Matrix_Mean);
    CorrWholeState_SignificantPos(CorrWholeState_SignificantPos < CorrStatesMean_ThrP) = NaN;
    [SignificantPairs_Pos(:, 1), SignificantPairs_Pos(:, 2)] = find(~isnan(CorrWholeState_SignificantPos));
    
    CorrWholeState_SignificantNeg = triu(Corr_Matrix_Mean);
    CorrWholeState_SignificantNeg(CorrWholeState_SignificantNeg > CorrStatesMean_ThrN) = NaN;
    [SignificantPairs_Neg(:, 1), SignificantPairs_Neg(:, 2)] = find(~isnan(CorrWholeState_SignificantNeg));
    
    % Build Adjacency Matrix.
    tmp_CorrMatrix = CorrWholeState_SignificantPos;
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AdjacencyMatrix_MeanOfStates = tmp_CorrMatrix;
    tmp_CorrMatrix = CorrWholeState_SignificantNeg; % Get the negative correlations too.
    tmp_CorrMatrix(isnan(tmp_CorrMatrix)) = 0;
    AdjacencyMatrix_MeanOfStates = AdjacencyMatrix_MeanOfStates + tmp_CorrMatrix;
    
    % Build Graph
    Corr_Graph_MeanOfStates = graph(AdjacencyMatrix_MeanOfStates, 'upper');
    
    % Remove Autoconnections and Lonely nodes.
    [Corr_Graph_MeanOfStates, Corr_Graph_Abs] = Graph_remove_singlets (Corr_Graph_MeanOfStates);
    
    % Centrality measures.
    Corr_Graph_Centrality = compute_centrality (Corr_Graph_Abs);
        
    % Connectivity Index
    [Corr_Graph_Connectivity_Index, Corr_Graph_Connectivity_Index_StE, ~] = compute_Connectivity_Index (Corr_Matrix_Mean, CorrStatesMean_ThrP, CorrStatesMean_ThrN);
    
    MeanOfStates_tmp(i_state_type).N_States = numel(CurrentStates_perSession);
    MeanOfStates_tmp(i_state_type).MeanStatesLength = nanmean(tmp_length);
    MeanOfStates_tmp(i_state_type).Corr_Thr_Criterion = CurrentStates_perSession(1).Corr_Thr_Criterion;
    MeanOfStates_tmp(i_state_type).CorrStatesMean_ThrP = CorrStatesMean_ThrP;
    MeanOfStates_tmp(i_state_type).CorrStatesMean_ThrN = CorrStatesMean_ThrN;
    MeanOfStates_tmp(i_state_type).CorrWholeState_SignificantPos = CorrWholeState_SignificantPos;
    MeanOfStates_tmp(i_state_type).CorrWholeState_SignificantNeg = CorrWholeState_SignificantNeg;
    MeanOfStates_tmp(i_state_type).Corr_Matrix_Mean = Corr_Matrix_Mean;
    MeanOfStates_tmp(i_state_type).AdjacencyMatrix_MeanOfStates = AdjacencyMatrix_MeanOfStates;
    MeanOfStates_tmp(i_state_type).Corr_Graph_MeanOfStates = Corr_Graph_Abs;
    MeanOfStates_tmp(i_state_type).Corr_Graph_Centrality = Corr_Graph_Centrality;
    MeanOfStates_tmp(i_state_type).Corr_Graph_Connectivity_Index = Corr_Graph_Connectivity_Index;
    
    clear SignificantPairs_Pos;
    clear SignificantPairs_Neg;
end