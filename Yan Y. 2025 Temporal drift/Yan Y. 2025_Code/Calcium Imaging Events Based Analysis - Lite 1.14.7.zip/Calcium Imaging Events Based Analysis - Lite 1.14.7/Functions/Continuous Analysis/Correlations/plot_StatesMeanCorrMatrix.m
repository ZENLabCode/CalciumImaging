function Stats = plot_StatesMeanCorrMatrix (MeanOfStates, Mouse_Names, Opts)
% This function plots the mean correlation matrix of each "average state"
% per mouse, and computes statistical differences of the correlation levels
% between different states.

Title_FontSize = 14;
SupTitle_FontSize = 18;

% Flags
FLAG_Save = Opts.CorrAnalysis.Opts_MeanStatesPlots.FLAG_Save;
FLAG_Plots = Opts.General.FLAG_Plots;
% Check existence of folder, erase if necessary
PlotPath = sprintf('%s\\Mean States Correlations', Opts.Dir_Figures);
if exist(PlotPath, 'dir') == 0
    mkdir(PlotPath);
    addpath(genpath(PlotPath));
end
n_mice = Opts.n_mice;
n_sessions = numel(MeanOfStates);
n_states = 4;
TagAwake = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;
FLAG_Session_or_Mouse = Opts.FLAG_Session_or_Mouse;

% Decide "Significant Correlation" Threshold
CorrThr_perSession = NaN(1, n_sessions);
for i_session = 1:n_sessions
    Current_MeanOfStates = MeanOfStates{i_session};
    CorrThr_perSession(i_session) = nanmean([Current_MeanOfStates.CorrStatesMean_ThrP]); % Also referred as ThrHard in the code.
end
CorrThr_SessionMin = nanmin(CorrThr_perSession);

subplot_n_cols = 3;
subplot_n_rows = 2;


%% Figure 1 ---- Mean Correlation Matrices
% Initialize variables.
N_Corrs = NaN(1, n_sessions);
MeanCorr = NaN(n_sessions, n_states);
MeanAbsCorr = NaN(n_sessions, n_states);
MeanAbsCorrThr = NaN(n_sessions, n_states);
MeanNPosCorrThrHard = NaN(n_sessions, n_states);
MeanNNegCorrThrHard = NaN(n_sessions, n_states);
N_StableNeurons_1_2 = NaN(1, n_sessions);
N_StableNeurons_1_4 = NaN(1, n_sessions);
N_StableNeurons_2_4 = NaN(1, n_sessions);

% Actual plots.
i_session_tot = 1;
for i_mouse = 1:n_mice
    % Get Current Mouse
    MouseName = Mouse_Names{i_mouse};
    Current_N_Sessions = Opts.Mouse_Sessions(i_mouse);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmpi(FLAG_Session_or_Mouse, 'mouse')
        Current_N_Sessions = 1;
    end
    % Scroll sessions for a single mouse
    for i_session = 1:Current_N_Sessions
        % Suptitle & Output Figure Strings
        if strcmpi(FLAG_Session_or_Mouse, 'session')
            Suptitle_Str = sprintf('Mean State Correlation Matrix - Mouse %s - Session %d', MouseName, i_session);
            FileName = sprintf('Correlation Changes - Mean Correlation Matrices - Mouse %s - Session %d', MouseName, i_session);
        elseif strcmpi(FLAG_Session_or_Mouse, 'mouse')
            Suptitle_Str = sprintf('Mean State Correlation Matrix - Mouse %s (All sessions)', MouseName);
            FileName = sprintf('Correlation Changes - Mean Correlation Matrices - Mouse %s (All sessions)', MouseName);
        end
        FilePath = sprintf('%s\\%s', PlotPath, FileName);
        
        % Get Quantities for current recordings session
        try
            Current_MeanOfStates = MeanOfStates{i_session_tot};
        catch
            keyboard
        end
        % Set whole matrix of NaNs instead of a single nan scalar, to
        % avoid later errors
        [Current_NCells, ~] = size(Current_MeanOfStates(TagAwake).Corr_Matrix_Mean);
        if Current_NCells <= 1
            [Current_NCells, ~] = size(Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean);
        end
        if Current_NCells <= 1
            [Current_NCells, ~] = size(Current_MeanOfStates(TagREM).Corr_Matrix_Mean);
        end
        if Current_NCells <= 1
            if strcmpi(FLAG_Session_or_Mouse, 'session')
                fprintf('No stable correlation for this recordings session (Mouse %s, Session %d)\n', MouseName, i_session);
            elseif strcmpi(FLAG_Session_or_Mouse, 'mouse')
                fprintf('No stable correlation for this recordings session (Mouse %s, All sessions)\n', MouseName);
            end
        end
        if isscalar(Current_MeanOfStates(TagAwake).Corr_Matrix_Mean) == 1
            Current_MeanOfStates(TagAwake).Corr_Matrix_Mean = NaN(Current_NCells);
        end
        if isscalar(Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean) == 1
            Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean = NaN(Current_NCells);
        end
        if isscalar(Current_MeanOfStates(TagREM).Corr_Matrix_Mean) == 1
            Current_MeanOfStates(TagREM).Corr_Matrix_Mean = NaN(Current_NCells);
        end
        [Current_NCells, ~] = size(Current_MeanOfStates(1).Corr_Matrix_Mean);
        N_Corrs(1, i_session_tot) = ((Current_NCells^2)-Current_NCells)/2; % Number of correlations (not taking into account the matrix diagonal, and taking into account its symmetry)
        
        % Get Maximum/Min/Mean correlation (to uniform the colorscale & Report).
        max_tmp = NaN(1, 4);
        min_tmp = NaN(1, 4);
        Mean_tmp = NaN(1, 4);
        MeanAbs_tmp = NaN(1, 4);
        MeanAbsThr_tmp = NaN(1, 4);
        for i_state = 1:4
            if  i_state == 3 % There's no state tag 3...
                continue
            end
            Current_MeanCorrMatrix = Current_MeanOfStates(i_state).Corr_Matrix_Mean;
            Current_MeanCorrMatrix_ThrAbs = Current_MeanCorrMatrix;
            Current_MeanCorrMatrix_ThrAbs(Current_MeanCorrMatrix_ThrAbs < CorrThr_perSession(i_session_tot)) = NaN;
            Current_MeanCorrMatrix_ThrHardPos = Current_MeanCorrMatrix;
            Current_MeanCorrMatrix_ThrHardPos(Current_MeanCorrMatrix_ThrHardPos < CorrThr_perSession(i_session_tot)) = NaN;
            Current_MeanCorrMatrix_ThrHardNeg = Current_MeanCorrMatrix;
            Current_MeanCorrMatrix_ThrHardNeg(Current_MeanCorrMatrix_ThrHardNeg > -CorrThr_perSession(i_session_tot)) = NaN;
            max_tmp(i_state) = nanmax(nanmax(Current_MeanCorrMatrix));
            min_tmp(i_state) = nanmin(nanmin(Current_MeanCorrMatrix));
            Mean_tmp(i_state) = nanmean(nanmean(Current_MeanCorrMatrix));
            MeanAbs_tmp(i_state) = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
            MeanAbsThr_tmp(i_state) = nanmean(nanmean(Current_MeanCorrMatrix_ThrAbs));
            MeanCorr(i_session_tot, i_state) = Mean_tmp(i_state);
            MeanAbsCorr(i_session_tot, i_state) = MeanAbs_tmp(i_state);
            MeanAbsCorrThr(i_session_tot, i_state) = MeanAbsThr_tmp(i_state);
            MeanNPosCorrThrHard(i_session_tot, i_state) = numel(find(triu(Current_MeanCorrMatrix_ThrHardPos) > 0));
            MeanNNegCorrThrHard(i_session_tot, i_state) = numel(find(triu(Current_MeanCorrMatrix_ThrHardNeg) < 0));
        end
        MaxCorr = nanmax(max_tmp);
        
        if FLAG_Plots == 1
            %% Figure 1 ---- Plot Mean State Corr Matrices
            figure(); set(gcf,'position', get(0,'screensize'));
            for i_state = 1:4
                if  i_state == 3 % There's no state tag 3...
                    continue
                end
                Current_MeanCorrMatrix = Current_MeanOfStates(i_state).Corr_Matrix_Mean;
                if numel(Current_MeanCorrMatrix) == 1 % If that state is not present, skip
                    if isnan(Current_MeanCorrMatrix)
                        continue
                    end
                end
                switch i_state
                    case TagAwake
                        subplot(subplot_n_rows, subplot_n_cols, i_state);
                        pcolor(Current_MeanCorrMatrix);
                        axis square
                        title('Awake', 'FontSize', Title_FontSize);
                    case TagNoNREM
                        subplot(subplot_n_rows, subplot_n_cols, i_state);
                        pcolor(Current_MeanCorrMatrix);
                        axis square
                        title('NoN-REM', 'FontSize', Title_FontSize);
                    case TagREM
                        subplot(subplot_n_rows, subplot_n_cols, i_state-1);
                        pcolor(Current_MeanCorrMatrix);
                        axis square
                        title('REM', 'FontSize', Title_FontSize);
                end
                caxis([0 MaxCorr]);
                colorbar
                ylabel('Neuron ID');
                xlabel(sprintf('Mean Correlation = %.3g\nMean Absolute Correlation = %.3g\nMean Absolute Significant Correlations = %.3g (Thr = %.2g)', Mean_tmp(i_state), MeanAbs_tmp(i_state), MeanAbsThr_tmp(i_state), CorrThr_perSession(i_session_tot)));
            end
            h_suptitle = suptitle(Suptitle_Str);
            h_suptitle.FontSize = SupTitle_FontSize;
            h_suptitle.FontWeight = 'bold';
            
            
            %% Figure 1 ---- Plot Corr Matrices Differences
            % Get difference between Mean Correlation Matrixes per state.
            Current_MeanCorrMatrixDiff1_2 = Current_MeanOfStates(TagAwake).Corr_Matrix_Mean - Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean;
            Current_MeanCorrMatrixDiff1_4 = Current_MeanOfStates(TagAwake).Corr_Matrix_Mean - Current_MeanOfStates(TagREM).Corr_Matrix_Mean;
            Current_MeanCorrMatrixDiff2_4 = Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean - Current_MeanOfStates(TagREM).Corr_Matrix_Mean;
            
            tmp = Current_MeanOfStates(TagAwake).Corr_Matrix_Mean;
            tmp1 = zeros(size(tmp));
            tmp1(tmp > CorrThr_perSession(i_session_tot)) = 1;
            tmp1(tmp < -CorrThr_perSession(i_session_tot)) = 1;
            tmp(~tmp1) = 0;
            StableState_1{i_session_tot} = tmp;
            
            tmp = Current_MeanOfStates(TagNoNREM).Corr_Matrix_Mean;
            tmp1 = zeros(size(tmp));
            tmp1(tmp > CorrThr_perSession(i_session_tot)) = 1;
            tmp1(tmp < -CorrThr_perSession(i_session_tot)) = 1;
            tmp(~tmp1) = 0;
            StableState_2{i_session_tot} = tmp;
            
            tmp = Current_MeanOfStates(TagREM).Corr_Matrix_Mean;
            tmp1 = zeros(size(tmp));
            tmp1(tmp > CorrThr_perSession(i_session_tot)) = 1;
            tmp1(tmp < -CorrThr_perSession(i_session_tot)) = 1;
            tmp(~tmp1) = 0;
            StableState_4{i_session_tot} = tmp;
            
            tmp1 = triu(StableState_1{i_session_tot});
            tmp2 = triu(StableState_2{i_session_tot});
            tmp3 = triu(StableState_4{i_session_tot});
            % Check whether the states are actually present, if that is the case, compute the number of stable hubs.
            if numel(tmp1) > 1 && numel(tmp2) > 1
                N_StableNeurons_1_2(i_session_tot) = numel(find(tmp2(tmp1 > 0)));
            else
                N_StableNeurons_1_2(i_session_tot) = NaN;
            end
            if numel(tmp2) > 1 && numel(tmp3) > 1
                N_StableNeurons_2_4(i_session_tot) = numel(find(tmp3(tmp2 > 0)));
            else
                N_StableNeurons_2_4(i_session_tot) = NaN;
            end
            if numel(tmp1) > 1 && numel(tmp3) > 1
                N_StableNeurons_1_4(i_session_tot) = numel(find(tmp3(tmp1 > 0)));
            else
                N_StableNeurons_1_4(i_session_tot) = NaN;
            end
            
            [StatesChange_1_2(i_session_tot)] = StatesMeanCorrMatrix_CorrStableAtTransition (Current_MeanCorrMatrixDiff1_2, CorrThr_perSession(i_session_tot), N_Corrs(i_session_tot));
            [StatesChange_1_4(i_session_tot)] = StatesMeanCorrMatrix_CorrStableAtTransition (Current_MeanCorrMatrixDiff1_4, CorrThr_perSession(i_session_tot), N_Corrs(i_session_tot));
            [StatesChange_2_4(i_session_tot)] = StatesMeanCorrMatrix_CorrStableAtTransition (Current_MeanCorrMatrixDiff2_4, CorrThr_perSession(i_session_tot), N_Corrs(i_session_tot));
            
            MaxDiff = nanmax([StatesChange_1_2(i_session_tot).MeanCorrMatrixDiff_Max, StatesChange_1_4(i_session_tot).MeanCorrMatrixDiff_Max, StatesChange_2_4(i_session_tot).MeanCorrMatrixDiff_Max]);
            MinDiff = nanmin([StatesChange_1_2(i_session_tot).MeanCorrMatrixDiff_Min, StatesChange_1_4(i_session_tot).MeanCorrMatrixDiff_Min, StatesChange_2_4(i_session_tot).MeanCorrMatrixDiff_Min]);
            
            for i_state = 1:4
                if  i_state == 3 % There's no state tag 3...
                    continue
                end
                switch i_state
                    case TagAwake
                        subplot(subplot_n_rows, subplot_n_cols, 3+i_state);
                        pcolor(StatesChange_1_2(i_session_tot).Current_MeanCorrMatrixDiff_Relevant);
                        axis square
                        title('\Delta(Awake-NonREM)', 'FontSize', Title_FontSize);
                        xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', StatesChange_1_2(i_session_tot).MeanCorrMatrixDiff_Mean, StatesChange_1_2(i_session_tot).MeanCorrMatrixDiff_Mean_Abs, StatesChange_1_2(i_session_tot).MeanCorrMatrixDiff_Mean_Abs_Relevant, CorrThr_perSession(i_session_tot)));
                    case TagNoNREM
                        subplot(subplot_n_rows, subplot_n_cols, 3+i_state);
                        try
                        pcolor(StatesChange_1_4(i_session_tot).Current_MeanCorrMatrixDiff_Relevant);
                        catch
                            keyboard
                        end
                        axis square
                        title('\Delta(Awake-REM)', 'FontSize', Title_FontSize);
                        xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', StatesChange_1_4(i_session_tot).MeanCorrMatrixDiff_Mean, StatesChange_1_4(i_session_tot).MeanCorrMatrixDiff_Mean_Abs, StatesChange_1_4(i_session_tot).MeanCorrMatrixDiff_Mean_Abs_Relevant, CorrThr_perSession(i_session_tot)));
                    case TagREM
                        subplot(subplot_n_rows, subplot_n_cols, 3+i_state-1);
                        pcolor(StatesChange_2_4(i_session_tot).Current_MeanCorrMatrixDiff_Relevant);
                        axis square
                        title('\Delta(NonREM-REM)', 'FontSize', Title_FontSize);
                        xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', StatesChange_2_4(i_session_tot).MeanCorrMatrixDiff_Mean, StatesChange_2_4(i_session_tot).MeanCorrMatrixDiff_Mean_Abs, StatesChange_2_4(i_session_tot).MeanCorrMatrixDiff_Mean_Abs_Relevant, CorrThr_perSession(i_session_tot)));
                end
                if isnan(MinDiff) || isnan(MinDiff) % Set color limits
                    if exist('clmap', 'var') ~= 0
                        caxis(clmap);
                    end
                else
                    clmap = [MinDiff MaxDiff];
                    caxis(clmap);
                end
                colorbar
                ylabel('Neuron ID');
            end
            h_suptitle = suptitle(Suptitle_Str);
            h_suptitle.FontSize = SupTitle_FontSize;
            h_suptitle.FontWeight = 'bold';
            if FLAG_Save == 1
                print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
                saveas(gcf, strcat(FilePath, '.jpg'))
                saveas(gcf, strcat(FilePath, '.fig'))
                close gcf
            end
        end
        i_session_tot = i_session_tot + 1;
    end
   
end


if FLAG_Plots == 1
    %% Figure 2 ---- Mean between states across various mice.
    figure; set(gcf,'position', get(0,'screensize'));
    n_rows = 2;
    n_cols = 3;
    i_subplot = 1;
    BoxPlot_Groups = [1*ones(1, n_sessions), 2*ones(1, n_sessions), 3*ones(1, n_sessions)];
    % Initialize Boxplots
    MeanNPosCorrThr_tmp = MeanNPosCorrThrHard;
    MeanNNegCorrThr_tmp = MeanNNegCorrThrHard;
    MeanNPosCorrThr_tmp(:, 3) = [];
    MeanNNegCorrThr_tmp(:, 3) = [];
    if strcmpi(FLAG_Session_or_Mouse, 'session') % If state doesnt exist, set value to NaN
        MeanNPosCorrThr_tmp([Opts.SessionHasState.Stable_Awake] == 0, 1) = NaN;
        MeanNPosCorrThr_tmp([Opts.SessionHasState.Stable_NoNREM] == 0, 2) = NaN;
        MeanNPosCorrThr_tmp([Opts.SessionHasState.Stable_REM] == 0, 3) = NaN;
        MeanNNegCorrThr_tmp([Opts.SessionHasState.Stable_Awake] == 0, 1) = NaN;
        MeanNNegCorrThr_tmp([Opts.SessionHasState.Stable_NoNREM] == 0, 2) = NaN;
        MeanNNegCorrThr_tmp([Opts.SessionHasState.Stable_REM] == 0, 3) = NaN;
    elseif strcmpi(FLAG_Session_or_Mouse, 'mouse') % If state doesnt exist, set value to NaN
        for i_mouse = 1:n_mice
            MeanNPosCorrThr_tmp(i_mouse, [MeanOfStates{1, i_mouse}.N_States] == 0) = NaN;
            MeanNPosCorrThr_tmp(i_mouse, isnan([MeanOfStates{1, i_mouse}.N_States])) = NaN;
        end
    end
    MeanNPosCorrThr_BoxPlot = reshape (MeanNPosCorrThr_tmp, 1, n_sessions*(n_states-1));
    MeanNNegCorrThr_BoxPlot = reshape (MeanNNegCorrThr_tmp, 1, n_sessions*(n_states-1));
    
    % Boxplot MeanCorr
    MeanCorr_tmp = MeanCorr;
    % MeanCorr_tmp(MeanCorr_tmp == 0) = [];
    MeanCorr_tmp(:, 3) = [];
    MeanCorr_BoxPlot = reshape (MeanCorr_tmp, 1, n_sessions*(n_states-1));
    subplot(n_rows, n_cols, i_subplot);
    h_boxplot_1 = boxplot(MeanCorr_BoxPlot, BoxPlot_Groups);
    set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
    i_subplot = i_subplot + 1;
    ylabel('Mean Correlation');
    title('Mean Correlation')
    axis square;
    
    % Boxplot Mean AbsCorr
    MeanCorr_tmp = MeanAbsCorr;
    % MeanCorr_tmp(MeanCorr_tmp == 0) = [];
    MeanCorr_tmp(:, 3) = [];
    MeanCorrAbs_BoxPlot = reshape (MeanCorr_tmp, 1, n_sessions*(n_states-1));
    subplot(n_rows, n_cols, i_subplot);
    h_boxplot_2 = boxplot(MeanCorrAbs_BoxPlot, BoxPlot_Groups);
    set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
    i_subplot = i_subplot + 1;
    ylabel('Mean Correlation');
    title('Mean Abs Correlation')
    axis square;
    
    % Boxplot Mean AbsCorrThr
    MeanCorr_tmp = MeanAbsCorrThr;
    MeanCorr_tmp(:, 3) = [];
    tmp = MeanCorr_tmp(:, 1:2); tmp(isnan(tmp)) = 0;
    MeanCorr_tmp(:, 1:2) = tmp;
    MeanAbsCorrThr_BoxPlot = reshape (MeanCorr_tmp, 1, n_sessions*(n_states-1));
    subplot(n_rows, n_cols, i_subplot);
    h_boxplot_3 = boxplot(MeanAbsCorrThr_BoxPlot, BoxPlot_Groups);
    set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
    ylabel('Mean Correlation');
    title(sprintf('Mean Abs Significant Correlation (Corr > ~%.2g)', CorrThr_SessionMin))
    axis square;
    i_subplot = i_subplot + 1;
    
    % Boxplot Mean N of Significant Positive Correlations
    subplot(n_rows, n_cols, i_subplot);
    h_boxplot_3 = boxplot(MeanNPosCorrThr_BoxPlot, BoxPlot_Groups);
    set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
    ylabel('# Significant Positive Correlations');
    title(sprintf('Mean # of Significant Correlation (Corr > ~%.2g)', CorrThr_SessionMin))
    axis square;
    i_subplot = i_subplot + 1;
    
    % Boxplot Mean N of Significant Correlations
    subplot(n_rows, n_cols, i_subplot);
    h_boxplot_3 = boxplot(MeanNNegCorrThr_BoxPlot, BoxPlot_Groups);
    set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
    ylabel('# Significant Negative Correlations');
    title(sprintf('Mean # of Significant Correlation (Corr < ~-%.2g)', CorrThr_SessionMin))
    axis square;
    i_subplot = i_subplot + 1;
    
    FileName = sprintf('Correlation Changes - Bar Plots');
    FilePath = sprintf('%s\\%s', PlotPath, FileName);
    if FLAG_Save == 1
        print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
        saveas(gcf, strcat(FilePath, '.jpg'))
        saveas(gcf, strcat(FilePath, '.fig'))
        close gcf
    end
    
    % Pie-chart "Stable Correlations"
    StableNeurons_Fraction_1_2 = N_StableNeurons_1_2./MeanNPosCorrThrHard(:, 1)';
    StableNeurons_Fraction_1_4 = N_StableNeurons_1_4./MeanNPosCorrThrHard(:, 1)';
    StableNeurons_Fraction_2_4 = N_StableNeurons_2_4./MeanNPosCorrThrHard(:, 2)';
    
    
    %% Figure 3 ---- Bar Plots of single correlation changes.
    figure(); set(gcf,'position', get(0,'screensize'));
    n_rows = 2;
    n_columns = 3;
    Groups_Bars = [1, 2, 4, 5, 7, 8];
    %     Groups_Bars = 1:n_mice;
    y = [[StatesChange_1_2.N_PosChangingCorrNorm]; -[StatesChange_1_2.N_NegChangingCorrNorm]; [StatesChange_2_4.N_PosChangingCorrNorm]; -[StatesChange_2_4.N_NegChangingCorrNorm]; [StatesChange_1_4.N_PosChangingCorrNorm]; -[StatesChange_1_4.N_NegChangingCorrNorm]].*100;
    if sum(y) ~= 0
        subplot(n_rows, n_columns, 1);
        bar(Groups_Bars, y, 'stacked');
        try
            ylim([-nanmax(nansum(abs(y), 2)), nanmax(nansum(abs(y), 2))]);
        catch
            keyboard
        end
        set(gca,'XTick', [1.5, 4.5, 7.5]);
        set(gca,'XTickLabel',{'Awake->NoN-REM', 'NoN-REM->REM', 'Awake->REM'});
        ylabel(sprintf('%% Significantly different Correlations\nbetween states'));
        % Fix legend
        h_legend = legend;
        tmp = h_legend.String;
        h_legend.Interpreter = 'none';
        i_session_tot = 1;
        for i_mouse = 1:n_mice
            Current_N_Sessions = Opts.Mouse_Sessions(i_mouse);
            if strcmpi(FLAG_Session_or_Mouse, 'session')
                for i_session = 1:Current_N_Sessions
                    tmp{i_session_tot} = sprintf('Mouse %s - Session %d', Mouse_Names{i_mouse}, i_session);
                    i_session_tot = i_session_tot + 1;
                end
            elseif strcmpi(FLAG_Session_or_Mouse, 'mouse')
                tmp{i_session_tot} = sprintf('Mouse %s - All sessions', Mouse_Names{i_mouse});
                i_session_tot = i_session_tot + 1;
            end
        end
        h_legend.String = tmp;
        h_legend.FontSize = 7;
        h_legend.Location = 'best';
        grid on; box on; axis square;
        % Change colors
        h_axis = get(gca);
        tmp = h_axis.Children;
        Color_Increment = [0, 0, 1/n_sessions];
        Color = [(1/n_sessions)*2, (1/n_sessions)*2, 0];
        for i_plot = 1:numel(tmp)
            tmp(i_plot).FaceColor = Color + Color_Increment*i_plot;
        end
    end
    
    % Pie-charts (ratio of significantly changing vs stable)
    if strcmpi(FLAG_Session_or_Mouse, 'session')
        Plot_XlabelStr = 'Session #';
        Lims_X = [0, n_sessions + 1];
    elseif strcmpi(FLAG_Session_or_Mouse, 'mouse')
        Plot_XlabelStr = 'Mouse #';
        Lims_X = [0, n_mice + 1];
    end
    subplot(n_rows, n_columns, 2);
    bar(StableNeurons_Fraction_1_2);
    title('Significant correlations Stable between Awake and NoN-REM')
    ylabel('Fraction of Stable Correlations')
    xlabel(Plot_XlabelStr)
    ylim([0, 1]); xlim(Lims_X);
    grid on; box on; axis square;
    subplot(n_rows, n_columns, 3);
    bar(StableNeurons_Fraction_1_4);
    title('Significant correlations Stable between Awake and REM')
    ylabel('Fraction of Stable Correlations')
    xlabel(Plot_XlabelStr)
    ylim([0, 1]); xlim(Lims_X);
    grid on; box on; axis square;
    subplot(n_rows, n_columns, 4);
    bar(StableNeurons_Fraction_2_4);
    title('Significant correlations Stable between NoN-REM and REM')
    ylabel('Fraction of Stable Correlations')
    xlabel(Plot_XlabelStr)
    ylim([0, 1]); xlim(Lims_X);
    grid on; box on; axis square;
    
    % Boxplots (distribtion of mice, previous results)
    subplot(n_rows, n_columns, 5); grid on; box on; axis square;
    BoxPlot_Groups = [1*ones(1, n_sessions), 2*ones(1, n_sessions), 3*ones(1, n_sessions)];
    h_boxplot = boxplot([StableNeurons_Fraction_1_2, StableNeurons_Fraction_1_4, StableNeurons_Fraction_2_4], BoxPlot_Groups);
    grid on; box on;
    title('Significant Stabe Correlations.')
    ylabel(sprintf('Fraction of Stable Correlations \n Distribution per Mouse'))
    xlabel('Transition')
    xticklabels({sprintf('Awake->NoNREM'), sprintf('Awake->REM'), sprintf('NoNREM->REM')});
    ylim([0, 1]);
    FileName = sprintf('Correlation Changes - Stable vs Unstable Neurons');
    FilePath = sprintf('%s\\%s', PlotPath, FileName);
    if FLAG_Save == 1
        print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
        saveas(gcf, strcat(FilePath, '.jpg'))
        saveas(gcf, strcat(FilePath, '.fig'))
        close gcf
    end
end


%% Statistics
% Mean Correlation.
Test_Name = 'Welch t-test';
Stats.Awake_NoNREM.MeanCorr.Test = Test_Name;
Stats.NoNREM_REM.MeanCorr.Test = Test_Name;
Stats.Awake_REM.MeanCorr.Test = Test_Name;
[Stats.Awake_NoNREM.MeanCorr.h, Stats.Awake_NoNREM.MeanCorr.P_Value, Stats.Awake_NoNREM.MeanCorr.Confidence_Interval, Stats.Awake_NoNREM.MeanCorr.Stats] = ttest2(MeanCorr(:, 1), MeanCorr(:, 2), 'Vartype', 'unequal');
[Stats.NoNREM_REM.MeanCorr.h, Stats.NoNREM_REM.MeanCorr.P_Value, Stats.NoNREM_REM.MeanCorr.Confidence_Interval, Stats.NoNREM_REM.MeanCorr.Stats] = ttest2(MeanCorr(:, 2), MeanCorr(:, 4), 'Vartype', 'unequal');
[Stats.Awake_REM.MeanCorr.h, Stats.Awake_REM.MeanCorr.P_Value, Stats.Awake_REM.MeanCorr.Confidence_Interval, Stats.Awake_REM.MeanCorr.Stats] = ttest2(MeanCorr(:, 1), MeanCorr(:, 4), 'Vartype', 'unequal');
% Mean Absolute Value Correlation.
Stats.Awake_NoNREM.MeanAbsCorr.Test = Test_Name;
Stats.NoNREM_REM.MeanAbsCorr.Test = Test_Name;
Stats.Awake_REM.MeanAbsCorr.Test = Test_Name;
[Stats.Awake_NoNREM.MeanAbsCorr.h, Stats.Awake_NoNREM.MeanAbsCorr.P_Value, Stats.Awake_NoNREM.MeanAbsCorr.Confidence_Interval, Stats.Awake_NoNREM.MeanAbsCorr.Stats] = ttest2(MeanAbsCorr(:, 1), MeanAbsCorr(:, 2), 'Vartype', 'unequal');
[Stats.NoNREM_REM.MeanAbsCorr.h, Stats.NoNREM_REM.MeanAbsCorr.P_Value, Stats.NoNREM_REM.MeanAbsCorr.Confidence_Interval, Stats.NoNREM_REM.MeanAbsCorr.Stats] = ttest2(MeanAbsCorr(:, 2), MeanAbsCorr(:, 4), 'Vartype', 'unequal');
[Stats.Awake_REM.MeanAbsCorr.h, Stats.Awake_REM.MeanAbsCorr.P_Value, Stats.Awake_REM.MeanAbsCorr.Confidence_Interval, Stats.Awake_REM.MeanAbsCorr.Stats] = ttest2(MeanAbsCorr(:, 1), MeanAbsCorr(:, 4), 'Vartype', 'unequal');
% Mean Absolute Value Significant Correlations.
Stats.Awake_NoNREM.MeanAbsCorrThr.Test = Test_Name;
Stats.NoNREM_REM.MeanAbsCorrThr.Test = Test_Name;
Stats.Awake_REM.MeanAbsCorrThr.Test = Test_Name;
[Stats.Awake_NoNREM.MeanAbsCorrThr.h, Stats.Awake_NoNREM.MeanAbsCorrThr.P_Value, Stats.Awake_NoNREM.MeanAbsCorrThr.Confidence_Interval, Stats.Awake_NoNREM.MeanAbsCorrThr.Stats] = ttest2(MeanAbsCorrThr(:, 1), MeanAbsCorrThr(:, 2), 'Vartype', 'unequal');
[Stats.NoNREM_REM.MeanAbsCorrThr.h, Stats.NoNREM_REM.MeanAbsCorrThr.P_Value, Stats.NoNREM_REM.MeanAbsCorrThr.Confidence_Interval, Stats.NoNREM_REM.MeanAbsCorrThr.Stats] = ttest2(MeanAbsCorrThr(:, 2), MeanAbsCorrThr(:, 4), 'Vartype', 'unequal');
[Stats.Awake_REM.MeanAbsCorrThr.h, Stats.Awake_REM.MeanAbsCorrThr.P_Value, Stats.Awake_REM.MeanAbsCorrThr.Confidence_Interval, Stats.Awake_REM.MeanAbsCorrThr.Stats] = ttest2(MeanAbsCorrThr(:, 1), MeanAbsCorrThr(:, 4), 'Vartype', 'unequal');
% Number of (Positive, Significant) Correlations.
Stats.Awake_NoNREM.MeanNPosCorrThr.Test = Test_Name;
Stats.NoNREM_REM.MeanNPosCorrThr.Test = Test_Name;
Stats.Awake_REM.MeanNPosCorrThr.Test = Test_Name;
[Stats.Awake_NoNREM.MeanNPosCorrThr.h, Stats.Awake_NoNREM.MeanNPosCorrThr.P_Value, Stats.Awake_NoNREM.MeanNPosCorrThr.Confidence_Interval, Stats.Awake_NoNREM.MeanNPosCorrThr.Stats] = ttest2(MeanNPosCorrThrHard(:, 1), MeanNPosCorrThrHard(:, 2), 'Vartype', 'unequal');
[Stats.NoNREM_REM.MeanNPosCorrThr.h, Stats.NoNREM_REM.MeanNPosCorrThr.P_Value, Stats.NoNREM_REM.MeanNPosCorrThr.Confidence_Interval, Stats.NoNREM_REM.MeanNPosCorrThr.Stats] = ttest2(MeanNPosCorrThrHard(:, 2), MeanNPosCorrThrHard(:, 4), 'Vartype', 'unequal');
[Stats.Awake_REM.MeanNPosCorrThr.h, Stats.Awake_REM.MeanNPosCorrThr.P_Value, Stats.Awake_REM.MeanNPosCorrThr.Confidence_Interval, Stats.Awake_REM.MeanNPosCorrThr.Stats] = ttest2(MeanNPosCorrThrHard(:, 1), MeanNPosCorrThrHard(:, 4), 'Vartype', 'unequal');
% Number of (Negative, Significant) Correlations.
Stats.Awake_NoNREM.MeanNNegCorrThr.Test = Test_Name;
Stats.NoNREM_REM.MeanNNegCorrThr.Test = Test_Name;
Stats.Awake_REM.MeanNNegCorrThr.Test = Test_Name;
[Stats.Awake_NoNREM.MeanNNegCorrThr.h, Stats.Awake_NoNREM.MeanNNegCorrThr.P_Value, Stats.Awake_NoNREM.MeanNNegCorrThr.Confidence_Interval, Stats.Awake_NoNREM.MeanNNegCorrThr.Stats] = ttest2(MeanNNegCorrThrHard(:, 1), MeanNNegCorrThrHard(:, 2), 'Vartype', 'unequal');
[Stats.NoNREM_REM.MeanNNegCorrThr.h, Stats.NoNREM_REM.MeanNNegCorrThr.P_Value, Stats.NoNREM_REM.MeanNNegCorrThr.Confidence_Interval, Stats.NoNREM_REM.MeanNNegCorrThr.Stats] = ttest2(MeanNNegCorrThrHard(:, 2), MeanNNegCorrThrHard(:, 4), 'Vartype', 'unequal');
[Stats.Awake_REM.MeanNNegCorrThr.h, Stats.Awake_REM.MeanNNegCorrThr.P_Value, Stats.Awake_REM.MeanNNegCorrThr.Confidence_Interval, Stats.Awake_REM.MeanNNegCorrThr.Stats] = ttest2(MeanNNegCorrThrHard(:, 1), MeanNNegCorrThrHard(:, 4), 'Vartype', 'unequal');