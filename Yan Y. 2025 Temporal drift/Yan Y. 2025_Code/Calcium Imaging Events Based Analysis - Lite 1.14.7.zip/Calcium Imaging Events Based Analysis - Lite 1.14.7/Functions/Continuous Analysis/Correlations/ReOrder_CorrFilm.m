function [CorrFilm_ReOrdered_AllSessions, Traces_ReOrdered_AllSessions] = ReOrder_CorrFilm (Mouse_Analysis, CalciumTraces_Noisy_AllSessions, Opts)
% This function reorders the calcium traces according to the measured
% connectivity, and consequently recomputes the correlation matrices.



%% Options
if nargin < 3
    warning('Options not found for "ReOrder_CorrFilm": using default values.')
    Opts = set_options;
end
FrameRate = Opts.General.FrameRate;
MinStableStateDuration = Opts.General.MinStableStateDuration;
Corr_Window_Length = Opts.CorrAnalysis.Window_Length;% 3 frames = 1 seconds
BaselineStateTag = Opts.CorrAnalysis.BaselineStateTag;% Sort according to State with Tag = N (N = 1 -> Awake)
sliding_window = ones(1, Corr_Window_Length);


%% Re-Ordering
n_sessions = Opts.n_sessions;
CorrFilm_ReOrdered_AllSessions = cell(1, n_sessions);
Traces_ReOrdered_AllSessions = cell(1, n_sessions);
fprintf('Reordering sessions...\n\n');
% Scroll Sessions
for i_session = 1:n_sessions
    fprintf('Reordering Session %d/%d.\n', i_session, n_sessions);
    Current_States_Analysis = Mouse_Analysis(i_session).States_Analysis;
    Current_CalciumTraces = CalciumTraces_Noisy_AllSessions{i_session};
    [n_frames, n_traces] = size(Current_CalciumTraces);
    tmp1 = (1:n_traces)';
    n_states = numel(Current_States_Analysis);
    % Take the correct cells order.
    for i_state = 1:n_states % Scroll every state
        Current_StateTag = Current_States_Analysis(i_state).StateTag;
        if ~isnan(Current_StateTag)
            Current_StateDuration = Current_States_Analysis(i_state).StartEnd(2) - Current_States_Analysis(i_state).StartEnd(1) + 1;
            Current_CorrWholeState = Current_States_Analysis(i_state).CorrWholeState.CorrWholeState;
            if Current_StateDuration > MinStableStateDuration % Get only stable states
                if Current_StateTag == BaselineStateTag % Get the 1st state of the wanted type
                    tmp_ordered_col = Current_States_Analysis(i_state).Corr_Graph_Centrality.Node_Tag_OrderedbyEigenW;
                    tmp1(tmp_ordered_col) = [];
                    OrderedArray = [tmp_ordered_col; tmp1];
                    break
                end
            end
        end
    end
    
    % Re-Order Traces
    Current_Traces_ReOrdered = NaN(n_frames, n_traces);
    for i_cell = 1:n_traces
        Current_Traces_ReOrdered(:, i_cell) = Current_CalciumTraces(:, OrderedArray(i_cell));
    end
    
    % Recompute film.
    film_length = n_frames - Corr_Window_Length + 1;
    CorrFilm_ReOrdered = NaN(n_traces, n_traces, film_length);

    for i_time = 1:film_length
        % Prepare time window
        current_window = zeros(1, n_frames);
        current_window(1, i_time:i_time + Corr_Window_Length - 1) = sliding_window;
        current_traces = Current_Traces_ReOrdered;
        current_traces(current_window == 0, :) = [];
        
        % Correlation
        [current_corr_matrix, ~] = corr(current_traces);
        CorrFilm_ReOrdered(1:n_traces, 1:n_traces, i_time) = current_corr_matrix;
    end
    
    % Shift the data correctly.
    tmp = NaN(n_traces, n_traces, n_frames);
    tmp(:, :, Corr_Window_Length:end) = CorrFilm_ReOrdered;
    CorrFilm_ReOrdered = tmp;
    Traces_ReOrdered_AllSessions{1, i_session} = Current_Traces_ReOrdered;
    CorrFilm_ReOrdered_AllSessions{1, i_session} = CorrFilm_ReOrdered;
end