function Continuous_Analysis_Integrals_Density (Current_State_perMouse, FrameRate)


% Plot Options.
plot_time_res = 1/3; % [s]
plot_MarkerSize = 4;
box_height_multiplier = 1.2;
FontSize_ylabel = 10;
FontSize_suptitle = 18;
str_suptitle = sprintf('Cumulative sums of Events Integrals Temporal Density\n(CumSum / State Duration)');

n_mice = nanmax([Current_State_perMouse.MouseNumber]);

% Get global values.
maxXglobal = 1300; % Dummy value: will be adjusted automatically later
minYglobal = 0;
minY = 0;

figure(); set(gcf,'position', get(0,'screensize'));
for i_mouse = 1:n_mice
    Current_States = Current_State_perMouse([Current_State_perMouse.MouseNumber] == i_mouse);
    n_states = numel(Current_States);
    
    h_subplot = subplot(n_mice, 1, i_mouse);
    hold on; box on; grid on; grid minor;

    max_Y = 0;
    
    Lag2StateChange_cell = cell(1, n_states);
    cumsum_cell = cell(1, n_states);
    for i_state = 1:n_states
        current_events = Current_States(i_state).Events;
        if ~isempty(current_events)
            current_events_complex = get_composite_info(current_events);
        else
            continue
        end
        % Sort events by their Lag after State Change.
        tmp_tableEvents = struct2table(current_events_complex);
        tmp_sortedEvents = sortrows(tmp_tableEvents, 'Dist_PreState', 'ascend'); % Sort
        current_events_LagSorted = table2struct(tmp_sortedEvents);
        clear tmp_tableEvents; clear tmp_sortedEvents;
        
        n_events = numel(current_events_LagSorted);
        Integrals_density_array = NaN(1, n_events);
        tmp = NaN(1, n_events);
        for i_event = 1:n_events
            % Get the integrals density array.
            Integrals_density_array(1, i_event) = [current_events_LagSorted(i_event).Integral]./Current_States(i_state).StateMinDuration_Sec;
            
            % Approximate Lags.
            tmp(1, i_event) = ([current_events_LagSorted(i_event).Dist_PreState])./plot_time_res;
        end
        Lag2StateChange_array = tmp;
        Lag2StateChange_array(isnan(Integrals_density_array)) = [];
        Integrals_density_array(isnan(Integrals_density_array)) = [];

        % Compute Cumsum
        current_cumsum = cumsum(Integrals_density_array);
        
        % Compute lags array (position of events respect to State Change)
        current_state = Current_States(i_state);
        Lag2StateChange_array = Lag2StateChange_array + current_state.StateStartEnd(1)./FrameRate;
        
        % Save into cell form, to plot later.
        Lag2StateChange_cell{i_state} = Lag2StateChange_array;
        cumsum_cell{i_state} = current_cumsum;
        
        % Get Y axis maximum (for colored box purpose)
        max_Y = nanmax([max_Y, nanmax(current_cumsum)]);
        
        clear current*
        clear tmp*
        clear Integrals_array
        clear Lag2StateChange_array
    end

    % --->>> Plot <<<--- %
    for i_state = 1:n_states
        current_state = Current_States(i_state);
        
        end_state = (current_state.StateStartEnd(2)+1)./FrameRate;
        start_state = current_state.StateStartEnd(1)./FrameRate;
        
        current_cumsum = cumsum_cell{i_state};
        Lag2StateChange_array = Lag2StateChange_cell{i_state};
        Lag2StateChange_array_NaNless = Lag2StateChange_array(~isnan(current_cumsum));
        current_cumsum_NaNless = current_cumsum(~isnan(current_cumsum));
        if any(isnan(current_cumsum))
%             current_cumsum_tail = ones(1, numel(current_cumsum(isnan(current_cumsum)))).*current_cumsum_NaNless(end);
%             Lag2StateChange_array_tail = Lag2StateChange_array(isnan(current_cumsum));
            current_cumsum_tail = ones(1, 2).*current_cumsum_NaNless(end);
            Lag2StateChange_array_tail = [Lag2StateChange_array_NaNless(end), end_state];
        end
        
        % Plot Cumsum
        %         plot(Lag2StateChange_array, current_cumsum)
        plot(Lag2StateChange_array_NaNless, current_cumsum_NaNless, '-k.', 'MarkerSize', plot_MarkerSize)
        if any(isnan(current_cumsum))
            plot(Lag2StateChange_array_tail, current_cumsum_tail, '-k')
        end
        axis([0, maxXglobal, minYglobal, max_Y]);
        
        % Plot State
        boxX = [start_state, start_state, end_state, end_state];
        boxY = [minY - box_height_multiplier, max_Y.*box_height_multiplier, max_Y.*box_height_multiplier, minY - box_height_multiplier];
        switch current_state.StateTag
            case 1; BoxColor = [0 0 1];
            case 2; BoxColor = [1 0 0];
            case 4; BoxColor = [0 1 0];
        end
        
        h_array(i_state) = patch(boxX, boxY, BoxColor, 'FaceAlpha', 0.1);
    end
    
    maxX(1, i_mouse) = current_state.StateStartEnd(2)./FrameRate;
    str_ylabel = sprintf('Cumsum\n(Mouse #%s)', Current_States(i_state).MouseTag);
    ylabel(str_ylabel, 'FontSize', FontSize_ylabel)
    h_subplot.XMinorTick = 'on'; h_subplot.YMinorTick = 'on';
end
maxXglobal = nanmax(maxX);

% Fix X axis.
for i_mouse = 1:n_mice
    h_subplot(i_mouse) = subplot(n_mice, 1, i_mouse);
    h_subplot(i_mouse).XLim = [0, maxXglobal];
end

xlabel('Time [s]');

% Suptitle
h_suptitle = suptitle(str_suptitle);
h_suptitle.FontSize = FontSize_suptitle;
h_suptitle.FontWeight = 'bold';

