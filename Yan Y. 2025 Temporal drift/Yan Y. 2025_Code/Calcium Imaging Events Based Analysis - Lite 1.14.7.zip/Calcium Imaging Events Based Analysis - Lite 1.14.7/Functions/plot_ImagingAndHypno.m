function plot_ImagingAndHypno(trace, Hypnogram, calTime)

% figure();
% 
% yyaxis left
% plot(calTime, Hypnogram, 'LineWidth', 1.5);
% axis([-inf, inf, 0.5, 4.5]);
% 
% ylabel('State')
% 
% yyaxis right
% plot(calTime, trace);
% ylabel('\DeltaF/F')
% xlabel('Time [s]')
% 
% grid on; box on;

figure('units','normalized','outerposition',[0 0 1 1]);

FontSize_ylabel = 16;
FontSize_xlabel = 16;
FontSize_title = 28;

[dim1, dim2] = size(trace);

yyaxis left
plot(calTime, Hypnogram, 'b', 'LineWidth', 2);
axis([-inf, inf, 0.5, 4.5]);
ylabel('State', 'FontWeight', 'bold', 'FontSize', FontSize_ylabel)
yticks([1, 2, 4])
yticklabels({'Awake', 'NREM', 'REM'})
hold on;
yyaxis right
plot(calTime, trace, '--k');

set(gca,'FontSize',14)

yticks([])
% ylabel('Traces', 'FontSize', FontSize_ylabel)
xlabel('Time [s]', 'FontWeight', 'bold', 'FontSize', FontSize_xlabel)
title('Example Trace', 'FontWeight', 'bold', 'FontSize', FontSize_title)

grid on;

