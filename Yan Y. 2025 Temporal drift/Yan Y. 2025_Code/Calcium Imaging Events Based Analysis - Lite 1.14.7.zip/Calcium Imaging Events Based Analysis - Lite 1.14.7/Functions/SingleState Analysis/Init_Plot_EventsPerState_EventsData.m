function [Events_Data] = Init_Plot_EventsPerState_EventsData(Events, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts)

% This function plots the events characteristics (as Boxplots), for each
% brain state separately. 
%  Events_Data = Init_Plot_EventsPerState(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);

% The analysis produces average quantities per cell (actually, per active
% cell):
% Each of the Events_Data output fields is of 1 x (N total active cells
% counting all mice) measures, where each measure is the average of all
% events produced by that cell during the corresponding session, and state
% type.

n_mice = Opts.n_mice;

TagAWAKE = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;

N_Sessions_PerMouse = Opts.n_sessions / n_mice;
if strcmpi(Opts.General.CellType, 'Astro') == 1
    N_Sessions_PerMouse = 13;
end

% Remove Event field, save RAM in this function.
if isfield(Events,'Event')
    Events = rmfield(Events, 'Event');
end
if isfield(Events,'Event_NoN_Interpolated')
    Events = rmfield(Events, 'Event_NoN_Interpolated');
end


% Consider all sessions of the same type together    
for i_session = 1:N_Sessions_PerMouse
    
    % Separate Events per State
    Events_Current_Session = Events([Events.Session] == i_session);
    Events_Current_Session_Awake = Events_Current_Session([Events_Current_Session.StateTag] == TagAWAKE);
    Events_Current_Session_NoNREM = Events_Current_Session([Events_Current_Session.StateTag] == TagNoNREM);
    Events_Current_Session_REM = Events_Current_Session([Events_Current_Session.StateTag] == TagREM);
    
    % Get state info (duration)
    Hypnogram_Current_Session = Hypnogram_AllSessions([Hypnogram_AllSessions.Session] == i_session);
    
    % Correction
    if strcmpi(Opts.General.CellType, 'Astro') == 1
        for i_mouse = 1:n_mice
            tmp_StateChanges = Hypnogram_Current_Session(i_mouse).StateChanges;
            tmp_StateChanges(end + 1) = numel(Hypnogram_Current_Session(i_mouse).Hypnogram);
            tmp_StateType = Hypnogram_Current_Session(i_mouse).StateType;
            tmp_StateType(end + 1) = NaN;
            tmp_StateDuration = Hypnogram_Current_Session(i_mouse).StateDuration;
            tmp_StateDuration(end + 1) = NaN;
            % do the same. Adding a NaN to every end point...
            Hypnogram_Current_Session(i_mouse).StateChanges = tmp_StateChanges;
            Hypnogram_Current_Session(i_mouse).StateType = tmp_StateType;
            Hypnogram_Current_Session(i_mouse).StateDuration = tmp_StateDuration;
        end
    end
    
    % Get all events belonging to a cell.
    N_Inactive_Cells = zeros(1, n_mice);
    Inactive_Cell = logical(zeros(1, nansum(MouseCellsRecorded)));
    i_cell_all = 0;
    for i_mouse = 1:n_mice
        MouseName = Mouse_Names{i_mouse};
        n_cells = MouseCellsRecorded(i_mouse);
        for i_cell = 1:n_cells
            
            i_cell_all = i_cell_all + 1;
            current_CellTag = sprintf('%s_%d_%d', MouseName, i_session, i_cell);
            tmp_events = Events_Current_Session;
            n_events = numel(tmp_events);
            Event_to_remove = []; % Remove events not belonging to the current cell
            for i_event = 1:n_events
                if strcmpi(Events_Current_Session(i_event).CellTag, current_CellTag) == 0
                    Event_to_remove = [Event_to_remove, i_event];
                end
            end
            tmp_events(Event_to_remove) = [];
            if isempty(tmp_events) % If there are no events, fill with NaNs
                Inactive_Cell(i_cell_all) = 1;
                N_Inactive_Cells(i_mouse) = N_Inactive_Cells(i_mouse) + 1;
                EventIntegral_Mean(i_cell_all).Awake = NaN;
                EventIntegral_Mean(i_cell_all).NoNREM = NaN;
                EventIntegral_Mean(i_cell_all).REM = NaN;
                EventIntegral_Std(i_cell_all).Awake = NaN;
                EventIntegral_Std(i_cell_all).NoNREM = NaN;
                EventIntegral_Std(i_cell_all).REM = NaN;
                EventAmplitude_Mean(i_cell_all).Awake = NaN;
                EventAmplitude_Mean(i_cell_all).NoNREM = NaN;
                EventAmplitude_Mean(i_cell_all).REM = NaN;
                EventAmplitude_Std(i_cell_all).Awake = NaN;
                EventAmplitude_Std(i_cell_all).NoNREM = NaN;
                EventAmplitude_Std(i_cell_all).REM = NaN;
                EventRate(i_cell_all).Awake = 0;
                EventRate(i_cell_all).NoNREM = 0;
                EventRate(i_cell_all).REM = 0;
            else % Otherwise, separate the events of the current cell according to the state they happened in, and compute the relative mean/std quantities
                tmp_events_Awake = tmp_events([tmp_events.StateTag] == TagAWAKE);
                tmp_events_NoNREM = tmp_events([tmp_events.StateTag] == TagNoNREM);
                tmp_events_REM = tmp_events([tmp_events.StateTag] == TagREM);
                
                EventIntegral_Mean(i_cell_all).Awake = nanmean([tmp_events_Awake.Integral]);
                EventIntegral_Mean(i_cell_all).NoNREM = nanmean([tmp_events_NoNREM.Integral]);
                EventIntegral_Mean(i_cell_all).REM = nanmean([tmp_events_REM.Integral]);
                EventIntegral_Std(i_cell_all).Awake = nanstd([tmp_events_Awake.Integral]);
                EventIntegral_Std(i_cell_all).NoNREM = nanstd([tmp_events_NoNREM.Integral]);
                EventIntegral_Std(i_cell_all).REM = nanstd([tmp_events_REM.Integral]);
                
                EventAmplitude_Mean(i_cell_all).Awake = nanmean([tmp_events_Awake.Amp_StartEnd]);
                EventAmplitude_Mean(i_cell_all).NoNREM = nanmean([tmp_events_NoNREM.Amp_StartEnd]);
                EventAmplitude_Mean(i_cell_all).REM = nanmean([tmp_events_REM.Amp_StartEnd]);
                EventAmplitude_Std(i_cell_all).Awake = nanstd([tmp_events_Awake.Amp_StartEnd]);
                EventAmplitude_Std(i_cell_all).NoNREM = nanstd([tmp_events_NoNREM.Amp_StartEnd]);
                EventAmplitude_Std(i_cell_all).REM = nanstd([tmp_events_REM.Amp_StartEnd]);
                
                if nansum([tmp_events_Awake.StateLength]) == 0
                    EventRate(i_cell_all).Awake = 0;
                else
                    EventRate(i_cell_all).Awake = (numel(tmp_events_Awake))/(nansum([tmp_events_Awake.StateLength]./Opts.General.FrameRate));
                end
                if nansum([tmp_events_NoNREM.StateLength]) == 0
                    EventRate(i_cell_all).NoNREM = 0;
                else
                    EventRate(i_cell_all).NoNREM = (numel(tmp_events_NoNREM))/(nansum([tmp_events_NoNREM.StateLength]./Opts.General.FrameRate));
                end
                if nansum([tmp_events_REM.StateLength]) == 0
                    EventRate(i_cell_all).REM = 0;
                else
                    EventRate(i_cell_all).REM = (numel(tmp_events_REM))/(nansum([tmp_events_REM.StateLength]./Opts.General.FrameRate));
                end
            end
        end
        MouseMeans(i_mouse).EventRate.Awake = nanmean([EventRate.Awake]);
        MouseMeans(i_mouse).EventRate.NoNREM = nanmean([EventRate.NoNREM]);
        MouseMeans(i_mouse).EventRate.REM = nanmean([EventRate.REM]);
        MouseMeans(i_mouse).EventIntegral_Mean.Awake = nanmean([EventIntegral_Mean.Awake]);
        MouseMeans(i_mouse).EventIntegral_Mean.NoNREM = nanmean([EventIntegral_Mean.NoNREM]);
        MouseMeans(i_mouse).EventIntegral_Mean.REM = nanmean([EventIntegral_Mean.REM]);
        MouseMeans(i_mouse).EventIntegral_Std.Awake = nanmean([EventIntegral_Std.Awake]);
        MouseMeans(i_mouse).EventIntegral_Std.NoNREM = nanmean([EventIntegral_Std.NoNREM]);
        MouseMeans(i_mouse).EventIntegral_Std.REM = nanmean([EventIntegral_Std.REM]);
        MouseMeans(i_mouse).EventAmplitude_Mean.Awake = nanmean([EventAmplitude_Mean.Awake]);
        MouseMeans(i_mouse).EventAmplitude_Mean.NoNREM = nanmean([EventAmplitude_Mean.NoNREM]);
        MouseMeans(i_mouse).EventAmplitude_Mean.REM = nanmean([EventAmplitude_Mean.REM]);
        MouseMeans(i_mouse).EventAmplitude_Std.Awake = nanmean([EventAmplitude_Std.Awake]);
        MouseMeans(i_mouse).EventAmplitude_Std.NoNREM = nanmean([EventAmplitude_Std.NoNREM]);
        MouseMeans(i_mouse).EventAmplitude_Std.REM = nanmean([EventAmplitude_Std.REM]);
    end
    
    % Remove inactive cells.
    if Opts.FLAG_Remove_Inactive_Cells == 1
        try
            EventIntegral_Mean(Inactive_Cell) = [];
            EventIntegral_Std(Inactive_Cell) = [];
            EventAmplitude_Mean(Inactive_Cell) = [];
            EventAmplitude_Std(Inactive_Cell) = [];
            EventRate(Inactive_Cell) = [];
        catch
            warning('Error with ignoring inactive cells.\n')
            keyboard
        end
    end
    
    Events_Data(i_session).EventIntegral_Mean = EventIntegral_Mean;
    Events_Data(i_session).EventIntegral_Std = EventIntegral_Std;
    Events_Data(i_session).EventAmplitude_Mean = EventAmplitude_Mean;
    Events_Data(i_session).EventAmplitude_Std = EventAmplitude_Std;
    Events_Data(i_session).EventRate = EventRate;
    Events_Data(i_session).MouseMeans = MouseMeans;
    
    % Add N Events field
    tmp_Awake = [EventIntegral_Mean.Awake];
    tmp_NREM = [EventIntegral_Mean.NoNREM];
    tmp_REM = [EventIntegral_Mean.REM];
    Events_Data(i_session).N_Events.Awake = numel(tmp_Awake(~isnan(tmp_Awake)));
    Events_Data(i_session).N_Events.NREM = numel(tmp_NREM(~isnan(tmp_NREM)));
    Events_Data(i_session).N_Events.REM = numel(tmp_REM(~isnan(tmp_REM)));
    
end
