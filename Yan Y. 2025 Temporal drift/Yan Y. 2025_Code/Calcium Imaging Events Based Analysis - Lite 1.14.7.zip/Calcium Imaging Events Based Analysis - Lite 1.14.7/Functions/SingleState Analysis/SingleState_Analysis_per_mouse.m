function State_Info_perSession = SingleState_Analysis_per_mouse(Events, Hypnogram_AllMice, Mouse_Names, Opts)

n_mouse = Opts.n_mice;
n_sessions = Opts.n_sessions;
Mouse_Sessions = Opts.Mouse_Sessions;
n_events = numel(Events);

% Make Binary Traces for Synchro Analysis.
Opts.Sync_BinType = 'Weighted'; % 'Weighted' or 'Flat'.
Opts.Sync_BinSize = 1; % A BinSize = 0 will make use of only the central bin.
Opts.Sync_BinWeights = 'Gauss'; % To use in case of 'Weighted' BinTypes

Binary_Traces_AllMice = make_binary_point_traces (Events, Hypnogram_AllMice, Opts);

% Scroll each mouse.
i_session_tot = 1;
for i_mouse = 1:n_mouse
    current_MouseName = Mouse_Names{i_mouse};
    Current_N_Sessions = Mouse_Sessions(i_mouse);
    current_mouse_Events = Events;
    % Take only events from the current mouse.
    events_to_remove = [];
    for i_event = n_events:-1:1
        if ~strcmpi(Events(i_event).MouseTag, current_MouseName)
            events_to_remove = [events_to_remove, i_event];
        end
    end
    current_mouse_Events(events_to_remove) = [];
    
    % Scroll each session.
    for i_session = 1:Current_N_Sessions
        current_session_Events = current_mouse_Events;
        % Take only events from the current session.
        events_to_remove = [];
        for i_event = numel(current_mouse_Events):-1:1
            if current_mouse_Events(i_event).Session ~= i_session
                events_to_remove = [events_to_remove, i_event];
            end
        end
        % Get current quantities.
        current_session_Events(events_to_remove) = [];
        current_session_Hypnogram = Hypnogram_AllMice(i_session_tot);
        current_session_BinaryTrace = Binary_Traces_AllMice{i_session_tot};
        
        % Get each state separately.
        Current_State = separate_per_state (current_session_Events, current_session_Hypnogram, current_session_BinaryTrace, Opts);
        
        for i_state = 1:numel(Current_State)
            Current_State(i_state).MouseTag = current_MouseName;
            Current_State(i_state).MouseNumber = i_mouse;
            Current_State(i_state).Session = i_session;
        end
        
        % Compute Point Sync.
        [Sync_Stats, Current_State] = SingleState_Analysis_PointSync (Current_State, Opts);
        
        % Stack all in the same variable...
        if i_mouse == 1 && i_session == 1 %...unless it's the 1st one.
            State_Info_perSession = Current_State;
        else
            State_Info_perSession = [State_Info_perSession, Current_State];
        end
        i_session_tot = i_session_tot + 1;
        clear Current_State;
    end
    
end


%% Time Locked Cumsum Analysis.
% Integrals.
SingleState_Analysis_TimeLocked_Cumsums(State_Info_perSession, Opts)


