function Current_State = separate_per_state (Events, Hypnogram, BinaryTrace, Opts)
% Separate the events belonging to each state.
% (intended as a sub-function to "SingleState_Analysis_per_mouse")

FrameRate = Opts.General.FrameRate;
n_events = numel(Events);
n_states = numel(Hypnogram.StateChanges);
n_traces = numel(BinaryTrace);

% Compute Sync Measures per state.
for i_state = 1:n_states
    
    % Get current State Start, End, Duration.
    if i_state == 1
        Current_State(i_state).StateTag = Hypnogram.Hypnogram(1);
        Current_State(i_state).StateStartEnd = [1, Hypnogram.StateChanges(i_state + 1) - 1];
        Current_State(i_state).StateDuration = NaN;
        Current_State(i_state).StateMinDuration = Current_State(i_state).StateStartEnd(2) - Current_State(i_state).StateStartEnd(1);
        Current_State(i_state).StateMinDuration_Sec = (Current_State(i_state).StateMinDuration)/FrameRate;
    elseif i_state == n_states
        Current_State(i_state).StateTag = Hypnogram.Hypnogram(end);
        Current_State(i_state).StateStartEnd = [Hypnogram.StateChanges(i_state), numel(Hypnogram.Hypnogram)];
        Current_State(i_state).StateDuration = NaN;
        Current_State(i_state).StateMinDuration = Current_State(i_state).StateStartEnd(2) - Current_State(i_state).StateStartEnd(1);
        Current_State(i_state).StateMinDuration_Sec = (Current_State(i_state).StateMinDuration)/FrameRate;
    else
        Current_State(i_state).StateTag = Hypnogram.Hypnogram(Hypnogram.StateChanges(i_state));
        Current_State(i_state).StateStartEnd = [Hypnogram.StateChanges(i_state), Hypnogram.StateChanges(i_state + 1) - 1];
        Current_State(i_state).StateDuration = Current_State(i_state).StateStartEnd(2) - Current_State(i_state).StateStartEnd(1);
        Current_State(i_state).StateMinDuration = Current_State(i_state).StateDuration;
        Current_State(i_state).StateMinDuration_Sec = (Current_State(i_state).StateMinDuration)/FrameRate;
    end
    
    % Get Current State Events.
    events_to_remove = [];
    current_state_events = Events;
    for i_event = n_events:-1:1
        if Events(i_event).Composite.CompositeTag == 1
            current_event_position = Events(i_event).Composite.Start;
        else
            current_event_position = Events(i_event).Start;
        end
        
        if current_event_position < Current_State(i_state).StateStartEnd(1) || current_event_position > Current_State(i_state).StateStartEnd(2)
            events_to_remove = [events_to_remove, i_event];
        end
    end
    current_state_events(events_to_remove) = [];
    Current_State(i_state).Events = current_state_events;
    
    % Cut binary traces.
    for i_trace = 1:n_traces
        tmp_trace = BinaryTrace{i_trace};
        Current_State(i_state).BinaryTrace{i_trace, 1} = tmp_trace(Current_State(i_state).StateStartEnd(1):Current_State(i_state).StateStartEnd(2));
    end
end