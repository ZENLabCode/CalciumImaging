function [Events_Data, MouseMeans] = Init_Plot_EventsPerState(Events, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts)

% This function plots the events characteristics (as Boxplots), for each
% brain state separately. 
%  Events_Data = Init_Plot_EventsPerState(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);

% The analysis produces average quantities per cell (actually, per active
% cell):
% Each of the Events_Data output fields is of 1 x (N total active cells
% counting all mice) measures, where each measure is the average of all
% events produced by that cell during the corresponding session, and state
% type.
% Each cell gets its own average per state for each quantity, and each
% mouse gets its own state average (the average of each cell), in
% MouseMeans.

n_mice = Opts.n_mice;
n_events = numel(Events);

TagAWAKE = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;

% Remove Event field, save RAM in this function.
if isfield(Events,'Event')
    Events = rmfield(Events, 'Event');
end
if isfield(Events,'Event_NoN_Interpolated')
    Events = rmfield(Events, 'Event_NoN_Interpolated');
end

try
    [Events_Data] = Init_Plot_EventsPerState_EventsData(Events, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);
catch
    Events_Data = [];
    warningtext = sprintf('There was an error, the Events_Data could not be computed. /nThe error likely has to do with the number of sessions./n Please check that your number of sessions correspond to what written in the code: each mouse is supposed to have the same number of sessions./n/n');
    warning(warningtext)
end
if strcmpi(Opts.General.CellType, 'Astro') == 1
    MouseMeans = [];
    return
end
N_Sessions = numel(Hypnogram_AllSessions);


% Consider all sessions of the same type together
i_cell_all = 0;
for i_mouse = 1:n_mice
    Current_Mouse_Name = Mouse_Names{i_mouse};
    N_Sessions_per_mouse = Opts.Mouse_Sessions(i_mouse);
    n_cells = MouseCellsRecorded(i_mouse);
    
    % Get Events from the current mouse
    tmp_removal_list = [];
    for i_event = 1:n_events
        if strcmpi(Events(i_event).MouseTag, Current_Mouse_Name) == 0
            tmp_removal_list = [tmp_removal_list, i_event];
        end
    end
    Events_Current_Mouse = Events;
    Events_Current_Mouse(tmp_removal_list) = [];

    % Get all events belonging to a cell.
    N_Inactive_Cells = zeros(1, n_mice);
    Inactive_Cell = logical(zeros(1, nansum(MouseCellsRecorded)));
    
    for i_cell = 1:n_cells
        i_cell_all = i_cell_all + 1;
        tmp_events = Events_Current_Mouse;
        
        % Remove events not belonging to the current cell
        tmp_events([Events_Current_Mouse.TraceNumber] ~= i_cell) = [];
        
        % Remove events belonging to unstable states
        tmp_events([tmp_events.StateLength] < Opts.General.MinStableStateDuration) = [];
        
        if isempty(tmp_events) % If there are no events, fill with NaNs
            Inactive_Cell(i_cell) = 1;
            N_Inactive_Cells(i_mouse) = N_Inactive_Cells(i_mouse) + 1;
            EventIntegral_Mean(i_cell).Awake = NaN;
            EventIntegral_Mean(i_cell).NoNREM = NaN;
            EventIntegral_Mean(i_cell).REM = NaN;
            EventIntegral_Std(i_cell).Awake = NaN;
            EventIntegral_Std(i_cell).NoNREM = NaN;
            EventIntegral_Std(i_cell).REM = NaN;
            EventAmplitude_Mean(i_cell).Awake = NaN;
            EventAmplitude_Mean(i_cell).NoNREM = NaN;
            EventAmplitude_Mean(i_cell).REM = NaN;
            EventAmplitude_Std(i_cell).Awake = NaN;
            EventAmplitude_Std(i_cell).NoNREM = NaN;
            EventAmplitude_Std(i_cell).REM = NaN;
            EventNumber(i_cell).Awake = 0;
            EventNumber(i_cell).NoNREM = 0;
            EventNumber(i_cell).REM = 0;
            EventRate(i_cell).Awake = 0;
            EventRate(i_cell).NoNREM = 0;
            EventRate(i_cell).REM = 0;
        else % Otherwise, separate the events of the current cell according to the state they happened in, and compute the relative mean/std quantities
            tmp_events_Awake = tmp_events([tmp_events.StateTag] == TagAWAKE);
            tmp_events_NoNREM = tmp_events([tmp_events.StateTag] == TagNoNREM);
            tmp_events_REM = tmp_events([tmp_events.StateTag] == TagREM);
            
            EventIntegral_Mean(i_cell).Awake = nanmean([tmp_events_Awake.Integral]);
            EventIntegral_Mean(i_cell).NoNREM = nanmean([tmp_events_NoNREM.Integral]);
            EventIntegral_Mean(i_cell).REM = nanmean([tmp_events_REM.Integral]);
            EventIntegral_Std(i_cell).Awake = nanstd([tmp_events_Awake.Integral]);
            EventIntegral_Std(i_cell).NoNREM = nanstd([tmp_events_NoNREM.Integral]);
            EventIntegral_Std(i_cell).REM = nanstd([tmp_events_REM.Integral]);
            
            EventAmplitude_Mean(i_cell).Awake = nanmean([tmp_events_Awake.Amp_StartEnd]);
            EventAmplitude_Mean(i_cell).NoNREM = nanmean([tmp_events_NoNREM.Amp_StartEnd]);
            EventAmplitude_Mean(i_cell).REM = nanmean([tmp_events_REM.Amp_StartEnd]);
            EventAmplitude_Std(i_cell).Awake = nanstd([tmp_events_Awake.Amp_StartEnd]);
            EventAmplitude_Std(i_cell).NoNREM = nanstd([tmp_events_NoNREM.Amp_StartEnd]);
            EventAmplitude_Std(i_cell).REM = nanstd([tmp_events_REM.Amp_StartEnd]);
            
            EventNumber(i_cell).Awake = numel(tmp_events_Awake);
            EventNumber(i_cell).NREM = numel(tmp_events_NoNREM);
            EventNumber(i_cell).REM = numel(tmp_events_REM);
            
            
            
            if nansum([tmp_events_Awake.StateLength]) == 0
                EventRate(i_cell).Awake = NaN;
            else
                EventRate(i_cell).Awake = (numel(tmp_events_Awake))/(nansum([tmp_events_Awake.StateLength]./Opts.General.FrameRate));
            end
            if nansum([tmp_events_NoNREM.StateLength]) == 0
                EventRate(i_cell).NoNREM = NaN;
            else
                EventRate(i_cell).NoNREM = (numel(tmp_events_NoNREM))/(nansum([tmp_events_NoNREM.StateLength]./Opts.General.FrameRate));
            end
            if nansum([tmp_events_REM.StateLength]) == 0
                EventRate(i_cell).REM = NaN;
            else
                EventRate(i_cell).REM = (numel(tmp_events_REM))/(nansum([tmp_events_REM.StateLength]./Opts.General.FrameRate));
            end
        end
    end
    
    % Remove inactive cells.
    try
        EventIntegral_Mean(Inactive_Cell) = [];
        EventIntegral_Std(Inactive_Cell) = [];
        EventAmplitude_Mean(Inactive_Cell) = [];
        EventAmplitude_Std(Inactive_Cell) = [];
%         EventRate(Inactive_Cell) = [];
    catch
        warning('Error with ignoring inactive cells.\n')
        keyboard
    end
    
    MouseMeans(i_mouse).EventRate.Awake = nanmean([EventRate.Awake]);
    MouseMeans(i_mouse).EventRate.NoNREM = nanmean([EventRate.NoNREM]);
    MouseMeans(i_mouse).EventRate.REM = nanmean([EventRate.REM]);
    MouseMeans(i_mouse).EventIntegral_Mean.Awake = nanmean([EventIntegral_Mean.Awake]);
    MouseMeans(i_mouse).EventIntegral_Mean.NoNREM = nanmean([EventIntegral_Mean.NoNREM]);
    MouseMeans(i_mouse).EventIntegral_Mean.REM = nanmean([EventIntegral_Mean.REM]);
    MouseMeans(i_mouse).EventIntegral_Std.Awake = nanmean([EventIntegral_Std.Awake]);
    MouseMeans(i_mouse).EventIntegral_Std.NoNREM = nanmean([EventIntegral_Std.NoNREM]);
    MouseMeans(i_mouse).EventIntegral_Std.REM = nanmean([EventIntegral_Std.REM]);
    MouseMeans(i_mouse).EventAmplitude_Mean.Awake = nanmean([EventAmplitude_Mean.Awake]);
    MouseMeans(i_mouse).EventAmplitude_Mean.NoNREM = nanmean([EventAmplitude_Mean.NoNREM]);
    MouseMeans(i_mouse).EventAmplitude_Mean.REM = nanmean([EventAmplitude_Mean.REM]);
    MouseMeans(i_mouse).EventAmplitude_Std.Awake = nanmean([EventAmplitude_Std.Awake]);
    MouseMeans(i_mouse).EventAmplitude_Std.NoNREM = nanmean([EventAmplitude_Std.NoNREM]);
    MouseMeans(i_mouse).EventAmplitude_Std.REM = nanmean([EventAmplitude_Std.REM]);
    
    MouseMeans(i_mouse).N_Events.Awake = nansum([EventNumber.Awake]);
    MouseMeans(i_mouse).N_Events.NREM = nansum([EventNumber.NREM]);
    MouseMeans(i_mouse).N_Events.REM = nansum([EventNumber.REM]);
    
end
