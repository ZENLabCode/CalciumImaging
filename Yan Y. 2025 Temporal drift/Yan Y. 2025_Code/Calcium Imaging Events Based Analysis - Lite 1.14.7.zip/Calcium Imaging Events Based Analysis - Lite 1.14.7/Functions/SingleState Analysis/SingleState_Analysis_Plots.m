function SingleState_Analysis_Plots(Current_State_perMouse, Mouse_Names, Opts)


%% Options.
% Micro-Arusal Duration
MicroArusalMaxDuration = Opts.General.MinStableStateDuration; % [frames]
StableStateMinDur = Opts.General.MinStableStateDuration; % [frames]
event_start_max_lag = 90/Opts.General.FrameRate; % [s]; 1 s = 3 frames

% Options for plots.
Opts.n_bins = 50;
Opts.marker_size = 10;
Opts.dist_grid = 'on';
Opts.FLAG_Save = 1;


%% Variables declaration.
States_MinDuration = [Current_State_perMouse.StateMinDuration];


%% Micro-Arusal States.
N_MicroArusals = numel(States_MinDuration(States_MinDuration < MicroArusalMaxDuration));
fprintf('Number of Micro-Arusal States: %d.\n', N_MicroArusals);

States_MicroArusal = Current_State_perMouse(States_MinDuration < MicroArusalMaxDuration);

% Take only states whose duration is thr_low < D, then 
% cut the longer states for a fair comparison.
States_Long = Current_State_perMouse(States_MinDuration > StableStateMinDur);
tmp_States_MinDuration = [States_Long.StateMinDuration];
n_long_states = numel(States_Long);
fprintf('Number of States with Duration > %d Frames: %d.\n', StableStateMinDur, n_long_states);


%% Sync 2 Previous State (Lag)
% Remove all the events that occurred after a certain duration.
States_Long_Cut = States_Long;

for i_state = 1:n_long_states
    Events_Current_State = States_Long(i_state).Events;
    n_events = numel(States_Long(i_state).Events);
    events_to_remove = [];
    for i_event = 1:n_events
        States_Long(i_state).Events(i_event);
        current_event_start = States_Long(i_state).Events(i_event).Dist_PreState;
        if current_event_start > event_start_max_lag
            events_to_remove = [events_to_remove, i_event];
        end
    end
    fprintf('Events Removed = %d\n', numel(events_to_remove))
    Events_Current_State(events_to_remove) = []; 
    
    States_Long_Cut(i_state).Events = Events_Current_State;
    current_traces = [States_Long(i_state).BinaryTrace];
    n_traces = numel(current_traces);
    if numel(current_traces{1}) > event_start_max_lag
        for i_trace = 1:n_traces
            current_traces{i_trace} = current_traces{i_trace}(1:event_start_max_lag);
        end
    end
    States_Long_Cut(i_state).BinaryTrace = current_traces;
    
end

% Stitch all Events together
for i_state = 1:numel(States_Long_Cut)
    if i_state == 1
        Events = States_Long_Cut(i_state).Events;
    else
        Events = [Events, States_Long_Cut(i_state).Events];
    end
end

% Plot the Lag2StateChange scatterhists
Sync2StateChange (Events, Mouse_Names, Current_State_perMouse, Opts)


%% Sync 2 Next State
% Remove all the events that occurred before a certain time respect to the next state change.
States_Long_Cut = States_Long;

for i_state = 1:n_long_states
    Events_Current_State = States_Long(i_state).Events;
    n_events = numel(States_Long(i_state).Events);
    events_to_remove = [];
    for i_event = 1:n_events
        States_Long(i_state).Events(i_event);
        current_event_end = States_Long(i_state).Events(i_event).Dist_NextState;
        if current_event_end > event_start_max_lag
            events_to_remove = [events_to_remove, i_event];
        end
    end
    fprintf('Events Removed = %d\n', numel(events_to_remove))
    Events_Current_State(events_to_remove) = []; 
    
    States_Long_Cut(i_state).Events = Events_Current_State;
    current_traces = [States_Long(i_state).BinaryTrace];
    n_traces = numel(current_traces);
    if numel(current_traces{1}) > event_start_max_lag
        for i_trace = 1:n_traces
            current_traces{i_trace} = current_traces{i_trace}(1:event_start_max_lag);
        end
    end
    States_Long_Cut(i_state).BinaryTrace = current_traces;
    
end

% Stitch all Events together
for i_state = 1:numel(States_Long_Cut)
    if i_state == 1
        Events = States_Long_Cut(i_state).Events;
    else
        Events = [Events, States_Long_Cut(i_state).Events];
    end
end

Sync2NextState (Events, Opts);


%% Plots
figure;
scatterhist([Current_State_perMouse.N_Events], [Current_State_perMouse.Sync_Index], 'Kernel', 'on')
xlabel('State Duration')
ylabel('Events Number')

% scatter([Current_State_perMouse.StateMinDuration], [Current_State_perMouse.Events_Frequency])
% xlabel('State Duration')
% ylabel('Events Frequency')