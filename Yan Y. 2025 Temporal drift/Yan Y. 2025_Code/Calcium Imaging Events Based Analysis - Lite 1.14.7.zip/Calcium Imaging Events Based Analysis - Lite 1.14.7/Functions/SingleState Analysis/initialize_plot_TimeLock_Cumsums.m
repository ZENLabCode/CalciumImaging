function [time_matrix, qty_matrix] = initialize_plot_TimeLock_Cumsums (plot_time_array, Lag2StateChange, Qty_CumSum)
% This function is an auxiliary function to
% "SingleState_Analysis_TimeLocked_Cumsums". It is used to order the array
% in a proper manner for plotting.

[n_states, ~] = size(Lag2StateChange);
n_time_points = numel(plot_time_array);
time_matrix = repmat(plot_time_array, n_states, 1);
qty_matrix = NaN(n_states, n_time_points);

for i_state = 1:n_states
    tmp1 = Lag2StateChange(i_state, :);
    current_value = NaN;
    for i_t1 = 1:n_time_points
        for i_t2 = 1:n_states
            if time_matrix(i_state, i_t1) == tmp1(i_t2)
                qty_matrix(i_state, i_t1) = Qty_CumSum(i_state, i_t2);
                current_value = Qty_CumSum(i_state, i_t2);
            else
                qty_matrix(i_state, i_t1) = current_value;
            end
        end
    end
end



