function [Sync_Stats, Current_State] = SingleState_Analysis_PointSync (Current_State, Opts)
% This function computes the Point Sync Indexes for a single state.
% Computations here are done on a per state base.

n_states = numel(Current_State);

if nargin < 2 % Set Defaults in case Opts is not specified.
    Opts.SingleStateAnalysis.Sync_BinType = 'Flat'; % 'Weighted' or 'Flat'.
    Opts.SingleStateAnalysis.Sync_BinSize = 1; % A BinSize = 0 will make use of only the central bin.
    Opts.SingleStateAnalysis.Sync_BinWeights = 'Gauss'; % To use in case of 'Weighted' BinTypes
end

n_events_singlets = NaN(1, n_states);
n_events = NaN(1, n_states);
n_events_overlap_avg = NaN(1, n_states);
Sync_Index = NaN(1, n_states);
Events_Frequency = NaN(1, n_states);
for i_state = 1:n_states
    % Get variables into readable format.
    if isnan(Current_State(i_state).StateDuration) || Current_State(i_state).StateDuration == 0
        continue
    end
    current_mouse_traces = Current_State(i_state).BinaryTrace;
    current_traces_matrix = cell2mat(current_mouse_traces);
    [current_n_cells, current_n_frames] = size(current_traces_matrix);
    [Sync_Index(i_state), n_events_overlap_avg(i_state), n_events(i_state), n_events_singlets(i_state)] = cmp_PointSync (current_traces_matrix, Opts);
    Events_Frequency(i_state) = n_events(i_state)./Current_State(i_state).StateMinDuration_Sec;
    
    clear current*
    clear tmp*
end

% Save Output.
Sync_Stats.Sync_Index = Sync_Index;
Sync_Stats.N_Events_overlap_avg = n_events_overlap_avg;
Sync_Stats.N_Events = n_events;
Sync_Stats.N_Events_singlets = n_events_singlets;
Sync_Stats.Events_Frequency = Events_Frequency;
Sync_Stats.Opts_BinType = Opts.SingleStateAnalysis.Sync_BinType;
Sync_Stats.Opts_BinSize = Opts.SingleStateAnalysis.Sync_BinSize;
for i_state = 1:n_states
    Current_State(i_state).Sync_Index = Sync_Stats.Sync_Index(i_state);
    Current_State(i_state).N_Events_overlap_avg = Sync_Stats.N_Events_overlap_avg(i_state);
    Current_State(i_state).N_Events = Sync_Stats.N_Events(i_state);
    Current_State(i_state).N_Events_singlets = Sync_Stats.N_Events_singlets(i_state);
    Current_State(i_state).Events_Frequency = Sync_Stats.Events_Frequency(i_state);
end