function SingleState_Analysis_TimeLocked_Cumsums(Current_State_perSession, Opts)
% This function computes the cumulative sums of relevant Calcium Events
% quantities, relative to a State Change.

% Options.
% LongStatesMinDur = 60; % [frames]; 1 s = 3 frames
LongStatesMinDur = Opts.General.MinStableStateDuration; % [frames];

% Plot Options.
FrameRate = Opts.General.FrameRate; % [Hz]
plot_time_res = 1/Opts.General.FrameRate; % [s]

Avg_LineWidth = 2;
STE_alpha = 0.4;
bk_lines_color_light = 0.7;
x_max = LongStatesMinDur/Opts.General.FrameRate;
x_max = 18;
y_max = 8000;

% Save Options.
FLAG_Plot_SingleStates = Opts.SingleStateAnalysis.Integrals.Plot.FLAG_Plot_SingleStates;
FLAG_Save = 1;
FileName = 'Figure TimeLocked CumSum';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);


%% Compute TimeLocked CumSum 
n_states = numel(Current_State_perSession);
% Get dimension (max number of events)
for i_state = 1:n_states
    Current_Events = Current_State_perSession(i_state).Events;
    if ~isempty(Current_Events)
        Current_Events_Complex = get_composite_info(Current_Events);
    else
        Current_Events_Complex = Current_Events;
    end
    n_Events(i_state) = numel(Current_Events_Complex);
end
n_Events_max = nanmax(n_Events);

Integrals = NaN(n_states, n_Events_max);
Amp_StartEnd = NaN(n_states, n_Events_max);
Duration = NaN(n_states, n_Events_max);
LagAfterStateChange = NaN(n_states, n_Events_max);
tmp = NaN(n_states, n_Events_max);

for i_state = 1:n_states
    Current_Events = Current_State_perSession(i_state).Events;
    if ~isempty(Current_Events)
        Current_Events_Complex = get_composite_info(Current_Events);
    else
        Current_Events_Complex = Current_Events;
    end
    
    % Sort events by their Lag after State Change.
    tmp_tableEvents = struct2table(Current_Events_Complex);
    tmp_sortedEvents = sortrows(tmp_tableEvents, 'Dist_PreState', 'ascend'); % Sort
    Current_Events_LagSorted = table2struct(tmp_sortedEvents);
    clear tmp_tableEvents; clear tmp_sortedEvents;
    n_events = numel(Current_Events_LagSorted);
    for i_event = 1:n_events
        Integrals(i_state, i_event) = [Current_Events_LagSorted(i_event).Integral];
        Amp_StartEnd(i_state, i_event) = [Current_Events_LagSorted(i_event).Amp_StartEnd];
        Duration(i_state, i_event) = [Current_Events_LagSorted(i_event).Duration];
        
        % Approximate Lags.
        tmp(i_state, i_event) = ([Current_Events_LagSorted(i_event).Dist_PreState]).*FrameRate;
        LagAfterStateChange(i_state, i_event) = round(tmp(i_state, i_event))./FrameRate;
        LagAfterStateChange(i_state, i_event) = tmp(i_state, i_event);
    end
end

% Filter out States shorter than LongStatesMinDur
Current_Long_States = Current_State_perSession;
Current_Long_States([Current_State_perSession.StateMinDuration] < LongStatesMinDur) = [];
Integrals([Current_State_perSession.StateMinDuration] < LongStatesMinDur, :) = [];
Amp_StartEnd([Current_State_perSession.StateMinDuration] < LongStatesMinDur, :) = [];
Duration([Current_State_perSession.StateMinDuration] < LongStatesMinDur, :) = [];
LagAfterStateChange([Current_State_perSession.StateMinDuration] < LongStatesMinDur, :) = [];

% Remove 1st state of a recording session, as the state start is unknown
% (they correspond to states where the LagAfterStateChange is = NaN for all
% Events.
tmp_LagsMean = nanmean(LagAfterStateChange, 2); % Get the states with all NaN lags.
Current_Long_States(isnan(tmp_LagsMean)) = [];
Integrals(isnan(tmp_LagsMean), :) = [];
Amp_StartEnd(isnan(tmp_LagsMean), :) = [];
Duration(isnan(tmp_LagsMean), :) = [];
LagAfterStateChange(isnan(tmp_LagsMean), :) = [];

% Separate Different States.
numel(Current_State_perSession([Current_State_perSession.StateTag] == 4))

Integrals_Awake = Integrals([Current_Long_States.StateTag] == 1, :);
Integrals_NoNREM = Integrals([Current_Long_States.StateTag] == 2, :);
Integrals_REM = Integrals([Current_Long_States.StateTag] == 4, :);

Amp_StartEnd_Awake = Amp_StartEnd([Current_Long_States.StateTag] == 1, :);
Amp_StartEnd_NoNREM = Amp_StartEnd([Current_Long_States.StateTag] == 2, :);
Amp_StartEnd_REM = Amp_StartEnd([Current_Long_States.StateTag] == 4, :);

Duration_Awake = Duration([Current_Long_States.StateTag] == 1, :);
Duration_NoNREM = Duration([Current_Long_States.StateTag] == 2, :);
Duration_REM = Duration([Current_Long_States.StateTag] == 4, :);

LagAfterStateChange_Awake = LagAfterStateChange([Current_Long_States.StateTag] == 1, :);
LagAfterStateChange_NoNREM = LagAfterStateChange([Current_Long_States.StateTag] == 2, :);
LagAfterStateChange_REM = LagAfterStateChange([Current_Long_States.StateTag] == 4, :);

% Convert NaN2Zeros for cumsum.
Integrals_Awake(isnan(Integrals_Awake)) = 0;
Integrals_NoNREM(isnan(Integrals_NoNREM)) = 0;
Integrals_REM(isnan(Integrals_REM)) = 0;

Amp_StartEnd_Awake(isnan(Amp_StartEnd_Awake)) = 0;
Amp_StartEnd_NoNREM(isnan(Amp_StartEnd_NoNREM)) = 0;
Amp_StartEnd_REM(isnan(Amp_StartEnd_REM)) = 0;

Duration_Awake(isnan(Duration_Awake)) = 0;
Duration_NoNREM(isnan(Duration_NoNREM)) = 0;
Duration_REM(isnan(Duration_REM)) = 0;

% LagAfterStateChange_Awake(isnan(LagAfterStateChange_Awake)) = 0;
% LagAfterStateChange_NoNREM(isnan(LagAfterStateChange_NoNREM)) = 0;
% LagAfterStateChange_REM(isnan(LagAfterStateChange_REM)) = 0;

% Compute Cumsums
Integrals_Awake_CumSum = cumsum(Integrals_Awake, 2);
Integrals_NoNREM_CumSum = cumsum(Integrals_NoNREM, 2);
Integrals_REM_CumSum = cumsum(Integrals_REM, 2);

Amp_StartEnd_Awake_CumSum = cumsum(Amp_StartEnd_Awake, 2);
Amp_StartEnd_NoNREM_CumSum = cumsum(Amp_StartEnd_NoNREM, 2);
Amp_StartEnd_REM_CumSum = cumsum(Amp_StartEnd_REM, 2);

Duration_Awake_CumSum = cumsum(Duration_Awake, 2);
Duration_NoNREM_CumSum = cumsum(Duration_NoNREM, 2);
Duration_REM_CumSum = cumsum(Duration_REM, 2);

% Arrange vectors for plotting.
plot_time_array = 0:(1/FrameRate):nanmax(nanmax(LagAfterStateChange));
[Awake_time_matrix, Awake_Integral_matrix] = initialize_plot_TimeLock_Cumsums (plot_time_array, LagAfterStateChange_Awake, Integrals_Awake_CumSum);
[NoNREM_time_matrix, NoNREM_Integral_matrix] = initialize_plot_TimeLock_Cumsums (plot_time_array, LagAfterStateChange_NoNREM, Integrals_NoNREM_CumSum);
[REM_time_matrix, REM_Integral_matrix] = initialize_plot_TimeLock_Cumsums (plot_time_array, LagAfterStateChange_REM, Integrals_REM_CumSum);

% Average + std Cumsum.
[n_states_Awake, ~] = size(Integrals_Awake_CumSum);
Integrals_Awake_CumSum_Avg = nanmean(Awake_Integral_matrix, 1);
Integrals_Awake_CumSum_StE = nanstd(Awake_Integral_matrix, 1)./sqrt(n_states_Awake);
Integrals_NoNREM_CumSum_Avg = nanmean(NoNREM_Integral_matrix, 1);
Integrals_NoNREM_CumSum_StE = nanstd(NoNREM_Integral_matrix, 1)./sqrt(n_states_Awake);
Integrals_REM_CumSum_Avg = nanmean(REM_Integral_matrix, 1);
Integrals_REM_CumSum_StE = nanstd(REM_Integral_matrix, 1)./sqrt(n_states_Awake);
Integrals_REM_CumSum_Avg(isnan(Integrals_REM_CumSum_Avg)) = 0; % Remove NaNs, otherwise there is no plot
Integrals_REM_CumSum_StE(isnan(Integrals_REM_CumSum_StE)) = 0;

Amp_StartEnd_Awake_CumSum_Avg = nanmean(Amp_StartEnd_Awake_CumSum, 1);
Amp_StartEnd_NoNREM_CumSum_Avg = nanmean(Amp_StartEnd_NoNREM_CumSum, 1);
Amp_StartEnd_REM_CumSum_Avg = nanmean(Amp_StartEnd_REM_CumSum, 1);

Duration_Awake_CumSum_Avg = nanmean(Duration_Awake_CumSum, 1);
Duration_NoNREM_CumSum_Avg = nanmean(Duration_NoNREM_CumSum, 1);
Duration_REM_CumSum_Avg = nanmean(Duration_REM_CumSum, 1);


%% Plot
FontSize_Title = 16;
FontSize_Labels = 14;
figure(); set(gcf,'position', get(0,'screensize'));
title('Cumulative sum of Ca^{2+} Events Integrals, aligned to State Change', 'FontSize', FontSize_Title);
hold on; box on; axis tight; grid on; grid minor;
set(gca,'XMinorTick','on')
% Plot Awake
[n_current_states, ~] = size(Integrals_Awake_CumSum);
if FLAG_Plot_SingleStates == 1
    for i_state = 1:n_current_states
        plot(Awake_time_matrix(i_state, :), Awake_Integral_matrix(i_state, :), 'b', 'Color', [bk_lines_color_light, bk_lines_color_light, 1])
    end
end
h_avg_Awake = plot(Awake_time_matrix(1, :), Integrals_Awake_CumSum_Avg, 'b', 'LineWidth', Avg_LineWidth);
tmp_x = Awake_time_matrix(1, :)';
h_fill = fill([tmp_x; flipud(tmp_x)], [(Integrals_Awake_CumSum_Avg-Integrals_Awake_CumSum_StE)'; flipud((Integrals_Awake_CumSum_Avg+Integrals_Awake_CumSum_StE)')], [0, 0, 1], 'EdgeColor','none');
alpha(STE_alpha);
xlabel('Time After State Change [s]', 'FontSize', FontSize_Labels)
ylabel('Cumulative Sum (Average, Integral)', 'FontSize', FontSize_Labels)

% Plot NoNREM
[n_current_states, ~] = size(Integrals_NoNREM_CumSum);
if FLAG_Plot_SingleStates == 1
    for i_state = 1:n_current_states
        plot(NoNREM_time_matrix(i_state, :), NoNREM_Integral_matrix(i_state, :), 'r', 'Color', [1 , bk_lines_color_light, bk_lines_color_light])
    end
end
h_avg_NoNREM = plot(NoNREM_time_matrix(1, :),Integrals_NoNREM_CumSum_Avg, 'r', 'LineWidth', Avg_LineWidth);
tmp_x = NoNREM_time_matrix(1, :)';
h_fill = fill([tmp_x; flipud(tmp_x)], [(Integrals_NoNREM_CumSum_Avg-Integrals_NoNREM_CumSum_StE)'; flipud((Integrals_NoNREM_CumSum_Avg+Integrals_NoNREM_CumSum_StE)')], [1, 0, 0], 'EdgeColor','none');
alpha(STE_alpha);

% Plot REM
if ~isempty(REM_time_matrix)
    [n_current_states, ~] = size(Integrals_REM_CumSum);
    if FLAG_Plot_SingleStates == 1
        for i_state = 1:n_current_states
            plot(REM_time_matrix(i_state, :), REM_Integral_matrix(i_state, :), 'g', 'Color', [bk_lines_color_light , 1, bk_lines_color_light])
        end
    end
    h_avg_REM = plot(REM_time_matrix(1, :), Integrals_REM_CumSum_Avg, 'g', 'LineWidth', Avg_LineWidth);
    tmp_x = REM_time_matrix(1, :)';
    h_fill = fill([tmp_x; flipud(tmp_x)], [(Integrals_REM_CumSum_Avg-Integrals_REM_CumSum_StE)'; flipud((Integrals_REM_CumSum_Avg+Integrals_REM_CumSum_StE)')], [0, 1, 0], 'EdgeColor','none');
    alpha(STE_alpha);
end

% axis([0, x_max, 0, y_max])

if exist('h_avg_REM', 'var')
    legend([h_avg_Awake, h_avg_NoNREM, h_avg_REM], {'Awake', 'NoN-REM Sleep', 'REM Sleep'}, 'Location', 'NorthEast');
else
    legend([h_avg_Awake, h_avg_NoNREM], {'Awake', 'NoN-REM Sleep'}, 'Location', 'NorthEast');
end
legend({'Awake', 'NoN-REM Sleep'}, 'Location', 'NorthEast');

% Save files
if FLAG_Save == 1
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
end