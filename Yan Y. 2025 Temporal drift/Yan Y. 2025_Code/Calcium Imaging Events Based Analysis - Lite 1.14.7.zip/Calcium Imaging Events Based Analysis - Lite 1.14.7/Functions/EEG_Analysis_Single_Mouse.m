function [FreqPower, spindles] = EEG_Analysis_Single_Mouse (EEG_Data_Folder, MouseName, RecSession, Opts)
% Gets the Frequency Power Spectrum time series & spindles for the selected
% EEG recordings.
% The input EEG_Data_Folder is the folder where all the EEG Raw recordings
% are stored. The EEG is assumed to be already cut to fit with the Ca2+
% imaging data. The File name of an EEG recording is assumeed to be like
% "EEG1.mat" and "EEG2.mat", inside the folders <MOUSENAME> is to be 
% changed according to the name assigned to that mouse (e.g. MA035), 
% and the respective RecSession subfolders, something like "session_1".
% The EEG signal is intented to be already aligned with the start of the
% calcium imaging, without any weird addition of padding or margins before
% and after the actual segment of interest of the signal.


%% Options
FLAG_Plot = Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Plot;
FLAG_Save_Plot = Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Save_Plot;
FLAG_use_PSD = Opts.EEG.TimeFreqAnalyis.FLAG_use_PSD;
FileNameEEG_1 = 'EEG1'; % Prefix to the EEG Raw Recording File: after the "_" there should be the mouse name
FileNameEEG_2 = 'EEG2'; % Prefix to the EEG Raw Recording File: after the "_" there should be the mouse name
Hypnogram_FileName = 'hypnogram.mat'; % Name of the hypnogram file.

idxNREM = Opts.General.TagNoNREM;
SamplingRate_Hypnogram = Opts.General.FrameRate; % Sampling rate of the Calcium imaging and Hypnogram [Hz]


%% Load Data
% Check if files need loading.
if exist('MouseName', 'var') && exist('EEG_Data_Folder', 'var')
    if ~isempty(MouseName) && ~isempty(EEG_Data_Folder)
        EEG_Path = sprintf('%s\\%s\\session_%d', EEG_Data_Folder, MouseName, RecSession);
        EEG_FileName_1 = sprintf('%s.mat', FileNameEEG_1);
        EEG_FileName_2 = sprintf('%s.mat', FileNameEEG_2);
        EEG_FilePathFull_1 = [EEG_Path, '\' ,EEG_FileName_1];
        EEG_FilePathFull_2 = [EEG_Path, '\' ,EEG_FileName_2];
        if exist(EEG_Data_Folder, 'dir') ~= 0 && exist(EEG_FilePathFull_1, 'file') ~= 0
            if ~exist(sprintf('%s\\%s', EEG_Path, Hypnogram_FileName), 'file')
                warning('Could not find the hypnogram file, make sure that the file is called "hypnogram.mat".')
                FLAG_ask_user_path = 1;
            else
                Hypnogram_FilePath = EEG_Path;
                FLAG_ask_user_path = 0;
            end
        else
            warning('Could not find file "%s".', EEG_FilePathFull_1);
            FLAG_ask_user_path = 1;
        end
    else
        warning('Variables "MouseName" or "EEG_Data_Folder" are empty.')
        FLAG_ask_user_path = 1;
    end
else
    warning('Missing variable "MouseName", or "EEG_Data_Folder".')
    FLAG_ask_user_path = 1;
end

% Ask user for FilePaths, if needed.
if FLAG_ask_user_path == 1
    clear EEG_FileName; clear EEG_FilePath; clear Hypnogram_FileName; clear Hypnogram_FilePath;
    % Select EEG Data File.
    [EEG_FileName_1, EEG_Path] = uigetfile('.mat', 'Select EEG Raw File', pwd);
    % Select Hypnogram Data File.
    [Hypnogram_FileName, Hypnogram_FilePath] = uigetfile('.mat', 'Select Hypnogram File', pwd);
end

% Load EEG
fprintf('\nLoading EEG data for Mouse %s, Rec Session #%d\n', MouseName, RecSession);
tmp_data_struct = load(EEG_FilePathFull_1);
tmp_var_1 = struct2cell(tmp_data_struct);
EEG_SamplingRate_1 = tmp_var_1{1};
EEG_Channel_1 = tmp_var_1{2};
EEG_ID_1 = tmp_var_1{3};
EEG_Raw_Cell_1 = tmp_var_1{4};
fprintf('%s Loaded.\n', EEG_FileName_1);
% Convert into standard name.
if exist(EEG_FilePathFull_2, 'file') == 0 && exist(EEG_FilePathFull_1, 'file') ~= 0 % The EEG Channel 2 is missing
    fprintf('EEG2 missing. Using only EEG1 for Mouse %s, Rec Session #%d\n', MouseName, RecSession)
elseif exist(EEG_FilePathFull_2, 'file') ~= 0 && exist(EEG_FilePathFull_1, 'file') ~= 0
    clear tmp_data_struct
    tmp_data_struct = load(EEG_FilePathFull_2);
    tmp_var_2 = struct2cell(tmp_data_struct);
    EEG_SamplingRate_2 = tmp_var_2{1};
    EEG_Channel_2 = tmp_var_2{2};
    EEG_ID_2 = tmp_var_2{3};
    EEG_Raw_Cell_2 = tmp_var_2{4};
    fprintf('%s Loaded.\n', EEG_FileName_2);
    % Sanity checks on EEG Raw signals
    if EEG_SamplingRate_2 ~= EEG_SamplingRate_1
        error('Sampling Rate for EEG1 and EEG2 are different for mouse %s, %d !!!', MouseName, RecSession);
    end
    if numel(EEG_Raw_Cell_1) ~= numel(EEG_Raw_Cell_2)
        error('EEG1 and EEG2 have different number of points for mouse %s, %d !!!', MouseName, RecSession);
    end
end
EEG_n_channels = 2;
clear tmp*

% Update Sampling Rate
SamplingRate_EEG = EEG_SamplingRate_1;

% Load Hypnogram.
tmp_data_struct = load([Hypnogram_FilePath,'\' ,Hypnogram_FileName]);
fprintf('%s Loaded.\n\n', Hypnogram_FileName);
% Convert into standard name.
tmp_var_1 = struct2cell(tmp_data_struct);
tmp_var_2 = tmp_var_1{1, 1};
Hypnogram = tmp_var_2;
clear tmp*;

% Resample Hypnogram
Hypnogram_Resampled = round(resample(Hypnogram, 1:numel(Hypnogram), SamplingRate_EEG/SamplingRate_Hypnogram, SamplingRate_EEG, SamplingRate_Hypnogram, 'pchip'));
% Remove length difference due to resampling, if any.
length_diff = numel(EEG_Raw_Cell_1) - numel(Hypnogram_Resampled);
if length_diff > 0
    EEG_Raw_Cell_1((end-length_diff+1):end) = [];
    fprintf('EEG was cut of %d points at the end to match Hypnogram signal.\n', abs(length_diff));
elseif length_diff < 0
    Hypnogram_Resampled((end+length_diff+1):end) = [];
    fprintf('Hypnogram Resampled was cut of %d points at the end to match EEG signal.\n', abs(length_diff));
end
% Get the Raw EEG Traces 
EEG_Raw = [EEG_Raw_Cell_1; EEG_Raw_Cell_2];
% EEG Signal Length
EEG_Length = numel(EEG_Raw_Cell_1);


%% Analysis for different Channels.
windows_length = Opts.EEG.TimeFreqAnalyis.WinLengthMultiplier*SamplingRate_EEG; % For time frequency analysis
window_step = Opts.EEG.TimeFreqAnalyis.WindowStep; % For time frequency analysis
SmoothSpanWidth = Opts.EEG.TimeFreqAnalyis.Plot.SmoothSpanWidth; % For the plots
FreqPower = cell(EEG_n_channels, 1);
spindles = cell(EEG_n_channels, 1);
for i_Channel = 1:EEG_n_channels % Only 2 EEG channels are implemented ATM
    % EEG Channel
    Current_Channel_EEGRaw = EEG_Raw(i_Channel, :);
    fprintf('Analysing EEG%d\n', i_Channel);
    
    
    %% Spindles Detection
    [spindle_tmp, spindle_detection_param_tmp] = f_spindleDetectionMice_Nic(Current_Channel_EEGRaw, Hypnogram_Resampled, SamplingRate_EEG, idxNREM);
    
    
    %% Frequency-Time Analysis
    tmp_length = EEG_Length - windows_length;
    FreqPower_tmp.delta = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.delta1 = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.delta2 = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.theta = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.sigma = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.gamma = NaN(1, floor(EEG_Length/window_step));
    FreqPower_tmp.total = NaN(1, floor(EEG_Length/window_step));
    
    fprintf('\nGetting Frequency Powers Time Series...\n...\n')
    tic
    % Initializing waitbar.
    prog_bar = waitbar(0, 'Cylon virus detected!', 'Name', 'Computing Frequency Power...',...
        'CreateCancelBtn',...
        'setappdata(gcbf,''canceling'',1)');
    
    % Frequency Power Computation.
    i_window = 1;
    
    for i_time = 1:window_step:tmp_length
        % Update waitbar
        waitbar(i_time/tmp_length, prog_bar, sprintf('Computing Frequency Power at time point: %d / %d', i_time, tmp_length));
        if getappdata(prog_bar, 'canceling')
            delete(prog_bar);
            warning('Operation cancelled by user.');
            return
        end
        t_start = i_time;
        t_end = t_start + windows_length;
        current_EEG_window = Current_Channel_EEGRaw(t_start:t_end);
        if FLAG_use_PSD == 1
            FreqPower_tmp.delta(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta, 'psd');
            FreqPower_tmp.delta1(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta1, 'psd');
            FreqPower_tmp.delta2(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta2, 'psd');
            FreqPower_tmp.theta(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_theta, 'psd');
            FreqPower_tmp.sigma(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_sigma, 'psd');
            FreqPower_tmp.gamma(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_gamma, 'psd');
            FreqPower_tmp.total(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_tot, 'psd');
        else
            FreqPower_tmp.delta(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta);
            FreqPower_tmp.delta1(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta1);
            FreqPower_tmp.delta2(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_delta2);
            FreqPower_tmp.theta(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_theta);
            FreqPower_tmp.sigma(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_sigma);
            FreqPower_tmp.gamma(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_gamma);
            FreqPower_tmp.total(i_window) = bandpower(current_EEG_window, SamplingRate_EEG, Opts.EEG.FBand_tot);
        end
        if i_window == 20
            time_tmp = toc;
            time_estimated = (time_tmp/20)*((tmp_length/window_step)-1) - time_tmp;
            time_est_hour = floor(time_estimated/(60*60));
            time_est_m = floor( (time_estimated - time_est_hour*(60*60)) /60);
            time_est_s = floor(rem( (time_estimated - time_est_hour*(60*60)), 60));
            fprintf('Estimated time to complete: %dh:%dm:%ds.\n...\n', time_est_hour, time_est_m, time_est_s);
        end
        i_window = i_window + 1;
    end
    time_estimated = toc;
    time_comp_hour = floor(time_estimated/(60*60));
    time_comp_m = floor( (time_estimated - time_est_hour*(60*60)) /60);
    time_comp_s = floor(rem( (time_estimated - time_est_hour*(60*60)), 60));
    fprintf('Frequency Power Time Series Completed. Time elapsed: %dh:%dm:%ds.\n\n', time_comp_hour, time_comp_m, time_comp_s);
    delete(prog_bar);
    
    
    %% Plot Power Spectrum time series
    if FLAG_Plot == 1
        if i_Channel == 1
            figure;
        end
        subplot(2, 1, i_Channel);
        hold on;
        time_array = NaN(1, floor(EEG_Length/window_step));
        time_array(1:numel(0:1/(SamplingRate_EEG/window_step):tmp_length/SamplingRate_EEG)) = 0:1/(SamplingRate_EEG/window_step):tmp_length/SamplingRate_EEG;
        Plot_LineWidth = 1.5;
        Plot_LineWidthHypnogram = 2.5;
        FLAG_smooth_plot = 1;
        if FLAG_smooth_plot == 1
            plot(time_array, (smooth(smooth(FreqPower_tmp.delta./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
%             plot(time_array, (smooth(smooth(FreqPower_tmp.delta1./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
%             plot(time_array, (smooth(smooth(FreqPower_tmp.delta2./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
            plot(time_array, (smooth(smooth(FreqPower_tmp.theta./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
            plot(time_array, (smooth(smooth(FreqPower_tmp.sigma./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
            plot(time_array, (smooth(smooth(FreqPower_tmp.gamma./FreqPower_tmp.total, SmoothSpanWidth), SmoothSpanWidth)), 'LineWidth', Plot_LineWidth);
        else
            plot(time_array, FreqPower_tmp.delta./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
%             plot(time_array, FreqPower_tmp.delta1./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
%             plot(time_array, FreqPower_tmp.delta2./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
            plot(time_array, FreqPower_tmp.theta./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
            plot(time_array, FreqPower_tmp.sigma./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
            plot(time_array, FreqPower_tmp.gamma./FreqPower_tmp.total, 'LineWidth', Plot_LineWidth);
        end

        tmp = round(resample(Hypnogram_Resampled, 1, window_step));
        tmp2 = numel(tmp) - numel(time_array);
        if tmp2 > 0
            tmp(end-tmp2+1:end) = [];
        elseif tmp2 < 0
            time_array(end-abs(tmp2)+1:end) = [];
        end
        plot(time_array, tmp./4, 'k', 'LineWidth', Plot_LineWidthHypnogram)
        box on; grid on;
        xlim([0, inf]); ylim([0, 1]);
        xlabel('Time [s]');
        ylabel('Power(Fband)/Power(Tot)');
        TitleStr = sprintf('Windows Length = %g. EEG Channel %g.', windows_length, i_Channel);
        title(TitleStr, 'FontSize', 14);
%         legend('Delta 1', 'Delta 2', 'Theta', 'Sigma', 'Gamma');
        legend('Delta', 'Theta', 'Sigma', 'Gamma');
    end
        
    % Resample to match Calcium Imaging
    if Opts.EEG.FLAG_Resample2Calcium == 1
        FreqPower_tmp.delta = resample(FreqPower_tmp.delta, numel(Hypnogram), numel(FreqPower_tmp.delta));
        FreqPower_tmp.delta1 = resample(FreqPower_tmp.delta1, numel(Hypnogram), numel(FreqPower_tmp.delta1));
        FreqPower_tmp.delta2 = resample(FreqPower_tmp.delta2, numel(Hypnogram), numel(FreqPower_tmp.delta2));
        FreqPower_tmp.theta = resample(FreqPower_tmp.theta, numel(Hypnogram), numel(FreqPower_tmp.theta));
        FreqPower_tmp.sigma = resample(FreqPower_tmp.sigma, numel(Hypnogram), numel(FreqPower_tmp.sigma));
        FreqPower_tmp.gamma = resample(FreqPower_tmp.gamma, numel(Hypnogram), numel(FreqPower_tmp.gamma));
        FreqPower_tmp.total = resample(FreqPower_tmp.total, numel(Hypnogram), numel(FreqPower_tmp.total));
        
        % Update Spindles
        tmp = num2cell(round([spindle_tmp.Start].*(SamplingRate_Hypnogram/SamplingRate_EEG)));
        [spindle_tmp.Start] = tmp{:};
        
        tmp = num2cell(round([spindle_tmp.End].*(SamplingRate_Hypnogram/SamplingRate_EEG)));
        [spindle_tmp.End] = tmp{:};
    end
    FreqPower{i_Channel} = FreqPower_tmp;
    spindles{i_Channel} = spindle_tmp;
    clear FreqPower_tmp;
    clear spindle_tmp;
end

if FLAG_Plot == 1 && FLAG_Save_Plot == 1
    Figs_Path = sprintf('%s\\EEG FreqPower', Opts.Dir_Figures);
    if exist(Figs_Path, 'dir') == 0
        mkdir(Figs_Path);
        addpath(genpath(Figs_Path));
    end
    FileName = sprintf('%s_%d_EEG_FreqPower Plot', MouseName, RecSession);
    FilePath = sprintf('%s\\%s', Figs_Path, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end




