function Hist_Results = plot_histograms_v2(Events, HypnoState, Opts)
% Plots the pie plot of the states and events distribution, and the events
% characteristics histograms.
% The output is the fit of a gaussian over each of the events
% characteristics distributions.
% In this version of the function, the events are split between complex and
% singlets (tonic) ones.


Dir_Figures = Opts.Dir_Figures;

%% Split events between states.
Events_Awake = Events([Events.StateTag] == 1);
Events_NREM = Events([Events.StateTag] == 2);
Events_REM = Events([Events.StateTag] == 4);

% Get the total duration of sleep states.
for i_mouse = 1:numel(HypnoState)
    Duration_ToT.Awake = HypnoState(i_mouse).Duration.Awake;
    Duration_ToT.NoNREM = HypnoState(i_mouse).Duration.NoNREM;
    Duration_ToT.REM = HypnoState(i_mouse).Duration.REM;
end

n_Awake = numel(Events_Awake);
n_NonREM = numel(Events_NREM);
n_REM = numel(Events_REM);

% Correction for Amplitude
tmp = [Events_Awake.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_Awake.Amp_Baseline])
   Events_Awake(i).Amp_Baseline = tmp(i);
end
tmp = [Events_NREM.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_NREM.Amp_Baseline])
   Events_NREM(i).Amp_Baseline = tmp(i);
end
tmp = [Events_REM.Amp_Baseline];
tmp(tmp < 0) = NaN;
for i = 1:numel([Events_REM.Amp_Baseline])
   Events_REM(i).Amp_Baseline = tmp(i);
end
clear tmp

% Get Inter-Events-Interval
Events_Awake_IEI = NaN(1, numel(Events_Awake));
Events_NREM_IEI = NaN(1, numel(Events_NREM));
Events_REM_IEI = NaN(1, numel(Events_REM));
Events_IEI = NaN(1, numel(Events));
for i_event = 1:numel(Events_Awake)
    Events_Awake_IEI(i_event) = Events_Awake(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events_NREM)
    Events_NREM_IEI(i_event) = Events_NREM(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events_REM)
    Events_REM_IEI(i_event) = Events_REM(i_event).InterEventInterval;    
end
for i_event = 1:numel(Events)
    Events_IEI(i_event) = Events(i_event).InterEventInterval;    
end

% Histograms Options.
Opts_Hist.FLAGs.gaussian_model = 'gauss1'; % 'gauss1', 'gauss2', 'HalfNormal'
Opts_Hist.FLAGs.fit_G1 = 1;
Opts_Hist.FLAGs.fit_G2 = 1;

Opts_Hist.subplots_rows = 2;
Opts_Hist.subplots_columns = 3;
Opts_Hist.n_bins_large = double(idivide(numel(Events), int32(12)));
Opts_Hist.n_bins = double(idivide(min([n_Awake, n_NonREM, n_REM]), int32(8)));
if Opts_Hist.n_bins == 0
   Opts_Hist.n_bins = 15; 
end
Opts_Hist.hist_alpha = 0.5;
Opts_Hist.FLAG_PreDefinedBins = 0;
Opts_Hist.Dir_Figures = Dir_Figures;


%% --------------- Histograms of Singlet Events --------------- %%
if Opts.FLAG_Tonic == 1
    StrType = 'Tonic';
    fprintf('Plotting histograms of Tonics Events...\n')
elseif Opts.FLAG_Tonic == 0
    StrType = 'Composite';
    fprintf('Plotting histograms of Composite Events...\n')
end
if Opts_Hist.FLAGs.fit_G1 || Opts_Hist.FLAGs.fit_G2
    fprintf('Fitting a %s to the histograms...\n', Opts_Hist.FLAGs.gaussian_model)
end
Opts_Hist.SupTitleStr = sprintf('Duration of (%s) Events', StrType);
Opts_Hist.FileName = sprintf('Events Duration - %s', StrType);
Opts_Hist.LabelStr = 'Duration [s]';
Opts_Hist.FLAG_PreDefinedBins = 1;
Opts_Hist.Suite2p_Format = Opts.General.Suite2p_Format;
max_bin = 25;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Duration = plot_histogram_single([Events_Awake.Duration], [Events_NREM.Duration], [Events_REM.Duration], Duration_ToT, Opts_Hist);

Opts_Hist.SupTitleStr = sprintf('Integral of (%s) Events', StrType);
Opts_Hist.FileName = sprintf('Events Integral - %s', StrType);
Opts_Hist.LabelStr = 'Integral [DFoF * s]';
Opts_Hist.FLAG_PreDefinedBins = 1;
if Opts_Hist.Suite2p_Format == 1
    max_bin = ceil(nanmax([[Events_Awake.Integral], [Events_NREM.Integral], [Events_REM.Integral]]));
else
    max_bin = 200;
end
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Integral = plot_histogram_single([Events_Awake.Integral], [Events_NREM.Integral], [Events_REM.Integral], Duration_ToT, Opts_Hist);

Opts_Hist.SupTitleStr = sprintf('Amplitude of (%s) Events', StrType);
Opts_Hist.FileName = sprintf('Events Amplitude - %s', StrType);
Opts_Hist.LabelStr = sprintf('Amplitude [\\DeltaFoF]');
Opts_Hist.FLAG_PreDefinedBins = 1;
if Opts_Hist.Suite2p_Format == 1
    max_bin = ceil(nanmax([[Events_Awake.Amp_Baseline], [Events_NREM.Amp_Baseline], [Events_REM.Amp_Baseline]]));
else
    max_bin = 80;
end
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.Amplitude = plot_histogram_single([Events_Awake.Amp_Baseline], [Events_NREM.Amp_Baseline], [Events_REM.Amp_Baseline], Duration_ToT, Opts_Hist);

Opts_Hist.SupTitleStr = sprintf('Inter Events Interval of (%s) Events', StrType);
Opts_Hist.FileName = sprintf('Events IEI - %s', StrType);
Opts_Hist.LabelStr = sprintf('IEI [s]');
Opts_Hist.FLAG_PreDefinedBins = 1;
max_bin = 100;
Opts_Hist.Bins_Edges = 0:max_bin/Opts_Hist.n_bins:max_bin;
Hist_Results.IEI = plot_histogram_single(Events_Awake_IEI, Events_NREM_IEI, Events_REM_IEI, Events_IEI, Opts_Hist);

fprintf('Events Histogram Plots Done!\n\n')