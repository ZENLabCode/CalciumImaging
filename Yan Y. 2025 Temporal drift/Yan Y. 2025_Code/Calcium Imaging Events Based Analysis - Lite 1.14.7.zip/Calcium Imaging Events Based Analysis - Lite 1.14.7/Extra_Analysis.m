% Extra Analysis

%% Options
Opts.SaveFiguresAutomatically = 1;


%% Plot Artifacts and artifact removal
if Opts.General.EMG_Artifact_Filter == 1
    [Total_Transitions, Total_Transitions_Artifacts] = artifacts_check_allSessions (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
end


%% Events stats per state, per session.
% Events_Data contains N_Cells x States structures, with quantities
% relative to each single cell that are averaged over every state of that
% type. Cells belonging to all mice recorded are added in the same
% structures. The data is kept in a separate structure per recording
% session.
Opts.FLAG_Remove_Inactive_Cells = 0; % Remove entries in Events_Data for inactive cells? If not removed, the Events_Data will have more consistent number of cells, but their values will be filled with NaNs
[Events_Data, MouseMeans] = Init_Plot_EventsPerState(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, MouseCellsRecorded, Opts);

% Analysis per State
State_Info_perSession = SingleState_Analysis_per_mouse(Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);
SingleState_Analysis_Plots(State_Info_perSession, Mouse_Names, Opts);


%% Separated Events Type Analysis
[EventsSinglets, EventsComposite, EventsSubComposite] = SeparateEventType (Events_AllSessions);
[MeanEvent_Singlets, MeanEvent_Composites, N_Events] = mean_event_per_state (EventsSinglets, EventsComposite, Opts);
plot_pie_v2(EventsSinglets, EventsComposite, HypnoState, Opts.Dir_Figures);
Opts.FLAG_Tonic = 1; % Singlet events
Hist_Results_Singlets = plot_histograms_v2(EventsSinglets, HypnoState, Opts);
Opts.FLAG_Tonic = 0; % Composite events
Hist_Results_Composites = plot_histograms_v2(EventsComposite, HypnoState, Opts);

Opts.FLAG_Tonic = 0; % Composite events
Hist_Results_All = plot_histograms_v2(Events_AllSessions, HypnoState, Opts);

f1_options.bins_width = 0.5;


%% Plot bar - Events distribution per state, averages per mouse
EventsFreq_Results = plot_bar(Events_AllSessions, Mouse_Names, HypnoState, Hypnogram_AllSessions, MouseCellsRecorded, Opts);


%% Sync Analysis
[Sync_Stats, n_states_per_session] = sync_point_analysis (Events_AllSessions, Hypnogram_AllSessions, Opts);


%% Analysis of Continuous variables (Whole State Traces Correlation + Entropy; Sliding Window Correlation + Entropy)
[Mouse_Analysis, MeanOfStates_PerSession, MeanOfStates_PerMouse, Mouse_Analysis_CorrOrdered, MeanOfStates_CorrOrdered, CalciumTraces_Noisy_AllSessions, Stats_MeanOfStatesDifferences_PerSession, Stats_MeanOfStatesDifferences_PerMouse] = Continuous_Raw_Analysis (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);

% Analysis of binarized variables along sliding windows.
ContinuousResults = SyncPoint_Analysis_Continuous (Events_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts);



%% Max DFF Analysis
analyze_mattia_data


%% Phase State Analysis


%% === WIP ===
% Events Frequency matrix per cell, per state
event_frequency_per_state(Events_AllSessions, Hypnogram_AllSessions(1).Hypnogram, Hypnogram_AllSessions(1).StateDuration_Array, Opts);

% Get the events frequency per single cell, per state, for every mouse and
% session together
EventsFrequency_allMice = mean_per_cell (Events_AllSessions, Mouse_Names, Opts);
imagesc([[EventsFrequency_allMice.Awake]; [EventsFrequency_allMice.NREM]; [EventsFrequency_allMice.REM]]')

% Cluster Data According to their state of major activity.
Opts.ClusteringVariable = 'Events_Rate'; % 'Events_Rate', 'N_Events', or 'Integral_Sum'
[CellsPerState_Results, CellTag_perMouse, CellTagNum_perMouse] = clustering_cells_activitybased (Events_AllSessions, Mouse_Names, Opts);
plot_clustering(CellTagNum_perMouse, Opts)

% Clustering New
CellType = 'Pyramidal CMT';
Opts.CellType = CellType;
FLAG_PlotClustering_Single = 1;
Opts.ClusteringVariable = 'Events_Rate'; % 'Events_Rate', 'N_Events', or 'Integral_Sum'
Opts.ClusteringMethod = 1; % 1 = Simple max. 2 = Inactive cells & Max. 3 = Threshold on median Ca2+ Firing Rate
Mouse_Cells = cmp_number_of_cells (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names);
[CellsPerState_Results, CellTag_perMouse, CellTagNum_perMouse] = clustering_cells_activitybased (Events_AllSessions, Mouse_Names, Mouse_Cells, Opts);
Opts.tmp_FileName = sprintf('%s - Cells Clustered per State', CellType);
if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse, Opts); end



% Divide each trace per mouse, according to cell Tag

% Plot each trace average per state

% Divide the events per mouse, according to cell Tag

% Plot events shapes per state

% Plot events integrals etc..per state



%% Plots
if Opts.General.FLAG_Plots == 1
    % Plot Pie Chart of events frequency.
    % Plot Histograms of the events characteristics divided per state.
    Hist_Results = plot_histograms(Events_AllSessions, HypnoState, Opts.Dir_Figures);

    % Plot lags to previous State Change
    Sync2StateChange (Events_AllSessions, Mouse_Names, Opts)
    % Plot advance time to next State Change
    Sync2NextState (Events_AllSessions, Opts)
end