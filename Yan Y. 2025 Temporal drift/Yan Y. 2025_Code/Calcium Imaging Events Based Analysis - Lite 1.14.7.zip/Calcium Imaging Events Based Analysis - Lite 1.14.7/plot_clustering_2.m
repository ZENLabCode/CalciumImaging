function plot_clustering_2 (CellTagNum_perMouse, CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Opts)

% Divides the calcium traces per mouse according to their cluster tag,
% compute their average per state.


%% Initialize
n_mice = numel(CellTagNum_perMouse);
MeanOfTraces_perSession = cell(1, n_mice);
n_tags = 7;

% Max n_of_cells
tmp = NaN(1, n_mice);
for i_mouse = 1:n_mice
    [~, tmp(i_mouse)] = size(CalciumTraces_Clean_AllSessions{i_mouse});
end
n_cells_max = nanmax(tmp);

CellMeansTogether_StableState_1 = [];
CellMeansTogether_StableState_2 = [];
CellMeansTogether_StableState_4 = [];
for i_mouse = 1:n_mice
    
    % Make state_stable_TagArray
    StateStableTagArray = Hypnogram_AllSessions(i_mouse).StateDuration_Array;
    StateStableTagArray(StateStableTagArray < Opts.General.MinStableStateDuration) = 0;
    StateStableTagArray(StateStableTagArray >= Opts.General.MinStableStateDuration) = 1;
    Hypnogram_AllSessions(i_mouse).StateStableTagArray = StateStableTagArray;
    
    % Get the hypnogram of the current mouse
    Current_Hypnogram = Hypnogram_AllSessions(i_mouse).Hypnogram;
    
    % Get traces of the current mouse
    Current_Traces = CalciumTraces_Clean_AllSessions{i_mouse};
    
    % Get cell tags of the current mouse
    CurrentCellTags = CellTagNum_perMouse{i_mouse};
    CurrentActiveTags = CurrentCellTags(CurrentCellTags > 0);
    
    % Discrard Traces marked as inactive
    Current_ActiveTraces = Current_Traces(:, CurrentCellTags > 0);
    [~, n_ActiveCells] = size (Current_ActiveTraces);
    
    % Get only stable state of the wanted type, and glue the traces
    % together, then compute the average trace for that state...
    ActiveTraces_StableState_1 = Current_ActiveTraces(Current_Hypnogram == Opts.General.TagAWAKE, :);
    ActiveTraces_StableState_2 = Current_ActiveTraces(Current_Hypnogram == Opts.General.TagNoNREM, :);
    ActiveTraces_StableState_4 = Current_ActiveTraces(Current_Hypnogram == Opts.General.TagREM, :);
    
    MeanOfTrace_StableState_1 = nanmean(ActiveTraces_StableState_1, 1);
    MeanOfTrace_StableState_2 = nanmean(ActiveTraces_StableState_2, 1);
    MeanOfTrace_StableState_4 = nanmean(ActiveTraces_StableState_4, 1);
    
    MeanOfTraces = [MeanOfTrace_StableState_1; MeanOfTrace_StableState_2; NaN(1, n_ActiveCells); MeanOfTrace_StableState_4];
    MeanTraceAvg = nanmean(MeanOfTraces, 2);
    MeanOfTraces_perSession{i_mouse} = MeanOfTraces';
    MeanTraceAvg_perSession(i_mouse, :) = MeanTraceAvg';
    
    % Add all Traces with same tag together
    CellMeans_StableState_1 = NaN(n_tags, n_cells_max);
    CellMeans_StableState_2 = NaN(n_tags, n_cells_max);
    CellMeans_StableState_4 = NaN(n_tags, n_cells_max);
    for i_tag = 1:n_tags
        % Take cells with tag = i_tag, and their mean DFF per state
        CellMeans_StableState_1(i_tag, 1:numel(find(CurrentActiveTags == i_tag))) = MeanOfTrace_StableState_1(CurrentActiveTags == i_tag); % Mean Activity of cells with tag i during Awake
        CellMeans_StableState_2(i_tag, 1:numel(find(CurrentActiveTags == i_tag))) = MeanOfTrace_StableState_2(CurrentActiveTags == i_tag); % Mean Activity of cells with tag i during NREM
        CellMeans_StableState_4(i_tag, 1:numel(find(CurrentActiveTags == i_tag))) = MeanOfTrace_StableState_4(CurrentActiveTags == i_tag); % Mean Activity of cells with tag i during REM
        
        CellMeansTogether_StableState_1 = [CellMeansTogether_StableState_1, CellMeans_StableState_1];
        CellMeansTogether_StableState_2 = [CellMeansTogether_StableState_2, CellMeans_StableState_2];
        CellMeansTogether_StableState_4 = [CellMeansTogether_StableState_4, CellMeans_StableState_4];
    end
    
    % Clear out the crap
    clear ActiveTraces_StableState_1; clear ActiveTraces_StableState_2; clear ActiveTraces_StableState_4
    clear StateStableTagArray; clear MeanOfTraces
end

% Get the cluster mean
CellMeans_StableState_1_perTag = nanmean(CellMeansTogether_StableState_1, 2);
CellMeans_StableState_2_perTag = nanmean(CellMeansTogether_StableState_2, 2);
CellMeans_StableState_4_perTag = nanmean(CellMeansTogether_StableState_4, 2);
CellMeansTogether_perTag = [CellMeans_StableState_1_perTag, CellMeans_StableState_2_perTag, CellMeans_StableState_4_perTag];

% Get total mean
total_mean_per_state = nanmean(MeanTraceAvg_perSession, 1);

% Colors
ColorsScale(1, :) = [0, 0, 0]; % Non-Selective - Black
ColorsScale(2, :) = [1, 0, 1]; % Awake&NREM - Magenta
ColorsScale(3, :) = [0, 1, 1]; % Awake&REM - Cyan
ColorsScale(4, :) = [1, 1, 0]; % NREM&REM - Yellow
ColorsScale(5, :) = [0, 0, 1]; % Awake - Blue
ColorsScale(6, :) = [1, 0, 0]; % NREM - Red
ColorsScale(7, :) = [0, 1, 0]; % REM - Green

keyboard


%% Plot 1 - All Traces
figure;
for i_mouse = 1:n_mice
    % Get current cell tags
    CurrentCellTags = CellTagNum_perMouse{i_mouse};
    CurrentCellTags(CurrentCellTags == 0) = [];
    
    current_plot = MeanOfTraces_perSession{i_mouse};
    current_plot(:, 3) = [];
    [n_cells, ~] = size(current_plot);
    hold on;
    for i_cell = 1:n_cells
        plot(current_plot(i_cell, :), '-', 'Color', ColorsScale(CurrentCellTags(i_cell), :), 'LineWidth', 0.5);
    end
end
% Add mean average
total_mean_per_state(3) = [];
plot(total_mean_per_state, 'k', 'LineWidth', 4);
    
xticks([1, 2, 3])
xticklabels({'Awake', 'NREM', 'REM'})
ax = gca;
ax.YGrid = 'on';
box on

% Save
FileName = 'Figure Traces Clustered per State';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))
close gcf 


%% Plot 2 - Plot the cluster means

figure;
for i_tag = 1:n_tags
    hold on;
    plot(CellMeansTogether_perTag(i_tag, :), 'Color', ColorsScale(i_tag, :), 'LineWidth', 1.5)
end

% Add mean average
plot(total_mean_per_state, 'k', 'LineWidth', 5);
xticks([1, 2, 3])
xticklabels({'Awake', 'NREM', 'REM'})
ax = gca;
ax.YGrid = 'on';
box on

legend ({'Non-Selective','Awake&NREM','Awake&REM','NREM&REM','Awake','NREM','REM', 'Total Average'}, 'location', 'best')

% Save
FileName = 'Figure Cluster mean DFF per State';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
saveas(gcf, strcat(FilePath, '.jpg'))
saveas(gcf, strcat(FilePath, '.fig'))
close gcf 