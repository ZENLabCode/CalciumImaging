function [MeanEvent_Singlets, MeanEvent_Composites, N_Events] = mean_event_per_state (EventsSinglets, EventsComposite, Opts)
% This function computes the mean event shape separately for singlet events
% ("tonic" activity), and composite events.
% The mean event shape is computed for each state.

% Options
n_states = 4;
Opts.MeanEvent.n_EventsPlotted = 100;
Opts.MeanEvent.SupTitleFontSize = 18;
Opts.MeanEvent.FLAG_Save = 1;

PlotsOutputPath = [Opts.Dir_Figures, '\', 'Mean Events Shapes'];
if exist(PlotsOutputPath, 'dir') == 0
    mkdir(PlotsOutputPath)
    addpath(genpath(PlotsOutputPath));
end
Opts.MeanEvent.PlotsOutputPath = PlotsOutputPath;

% Separate Events between Stable and Unstable States
EventsSinglets_StateLength = [EventsSinglets.StateLength];
EventsSinglets_Stable = EventsSinglets(EventsSinglets_StateLength >= Opts.General.MinStableStateDuration);
EventsSinglets_Unstable = EventsSinglets(EventsSinglets_StateLength < Opts.General.MinStableStateDuration);

EventsComposite_StateLength = [EventsComposite.StateLength];
EventsComposite_Stable = EventsComposite(EventsComposite_StateLength >= Opts.General.MinStableStateDuration);
EventsComposite_Unstable = EventsComposite(EventsComposite_StateLength < Opts.General.MinStableStateDuration);

% Align all the shapes to zero
Events_Shapes = [EventsSinglets_Stable.Event];
E_Length = NaN(1, numel(Events_Shapes));
for i_event = 1:numel(Events_Shapes)
    E_Length(i_event) = numel(Events_Shapes{i_event});
end
MaxEventLength_Singlets = nanmax(E_Length);

Events_Shapes = [EventsComposite_Stable.Event];
E_Length = NaN(1, numel(Events_Shapes));
for i_event = 1:numel(Events_Shapes)
    E_Length(i_event) = numel(Events_Shapes{i_event});
end
MaxEventLength_Composite = nanmax(E_Length);

% Get States Tags
EventsSinglets_Stable_StateTag = [EventsSinglets_Stable.StateTag];
EventsComposite_Stable_StateTag = [EventsComposite_Stable.StateTag];

% Separate per State
EventsSinglets_Stable_State = cell(1, n_states);
EventsComposite_Stable_State = cell(1, n_states);
MeanEvent_Singlets = cell(1, n_states);
MeanEvent_Composites = cell(1, n_states);
TitlesCell = {'Awake', 'NREM', '', 'REM'};
for CurrentTag = 1:n_states
    if CurrentTag == 3
        continue
    end
    EventsSinglets_Stable_State{CurrentTag} = EventsSinglets_Stable(EventsSinglets_Stable_StateTag == CurrentTag);
    EventsComposite_Stable_State{CurrentTag} = EventsComposite_Stable(EventsComposite_Stable_StateTag == CurrentTag);
    
    % Get and plot mean events shapes.
    Opts.tmp.CurrentTag = CurrentTag;
    Opts.MeanEvent.SupTitle = sprintf('Events Shapes - Singlets - %s', TitlesCell{CurrentTag});
    Opts.MeanEvent.FileName = sprintf('Events Shapes - Singlets - %s', TitlesCell{CurrentTag});
    MeanEvent_Singlets{CurrentTag} = mean_event_plot (EventsSinglets_Stable_State{CurrentTag}, Opts);
    Opts.MeanEvent.SupTitle = sprintf('Events Shapes - Composite - %s', TitlesCell{CurrentTag});
    Opts.MeanEvent.FileName = sprintf('Events Shapes - Composite - %s', TitlesCell{CurrentTag});
    MeanEvent_Composites{CurrentTag} = mean_event_plot (EventsComposite_Stable_State{CurrentTag}, Opts);
    N_Events(CurrentTag).Singlets = numel(EventsSinglets_Stable_State);
    N_Events(CurrentTag).Composites = numel(EventsSinglets_Stable_State);
end


%% Plot Event Shape - Comparison Between States.

% Singlets
Opts.MeanEvent.SupTitle = 'Events - Tonic';
Opts.MeanEvent.FileName = sprintf('Events Shapes - Singlets - States Comparisons');

mean_event_plot_states_comparison (EventsSinglets_Stable_State, Opts);

% Composites
Opts.MeanEvent.SupTitle = 'Events - Composite';
Opts.MeanEvent.FileName = sprintf('Events Shapes - Composites - States Comparisons');

mean_event_plot_states_comparison (EventsComposite_Stable_State, Opts);
