function Events_Freq_Matrix = event_frequency_per_state(Events, Hypnogram, StateLength, Opts)

% Get total state duration
tmp = Hypnogram;
tmp(StateLength < 10) = [];
TotalDuration.Awake = numel(tmp(tmp == 1))./Opts.General.FrameRate;
TotalDuration.NREM = numel(tmp(tmp == 2))./Opts.General.FrameRate;
TotalDuration.REM = numel(tmp(tmp == 4))./Opts.General.FrameRate;

% Get each trace (cell) separately
cell_num_array = [Events.TraceNumber];
trace_i_max = nanmax(cell_num_array);
Events_Freq_Matrix = NaN(3, trace_i_max);
for i_cell = 1:trace_i_max
    Events_CurrentCell = Events(cell_num_array == i_cell);
    CurrentCell_state_array = [Events_CurrentCell.StateTag];
    
    % Separate per State
    Events_CurrentCell_Awake = Events_CurrentCell(CurrentCell_state_array == 1);
    Events_CurrentCell_NREM = Events_CurrentCell(CurrentCell_state_array == 2);
    Events_CurrentCell_REM = Events_CurrentCell(CurrentCell_state_array == 4);
    
    Events_Number_Awake(i_cell) = numel(Events_CurrentCell_Awake);
    Events_Number_NREM(i_cell) = numel(Events_CurrentCell_NREM);
    Events_Number_REM(i_cell) = numel(Events_CurrentCell_REM);
    
    Events_Freq_Awake(i_cell) = Events_Number_Awake(i_cell)./TotalDuration.Awake;
    Events_Freq_NREM(i_cell) = Events_Number_NREM(i_cell)./TotalDuration.NREM;
    Events_Freq_REM(i_cell) = Events_Number_REM(i_cell)./TotalDuration.REM;
    
    Events_Freq_Matrix(1, i_cell) = Events_Freq_Awake(i_cell);
    Events_Freq_Matrix(2, i_cell) = Events_Freq_NREM(i_cell);
    Events_Freq_Matrix(3, i_cell) = Events_Freq_REM(i_cell);
end

Events_Freq_Matrix = Events_Freq_Matrix';

figure;
imagesc(Events_Freq_Matrix)
xticks([1, 2, 3])
xticklabels({'Awake','NREM','REM'})
title (sprintf('Events rate per state\nPer Cell'))
ylabel('Cell ID')
tmp_colorbar = colorbar;
tmp_colorbar.Label.String = 'Events Rate [s]';

set(gca,'FontSize',14)


