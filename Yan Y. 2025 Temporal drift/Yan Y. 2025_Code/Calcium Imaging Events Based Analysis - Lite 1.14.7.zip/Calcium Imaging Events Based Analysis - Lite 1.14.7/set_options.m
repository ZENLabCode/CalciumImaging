function Opts = set_options (Dir_Main, Dir_Data)
% This function is used to set all the options for the whole analysis.

% Load some pre-set configuration for specific cell type (set 'Manual' to
% not load any pre-set config, but use only the manual options below): for
% now it changes only the options for the events detection.
FLAG_Cell_PreSet = 'Pyr'; % 'Manual', 'Pyr', 'Astro', 'Dendrites'


%% General Settings.
Opts.General.FrameRate = 3; % Frame Rate of the calcium traces. Default is 3 for 2-photon Data from Mattia
Opts.General.EEG_SamplingRate = 200; % Frame Rate of the EEG recordings. Default is 200 (data from Mattia or Lukas)
Opts.General.CellType = 'Dendrites_2'; % Can be 'Pyr', 'PV', 'Astro'
Opts.General.FLAG_Plots = 1; % 0 = Stop Plotting
Opts.General.MinStableStateDuration = 20*Opts.General.FrameRate; % Should always be a function of the FrameRate: change only the multiplier.
Opts.General.TagAWAKE = 1;
Opts.General.TagNoNREM = 2;
Opts.General.TagREM = 4;


%% Single Traces Analysis
Opts.SingleTraceAnalysis.FLAG_display = 1;
Opts.SingleTraceAnalysis.FLAG_display_neg_peak = 1;
Opts.SingleTraceAnalysis.FrameRate = Opts.General.FrameRate; % (3 for Mattia experiments, 10 for Miniscope)
Opts.SingleTraceAnalysis.FLAG_Verbose = 0; % Stop printing all messaged.
Opts.SingleTraceAnalysis.Interp_step = 0.01; % Default is 0.01
Opts.SingleTraceAnalysis.noise_estimation_steps = 2; % Estimate noise ignoring values vastly over the noise: repeat this steps N times
Opts.SingleTraceAnalysis.deriv_envelope_multiplier = 0; % value of 0, will set the derivative threshold to 0
% Find Peaks (with trace interpolation)
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 10;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 1; % 1 Default. Controls the multiplier to the noise, for the minimum peak prominence.
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 10;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = 50/Opts.SingleTraceAnalysis.Interp_step;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;
Opts.SingleTraceAnalysis.CheckEveryTrace = 0; % Debug: visual check of every trace
% Get Peaks function
Opts.SingleTraceAnalysis.GetPeaks.FLAG_PeakDetectionCheck = 0; % Check every detection visually?
Opts.SingleTraceAnalysis.GetPeaks.Save_EventShape = 0; % Save events shapes? Set to 0 to save lots of RAM
Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = 20/Opts.SingleTraceAnalysis.Interp_step; % Raise duration should be 200~300
Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 0; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 0; % In place of the second derivative, take its moving average.
Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
% Get Peaks function - Integrity checks
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (6/Opts.General.FrameRate); % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (3/Opts.General.FrameRate); % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 20; % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 1.5; % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.33;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 2; % 2 by default for DFoF
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 2; % 2 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegral = 5;
% Get Peaks function - Find Peaks in 2nd Derivative
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 1; % 1 Default. Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 1; % 1 Default. Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 5/Opts.SingleTraceAnalysis.Interp_step;
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 1;
% Negative Peaks
Opts.SingleTraceAnalysis.NegativePeaks.Smoothing_Steps = 3; % 3 default
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinBaseWidth = 10;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinHalfWidth = 5;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinAmplitude = 1*10^3;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinIntegral = 5;
Opts.SingleTraceAnalysis.NegativePeaks.FLAG_Display = 0;


%% Binarization of calcium events.
% This option decides what to set as '1' value in the events binarization:
% it can consider only the start or peak of every event.
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'. Default is 'StartComposite'.


%% SingleState Analysis (SingleState_Analysis_per_mouse)
% Binning.
Opts.SingleStateAnalysis.Sync_BinType = 'Weighted'; % 'Weighted' or 'Flat'.
Opts.SingleStateAnalysis.Sync_BinSize = 1; % A BinSize = 0 will make use of only the central bin.
Opts.SingleStateAnalysis.Sync_BinWeights = 'Gauss'; % To use in case of 'Weighted' BinTypes

% Which criteria to use for binarizing the signal?
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'

% Integrals Plot.
Opts.SingleStateAnalysis.Integrals.Plot.FLAG_Plot_SingleStates = 0; % Plot every single state trace (or just the average)?



%% Options Correlation Analysis (Analyze_Correlation_Film)
Opts.CorrAnalysis.n_shuffle_iterations = 200;
Opts.CorrAnalysis.Window_Length = 6*Opts.General.FrameRate; % 18 frames = 6 seconds
Opts.CorrAnalysis.FLAG_SkipUnstableStates = 1;
Opts.CorrAnalysis.FLAG_Plot_Graphs_All = 0;
Opts.CorrAnalysis.FLAG_Plot_Graphs_perMouse = 1;
Opts.CorrAnalysis.FLAG_Save_Film = 0;
Opts.CorrAnalysis.FLAG_Save_Plots = 1;
% The criterion for the correlations to be considered significant:              
% 'Shuffle Mean' threshold is the shuffle correlation mean + k* shuffle
%   correlation standard deviation, computed for each state separately.
% 'Shuffle Mean Uniform' is the same as before, but computed using the
% average standard deviation between all 
Opts.CorrAnalysis.Corr_Thr_Criterion = 'Shuffle Mean'; % 'Shuffle Mean', 'Shuffle Mean Uniform', 'Mean' ('Mean' and 'pValue' are partly supported, might return errors')
Opts.CorrAnalysis.Corr_Thr_Std_Multiplier = 2.5;
Opts.CorrAnalysis.Corr_Thr_Std_Multiplier_Mean = Opts.CorrAnalysis.Corr_Thr_Std_Multiplier;
% Reorder Traces and Correlation
Opts.CorrAnalysis.BaselineStateTag = 1; % Sort according to State with Tag = N (N = 1 -> Awake)
% Plot Options - Graphs
Opts.CorrAnalysis.Opts_GraphPlot.Centrality_Displayed = 'Degree Weighted'; % Centrality measure to be displayed
Opts.CorrAnalysis.Opts_GraphPlot.Marker_Thickness_Mult = 2;
% Plot Options - Mean of States Correlation Plots
Opts.CorrAnalysis.Opts_MeanStatesPlots.FLAG_Save = 1;


%% Continuous Analysis (Continuous_Raw_Analysis)
Opts.ContinuousAnalys.FLAG_AddWhiteNoise = 1; % Add white noise to calcium traces before computing the correlations? (destroy correlated noise), Default = 1
Opts.ContinuousAnalys.FLAG_Save_Film = 0; % Saves the correlation films Default = 1
Opts.ContinuousAnalys.FLAG_ReorderCorr = 0; % Reorder trace and repeat (part of) the analysis
% Plot Options
Opts.ContinuousAnalys.PlotEntropy.FLAG_Save = 1; % Default = 1
Opts.ContinuousAnalys.PlotEntropy.BoxHeight_Multiplier = 1.5; % Default 1.5
Opts.ContinuousAnalys.PlotEntropy.FontSize_ylabel = 12; % Default 12
Opts.ContinuousAnalys.PlotEntropy.FontSize_suptitle = 18; % Default 18


%% Continuous Analysis (Binarized Signal - PointSync Analysis)
Opts.ContinuousPointAnalysis.Window_Length = 3*Opts.General.FrameRate;
Opts.ContinuousPointAnalysis.FLAG_Plot = 1;
Opts.ContinuousPointAnalysis.FLAG_Save = 1;
Opts.ContinuousPointAnalysis.Entropy.Window_Length = 10*Opts.General.FrameRate;


%% Sync
Opts.Sync.NLagBins = 5;
% Plots
Opts.Sync.Plot.StE_alpha = 0.2;
Opts.Sync.Plot.Avg_LineWidth = 2;
Opts.Sync.Plot.n_bins = 50;
Opts.Sync.Plot.marker_size = 10;
Opts.Sync.Plot.dist_grid = 'on';
Opts.Sync.Plot.FLAG_Save = 1;
Opts.Sync.Plot.FLAG_Plot_AwakeDiffStates = 1; % Plot also the separate Awake after NoN-REM & Awake after REM states? 


%% EEG
% Frequency Bands
Opts.EEG.FBand_tot = [0.5, 99];
Opts.EEG.FBand_delta = [0.5, 4.5];
Opts.EEG.FBand_delta1 = [0.5, 1.5];
Opts.EEG.FBand_delta2 = [1.5, 4.5];
Opts.EEG.FBand_theta = [5, 9];
Opts.EEG.FBand_sigma = [11, 16];
Opts.EEG.FBand_gamma = [30, 99];
Opts.EEG.TimeFreqAnalyis.WinLengthMultiplier = 2; % Window Length = WinLengthMultiplier * SamplingRate_EEG
Opts.EEG.TimeFreqAnalyis.WindowStep = 20;  % That's the window advance step
Opts.EEG.TimeFreqAnalyis.FLAG_use_PSD = 0; % I suggest to keep = 0, as it is an untested feature
Opts.EEG.TimeFreqAnalyis.Plot.SmoothSpanWidth = 30; % How large is the smoothing window
Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Plot = 1;
Opts.EEG.TimeFreqAnalyis.Plot.FLAG_Save_Plot = 1;
Opts.EEG.FLAG_Resample2Calcium = 1; % Adapt the EEG Analysis (FreqPower & Spindles) to fit with the Calcium Imaging and its FrameRate.



%% Folders
if nargin > 0 % Save Main Dir
    if isempty (Dir_Main)
        Dir_Main = pwd;
    end
else
    Dir_Main = pwd;
end
Opts.Dir_Main = Dir_Main;
if nargin > 1 % Save Data Dir
    if isempty (Dir_Data)
        Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');
    end
else
    Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');
end
Opts.Dir_Data = Dir_Data;

% Add Figures Directories.
Opts.Dir_Figures = sprintf('%s\\Figures', Dir_Main);
if exist(Opts.Dir_Figures, 'dir') == 0
    Opts.Dir_Figures = uigetdir(Dir_Main, 'Choose Output Figures Folder');
end

fprintf('\n---\nMain Folder Set as "%s".\n', Opts.Dir_Main);
fprintf('Data Folder Set as "%s".\n', Opts.Dir_Data);
fprintf('Figures Folder Set as "%s".\n---\n', Opts.Dir_Figures);














%% Pre-Sets
if strcmpi(FLAG_Cell_PreSet, 'Pyr') == 1
    Opts.General.CellType = 'Pyr'; % Can be 'Pyr', 'PV', 'Astro'
    % Find Peaks (with trace interpolation)
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 3*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 1; % 1 Default. Controls the multiplier to the noise, for the minimum peak prominence.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 3.33*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = (16/Opts.SingleTraceAnalysis.Interp_step).*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;
    Opts.SingleTraceAnalysis.CheckEveryTrace = 0; % Debug: visual check of every trace
    % Get Peaks function
    Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
    Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = (6/Opts.SingleTraceAnalysis.Interp_step)*Opts.General.FrameRate; % Raise duration should be 200~300
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 0; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 0; % In place of the second derivative, take its moving average.
    Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
    % Get Peaks function - Integrity checks
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (1.3); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (1);
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 20; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 2; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.33;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 2; % 2 by default for DFoF
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 2; % 2 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegral = 5;
    % Get Peaks function - Find Peaks in 2nd Derivative
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 1; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 1; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 5/Opts.SingleTraceAnalysis.Interp_step;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 0;
elseif strcmpi(FLAG_Cell_PreSet, 'Dendrites_2') == 1
    Opts.General.CellType = 'Dendrites_2'; % Can be 'Pyr', 'PV', 'Astro', 'Dendrites'
    % Find Peaks (with trace interpolation)
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 3*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 3.5; % 2.5 Default. Controls the multiplier to the noise, for the minimum peak prominence.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 4*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = (16/Opts.SingleTraceAnalysis.Interp_step).*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;
    Opts.SingleTraceAnalysis.CheckEveryTrace = 0; % Debug: visual check of every trace
    % Get Peaks function
    Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
    Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = (6/Opts.SingleTraceAnalysis.Interp_step)*Opts.General.FrameRate; % Raise duration should be 200~300
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 0; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 0; % In place of the second derivative, take its moving average.
    Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
    % Get Peaks function - Integrity checks
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (1.4); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (1.1); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 18; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 2; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.33;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 2.3; % 2 by default for DFoF
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 2; % 2 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegral = 6;
    % Get Peaks function - Find Peaks in 2nd Derivative
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 1; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 1.5; % 1 Default. Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 5/Opts.SingleTraceAnalysis.Interp_step;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 0;
    
elseif strcmpi(FLAG_Cell_PreSet, 'Astro') == 1
    Opts.General.CellType = 'Astro'; % Can be 'Pyr', 'PV', 'Astro'
    % Find Peaks (with trace interpolation)
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 3*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 3; % 1 Default. Controls the multiplier to the noise, for the minimum peak prominence.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 5*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = (32/Opts.SingleTraceAnalysis.Interp_step).*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;
    Opts.SingleTraceAnalysis.CheckEveryTrace = 0; % Debug: visual check of every trace
    % Get Peaks function
    Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
    Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = (6/Opts.SingleTraceAnalysis.Interp_step)*Opts.General.FrameRate; % Raise duration should be 200~300
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 1; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 1; % In place of the second derivative, take its moving average.
    Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
    % Get Peaks function - Integrity checks
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (3); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (1.3); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 30; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 2; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.4;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 3; % 2 by default for DFoF
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 3; % 2 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegral = 4;
    % Get Peaks function - Find Peaks in 2nd Derivative
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 0.75; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 0.75; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 10/Opts.SingleTraceAnalysis.Interp_step;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 0;
elseif strcmpi(FLAG_Cell_PreSet, 'Dendrites') == 1
    Opts.General.CellType = 'Dendrites'; % Can be 'Pyr', 'PV', 'Astro', 'Dendrites'
    % Find Peaks (with trace interpolation)
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 3*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 3.5; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 3.5; % 2.5 Default. Controls the multiplier to the noise, for the minimum peak prominence.
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 4*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = (16/Opts.SingleTraceAnalysis.Interp_step).*Opts.General.FrameRate;
    Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;
    Opts.SingleTraceAnalysis.CheckEveryTrace = 0; % Debug: visual check of every trace
    % Get Peaks function
    Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
    Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = (6/Opts.SingleTraceAnalysis.Interp_step)*Opts.General.FrameRate; % Raise duration should be 200~300
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 0; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
    Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 0; % In place of the second derivative, take its moving average.
    Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
    % Get Peaks function - Integrity checks
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (1.3); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (1.3); % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 18; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 2; % [s]
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.33;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 2.4; % 2 by default for DFoF
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 2; % 2 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
    Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegral = 6;
    % Get Peaks function - Find Peaks in 2nd Derivative
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 1; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 1.5; % 1 Default. Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 5/Opts.SingleTraceAnalysis.Interp_step;
    Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 0;
    
end
