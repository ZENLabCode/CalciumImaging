function syncro_results = syncro_analysis (Events_AllMice, Hypnogram_AllMice, calTime, Hist_Results)
% This function performs the temporal analysis of the calcium events
% (synchronization)

n_mouse = numel(Hypnogram_AllMice);
n_Events_Tot = numel(Events_AllMice);

Opts.Max_EventsDistance = 10; % [frames, seconds = frames/3]

% Decide the maximum distance for two events to consider a measure of
% synchronicity.
tmp_max_std = nanmax([Hist_Results.IEI.Fit_Results.Awake.G1_std, Hist_Results.IEI.Fit_Results.NoNREM.G1_std, Hist_Results.IEI.Fit_Results.REM.G1_std]);
thr_events_vicinity = tmp_max_std/2;

% Make Binary Traces for Synchro Analysis.
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'
Binary_Traces_AllMice = make_binary_traces (Events_AllMice, Hypnogram_AllMice, calTime, Opts.MakeBinary);

figure(1);
for i_trace = 1:numel(Binary_Traces_AllMice{1, 7})
    subplot(2, 1, 1); hold on; grid on; grid minor; box on;
    plot(Binary_Traces_AllMice{1, 7}{1, i_trace} + 2*i_trace, 'k');
    subplot(2, 1, 2); hold on; grid on; grid minor; box on;
    plot(CalciumTraces(:, i_trace) +20*i_trace, 'g');
end
subplot(2, 1, 1);
axis([0, inf, -inf, inf])
subplot(2, 1, 2);
axis([0, inf, -inf, inf])

% Separate each Mouse binary traces by State.
for i_mouse = 1:n_mouse
    current_mouse_traces = (Binary_Traces_AllMice{i_mouse})';
    current_Hypnogram = Hypnogram_AllMice(i_mouse).Hypnogram;
    current_StateChanges = Hypnogram_AllMice(i_mouse).StateChanges;
    current_traces_matrix = cell2mat(current_mouse_traces);

    current_n_traces = numel(current_mouse_traces);
    current_n_states = numel(current_StateChanges);
    [current_n_cells, current_n_frames] = size(current_traces_matrix);
    
    % Computes the synchrony per single state (interval between 2 state
    % changes). Synchrony is defined as sum(binary events)/events(not
    % counting the overlapping ones).
    
    % Sync is the mean number of events in sync / #events, basically, it is
    % equivalent to the SPIKE-synchronization measure presented here:
    % http://www.scholarpedia.org/article/Measures_of_spike_train_synchrony
    synchron = NaN(1, current_n_states);
    for i_state = 1:current_n_states-1
        if current_StateChanges(i_state) > 1
            current_state = current_Hypnogram(current_StateChanges(i_state) - 1);
        elseif current_StateChanges(i_state) == 1
            current_state = current_Hypnogram(1);
        end
        current_trace_state = current_StateChanges(i_state):current_StateChanges(i_state + 1);
        tmp_sync = NaN(1, numel(1:current_trace_state(end)));
        tmp_sync(current_trace_state(1):current_trace_state(end)) = nansum(current_traces_matrix(:, current_trace_state(1):current_trace_state(end)), 1);
        tmp_sync(isnan(tmp_sync)) = [];
%         tmp_sync = tmp_sync./current_n_cells;
        n_events_no_overlap = numel(tmp_sync(tmp_sync > 0));
        n_events = nansum(tmp_sync);
        tmp_sync(tmp_sync == 0) = NaN;
        tmp_sync(tmp_sync == 1) = 0;
        n_events_overlap = nansum(tmp_sync);
        events_overlap_average = nanmean(tmp_sync);
        synchron(i_state) = events_overlap_average/n_events;
    end
    
    tmp_sync = NaN(1, current_n_frames);
    for i_frame = 1:current_n_frames
        current_frame = current_traces_matrix(:, i_frame);
        tmp_sync(i_frame) = nansum(current_frame);
    end
    tmp_sync = tmp_sync./current_n_cells;
    
    % Examine each trace separately.
    for i_trace = 1:n_traces-1
        current_trace = current_mouse_traces{i_trace};
        next_trace = current_mouse_traces{i_trace + 1};
        current_traces_matrix_mod = current_traces_matrix;
        current_traces_matrix_mod(i_trace, :) = [];
        
        % Compute the distance between each event of the current trace, and
        % any other event.
        tmp_events_pos = find(current_trace == 1);
        for i_event = 1:numel(tmp_events_pos)
            if tmp_events_pos(i_event) > Opts.Max_EventsDistance && tmp_events_pos(i_event) < numel(current_trace) - Opts.Max_EventsDistance
                tmp_trace_matrix = current_traces_matrix_mod(:, tmp_events_pos(i_event) - Opts.Max_EventsDistance:tmp_events_pos(i_event) + Opts.Max_EventsDistance);
            end
        end
%         [tmp_xcorr, lags_xcorr] = xcorr(current_trace, next_trace);
%         stem(lags_xcorr, tmp_xcorr)
    end
    clear current*
    clear next*
    clear tmp*
end

% Compute covariance, information, G.Causality matricex between traces,
% both in the case of the whole trace, and for long.

