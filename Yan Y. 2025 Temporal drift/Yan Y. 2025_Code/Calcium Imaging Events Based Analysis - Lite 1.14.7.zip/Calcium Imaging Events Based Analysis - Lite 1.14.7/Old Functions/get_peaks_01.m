function Pos_Peaks = get_peaks(trace, FLAG_display)
% This function gets the peaks in the Ca2+ signal, their characteristics,
% and saves them as output.

% Peaks candidates are first identified, their characteristics measured,
% then a sanity check is made for the peak candidates, removing the ones
% with implausible characteristics.


%% Options
interp_step = 0.01; % 0.01 default
noise_estimation_steps = 1;
smoothing_steps = 3; % 3 default
deriv_thr_multiplier = 1.5;
deriv_envelope_multiplier = 0; % value of 0, will set the derivative threshold to 0
event_end_thr_multiplier = 1;
prePeak_interval_length = 1500; % Raise duration should be 200~300
    
% Options - Integrity checks.
IntCheck.MinBaseWidth = 10;
IntCheck.MinHalfWidth = 5;
IntCheck.MinAmplitude = 1*10^3;
IntCheck.MinIntegral = 5;


%% Preliminary peaks localization.

n_datapoints = numel(trace);

% Get an estimation of the noise. (multiple steps of std estimation)
[noise_estimate, median_estimate] = estimate_noise (trace, noise_estimation_steps);

% Interpolate trace.
tmpX_raw = 1:1:n_datapoints;
tmpX_interp = 0:interp_step:n_datapoints;
trace_interp = spline(tmpX_raw, trace, tmpX_interp);

% Restore NaNs lost during the interpolation.
trace_interp = Restore_NaNs_InterpSmooth (trace, trace_interp, interp_step);

% Find Peaks
FindPeaks_Opt.trace_interp.MinPeak_Dist = 10;
FindPeaks_Opt.trace_interp.MinPeak_Heigth = median_estimate + 4*noise_estimate; % Should be = baseline + noise.
FindPeaks_Opt.trace_interp.MinPeak_Prom = noise_estimate;
FindPeaks_Opt.trace_interp.MinPeak_Width = 10;
FindPeaks_Opt.trace_interp.MaxPeak_Width = 50/interp_step;
FindPeaks_Opt.trace_interp.Display = 1;
[~, peaks_location, ~, ~] = findpeaks_shortform (trace_interp, FindPeaks_Opt.trace_interp);
n_peaks = numel(peaks_location);

% Compute derivative.
trace_interp_diff = diff(trace_interp);
trace_interp_diff = [NaN; trace_interp_diff];
trace_interp_diff2 = diff(trace_interp_diff);
trace_interp_diff2 = [NaN; trace_interp_diff2];

% % Smooth the derivatives. ---> Smooth then interpolate
% trace_interp_diff_smooth = trace_interp_diff;
% tic
% for i_smoothing = 1:1 % smoothing_steps
%     trace_interp_diff_smooth = smooth(trace_interp_diff_smooth);
% end
% toc
% % Restore NaNs lost during the interpolation.
% trace_interp_diff_smooth = Restore_NaNs_InterpSmooth (trace_interp_diff, trace_interp_diff_smooth, 1);

% Estimate derivative std, in 2 steps.
trace_interp_diff_std_tmp = nanstd(trace_interp_diff);
tmp = trace_interp_diff;
for i = 1:numel(trace_interp_diff)
    if tmp(i) > trace_interp_diff_std_tmp || tmp(i) < -trace_interp_diff_std_tmp
        tmp(i) = NaN;
    end
end

% Get Threshold.
trace_interp_diff_std = nanstd(tmp);
noise_thr_diff = trace_interp_diff_std.*deriv_thr_multiplier;

% Plot Check
DUMMY = 1; % This is just for readability (to collapse the while)
while FLAG_display == 1 && DUMMY == 1
    figure; set(gcf,'position', get(0,'screensize'));
    subplot(4,1,1); plot(trace_interp); grid on; grid minor; axis tight;
    ylabel('\DeltaF/F');
    title('Signal Control', 'FontSize', 14)
    subplot(4,1,2); plot((trace_interp_diff)); grid on; grid minor; axis tight; hold on;
    line([0, numel(trace_interp_diff)], [noise_thr_diff, noise_thr_diff], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    line([0, numel(trace_interp_diff)], [-noise_thr_diff, -noise_thr_diff], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
    ylabel('d`\DeltaF/F')
    subplot(4,1,3); plot(trace_interp_diff2); grid on; grid minor; axis tight;
    ylabel('d``\DeltaF/F'); xlabel ('Frames');
    
    subplot(4,1,4);
    findpeaks(trace_interp, ...
        'MinPeakHeight', FindPeaks_Opt.trace_interp.MinPeak_Heigth, ...
        'MinPeakProminence', FindPeaks_Opt.trace_interp.MinPeak_Prom, ...
        'MinPeakDistance', FindPeaks_Opt.trace_interp.MinPeak_Dist, ...
        'MinPeakWidth', FindPeaks_Opt.trace_interp.MinPeak_Width, ...
        'MaxPeakWidth', FindPeaks_Opt.trace_interp.MaxPeak_Width, ...
        'Annotate', 'extents');
    s = findobj('type','legend');
    delete(s); grid minor; axis tight;
    ylabel('\DeltaF/F'); xlabel ('Frames');
    title('Identified Peaks', 'FontSize', 14)
    DUMMY = 0;
end

% Initialize.
% Events = struct;
Events = cell(1, n_peaks);
Events_interpolated = cell(1, n_peaks);
Events_Start = NaN(1, n_peaks);
Events_End = NaN(1, n_peaks);
Events_Duration = NaN(1, n_peaks);
Events_Baseline = NaN(1, n_peaks);
Events_Composite = cell(1, n_peaks);
Events_Composite_Tag = NaN(1, n_peaks);
Events_Composite_Group_Tag = NaN(1, n_peaks);
Events_Composite_Duration = NaN(1, n_peaks);
Events_HalfWidth = NaN(1, n_peaks);
Events_peak_value = NaN(1, n_peaks);
Events_peak_loc = NaN(1, n_peaks);
Events_Amp_StartEnd = NaN(1, n_peaks);
Events_Amp_Baseline = NaN(1, n_peaks);
Events_Integral = NaN(1, n_peaks);
i_composite = 1;

% Scroll each candidate peak.
for i_peak = 1:n_peaks
    % Get a fixed interval before the peak.
    if peaks_location(i_peak) > prePeak_interval_length
        tmp_start = peaks_location(i_peak) - prePeak_interval_length;
    else
        tmp_start = 1;
    end
    tmp_pre_event = trace_interp(tmp_start:peaks_location(i_peak)-1);
    tmp_pre_event_diff2 = trace_interp_diff2(tmp_start:peaks_location(i_peak)-1);
    [tmp_noise_estimate, tmp_median_estimate] = estimate_noise (tmp_pre_event_diff2, noise_estimation_steps);
    
    % Find 2nd derivative peaks here.
    FindPeaks_Opt.diff2.MinPeak_Dist = 5;
    FindPeaks_Opt.diff2.MinPeak_Heigth = tmp_noise_estimate; % Should be = 0 + noise.
    FindPeaks_Opt.diff2.MinPeak_Prom = tmp_noise_estimate;
    FindPeaks_Opt.diff2.MinPeak_Width = 5;
    FindPeaks_Opt.diff2.MaxPeak_Width = 5/interp_step;
    FindPeaks_Opt.diff2.Display = 0;
    
    [~, tmp_peaks_location, ~, ~] = findpeaks_shortform (tmp_pre_event_diff2, FindPeaks_Opt.diff2);

    % Find the 2nd derivative peak that is closest to the signal peak:
    % this is the event_start.
    tmp_event_start = tmp_peaks_location(end);
    Events_Start(i_peak) = peaks_location(i_peak) - (prePeak_interval_length - tmp_event_start);
    
    % Get the median of the interval of values before the starting of the
    % event. This is the "baseline" value of the event neighbourhood.
    % Get new points, in case another event is present...
    Events_Baseline(i_peak) = nanmedian(tmp_pre_event(1:tmp_event_start));
    
    if i_peak > 1 % Does not apply to the 1st event.
        % TRYING TO MAKE IT ITERATIVE, but needs every time to extend the
        % pre event interval, not just recompute it.
%         i_peak_1 = i_peak;
%         while (i_peak_1 > 1) && abs(Events_End(i_peak_1 - 1) - Events_Start(i_peak_1)) < prePeak_interval_length
            if abs(Events_End(i_peak - 1) - Events_Start(i_peak)) < prePeak_interval_length % If the previous event inside the "pre-event" zone of the following event
                % Extend length of the pre-event area of the event i, of the
                % duration of the event i-1; then set all the values
                % corresponding to the event i-1 to NaNs, and recompute the
                % baseline level.
                prePeak_interval_length_2 = prePeak_interval_length + Events_Duration(i_peak - 1);
                tmp_start_2 = peaks_location(i_peak) - prePeak_interval_length_2;
                tmp_pre_event_2 = trace_interp(tmp_start_2:peaks_location(i_peak)-1);
                tmp_c1 = find(tmp_pre_event_2 == trace_interp(Events_End(i_peak - 1)));
                tmp_c2 = find(tmp_pre_event_2 == trace_interp(Events_Start(i_peak - 1)));
                tmp_pre_event_2(tmp_c2:tmp_c1) = NaN(numel(tmp_c2:tmp_c1), 1);
                % Recompute baseline.
                Events_Baseline(i_peak) = nanmedian(tmp_pre_event_2(1:tmp_event_start));
%                 
%             else
%                 break
            end
%             i_peak_1 = i_peak_1 - 1;
%         end
    end

    % Check when the event will reach baseline (+ noise) again, 
    % this is the end of  the event. 
    % (unless another event will start during this time, in
    % this case, that will also become the end of the previous event.
    for i_t = peaks_location(i_peak):numel(trace_interp)
        if trace_interp(i_t) <= Events_Baseline(i_peak) + tmp_noise_estimate*event_end_thr_multiplier
            Events_End(i_peak) = i_t;
            
            if i_peak == 1 % Assign the 1st tag.
                Events_Composite_Group_Tag(1) = 1;
            elseif i_peak > 1
                % If another event starts before the previous one finishes, that becomes the end of the previous event
                if Events_Start(i_peak) <= Events_End(i_peak - 1)% Events are together.
                    Events_End(i_peak - 1) = Events_Start(i_peak);
                    Events_Composite_Group_Tag(i_peak) = i_composite; % Assign the same tag to the composite event.
                elseif Events_Start(i_peak) > Events_End(i_peak - 1) % Events are separated.
                    i_composite = i_composite + 1;
                    Events_Composite_Group_Tag(i_peak) = i_composite;
                end
            end
            
            break
        end
    end
    % Event (interpolated)
    Events{i_peak} = trace_interp(Events_Start(i_peak):Events_End(i_peak));
    
    % Get Event Duration (End - Start + 1)
    Events_Duration(i_peak) = Events_End(i_peak) - Events_Start(i_peak) + 1;
    
    % Peak value & loc
    [Events_peak_value(i_peak), Events_peak_loc(i_peak)] = nanmax(Events{i_peak});
    
    % Amplitude from Start/End
    tmp_base = nanmean([Events_End(i_peak), Events_Start(i_peak)]);
    Events_Amp_StartEnd(i_peak) = nanmax(Events{i_peak} - tmp_base);
    
    % Amplitude from Baseline
    Events_Amp_Baseline(i_peak) = nanmax(Events{i_peak} - Events_Baseline(i_peak));
    
    % HalfWidth from Start/End
    Events_HalfWidth(i_peak) = compute_HalfWidth(Events_Amp_StartEnd(i_peak), Events{i_peak}, interp_step);

    % Integral
    Events_Integral(i_peak) = sum(Events{i_peak}(Events{i_peak} > 0));
    
end

% Set Composite Event Binary Tag.
for i_peak = 1:n_peaks
    count_grp = numel(find(Events_Composite_Group_Tag == Events_Composite_Group_Tag(i_peak)));
    if count_grp > 1
        Events_Composite_Tag(i_peak) = 1;
    else
        Events_Composite_Tag(i_peak) = 0;
    end
end
tmp_events_2 = [];
for i_peak = 1:n_peaks
    tmp_events_1 = find(Events_Composite_Group_Tag == Events_Composite_Group_Tag(i_peak));
%     fprintf('Grp Tag %d\n', tmp_events_1)
    if isempty(tmp_events_2)
        tmp_events_2 = tmp_events_1;
    end
    
%     if numel(tmp_events_2) == numel(tmp_events_1) % If the 2 events are part of the same group
%         if min(tmp_events_2 == tmp_events_1) == 1 % If the 2 events are part of the same group
            event_composite_start = Events_Start(tmp_events_1(1));
            event_composite_end = Events_End(tmp_events_1(end));
            Events_Composite{i_peak} = trace_interp(Events_Start(tmp_events_1(1)):Events_End(tmp_events_1(end)));
%         else % If the 2 events are NOT part of the same group
%             
%         end
%     else % If the 2 events are NOT part of the same group
%         
%     end
%     Events_Composite
    
    tmp_events_2 = tmp_events_1;
end

% End point for composite events.
trace_interp_NaNless = NaN_to_NeighbourhoodMean(trace_interp);

% Get signal envelope.
maxima_EnvPeakSep = 250;
[trace_envelope, ~] = envelope(trace_interp_NaNless, maxima_EnvPeakSep, 'peak');
trace_envelope_diff = diff(trace_envelope);
trace_envelope_diff = [NaN; trace_envelope_diff];
trace_envelope_diff = Restore_NaNs_InterpSmooth (trace, trace_envelope_diff, interp_step);

% Get the end of the composite events through the envelope derivative.
% (gets only the end of single events, or of the last event of a complex)
% Estimate derivative noise FIRST
[noise_envelope_diff, ~] = estimate_noise (trace_envelope_diff, noise_estimation_steps);
% Get new event end.
i_peak = 1;
while i_peak <= n_peaks
    current_group_tag = Events_Composite_Group_Tag(i_peak);
    last_event_group = nanmax(find(Events_Composite_Group_Tag == current_group_tag));
    i_peak = last_event_group;
    fprintf('Peak to re-examine = %d\n', i_peak)
    for i_t = peaks_location(i_peak)+4/interp_step:numel(trace_interp)
        if isnan(trace_envelope_diff(i_t))
            if trace_envelope_diff(i_t) >= -(noise_envelope_diff*deriv_envelope_multiplier)
                Events_End(i_peak) = i_t;
                fprintf('Updated Event End for peak #%d\n', i_peak)
                break
            end
        else
            Events_End(i_peak) = i_t;
            fprintf('Updated Event End for peak #%d\n', i_peak)
            break
        end
    end
    i_peak = i_peak + 1;
end

% Plot to visualize event start-end.
figure();
subplot(2, 1, 1);
plot(trace_interp, 'LineWidth', 1); 
hold on; box on; grid on; grid minor; axis tight;
plot(Events_Start, Events_Baseline, '^r');
plot(Events_End, Events_Baseline, 'vr');
plot(trace_envelope, 'g');
legend({'Signal', 'Event Start', 'Event End', 'Envelope', 'Event End Updated'})

subplot(2, 1, 2);
plot(trace_envelope_diff, 'g')
hold on; box on; grid on; grid minor; axis tight;
line([0, numel(trace_envelope_diff)], [-(noise_envelope_diff*deriv_envelope_multiplier), -(noise_envelope_diff*deriv_envelope_multiplier)], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5)
legend({'d(Envelope)', 'd(Envelope) Threshold'})


figure();
subplot(2,1,1); hold on;
plot(Events_End, Events_Baseline, 'vk');
legend({'Signal', 'Event Start', 'Event End', 'Envelope', 'Event End Updated'})
subplot(2,1,2); hold on;
plot(Events_End, 0, 'vk');
legend({'d(Envelope)', 'd(Envelope) Threshold', 'Event End Updated'})

% Update {duration, Event, Event_interpolated Baseline} of events.
for i_peak = 1:n_peaks
    Events_Duration(i_peak) = Events_End(i_peak) - Events_Start(i_peak) + 1;
%     Events{i_peak} = trace(Events_Start(i_peak):Events_End(i_peak));
    Events_interpolated{i_peak} = trace(Events_Start(i_peak):Events_End(i_peak));
    Events_baseline_value = nanmin(Events_interpolated{i_peak});
    
end

% Get characteristics of complex events. 
for i_peak = 1:n_peaks
    current_group_tag = Events_Composite_Group_Tag(i_peak);
    current_group = find(Events_Composite_Group_Tag == current_group_tag);
    % Start & End
    tmp_Start = Events_Start(current_group);
    tmp_End = Events_End(current_group);
    Group_End(i_peak) = tmp_End(end);
    Group_Start(i_peak) = tmp_Start(1);
    % Duration
    Events_Composite_Duration(i_peak) = Group_End(i_peak) - Group_Start(i_peak);
    % Max peak value
    
    % Max peak loc
    
    % Amplitude from Start/End
    
    % Amplitude from Baseline
    
    % HalfWidth from Start/End
    
    % Integral
end

% Divide signal in up/down states (?)


% Plot.
figure(); 
subplot(3,1,1); plot(trace, 'LineWidth', 1.5); ylabel('Trace'); axis tight; grid on; hold on;
line([0, n_datapoints], [median_estimate + noise_estimate, median_estimate + noise_estimate], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 0.5)
line([0, n_datapoints], [median_estimate, median_estimate], 'Color', 'y', 'LineStyle', '--', 'LineWidth', 1)
line([0, n_datapoints], [median_estimate - noise_estimate, median_estimate - noise_estimate], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 0.5)
subplot(3,1,2); plot(trace_smooth, 'LineWidth', 1.5);  ylabel('Trace Smooth'); axis tight; grid on; hold on;
line([0, n_datapoints], [median_estimate + noise_estimate, median_estimate + noise_estimate], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 0.5)
line([0, n_datapoints], [median_estimate, median_estimate], 'Color', 'y', 'LineStyle', '--', 'LineWidth', 1)
line([0, n_datapoints], [median_estimate - noise_estimate, median_estimate - noise_estimate], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 0.5)
subplot(3,1,3); plot(trace, 'LineWidth', 1.5); ylabel('Trace'); axis tight; grid on; hold on;
plot()




