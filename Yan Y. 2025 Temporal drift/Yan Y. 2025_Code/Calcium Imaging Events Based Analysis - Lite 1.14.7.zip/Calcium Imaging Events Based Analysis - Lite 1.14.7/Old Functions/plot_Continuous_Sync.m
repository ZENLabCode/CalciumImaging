function plot_Continuous_Sync (ContinuousResults, Hypnogram_AllMice, Mouse_Names, Opts)
% This function plots the continuos analysis results (Sync only for now)

FrameRate = Opts.General.FrameRate;
n_mice = Opts.n_mice;

% Options - Plot
box_height_multiplier = 1.2;
FontSize_ylabel = 9;
FontSize_suptitle = 18;
str_suptitle = sprintf('Events (point-)Sync');
FileName = 'Continuous Sync';

% Get global maxmum sync.
for i_mouse = 1:n_mice
    current_sync = ContinuousResults.Sync_Index(i_mouse, :);
    current_Hypno = Hypnogram_AllMice(i_mouse).Hypnogram;
    tmp_maxX(i_mouse) = numel(current_Hypno);
    tmp_maxY(i_mouse) = nanmax(current_sync);
    tmp_minY(i_mouse) = nanmin(current_sync);
end
maxXglobal = nanmax(tmp_maxX)./FrameRate;
maxYglobal = nanmax(tmp_maxY);
minYglobal = nanmin(tmp_minY);

% Plot Sync vs States
figure(); set(gcf,'position', get(0,'screensize'));
for i_mouse = 1:n_mice
    current_Hypno = Hypnogram_AllMice(i_mouse).Hypnogram;
    current_StateChanges = Hypnogram_AllMice(i_mouse).StateChanges;
    n_states = numel(current_StateChanges);
    current_sync = ContinuousResults.Sync_Index(i_mouse, :);
    current_sync(numel(current_Hypno)+1:end) = [];
    time_array = (1:1:numel(current_Hypno))./FrameRate;
    
    maxY = nanmax(current_sync).*box_height_multiplier;
    minY = nanmin(current_sync).*box_height_multiplier;
    if minY == 0
        minY = -0.2;
    end
    
    h_subplot = subplot(n_mice, 1, i_mouse);
    hold on; box on; grid on; grid minor;
    plot(time_array, current_sync, 'k');
    for i_state = 1:n_states
        if i_state < n_states
            end_state = (current_StateChanges(i_state+1) - 1)./FrameRate;
        else
            end_state = numel(current_Hypno)./FrameRate;
        end
        boxX = [current_StateChanges(i_state)./FrameRate, current_StateChanges(i_state)./FrameRate, end_state, end_state];
        boxY = [minY, maxYglobal.*box_height_multiplier, maxYglobal.*box_height_multiplier, minY];
        switch current_Hypno(current_StateChanges(i_state))
            case 1; BoxColor = [0 0 1];
            case 2; BoxColor = [1 0 0];
            case 4; BoxColor = [0 1 0];
        end
        h_array(i_state) = patch(boxX, boxY, BoxColor, 'FaceAlpha', 0.1);
    end
    h_subplot.XMinorTick = 'on'; h_subplot.YMinorTick = 'on';
    axis([0, maxXglobal, minYglobal, maxYglobal])
    
    str_ylabel = sprintf('Point Sync\n(Mouse #%s)', Mouse_Names{i_mouse});
    ylabel(str_ylabel, 'FontSize', FontSize_ylabel)
end

xlabel('Time [s]');

% Suptitle
h_suptitle = suptitle(str_suptitle);
h_suptitle.FontSize = FontSize_suptitle;
h_suptitle.FontWeight = 'bold';

if Opts.ContinuousPointAnalysis.FLAG_Save == 1
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
end