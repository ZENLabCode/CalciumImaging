
warning('off', 'MATLAB:chckxy:IgnoreNaN'); % Ignore spline interpolation warning messages.

% Add Default Directories
Dir_Main = pwd;
addpath(genpath(Dir_Main));
addpath(genpath('Z:\Lab_resources\calcium_imaging_toolbox'));
fprintf('Please Specify the Data Folder.')
Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');

Opts = set_options (Dir_Main, Dir_Data);
Opts.DendriteAnalysis.min_n_pixels = 12;
Opts.DendriteAnalysis.grid_size_input = 7;
Opts.DendriteAnalysis.max_frames_between_events = 10;


% Ask user for the data format.
window_title = 'Data format.';
string_tmp = 'Please select your data format.';
FileTypeToConvert = questdlg(string_tmp, window_title, 'Multiple tif files', 'Single tif file', 'avi/mov', 'Multiple tif files');
assert(~isempty(FileTypeToConvert), 'Operation stopped by user.');

fprintf('\nImportant: it is advised to use .tif files, use avi/mov only if .tif is not available.\n');
fprintf('(Note that loading big files might require several Gb of RAM!)\n');
FLAG_multi_tif = 0;
FLAG_single_tif = 0;
tic

% Load images stack matrix and get infos.
[images_stack, images_info] = load_tiff_stack ([]);
file_name_tmp = images_info.Filename;

images_stack_info = images_info(1);
images_stack_info.FileName_short = strtok(file_name_tmp, '.');
images_stack_info.FileName_extention = '.tif';
images_stack_info.number_of_frames = numel(images_info);
clear images_info;
FLAG_single_tif = 1;

[img_stack_projection, img_stack_proj_info] = compute_img_stack_projection(images_stack, 'avg');
background_img = img_stack_projection;
[dim1, dim2] = size(background_img);

cstrFilenames = 'C:\Users\nicco\OneDrive\Desktop\Calcium Imaging ARES Toolbox 1.04\New folder (4)\Example dendri\MA095\02.06.2020\RoiSet.zip';
[sROI] = ReadImageJROI(cstrFilenames);
n_ROIs = numel(sROI);

% Analyze whole ROIs




% Make Overlay
ROI_Overlay_Base = zeros(dim1, dim2);
for i_ROI = 1:n_ROIs
    current_ROI_Surface = ROI_Overlay_Base;
    current_ROI_Points = sROI{1, i_ROI}.mnCoordinates;
    for i_ROIpoint = 1:numel(current_ROI_Points(:,1))
        current_x = current_ROI_Points(i_ROIpoint, 1);
        current_y = current_ROI_Points(i_ROIpoint, 2);
        current_ROI_Surface(current_x, current_y) = 1;
    end
    % Fill Gaps at the border and Fill ROI
    current_ROI_Surface = Fill_ROI_Gaps (current_ROI_Surface);
    ROI_Surfaces{i_ROI} = current_ROI_Surface;
end

% Remove overlapping sections of the ROIs.
tic
ROI_Surfaces = remove_overlapping_ROI_sections (ROI_Surfaces);
toc

imshow(current_ROI_Surface)

figure
img_tot = zeros(size(ROI_Surfaces{i_ROI}));
for i_ROI = 1:n_ROIs
    img_tot = img_tot + ROI_Surfaces{i_ROI};
    
end
imshow(img_tot)
close gcf


overlay_tag_input = 2;
overlay_tag = cell(1, n_ROIs);
ROI_masks = cell(1, n_ROIs);
ROI_fragmented_overlay = cell(1, n_ROIs);
ROI_overlay = cell(1, n_ROIs);
for i_ROI = 1:n_ROIs
    % Selected ROI
    selected_ROI = ROI_Surfaces{i_ROI};
    
    % ROI is turned
    
    % ROI is segmented
    [ROI_fragmented_overlay{i_ROI}, ROI_masks{i_ROI}, overlay_tag{i_ROI}] = segment_ROI_into_regions (selected_ROI, Opts.DendriteAnalysis.grid_size_input, overlay_tag_input);
    imshow(ROI_fragmented_overlay{i_ROI})
    selected_ROI_overlay = ROI_fragmented_overlay{i_ROI};
    
    ROI_overlay{i_ROI} = make_ROI_with_0_overlay (selected_ROI, selected_ROI_overlay);
    [overlay_boundaries{i_ROI}, overlay_labels{i_ROI}, overlay_number_of_regions{i_ROI}] = bwboundaries(ROI_overlay{i_ROI}, 8, 'noholes');

end
close gcf

figure
img_tot = zeros(size(ROI_overlay{i_ROI}));
for i_ROI = 1:n_ROIs
    img_tot = img_tot + ROI_overlay{i_ROI};
    
end
imshow(img_tot)
close gcf


% Opts.Interp_step = 0.01;
% Opts.NegativePeaks.Smoothing_Steps = 3;
% Opts.NegativePeaks.FLAG_Display = 0;
% Opts.FLAG_display = 0;
n_timepoints = numel(Hypnogram);

% Get each sub-ROI trace
tic
for i_ROI = 1:n_ROIs
    
    try
        n_subROI = overlay_number_of_regions{i_ROI};
        fprintf('-- Analyzing ROI #%d with %d subROIs --\n', i_ROI, n_subROI);

        selected_region_tag = i_ROI;
        [time_series_region{i_ROI}, n_region_pixels{i_ROI}, region_pixels_allROI{i_ROI}] = get_subregion_TS (images_stack, overlay_labels{i_ROI}, n_subROI, Opts);
        current_time_series_region = time_series_region{i_ROI};
        current_region_pixels = region_pixels_allROI{i_ROI};
        
        region_centers = NaN(n_subROI, 2);
        for i_subROI = 1:n_subROI
            % Get Region Centers
            region_centers(i_subROI, :) = get_region_centers(current_region_pixels{i_subROI});
            % Select average time series and smooth it
            if isstruct(current_time_series_region{i_subROI})
                current_time_series_subregion_mean{i_subROI} = current_time_series_region{i_subROI}.average;
                current_time_series_subregion_mean_smooth{i_subROI} = smooth(smooth(current_time_series_subregion_mean{i_subROI}));
            else
                fprintf('Sub_ROI #%d has not enough pixels.\n', i_subROI);
                current_time_series_subregion_mean{i_subROI} = NaN(1, n_timepoints);
                current_time_series_subregion_mean_smooth{i_subROI} = NaN(1, n_timepoints);
            end
        end
        % Get region distances
        region_distances = squareform(pdist(region_centers));
        % Make matrix of bordering subregions. 1 = first neighbours, 2 =
        % second neighbours
        region_neighbouring = region_distances;
        region_neighbouring(region_neighbouring == 0) = NaN;
        region_neighbouring(region_neighbouring <= Opts.DendriteAnalysis.grid_size_input) = 1;
        region_neighbouring(region_neighbouring > Opts.DendriteAnalysis.grid_size_input.*sqrt(2)) = 0;
        region_neighbouring(region_neighbouring > 1) = 2;
        
        % Save for each ROI
        n_regions(i_ROI) = n_subROI;
        region_centers_allROI{i_ROI} = region_centers;
        region_distances_allROI{i_ROI} = region_distances;
        region_neighbouring_allROI{i_ROI} = region_neighbouring;
        time_series_subregion_mean_allROI{i_ROI} = current_time_series_subregion_mean;
        mean_subregion_trace_allROI{i_ROI} = nanmean(cell2mat(current_time_series_subregion_mean'));
        time_series_subregion_mean_smooth_allROI{i_ROI} = current_time_series_subregion_mean_smooth;
    catch
        keyboard
    end
end
toc

try
    
    EventsCourse_allROI = cell(1, n_ROIs);
    Events_StateTag_allROI = cell(1, n_ROIs);
    warning_count_out_of_bounds = 0;
    for i_ROI = 1:n_ROIs
        current_time_series_subregion_mean_smooth = time_series_subregion_mean_smooth_allROI{i_ROI};
        current_mean_subregion_trace = mean_subregion_trace_allROI{i_ROI};
        current_region_neighbouring = region_neighbouring_allROI{i_ROI};
        current_region_distances = region_distances_allROI{i_ROI};
        
        First_Event_Start = NaN(1, n_subROI);
        First_Event_Amplitude = NaN(1, n_subROI);
        tmp_First_Active_Region = NaN(1, n_subROI);
        for i_subROI = 1:n_subROI
            % Get Events
            [Events, StateChanges, StateLength, n_removed, trace_clean] = analyze_single_trace (current_time_series_subregion_mean_smooth{i_subROI}, Hypnogram, current_mean_subregion_trace, i_subROI, Opts.SingleTraceAnalysis);
            close gcf
            if isempty(Events)
                First_Event_Start(1, i_subROI) = NaN;
                First_Event_Amplitude(1, i_subROI) = NaN;
                tmp_First_Active_Region(1, i_subROI) = NaN;
                Events_Peaks = NaN;
                Events_Start = NaN;
                Events_Amplitude = NaN;
                Events_StateTag = NaN;
            else
                Events_Start = [Events.Start];
                Events_Peaks = [Events.PeakLoc];
                Events_Amplitude = [Events.Amp_Baseline];
                Events_StateTag = [Events.StateTag];
                
                % Get 1st event start
                [First_Event_Start(1, i_subROI), tmp_First_Active_Region(1, i_subROI)] = nanmin (Events_Peaks);% nanmin (Events_Start);
                First_Event_Amplitude(1, i_subROI)
            end
            
            Events_Peak_allSubRegion{i_subROI} = Events_Peaks;
            Events_Start_allSubRegion{i_subROI} = Events_Start;
            Events_StateTag_allSubRegion{i_subROI} = Events_StateTag;
        end
        
        % Get the maximum number of peaks
        tmp_n_peaks = NaN(1, n_subROI);
        for i_subROI = 1:n_subROI
            Current_Peaks_Position = Events_Peak_allSubRegion{i_subROI};
            Current_StateTag = Events_StateTag_allSubRegion{i_subROI};
            [Current_Peaks_Position, unique_indexes] = unique(Current_Peaks_Position); % remove duplicate errors
            Current_StateTag = Current_StateTag(unique_indexes);
            Events_Peak_allSubRegion{i_subROI} = Current_Peaks_Position;
            Events_StateTag_allSubRegion{i_subROI} = Current_StateTag;
            tmp_n_peaks(i_subROI) = numel(Current_Peaks_Position(~isnan(Current_Peaks_Position)));
        end
        tmp_n_peaks_max = nanmax(tmp_n_peaks);
        
        % Make the table of all events peaks per subregion.
        Events_Peak_allSubRegion = Events_Peak_allSubRegion';
        Events_StateTag_allSubRegion = Events_StateTag_allSubRegion';
        E_Peaks_allSR_matrix = NaN(numel(Events_Peak_allSubRegion), tmp_n_peaks_max);
        E_StateTags_allSR_matrix = NaN(numel(Events_StateTag_allSubRegion), tmp_n_peaks_max);
        for i_subROI = 1:n_subROI
            Current_Peaks_Position = Events_Peak_allSubRegion{i_subROI};
            Current_StateTags = Events_StateTag_allSubRegion{i_subROI};
            E_Peaks_allSR_matrix(i_subROI, 1:numel(Current_Peaks_Position)) = Current_Peaks_Position;
            E_StateTags_allSR_matrix(i_subROI, 1:numel(Current_StateTags)) = Current_StateTags;
        end
        % Remove zeros
        E_StateTags_allSR_matrix(E_Peaks_allSR_matrix == 0) = NaN;
        E_Peaks_allSR_matrix(E_Peaks_allSR_matrix == 0) = NaN;
        
        tmp_E_Peaks_allSR_matrix = E_Peaks_allSR_matrix;
        max_frames_between_events = Opts.DendriteAnalysis.max_frames_between_events;
        DUMMY = 1;
        i_EventCourse = 1;
        
        
        while DUMMY == 1
            tmp = tmp_E_Peaks_allSR_matrix;
            if isnan(max(nanmax(tmp))) == 1
                break
            end
            % Find the first Event
            CurrentEvent = min(nanmin(tmp_E_Peaks_allSR_matrix));
            [contemp_row, ~] = find(tmp_E_Peaks_allSR_matrix == CurrentEvent);
            [contemp_row, contemp_col] = find(tmp_E_Peaks_allSR_matrix <= CurrentEvent + max_frames_between_events);
            
            % Find the closest Event
            if numel(contemp_row) > 1
                if i_EventCourse == 3
                    %                 keyboard
                end
                for i_1 = 1:numel(contemp_row)
                    Event_Couple(1, i_1) = tmp_E_Peaks_allSR_matrix(contemp_row(i_1), contemp_col(i_1));
                end
                
                CurrentEvent = CurrentEvent(1);
                CurrentEvent_subROI = contemp_row;
                tmp_Event_Start = Event_Couple(1);
                tmp_Event_StateTag = Hypnogram(tmp_Event_Start);
                EventsCourse(i_EventCourse).Frames = Event_Couple;
                EventsCourse(i_EventCourse).Regions = contemp_row;
                
                % Get max distance between regions
                
                i_dist = 1;
                distances_reg = [];
                for i_reg_1 = 1:numel(contemp_row)
                    for i_reg_2 = 1:numel(contemp_row)
                        try
                            distances_reg(i_dist) = current_region_distances (contemp_row(i_reg_1), contemp_row(i_reg_2));
                            i_dist = i_dist + 1;
                        catch
                            warning_count_out_of_bounds = warning_count_out_of_bounds + 1;
                            [h1, h2] = nanmax(contemp_row);
                            continue
                            contemp_row(h2) = [];
                            try
                                distances_reg(i_dist) = current_region_distances (contemp_row(i_reg_1), contemp_row(i_reg_2));
                            catch
                                distances_reg(i_dist) = current_region_distances (contemp_row(i_reg_1), contemp_row(i_reg_2 - 1));
                            end
                            i_dist = i_dist + 1;
                        end
                    end
                end
                
                event_distance = nanmax(distances_reg);
                EventsCourse(i_EventCourse).MaxDistance = event_distance;
                EventsCourse(i_EventCourse).StateTag = tmp_Event_StateTag;
                
                i_EventCourse = i_EventCourse + 1;
                clear Event_Couple
                clear distances_reg
                tmp(tmp == CurrentEvent) = NaN;
                NextEvent = min(nanmin(tmp));
                if isnan(NextEvent)
                    break
                end
            end
            tmp(tmp == CurrentEvent) = NaN;
            tmp_E_Peaks_allSR_matrix = tmp;
            
            if isempty(contemp_row)
                NextEvent = min(nanmin(tmp));
                if isnan(NextEvent)
                    break
                end
            end
            clear contemp_row
        end
        
        EventsCourse_allROI{i_ROI} = EventsCourse;
        Events_StateTag_allROI{i_ROI} = Events_StateTag_allSubRegion;
        clear EventsCourse
        clear Events_StateTag_allSubRegion
    end
    
catch ME
    keyboard
end


% Get average per dendrite per state
for i_ROI = 1:n_ROIs
    current_Events_Course = EventsCourse_allROI{i_ROI};
    current_StateTag = [current_Events_Course.StateTag];
    current_Events_Course_Awake = current_Events_Course(current_StateTag == 1);
    current_Events_Course_NREM = current_Events_Course(current_StateTag == 2);
    current_Events_Course_REM = current_Events_Course(current_StateTag == 4);
    AverageDistance_perROI(i_ROI).Awake = nanmean([current_Events_Course_Awake.MaxDistance]);
    AverageDistance_perROI(i_ROI).NREM = nanmean([current_Events_Course_NREM.MaxDistance]);
    AverageDistance_perROI(i_ROI).REM = nanmean([current_Events_Course_REM.MaxDistance]);
    AverageNEvent_perROI(i_ROI).Awake = numel([current_Events_Course_Awake.MaxDistance]);
    AverageNEvent_perROI(i_ROI).NREM = numel([current_Events_Course_NREM.MaxDistance]);
    AverageNEvent_perROI(i_ROI).REM = numel([current_Events_Course_REM.MaxDistance]);
end

DistAvg_All_Awake = nanmean([AverageDistance_perROI.Awake]);
DistAvg_All_NREM = nanmean([AverageDistance_perROI.NREM]);
DistAvg_All_REM = nanmean([AverageDistance_perROI.REM]);

DistStd_All_Awake = nanstd([AverageDistance_perROI.Awake]);
DistStd_All_NREM = nanstd([AverageDistance_perROI.NREM]);
DistStd_All_REM = nanstd([AverageDistance_perROI.REM]);

DistStE_All_Awake = DistStd_All_Awake./sqrt(n_ROIs);
DistStE_All_NREM = DistStd_All_NREM./sqrt(n_ROIs);
DistStE_All_REM = DistStd_All_REM./sqrt(n_ROIs);


%% Bar Plot
x = 1:3;
data = [DistAvg_All_Awake, DistAvg_All_NREM, DistAvg_All_REM]';
errhigh = [DistStE_All_Awake, DistStE_All_NREM, DistStE_All_REM];
errlow  = [DistStE_All_Awake, DistStE_All_NREM, DistStE_All_REM];
h_barplot = bar(x, data);
hold on
er = errorbar(x,data,errlow,errhigh);    
er.Color = [0 0 0];                            
er.LineStyle = 'none';  
hold off
title(sprintf('Average Calcium Propagation \n in Dendrites (n = 1 mouse, 50 dendrites)'), 'FontSize', 16)
xticklabels({'Awake', 'NREM', 'REM'})
xlabel('State', 'FontSize',14)
ylabel('Distance [AU]', 'FontSize',14)
grid on;




n_row = 4;
n_col = 1;
subplot(n_row,n_col,1)
plot(smooth(time_series_region{1, 15}.average))
subplot(n_row,n_col,2)
plot(smooth(time_series_region{1, 16}.average))
subplot(n_row,n_col,3)
plot(smooth(time_series_region{1, 17}.average))
subplot(n_row,n_col,4)
plot(smooth(time_series_region{1, 34}.average))
plot_tests

