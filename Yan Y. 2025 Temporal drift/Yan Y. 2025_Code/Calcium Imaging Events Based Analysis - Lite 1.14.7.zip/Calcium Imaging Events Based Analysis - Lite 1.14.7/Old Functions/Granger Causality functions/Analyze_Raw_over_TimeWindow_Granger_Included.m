function [correlation_film, entropy_trace] = Analyze_Raw_over_TimeWindow (CalciumTraces, Hypnogram_CurrentMouse, MouseName)
% This function computes the correlation coefficients between each traces,
% over a sliding time window.


%% Options.
FLAG_Save_Film = 0;

window_length = 18; % 18 frames = 6 seconds
Title_FontSize = 16;
Title_FontWeight = 'bold';
Title_FontColor = 'k';
Film_FrameRate = 10;

% Grager Causality
FLAG_Granger = 0;
maxlag1 = 3;
maxlag2 = 3;
minlag2 = 0; % either 1 or 0
significance_thr = 0.01;


%% Computations
% Sliding Window.
sliding_window = ones(1, window_length);

[n_time_points, n_traces] = size(CalciumTraces);
Combinations = nchoosek(1:1:n_traces, 2);
[n_combinations, ~] = size(Combinations);
film_length = n_time_points - window_length + 1;

correlation_film = NaN(n_traces, n_traces, film_length);
entropy_trace = NaN(1, film_length);
if FLAG_Granger == 1
    fprintf('Computing Correlation & GC Films.\n');
    GC_Film = NaN(n_traces, n_traces, film_length);
    GC_Film_Shuffled = NaN(n_traces, n_traces, film_length);
    GC_Film_Filtered = NaN(n_traces, n_traces, film_length);
    Shuffling_GCMax = NaN(1, film_length);
end
tic
for i_time = 1:film_length
% for i_time = 1:10 % TEST
    % Prepare time window
    current_window = zeros(1, n_time_points);
    current_window(1, i_time:i_time + window_length - 1) = sliding_window;
    current_traces = CalciumTraces;
    current_traces(current_window == 0, :) = [];
    current_traces_shuffled = shuffle_matrix(current_traces, 2);
    current_traces_shuffled2 = shuffle_matrix(current_traces, 2);
    current_traces_shuffled3 = shuffle_matrix(current_traces, 2);
    current_traces_shuffled4 = shuffle_matrix(current_traces, 2);
    
    % Correlation
    [current_corr_matrix, p_val_matrix] = corr(current_traces);
    correlation_film(1:n_traces, 1:n_traces, i_time) = current_corr_matrix;
    
    % Granger Causality
    if FLAG_Granger == 1
        fprintf('Granger Causality Frame %d.\n', i_time)
        % GC
        current_GC_matrix = NaN(n_traces, n_traces);
        for i_combination = 1:n_combinations
            trace1 = current_traces(:, Combinations(i_combination, 1));
            trace2 = current_traces(:, Combinations(i_combination, 2));
            [GC_tmp.F, GC_tmp.c_v, GC_tmp.Fprob, GC_tmp.Fprob_Corrected, GC_tmp.dAIC, GC_tmp.dBIC, GC_tmp.chosen_x_lag, GC_tmp.chosen_y_lag] = granger_cause_1(trace1, trace2, significance_thr, maxlag1, 1, maxlag2, 1, minlag2, [], [], [], [], [], [], 0);
            current_GC_matrix(Combinations(i_combination, 1), Combinations(i_combination, 2)) = GC_tmp.F;
            current_GC_matrix(Combinations(i_combination, 2), Combinations(i_combination, 1)) = GC_tmp.F;
        end
        % GC Shuffle Matrix
        current_GC_matrix_shuffled = NaN(n_traces, n_traces);
        for i_combination = 1:n_combinations
            trace1 = current_traces_shuffled(:, Combinations(i_combination, 1));
            trace2 = current_traces_shuffled(:, Combinations(i_combination, 2));
            [GC_tmp_shuf.F, GC_tmp_shuf.c_v, GC_tmp_shuf.Fprob, GC_tmp_shuf.Fprob_Corrected, GC_tmp_shuf.dAIC, GC_tmp_shuf.dBIC, GC_tmp_shuf.chosen_x_lag, GC_tmp_shuf.chosen_y_lag] = granger_cause_1(trace1, trace2, significance_thr, maxlag1, 1, maxlag2, 1, minlag2, [], [], [], [], [], [], 0);
            current_GC_matrix_shuffled(Combinations(i_combination, 1), Combinations(i_combination, 2)) = GC_tmp_shuf.F;
            current_GC_matrix_shuffled(Combinations(i_combination, 2), Combinations(i_combination, 1)) = GC_tmp_shuf.F;
        end
        tmp = max(nanmax(current_GC_matrix_shuffled));
        Shuffling_GCMax(i_time) = tmp;
        
        % GC Shuffle Matrix2
        current_GC_matrix_shuffled2 = NaN(n_traces, n_traces);
        for i_combination = 1:n_combinations
            trace1 = current_traces_shuffled2(:, Combinations(i_combination, 1));
            trace2 = current_traces_shuffled2(:, Combinations(i_combination, 2));
            [GC_tmp_shuf.F, GC_tmp_shuf.c_v, GC_tmp_shuf.Fprob, GC_tmp_shuf.Fprob_Corrected, GC_tmp_shuf.dAIC, GC_tmp_shuf.dBIC, GC_tmp_shuf.chosen_x_lag, GC_tmp_shuf.chosen_y_lag] = granger_cause_1(trace1, trace2, significance_thr, maxlag1, 1, maxlag2, 1, minlag2, [], [], [], [], [], [], 0);
            current_GC_matrix_shuffled2(Combinations(i_combination, 1), Combinations(i_combination, 2)) = GC_tmp_shuf.F;
            current_GC_matrix_shuffled2(Combinations(i_combination, 2), Combinations(i_combination, 1)) = GC_tmp_shuf.F;
        end
        tmp2 = max(nanmax(current_GC_matrix_shuffled2));
        Shuffling_GCMax2(i_time) = tmp2;
        
        % GC Shuffle Matrix3
        current_GC_matrix_shuffled3 = NaN(n_traces, n_traces);
        for i_combination = 1:n_combinations
            trace1 = current_traces_shuffled3(:, Combinations(i_combination, 1));
            trace2 = current_traces_shuffled3(:, Combinations(i_combination, 2));
            [GC_tmp_shuf.F, GC_tmp_shuf.c_v, GC_tmp_shuf.Fprob, GC_tmp_shuf.Fprob_Corrected, GC_tmp_shuf.dAIC, GC_tmp_shuf.dBIC, GC_tmp_shuf.chosen_x_lag, GC_tmp_shuf.chosen_y_lag] = granger_cause_1(trace1, trace2, significance_thr, maxlag1, 1, maxlag2, 1, minlag2, [], [], [], [], [], [], 0);
            current_GC_matrix_shuffled3(Combinations(i_combination, 1), Combinations(i_combination, 2)) = GC_tmp_shuf.F;
            current_GC_matrix_shuffled3(Combinations(i_combination, 2), Combinations(i_combination, 1)) = GC_tmp_shuf.F;
        end
        tmp3 = max(nanmax(current_GC_matrix_shuffled3));
        Shuffling_GCMax3(i_time) = tmp3;
        % GC Shuffle Matrix4
        current_GC_matrix_shuffled4 = NaN(n_traces, n_traces);
        for i_combination = 1:n_combinations
            trace1 = current_traces_shuffled4(:, Combinations(i_combination, 1));
            trace2 = current_traces_shuffled4(:, Combinations(i_combination, 2));
            [GC_tmp_shuf.F, GC_tmp_shuf.c_v, GC_tmp_shuf.Fprob, GC_tmp_shuf.Fprob_Corrected, GC_tmp_shuf.dAIC, GC_tmp_shuf.dBIC, GC_tmp_shuf.chosen_x_lag, GC_tmp_shuf.chosen_y_lag] = granger_cause_1(trace1, trace2, significance_thr, maxlag1, 1, maxlag2, 1, minlag2, [], [], [], [], [], [], 0);
            current_GC_matrix_shuffled4(Combinations(i_combination, 1), Combinations(i_combination, 2)) = GC_tmp_shuf.F;
            current_GC_matrix_shuffled4(Combinations(i_combination, 2), Combinations(i_combination, 1)) = GC_tmp_shuf.F;
        end
        tmp4 = max(nanmax(current_GC_matrix_shuffled4));
        Shuffling_GCMax4(i_time) = tmp4;
        
        % Filtered
        current_GC_matrix_filtered = current_GC_matrix - Shuffling_GCMax(i_time);
        current_GC_matrix_filtered(current_GC_matrix_filtered < 0) = 0;
        
        GC_Film(1:n_traces, 1:n_traces, i_time) = current_GC_matrix;
        GC_Film_Shuffled(1:n_traces, 1:n_traces, i_time) = current_GC_matrix_shuffled;
        GC_Film_Filtered(1:n_traces, 1:n_traces, i_time) = current_GC_matrix_filtered;
        
        Shuffling_Max_Matrix = [tmp; tmp2; tmp3; tmp4];
        Shuffling_GCStd(1, i_time) = nanstd(Shuffling_Max_Matrix);
        figure; pcolor(current_GC_matrix_filtered);
    end
    
    % Entropy
    entropy_trace(1, i_time) = entropy(current_traces);
    if i_time == 2
        time_2nd_frame = toc;
        time_estimated = (time_2nd_frame/2)*film_length - 2*time_2nd_frame;
        time_est_hour = floor(time_estimated/(60*60));
        time_est_m = floor( (time_estimated - time_est_hour*(60*60)) /60);
        time_est_s = floor(rem( (time_estimated - time_est_hour*(60*60)), 60));
        fprintf('\nEstimated time to complete: %dh:%dm:%ds.\n', time_est_hour, time_est_m, time_est_s);
    end
end
if FLAG_Granger == 1
    figure; hold on; plot(Shuffling_GCMax); plot(Shuffling_GCMax2); plot(Shuffling_GCMax3); plot(Shuffling_GCMax4); title('Shuffle Max Plot on different reps in same frame');
    figure; hold on; plot(Shuffling_GCStd); title ('Std Shuffle Plot');
    figure; hold on; plot(Shuffling_GCMax); title('Max Shuffle Plot');
end
% Shift the data correctly.
tmp = NaN(1, n_time_points);
tmp(1, window_length:end) = entropy_trace;
entropy_trace = tmp;
tmp = NaN(n_traces, n_traces, n_time_points);
tmp(:, :, window_length:end) = correlation_film;
correlation_film = tmp;

% Max and Min of Correlation.
CorrMax = max(max(nanmax(correlation_film)));
CorrMin = min(min(nanmin(correlation_film)));


%% Save .avi correlation Film.
if FLAG_Save_Film == 1
    fprintf ('\nWriting output as .avi film...\n...\n');
    
    video_name = sprintf('Correlation Film - Mouse %s', MouseName);
    video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'
    
    % Initialize and open video object.
    analysed_colour_video_obj = VideoWriter(video_name, video_profile);    
    analysed_colour_video_obj.FrameRate = Film_FrameRate;
    open(analysed_colour_video_obj);
    
    fig_tmp = figure;
    for i_time = 1:n_time_points
        if rem(i_time, 10) == 0
            fprintf('Saving Frame #%d/n_time_points\n', i_time)
        end
        if isnan(nanmean(nanmean(correlation_film(:, :, i_time))))
            str_title = 'State: ---';
            Title_FontColor = 'k';
        else
            switch Hypnogram_CurrentMouse(i_time)
                case 1
                    str_title = 'State: Awake';
                    Title_FontColor = 'b';
                case 2
                    str_title = 'State: Non-REM';
                    Title_FontColor = 'r';
                case 4
                    str_title = 'State: REM';
                    Title_FontColor = 'g';
            end
        end
        h = pcolor(correlation_film(:, :, i_time));
        view(2);
        colorbar;
        caxis([-1, 1]);
        axis tight;
        title(str_title, 'FontSize', Title_FontSize, 'FontWeight', Title_FontWeight, 'Color', Title_FontColor)
        
        %     set(gcf,'PaperPositionMode','auto')
        frame = getframe(fig_tmp);
        writeVideo(analysed_colour_video_obj, frame);
    end
    
    
    close(analysed_colour_video_obj);
    close % Close the figure used to produce the film.
    fprintf('\nFilm saved successfully in .avi format.\n\n')
end