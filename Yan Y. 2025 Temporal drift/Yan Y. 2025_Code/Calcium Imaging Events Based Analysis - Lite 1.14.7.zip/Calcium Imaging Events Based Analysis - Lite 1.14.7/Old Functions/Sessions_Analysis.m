
CellType = 'VGlut2';
Opts.Matrix_Distance_Type = 'Cosine';
Opts.SaveFiguresAutomatically = 1; % Change between 1 and 0, self explanatory.

% Session Analysis 
Events_perSession = separate_all_sessions (Events_AllSessions, HypnoState);

% Get n_cells
Mouse_Cells = cmp_number_of_cells (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names);



%% Grouping based on time of the day and baseline/SD/rec
DUMMY = 1;
while DUMMY == 1
    %% Baseline
    % Baseline Morning
    Group = [1, 4, 7];
    [Events_Grouped_Baseline_10am, Hypnogram_Group_Baseline_10am] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 3pm
    Group = [2, 5, 8];
    [Events_Grouped_Baseline_3pm, Hypnogram_Group_Baseline_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 5pm
    Group = [3, 6, 9];
    [Events_Grouped_Baseline_5pm, Hypnogram_Group_Baseline_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% SD
    % SD 12pm
    Group = 10;
    [Events_Grouped_SD_12pm, Hypnogram_Group_SD_12pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % SD 12pm
    Group = 11;
    [Events_Grouped_SD_3pm, Hypnogram_Group_SD_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % SD 5pm
    Group = 12;
    [Events_Grouped_SD_5pm, Hypnogram_Group_SD_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    
    %% Recovery
    % Recovery Morning
    Group = [13, 16, 19];
    [Events_Grouped_Recovery_10am, Hypnogram_Group_Recovery_10am] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 3pm
    Group = [14, 17, 20];
    [Events_Grouped_Recovery_3pm, Hypnogram_Group_Recovery_3pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 5pm
    Group = [15, 18, 21];
    [Events_Grouped_Recovery_5pm, Hypnogram_Group_Recovery_5pm] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    DUMMY = 0;
end


%% Get the events frequency for each session for each mouse.
% Baseline
[Events_Freq_Matrix_perMouse_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_10am] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_10am, Hypnogram_Group_Baseline_10am, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_3pm, Hypnogram_Group_Baseline_3pm, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_5pm, Events_Freq_Matrix_allMice_Baseline_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_5pm, Hypnogram_Group_Baseline_5pm, Mouse_Names, Mouse_Cells, Opts);

% SD
[Events_Freq_Matrix_perMouse_SD_12pm, Events_Freq_Matrix_allMice_SD_12pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_12pm, Hypnogram_Group_SD_12pm, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_SD_3pm, Events_Freq_Matrix_allMice_SD_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_3pm, Hypnogram_Group_SD_3pm, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_SD_5pm, Events_Freq_Matrix_allMice_SD_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_5pm, Hypnogram_Group_SD_5pm, Mouse_Names, Mouse_Cells, Opts);

% Recovery
[Events_Freq_Matrix_perMouse_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_10am] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_10am, Hypnogram_Group_Recovery_10am, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_3pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_3pm, Hypnogram_Group_Recovery_3pm, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_5pm, Events_Freq_Matrix_allMice_Recovery_5pm] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_5pm, Hypnogram_Group_Recovery_5pm, Mouse_Names, Mouse_Cells, Opts);


% %% Get the difference between Firing Rate
% FR_difference_baseline_10am3pm = abs (Events_Freq_Matrix_allMice_Baseline_10am - Events_Freq_Matrix_allMice_Baseline_3pm);
% 
% FR_difference_baseline_recovery_10am = abs (Events_Freq_Matrix_allMice_Baseline_10am - Events_Freq_Matrix_allMice_Recovery_10am);


%% Grouping: Each session separated.
DUMMY = 1;
while DUMMY == 1
    %% Baseline Day 1
    % Baseline 1
    Group = [1];
    [Events_Grouped_Baseline_1, Hypnogram_Group_Baseline_1] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 2
    Group = [2];
    [Events_Grouped_Baseline_2, Hypnogram_Group_Baseline_2] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 3
    Group = [3];
    [Events_Grouped_Baseline_3, Hypnogram_Group_Baseline_3] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% Baseline Day 2
    % Baseline 4
    Group = [4];
    [Events_Grouped_Baseline_4, Hypnogram_Group_Baseline_4] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 5
    Group = [5];
    [Events_Grouped_Baseline_5, Hypnogram_Group_Baseline_5] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 6
    Group = [6];
    [Events_Grouped_Baseline_6, Hypnogram_Group_Baseline_6] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% Baseline Day 3
    % Baseline 7
    Group = [7];
    [Events_Grouped_Baseline_7, Hypnogram_Group_Baseline_7] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 8
    Group = [8];
    [Events_Grouped_Baseline_8, Hypnogram_Group_Baseline_8] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Baseline 9
    Group = [9];
    [Events_Grouped_Baseline_9, Hypnogram_Group_Baseline_9] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% SD
    % SD 10
    Group = [10];
    [Events_Grouped_SD_10, Hypnogram_Group_SD_10] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % SD 11
    Group = [11];
    [Events_Grouped_SD_11, Hypnogram_Group_SD_11] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % SD 12
    Group = [12];
    [Events_Grouped_SD_12, Hypnogram_Group_SD_12] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% Recovery Day 1
    % Recovery 13
    Group = [13];
    [Events_Grouped_Recovery_13, Hypnogram_Group_Recovery_13] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 14
    Group = [14];
    [Events_Grouped_Recovery_14, Hypnogram_Group_Recovery_14] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 15
    Group = [15];
    [Events_Grouped_Recovery_15, Hypnogram_Group_Recovery_15] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% Recovery Day 2
    % Recovery 16
    Group = [16];
    [Events_Grouped_Recovery_16, Hypnogram_Group_Recovery_16] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 17
    Group = [17];
    [Events_Grouped_Recovery_17, Hypnogram_Group_Recovery_17] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 18
    Group = [18];
    [Events_Grouped_Recovery_18, Hypnogram_Group_Recovery_18] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    %% Recovery Day 3
    % Recovery 19
    Group = [19];
    [Events_Grouped_Recovery_19, Hypnogram_Group_Recovery_19] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 20
    Group = [20];
    [Events_Grouped_Recovery_20, Hypnogram_Group_Recovery_20] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    % Recovery 21
    Group = [21];
    [Events_Grouped_Recovery_21, Hypnogram_Group_Recovery_21] = group_Sessions (Events_perSession, Hypnogram_AllSessions, Group);
    
    DUMMY = 0;
end

%% Get the events frequency for each session for each mouse.
% Baseline Day 1
[Events_Freq_Matrix_perMouse_Baseline_1, Events_Freq_Matrix_allMice_Baseline_1] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_1, Hypnogram_Group_Baseline_1, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_2, Events_Freq_Matrix_allMice_Baseline_2] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_2, Hypnogram_Group_Baseline_2, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_3, Events_Freq_Matrix_allMice_Baseline_3] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_3, Hypnogram_Group_Baseline_3, Mouse_Names, Mouse_Cells, Opts);
% Baseline Day 2
[Events_Freq_Matrix_perMouse_Baseline_4, Events_Freq_Matrix_allMice_Baseline_4] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_4, Hypnogram_Group_Baseline_4, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_5, Events_Freq_Matrix_allMice_Baseline_5] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_5, Hypnogram_Group_Baseline_5, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_6, Events_Freq_Matrix_allMice_Baseline_6] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_6, Hypnogram_Group_Baseline_6, Mouse_Names, Mouse_Cells, Opts);
% Baseline Day 3
[Events_Freq_Matrix_perMouse_Baseline_7, Events_Freq_Matrix_allMice_Baseline_7] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_7, Hypnogram_Group_Baseline_7, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_8, Events_Freq_Matrix_allMice_Baseline_8] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_8, Hypnogram_Group_Baseline_8, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Baseline_9, Events_Freq_Matrix_allMice_Baseline_9] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Baseline_9, Hypnogram_Group_Baseline_9, Mouse_Names, Mouse_Cells, Opts);

% Baseline SD
[Events_Freq_Matrix_perMouse_SD_10, Events_Freq_Matrix_allMice_SD_10] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_10, Hypnogram_Group_SD_10, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_SD_11, Events_Freq_Matrix_allMice_SD_11] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_11, Hypnogram_Group_SD_11, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_SD_12, Events_Freq_Matrix_allMice_SD_12] = Sessions_Analysis_Events_Frequencies (Events_Grouped_SD_12, Hypnogram_Group_SD_12, Mouse_Names, Mouse_Cells, Opts);

% Recovery Day 1
[Events_Freq_Matrix_perMouse_Recovery_13, Events_Freq_Matrix_allMice_Recovery_13] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_13, Hypnogram_Group_Recovery_13, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_14, Events_Freq_Matrix_allMice_Recovery_14] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_14, Hypnogram_Group_Recovery_14, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_15, Events_Freq_Matrix_allMice_Recovery_15] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_15, Hypnogram_Group_Recovery_15, Mouse_Names, Mouse_Cells, Opts);
% Recovery Day 2
[Events_Freq_Matrix_perMouse_Recovery_16, Events_Freq_Matrix_allMice_Recovery_16] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_16, Hypnogram_Group_Recovery_16, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_17, Events_Freq_Matrix_allMice_Recovery_17] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_17, Hypnogram_Group_Recovery_17, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_18, Events_Freq_Matrix_allMice_Recovery_18] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_18, Hypnogram_Group_Recovery_18, Mouse_Names, Mouse_Cells, Opts);
% Recovery Day 3
[Events_Freq_Matrix_perMouse_Recovery_19, Events_Freq_Matrix_allMice_Recovery_19] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_19, Hypnogram_Group_Recovery_19, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_20, Events_Freq_Matrix_allMice_Recovery_20] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_20, Hypnogram_Group_Recovery_20, Mouse_Names, Mouse_Cells, Opts);
[Events_Freq_Matrix_perMouse_Recovery_21, Events_Freq_Matrix_allMice_Recovery_21] = Sessions_Analysis_Events_Frequencies (Events_Grouped_Recovery_21, Hypnogram_Group_Recovery_21, Mouse_Names, Mouse_Cells, Opts);

n_events(1) = numel(Events_Grouped_Baseline_1);
n_events(2) = numel(Events_Grouped_Baseline_2);
n_events(3) = numel(Events_Grouped_Baseline_3);
n_events(4) = numel(Events_Grouped_Baseline_4);
n_events(5) = numel(Events_Grouped_Baseline_5);
n_events(6) = numel(Events_Grouped_Baseline_6);
n_events(7) = numel(Events_Grouped_Baseline_7);
n_events(8) = numel(Events_Grouped_Baseline_8);
n_events(9) = numel(Events_Grouped_Baseline_9);

n_events(10) = numel(Events_Grouped_SD_10);
n_events(11) = numel(Events_Grouped_SD_11);
n_events(12) = numel(Events_Grouped_SD_12);

n_events(13) = numel(Events_Grouped_Recovery_13);
n_events(14) = numel(Events_Grouped_Recovery_14);
n_events(15) = numel(Events_Grouped_Recovery_15);
n_events(16) = numel(Events_Grouped_Recovery_16);
n_events(17) = numel(Events_Grouped_Recovery_17);
n_events(18) = numel(Events_Grouped_Recovery_18);
n_events(19) = numel(Events_Grouped_Recovery_19);
n_events(20) = numel(Events_Grouped_Recovery_20);
n_events(21) = numel(Events_Grouped_Recovery_21);

plot_n_events (n_events)




%% Clustering
FLAG_PlotClustering_Single = 0;

Opts.Dir_Figures = 'C:\Users\nicco\OneDrive\Desktop\Calcium Imaging ARES Toolbox 1.04\New folder (4)\Calcium Imaging Events Based Analysis - Lite 0.9.7\Figures';
Opts.ClusteringVariable = 'Events_Rate'; % 'Events_Rate', 'N_Events', or 'Integral_Sum'
Opts.ClusteringMethod = 2; % 1 = Simple max. 2 = Inactive cells & Max. 3 = Threshold on median Ca2+ Firing Rate

% Clustering
DUMMY = 1;
while DUMMY == 1
    [CellsPerState_Results_1, CellTag_perMouse_1, CellTagNum_perMouse{1}] = clustering_cells_activitybased (Events_Grouped_Baseline_1, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 1 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{1}, Opts); end
    
    [CellsPerState_Results_2, CellTag_perMouse_2, CellTagNum_perMouse{2}] = clustering_cells_activitybased (Events_Grouped_Baseline_2, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 1 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{2}, Opts); end
    
    [CellsPerState_Results_3, CellTag_perMouse_3, CellTagNum_perMouse{3}] = clustering_cells_activitybased (Events_Grouped_Baseline_3, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 1 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{3}, Opts); end
    
    [CellsPerState_Results_4, CellTag_perMouse_4, CellTagNum_perMouse{4}] = clustering_cells_activitybased (Events_Grouped_Baseline_4, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 2 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{4}, Opts); end
    
    [CellsPerState_Results_5, CellTag_perMouse_5, CellTagNum_perMouse{5}] = clustering_cells_activitybased (Events_Grouped_Baseline_5, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 2 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{5}, Opts); end
    
    [CellsPerState_Results_6, CellTag_perMouse_6, CellTagNum_perMouse{6}] = clustering_cells_activitybased (Events_Grouped_Baseline_6, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 2 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{6}, Opts); end
    
    [CellsPerState_Results_7, CellTag_perMouse_7, CellTagNum_perMouse{7}] = clustering_cells_activitybased (Events_Grouped_Baseline_7, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 3 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{7}, Opts); end
    
    [CellsPerState_Results_8, CellTag_perMouse_8, CellTagNum_perMouse{8}] = clustering_cells_activitybased (Events_Grouped_Baseline_8, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 3 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{8}, Opts); end
    
    [CellsPerState_Results_9, CellTag_perMouse_9, CellTagNum_perMouse{9}] = clustering_cells_activitybased (Events_Grouped_Baseline_9, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 3 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{9}, Opts); end
    
    [CellsPerState_Results_10, CellTag_perMouse_10, CellTagNum_perMouse{10}] = clustering_cells_activitybased (Events_Grouped_SD_10, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 4 (SD) - 12pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{10}, Opts); end
    
    [CellsPerState_Results_11, CellTag_perMouse_11, CellTagNum_perMouse{11}] = clustering_cells_activitybased (Events_Grouped_SD_11, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 4 (SD) - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{11}, Opts); end
    
    [CellsPerState_Results_12, CellTag_perMouse_12, CellTagNum_perMouse{12}] = clustering_cells_activitybased (Events_Grouped_SD_12, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 4 (SD) - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{12}, Opts); end
    
    [CellsPerState_Results_13, CellTag_perMouse_13, CellTagNum_perMouse{13}] = clustering_cells_activitybased (Events_Grouped_Recovery_13, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 5 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{13}, Opts); end
    
    [CellsPerState_Results_14, CellTag_perMouse_14, CellTagNum_perMouse{14}] = clustering_cells_activitybased (Events_Grouped_Recovery_14, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 5 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{14}, Opts); end
    
    [CellsPerState_Results_15, CellTag_perMouse_15, CellTagNum_perMouse{15}] = clustering_cells_activitybased (Events_Grouped_Recovery_15, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 5 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{15}, Opts); end
    
    [CellsPerState_Results_16, CellTag_perMouse_16, CellTagNum_perMouse{16}] = clustering_cells_activitybased (Events_Grouped_Recovery_16, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 6 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{16}, Opts); end
    
    [CellsPerState_Results_17, CellTag_perMouse_17, CellTagNum_perMouse{17}] = clustering_cells_activitybased (Events_Grouped_Recovery_17, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 6 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{17}, Opts); end
    
    [CellsPerState_Results_18, CellTag_perMouse_18, CellTagNum_perMouse{18}] = clustering_cells_activitybased (Events_Grouped_Recovery_18, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 6 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{18}, Opts); end
    
    [CellsPerState_Results_19, CellTag_perMouse_19, CellTagNum_perMouse{19}] = clustering_cells_activitybased (Events_Grouped_Recovery_19, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 7 - 10am - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{19}, Opts); end
    
    [CellsPerState_Results_20, CellTag_perMouse_20, CellTagNum_perMouse{20}] = clustering_cells_activitybased (Events_Grouped_Recovery_20, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 7 - 3pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{20}, Opts); end
    
    [CellsPerState_Results_21, CellTag_perMouse_21, CellTagNum_perMouse{21}] = clustering_cells_activitybased (Events_Grouped_Recovery_21, Mouse_Names, Mouse_Cells, Opts);
    Opts.tmp_FileName = sprintf('%s - Day 7 - 5pm - Cells Clustered per State', CellType);
    if FLAG_PlotClustering_Single == 1; h_piechart = plot_clustering(CellTagNum_perMouse{21}, Opts); end
    
    DUMMY = 0;
end

% Clustering Change
if Opts.ClusteringMethod == 1 || Opts.ClusteringMethod == 2
    
    % Change during a single baseline day.
    Opts.SubTitle_part = sprintf('\nBaseline Across Day 1');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 1 (10am) - Baseline Day 1 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts)
    % Change across Baseline - 5pm
    Opts.SubTitle_part = sprintf('\nBaseline Across Days');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 1 (5pm) - Baseline Day 2 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_3, CellTag_perMouse_6, CellTag_perMouse_6, Opts)
    % Change across SD - 5pm
    Opts.SubTitle_part = sprintf('\nSD Change');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 3 (5pm) - SD Day 1 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_9, CellTag_perMouse_12, CellTag_perMouse_12, Opts)
    % Change across Baseline Day 3 (5pm) - Recovery Day 1 (5pm)
    Opts.SubTitle_part = sprintf('\nSD Change');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nSD Day (5pm) - Recovery Day 1 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_12, CellTag_perMouse_15, CellTag_perMouse_15, Opts)
    % Change across Baseline Day 3 (5pm) - Recovery Day 1 (5pm)
    Opts.SubTitle_part = sprintf('\nSD Change');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 3 (5pm) - Recovery Day 1 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_9, CellTag_perMouse_12, CellTag_perMouse_15, Opts)
    % Change across Recovery - 5pm
    Opts.SubTitle_part = sprintf('\nRecovery Across Days');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nRecovery Day 1 (5pm) - Recovery Day 2 (5pm)');
    clustering_change_MaxState (CellTag_perMouse_15, CellTag_perMouse_18, CellTag_perMouse_18, Opts)
    % Change across Recovery - 5pm (3pm)
    Opts.SubTitle_part = sprintf('\nRecovery Across Days');
    Opts.SupTitle_Text = sprintf('State specificity variation between\nRecovery Day 2 (3pm) - Recovery Day 3 (3pm)');
    clustering_change_MaxState (CellTag_perMouse_17, CellTag_perMouse_20, CellTag_perMouse_20, Opts)
    
elseif Opts.ClusteringMethod == 3
    
    % Change during a single baseline day.
    clustering_change (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts)
    % Change across Baseline - 5pm
    clustering_change (CellTag_perMouse_3, CellTag_perMouse_6, CellTag_perMouse_9, Opts)
    % Change across SD - 5pm
    clustering_change (CellTag_perMouse_9, CellTag_perMouse_12, CellTag_perMouse_15, Opts)
    % Change across Recovery - 5pm
    clustering_change (CellTag_perMouse_15, CellTag_perMouse_18, CellTag_perMouse_21, Opts)

end

%% Clustering flow evolution 

% Change during a single baseline day.
Opts.SubTitle_part = sprintf('\nBaseline Across Day 1');
Opts.SupTitle_Text = sprintf('State specificity variation between\nBaseline Day 1 (10am) - Baseline Day 1 (5pm)');
tmpOpts = Opts.SaveFiguresAutomatically;
Opts.SaveFiguresAutomatically = 0;
[Awake, NREM, REM] = clustering_change_MaxState (CellTag_perMouse_1, CellTag_perMouse_2, CellTag_perMouse_3, Opts);
Opts.SaveFiguresAutomatically = tmpOpts;
CellsTagChange.Awake = Awake;
CellsTagChange.NREM = NREM;
CellsTagChange.REM = REM;

% Compute the evolution matrix for every cell separately
CellTags_EvolutionMatrix = cmp_CellTags_Evolution_Matrix(CellTagNum_perMouse, CellType, Opts);

% Flow Plot
plot_Sanesky (CellTagNum_perMouse, CellTags_EvolutionMatrix, CellsTagChange)



%% Plots


corr_analysis (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, HypnoState, Mouse_Names, Opts)

% Plot Example Traces
ExampleSession2Plot = 5;
ExampleSession = CalciumTraces_Clean_AllSessions{ExampleSession2Plot};
ExampleHypnogram = Hypnogram_AllSessions(ExampleSession2Plot).Hypnogram;
plot_ImagingAllAndHypno(ExampleSession, ExampleHypnogram, Hypnogram_AllSessions(ExampleSession2Plot).calTime)
% Plot Example Single Trace
ExampleTrace2Plot = 4;
ExampleTrace = ExampleSession(:, ExampleTrace2Plot);
plot_ImagingAndHypno(ExampleTrace, ExampleHypnogram, Hypnogram_AllSessions(ExampleSession2Plot).calTime)

% Clustering Continuity Evolution
plot_clustering_continuity (CellTagNum_perMouse, CellType, Opts);

% Plot Ordered, comparison between days.
plot_events_frequency_session_comparison (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm);

% Plot Ordered, comparison between states.
plot_events_frequency_session_comparison_ordered (Events_Freq_Matrix_allMice_Baseline_10am, Events_Freq_Matrix_allMice_Baseline_3pm, Events_Freq_Matrix_allMice_Baseline_5pm, Events_Freq_Matrix_allMice_Recovery_10am, Events_Freq_Matrix_allMice_Recovery_3pm, Events_Freq_Matrix_allMice_Recovery_5pm, Events_Freq_Matrix_allMice_SD_12pm, Events_Freq_Matrix_allMice_SD_3pm, Events_Freq_Matrix_allMice_SD_5pm);

% Stability Plots and results
Cmp_Stability;

% Plots Awake Stability ===== WIP =====
plot_events_frequency_awake_stability (Events_Freq_Matrix_allMice_Baseline_1, Events_Freq_Matrix_allMice_Baseline_2, Events_Freq_Matrix_allMice_Baseline_3, Events_Freq_Matrix_allMice_Baseline_4, Events_Freq_Matrix_allMice_Baseline_5, Events_Freq_Matrix_allMice_Baseline_6, Events_Freq_Matrix_allMice_Baseline_7, Events_Freq_Matrix_allMice_Baseline_8, Events_Freq_Matrix_allMice_Baseline_9, Events_Freq_Matrix_allMice_SD_10, Events_Freq_Matrix_allMice_SD_11, Events_Freq_Matrix_allMice_SD_12, Events_Freq_Matrix_allMice_Recovery_13, Events_Freq_Matrix_allMice_Recovery_14, Events_Freq_Matrix_allMice_Recovery_15, Events_Freq_Matrix_allMice_Recovery_16, Events_Freq_Matrix_allMice_Recovery_17, Events_Freq_Matrix_allMice_Recovery_18, Events_Freq_Matrix_allMice_Recovery_19, Events_Freq_Matrix_allMice_Recovery_20, Events_Freq_Matrix_allMice_Recovery_21);

% Plots Awake ===== WIP =====
plot_events_frequency_awake_comparison_ordered (Events_Freq_Matrix_allMice_Baseline_7, Events_Freq_Matrix_allMice_Baseline_8, Events_Freq_Matrix_allMice_Baseline_9, Events_Freq_Matrix_allMice_SD_10, Events_Freq_Matrix_allMice_SD_11, Events_Freq_Matrix_allMice_SD_12, Events_Freq_Matrix_allMice_Recovery_13, Events_Freq_Matrix_allMice_Recovery_14, Events_Freq_Matrix_allMice_Recovery_15);

% ??? WIP
EventsFreq_Results = plot_bar_horizontal(Events_Grouped_SD_5pm, Mouse_Names, HypnoState, Hypnogram_Group_SD_5pm, MouseCellsRecorded, Opts.Dir_Figures, Opts);
