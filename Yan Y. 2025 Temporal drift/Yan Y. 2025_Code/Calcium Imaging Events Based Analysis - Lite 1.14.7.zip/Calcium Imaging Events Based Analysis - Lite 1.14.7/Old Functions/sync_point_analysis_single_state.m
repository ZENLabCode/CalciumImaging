function Sync_Stats = sync_point_analysis_single_state (Events, Hypnogram_AllMice, StateStartEnd)
% This function performs the temporal analysis of the calcium events
% (synchronization), for a single state.

% Computes the synchrony per single state (interval between 2 state
% changes).
% Sync is the mean number of events in sync / #events, basically, it is
% equivalent to the SPIKE-synchronization measure presented here:
% http://www.scholarpedia.org/article/Measures_of_spike_train_synchrony


Opts.FrameRate = 3;
Opts.Min_StateLength = 30*Opts.FrameRate;
Opts.Max_EventsDistance = 10; % [frames, seconds = frames/3]
Opts.Sync_Normalization = 'Events Rate'; % 'Total Events Number' or 'Events Rate'


%% Preliminary operations.
n_mouse = numel(Hypnogram_AllMice);
n_Events_Tot = numel(Events);

% Make Binary Traces for Synchro Analysis.
Opts.MakeBinary.EventIdentifier = 'StartComposite'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'
Binary_Traces_AllMice = make_binary_point_traces (Events, Hypnogram_AllMice, Opts.MakeBinary);

% Max number of states in mouse.
states_n_max = 0;
for i_mouse = 1:n_mouse
    states_n_max = max(numel(Hypnogram_AllMice(i_mouse).StateChanges), states_n_max);
end


%% Synchrony analysis.
sync_matrix = NaN(n_mouse, states_n_max);
state_matrix = NaN(n_mouse, states_n_max);
n_events_matrix = NaN(n_mouse, states_n_max);
n_events_overlap_avg_matrix = NaN(n_mouse, states_n_max);
n_events_singlets_matrix = NaN(n_mouse, states_n_max);
state_length = NaN(n_mouse, states_n_max);
n_cells = NaN(1, n_mouse);


% New code
current_mouse_traces = Current_State.BinaryTrace;
current_traces_matrix = cell2mat(current_mouse_traces);
[current_n_cells, current_n_frames] = size(current_traces_matrix);


for i_mouse = 1:n_mouse
    % Get quantities for the current mouse.
    current_mouse_traces = (Binary_Traces_AllMice{i_mouse})';
    current_Hypnogram = Hypnogram_AllMice(i_mouse).Hypnogram;
    current_StateChanges = Hypnogram_AllMice(i_mouse).StateChanges;
    current_traces_matrix = cell2mat(current_mouse_traces);

    n_cells(i_mouse) = numel(current_mouse_traces);
    current_n_states = numel(current_StateChanges);
    [current_n_cells, current_n_frames] = size(current_traces_matrix);
    
    % Separate each Mouse binary traces by State.
    SyncIndex = NaN(1, current_n_states);
    state_vector = NaN(1, current_n_states);
    
    for i_state = 1:current_n_states-1
        if current_StateChanges(i_state) > 1
            state_vector(i_state) = current_Hypnogram(current_StateChanges(i_state));
        elseif current_StateChanges(i_state) == 1
            state_vector(i_state) = current_Hypnogram(1);
        end
        current_state_array = current_StateChanges(i_state):current_StateChanges(i_state + 1);
        current_traces_state = current_traces_matrix(:, current_state_array(1):current_state_array(end));
        keyboard
        tmp_sync = nansum(current_traces_state, 1);
        tmp_sync(tmp_sync == 0) = NaN;
        n_events_singlets = numel(tmp_sync(tmp_sync == 1));
        n_events = nansum(tmp_sync);
        tmp_sync(tmp_sync == 1) = 0;
        n_events_overlap = nansum(tmp_sync);
        n_events_overlap_avg = nanmean(tmp_sync); % The average # of overlapping events in a time bin, independent from the total number of cells (will be presented as a normalized quantity below)
        tmp_sync = tmp_sync./current_n_cells; % Sync does take into account the total number of cells, both active and silent ones
        
        SyncIndex(i_state) = nanmean(tmp_sync);
        if numel(SyncIndex) ~= numel(state_vector)
            warning('Number of states ~= number of Syncs')
        end
        
        state_length(i_mouse, i_state) = numel(current_state_array);
        % If the state is of not short enough duration, ignore it.
        if state_length(i_mouse, i_state) < Opts.Min_StateLength
            state_vector(i_state) = NaN;
            SyncIndex(i_state) = NaN;
            n_events_matrix(i_mouse, i_state) = NaN;
            n_events_overlap_avg_matrix(i_mouse, i_state) = NaN;
            n_events_singlets_matrix(i_mouse, i_state) = NaN;
           continue 
        end
        
        n_events_matrix(i_mouse, i_state) = n_events;
        n_events_overlap_avg_matrix(i_mouse, i_state) = n_events_overlap_avg;
        n_events_singlets_matrix(i_mouse, i_state) = n_events_singlets;
    end

    sync_matrix(i_mouse, 1:numel(SyncIndex)) = SyncIndex;
    state_matrix(i_mouse, 1:numel(SyncIndex)) = state_vector;
    
    clear current*
    clear next*
    clear tmp*
end


%% Get statistics per state.
Sync_REM = sync_matrix(state_matrix == 4);
Sync_REM(isnan(Sync_REM)) = [];

state_length_tot_REM = nansum(state_length(state_matrix == 4));
state_length_avg_REM = nanmean(state_length(state_matrix == 4));
state_length_std_REM = nanstd(state_length(state_matrix == 4));

% REM
n_events_REM = n_events_matrix(state_matrix == 4);
n_events_REM(isnan(n_events_REM)) = [];
n_cells_avg_REM = mean(n_cells(any(state_matrix == 4, 2)));
n_events_overlap_avg_REM = n_events_overlap_avg_matrix(state_matrix == 4);
n_events_overlap_avg_REM(isnan(n_events_overlap_avg_REM)) = [];
n_events_singlets_REM = n_events_singlets_matrix(state_matrix == 4);
n_events_singlets_REM(isnan(n_events_singlets_REM)) = [];

% REM
Sync_Stats.REM.n_states = numel(Sync_REM);
Sync_Stats.REM.state_length_tot = state_length_tot_REM;
Sync_Stats.REM.state_length_avg = state_length_avg_REM;
Sync_Stats.REM.state_length_std = state_length_std_REM;
Sync_Stats.REM.n_cells_avg = n_cells_avg_REM;
Sync_Stats.REM.n_events = nansum(n_events_REM);
Sync_Stats.REM.events_rate = Sync_Stats.REM.n_events/Sync_Stats.REM.state_length_tot;
Sync_Stats.REM.n_events_overlap_avg = nanmean(n_events_overlap_avg_REM);
Sync_Stats.REM.n_events_overlap_std = nanstd(n_events_overlap_avg_REM);
Sync_Stats.REM.n_events_singlets = nansum(n_events_singlets_REM);
Sync_Stats.REM.Sync_Mean = nanmean(Sync_REM);
Sync_Stats.REM.Sync_Std = nanstd(Sync_REM);
Sync_Stats.REM.Normalization = Opts.Sync_Normalization;
if strcmpi(Opts.Sync_Normalization, 'Total Events Number')
    Sync_Stats.REM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.Sync_Mean_Norm = nanmean(Sync_REM./Sync_Stats.REM.n_events);
    Sync_Stats.REM.Sync_Mean_Std = nanstd(Sync_REM./Sync_Stats.REM.n_events);
elseif strcmpi(Opts.Sync_Normalization, 'Events Rate')
    Sync_Stats.REM.n_events_overlap_avg_Norm = nanmean(n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.n_events_overlap_avg_Std = nanstd(n_events_overlap_avg_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.Sync_Mean_Norm = nanmean(Sync_REM./Sync_Stats.REM.events_rate);
    Sync_Stats.REM.Sync_Mean_Std = nanstd(Sync_REM./Sync_Stats.REM.events_rate);
else
    warning('Unrecognized Normalization type "%s"', Opts.Sync_Normalization)
end
