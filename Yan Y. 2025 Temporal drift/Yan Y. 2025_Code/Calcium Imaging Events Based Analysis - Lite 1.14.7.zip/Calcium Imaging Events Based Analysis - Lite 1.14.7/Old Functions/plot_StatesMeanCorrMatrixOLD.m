function plot_StatesMeanCorrMatrixOLD (MeanOfStates, Mouse_Names, Dir_Figures)
% This function plots the mean correlation matrix of each "average state"
% per mouse.

Title_FontSize = 14;
SupTitle_FontSize = 18;
CorrThr = 0.1;
CorrThr_Diff = 0.2; % Also referred as ThrHard in the code.

n_states = 4;

n_mice = numel(MeanOfStates);
subplot_n_cols = 3;
subplot_n_rows = 2;

% Initialize variables.
MeanPosThr1_2 = NaN(1, n_mice);
MeanNegThr1_2 = NaN(1, n_mice);
N_StableCorr1_2 = NaN(1, n_mice);
N_PosChangingCorr1_2 = NaN(1, n_mice);
N_NegChangingCorr1_2 = NaN(1, n_mice);
N_PosChangingCorrNorm1_2 = NaN(1, n_mice);
N_NegChangingCorrNorm1_2 = NaN(1, n_mice);

MeanPosThr1_4 = NaN(1, n_mice);
MeanNegThr1_4 = NaN(1, n_mice);
N_StableCorr1_4 = NaN(1, n_mice);
N_PosChangingCorr1_4 = NaN(1, n_mice);
N_NegChangingCorr1_4 = NaN(1, n_mice);
N_PosChangingCorrNorm1_4 = NaN(1, n_mice);
N_NegChangingCorrNorm1_4 = NaN(1, n_mice);

MeanPosThr2_4 = NaN(1, n_mice);
MeanNegThr2_4 = NaN(1, n_mice);
N_StableCorr2_4 = NaN(1, n_mice);
N_PosChangingCorr2_4 = NaN(1, n_mice);
N_NegChangingCorr2_4 = NaN(1, n_mice);
N_PosChangingCorrNorm2_4 = NaN(1, n_mice);
N_NegChangingCorrNorm2_4 = NaN(1, n_mice);

N_Corrs = NaN(1, n_mice);
MeanNPosCorrThrHard = NaN(n_mice, n_states);
MeanNNegCorrThrHard = NaN(n_mice, n_states);
 
% Actual plots.
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    Suptitle_Str = sprintf('Mean State Correlation Matrix - Mouse %s', MouseName);
    Current_MeanOfStates = MeanOfStates{i_mouse};
    [Current_NCells, ~] = size(Current_MeanOfStates(1).Corr_Matrix_Mean);
    N_Corrs(1, i_mouse) = ((Current_NCells^2)-Current_NCells)/2;
    
    % Get Maximum/Min/Mean correlation (to uniform the colorscale & Report).
    max_tmp = NaN(1, 4);
    min_tmp = NaN(1, 4);
    Mean_tmp = NaN(1, 4);
    MeanAbs_tmp = NaN(1, 4);
    MeanAbsThr_tmp = NaN(1, 4);
    for i_state = 1:4
       if  i_state == 3 % There's no state tag 3...
           continue
       end
       Current_MeanCorrMatrix = Current_MeanOfStates(i_state).Corr_Matrix_Mean;
       Current_MeanCorrMatrix_ThrAbs = Current_MeanCorrMatrix;
       Current_MeanCorrMatrix_ThrAbs(Current_MeanCorrMatrix_ThrAbs < CorrThr) = NaN;
       Current_MeanCorrMatrix_ThrHardPos = Current_MeanCorrMatrix;
       Current_MeanCorrMatrix_ThrHardPos(Current_MeanCorrMatrix_ThrHardPos < CorrThr_Diff) = NaN;
       Current_MeanCorrMatrix_ThrHardNeg = Current_MeanCorrMatrix;
       Current_MeanCorrMatrix_ThrHardNeg(Current_MeanCorrMatrix_ThrHardNeg > -CorrThr_Diff) = NaN;
       max_tmp(i_state) = nanmax(nanmax(Current_MeanCorrMatrix));
       min_tmp(i_state) = nanmin(nanmin(Current_MeanCorrMatrix));
       Mean_tmp(i_state) = nanmean(nanmean(Current_MeanCorrMatrix));
       MeanAbs_tmp(i_state) = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
       MeanAbsThr_tmp(i_state) = nanmean(nanmean(Current_MeanCorrMatrix_ThrAbs));
       MeanCorr(i_mouse, i_state) = Mean_tmp(i_state);
       MeanAbsCorr(i_mouse, i_state) = MeanAbs_tmp(i_state);
       MeanAbsCorrThr(i_mouse, i_state) = MeanAbsThr_tmp(i_state);
       MeanNPosCorrThrHard(i_mouse, i_state) = numel(find(triu(Current_MeanCorrMatrix_ThrHardPos) > 0));
       MeanNNegCorrThrHard(i_mouse, i_state) = numel(find(triu(Current_MeanCorrMatrix_ThrHardNeg) < 0));
    end
    MaxCorr = nanmax(max_tmp);
    
    figure();
    set(gcf,'position', get(0,'screensize'));
    
    %% Figure 1 ---- Plot Corr Matrices
    for i_state = 1:4
       if  i_state == 3 % There's no state tag 3...
           continue
       end
       Current_MeanCorrMatrix = Current_MeanOfStates(i_state).Corr_Matrix_Mean;
       switch i_state
           case 1
               subplot(subplot_n_rows, subplot_n_cols, i_state);
               pcolor(Current_MeanCorrMatrix);
               axis square
               title('Awake', 'FontSize', Title_FontSize);
           case 2
               subplot(subplot_n_rows, subplot_n_cols, i_state);
               pcolor(Current_MeanCorrMatrix);
               axis square
               title('NoN-REM', 'FontSize', Title_FontSize);
           case 4
               subplot(subplot_n_rows, subplot_n_cols, i_state-1);
               pcolor(Current_MeanCorrMatrix);
               axis square
               title('REM', 'FontSize', Title_FontSize);
       end
       caxis([0 MaxCorr]);
       colorbar
       ylabel('Neuron ID');
       xlabel(sprintf('Mean Correlation = %.3g\nMean Absolute Correlation = %.3g\nMean Absolute Significant Correlations = %.3g (Thr = %.2g)', Mean_tmp(i_state), MeanAbs_tmp(i_state), MeanAbsThr_tmp(i_state), CorrThr));
    end
    h_suptitle = suptitle(Suptitle_Str);
    h_suptitle.FontSize = SupTitle_FontSize;
    
    
    %% Figure 1 ---- Plot Corr Matrices Differences
    Current_MeanCorrMatrixDiff1_2 = Current_MeanOfStates(1).Corr_Matrix_Mean - Current_MeanOfStates(2).Corr_Matrix_Mean;
    Current_MeanCorrMatrixDiff1_4 = Current_MeanOfStates(1).Corr_Matrix_Mean - Current_MeanOfStates(4).Corr_Matrix_Mean;
    Current_MeanCorrMatrixDiff2_4 = Current_MeanOfStates(2).Corr_Matrix_Mean - Current_MeanOfStates(4).Corr_Matrix_Mean;
    
%     [StatesChange_1_2] = StatesMeanCorrMatrix_CorrStableAtTransition (Current_MeanCorrMatrixDiff1_2, CorrThr_Diff, N_Corrs(i_mouse), MeanNPosCorrThrHard(i_mouse, 1), MeanNNegCorrThrHard(i_mouse, 1));
    
    % 1_2
    Current_MeanCorrMatrix = Current_MeanCorrMatrixDiff1_2;
    max_tmp1_2 = nanmax(nanmax(Current_MeanCorrMatrix));
    min_tmp1_2 = nanmin(nanmin(Current_MeanCorrMatrix));
    Mean_tmp1_2 = nanmean(nanmean(Current_MeanCorrMatrix));
    MeanAbs_tmp1_2 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    Current_MeanCorrMatrix(Current_MeanCorrMatrix < CorrThr_Diff) = NaN;
    tmp = zeros(size(Current_MeanCorrMatrixDiff1_2));
    tmp(Current_MeanCorrMatrixDiff1_2 > CorrThr_Diff) = 1;
    tmp(Current_MeanCorrMatrixDiff1_2 < -CorrThr_Diff) = 1;
    Current_MeanCorrMatrixDiff1_2(~tmp) = 0;
    MeanAbsThr_tmp1_2 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    MeanPosThr1_2(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff1_2(Current_MeanCorrMatrixDiff1_2 > CorrThr_Diff)));
    MeanNegThr1_2(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff1_2(Current_MeanCorrMatrixDiff1_2 < - CorrThr_Diff)));
    N_PosChangingCorr1_2(i_mouse) = numel(Current_MeanCorrMatrixDiff1_2(Current_MeanCorrMatrixDiff1_2 > CorrThr_Diff))./2;
    N_NegChangingCorr1_2(i_mouse) = numel(Current_MeanCorrMatrixDiff1_2(Current_MeanCorrMatrixDiff1_2 < - CorrThr_Diff))./2;
    N_PosChangingCorrNorm1_2(i_mouse) = N_PosChangingCorr1_2(i_mouse)./N_Corrs(1, i_mouse);
    N_NegChangingCorrNorm1_2(i_mouse) = N_NegChangingCorr1_2(i_mouse)./N_Corrs(1, i_mouse);
    N_StableCorr1_2(i_mouse) = (MeanNPosCorrThrHard(i_mouse, 1) + MeanNNegCorrThrHard(i_mouse, 1)) - (N_PosChangingCorr1_2(i_mouse) + N_NegChangingCorr1_2(i_mouse));
    
    % 1_4
    Current_MeanCorrMatrix = Current_MeanCorrMatrixDiff1_4;
    max_tmp1_4 = nanmax(nanmax(Current_MeanCorrMatrix));
    min_tmp1_4 = nanmin(nanmin(Current_MeanCorrMatrix));
    Mean_tmp1_4 = nanmean(nanmean(Current_MeanCorrMatrix));
    MeanAbs_tmp1_4 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    Current_MeanCorrMatrix(Current_MeanCorrMatrix < CorrThr_Diff) = NaN;
    tmp = zeros(size(Current_MeanCorrMatrixDiff1_4));
    tmp(Current_MeanCorrMatrixDiff1_4 > CorrThr_Diff) = 1;
    tmp(Current_MeanCorrMatrixDiff1_4 < -CorrThr_Diff) = 1;
    Current_MeanCorrMatrixDiff1_4(~tmp) = 0;
    MeanAbsThr_tmp1_4 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    MeanPosThr1_4(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff1_4(Current_MeanCorrMatrixDiff1_4 > CorrThr_Diff)));
    MeanNegThr1_4(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff1_4(Current_MeanCorrMatrixDiff1_4 < - CorrThr_Diff)));
    N_PosChangingCorr1_4(i_mouse) = numel(Current_MeanCorrMatrixDiff1_4(Current_MeanCorrMatrixDiff1_4 > CorrThr_Diff))./2;
    N_NegChangingCorr1_4(i_mouse) = numel(Current_MeanCorrMatrixDiff1_4(Current_MeanCorrMatrixDiff1_4 < - CorrThr_Diff))./2;
    N_PosChangingCorrNorm1_4(i_mouse) = N_PosChangingCorr1_4(i_mouse)./N_Corrs(1, i_mouse);
    N_NegChangingCorrNorm1_4(i_mouse) = N_NegChangingCorr1_4(i_mouse)./N_Corrs(1, i_mouse);
    N_StableCorr1_4(i_mouse) = (MeanNPosCorrThrHard(i_mouse, 1) + MeanNNegCorrThrHard(i_mouse, 1)) - (N_PosChangingCorr1_4(i_mouse) + N_NegChangingCorr1_4(i_mouse));
    
    % 2_4
    Current_MeanCorrMatrix = Current_MeanCorrMatrixDiff2_4;
    max_tmp2_4 = nanmax(nanmax(Current_MeanCorrMatrix));
    min_tmp2_4 = nanmin(nanmin(Current_MeanCorrMatrix));
    Mean_tmp2_4 = nanmean(nanmean(Current_MeanCorrMatrix));
    MeanAbs_tmp2_4 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    Current_MeanCorrMatrix(Current_MeanCorrMatrix < CorrThr_Diff) = NaN;
    tmp = zeros(size(Current_MeanCorrMatrixDiff2_4));
    tmp(Current_MeanCorrMatrixDiff2_4 > CorrThr_Diff) = 1;
    tmp(Current_MeanCorrMatrixDiff2_4 < -CorrThr_Diff) = 1;
    Current_MeanCorrMatrixDiff2_4(~tmp) = 0;
    MeanAbsThr_tmp2_4 = nanmean(nanmean(abs(Current_MeanCorrMatrix)));
    MeanPosThr2_4(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff2_4(Current_MeanCorrMatrixDiff2_4 > CorrThr_Diff)));
    MeanNegThr2_4(i_mouse) = nanmean(nanmean(Current_MeanCorrMatrixDiff2_4(Current_MeanCorrMatrixDiff2_4 < - CorrThr_Diff)));
    N_PosChangingCorr2_4(i_mouse) = numel(Current_MeanCorrMatrixDiff2_4(Current_MeanCorrMatrixDiff2_4 > CorrThr_Diff))./2;
    N_NegChangingCorr2_4(i_mouse) = numel(Current_MeanCorrMatrixDiff2_4(Current_MeanCorrMatrixDiff2_4 < - CorrThr_Diff))./2;
    N_PosChangingCorrNorm2_4(i_mouse) = N_PosChangingCorr2_4(i_mouse)./N_Corrs(1, i_mouse);
    N_NegChangingCorrNorm2_4(i_mouse) = N_NegChangingCorr2_4(i_mouse)./N_Corrs(1, i_mouse);
    N_StableCorr2_4(i_mouse) = (MeanNPosCorrThrHard(i_mouse, 2) + MeanNNegCorrThrHard(i_mouse, 2)) - (N_PosChangingCorr2_4(i_mouse) + N_NegChangingCorr2_4(i_mouse));
    
    
        MaxDiff = nanmax([max_tmp1_2, max_tmp1_4, max_tmp2_4]);
    MinDiff = nanmin([min_tmp1_2, min_tmp1_4, min_tmp2_4]);
    for i_state = 1:4
        if  i_state == 3 % There's no state tag 3...
            continue
        end
        switch i_state
            case 1
                subplot(subplot_n_rows, subplot_n_cols, 3+i_state);
                pcolor(Current_MeanCorrMatrixDiff1_2);
                axis square
                title('\Delta(Awake-NonREM)', 'FontSize', Title_FontSize);
                xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', Mean_tmp1_2, MeanAbs_tmp1_2, MeanAbsThr_tmp1_2, CorrThr_Diff));
            case 2
                subplot(subplot_n_rows, subplot_n_cols, 3+i_state);
                pcolor(Current_MeanCorrMatrixDiff1_4);
                axis square
                title('\Delta(Awake-REM)', 'FontSize', Title_FontSize);
                xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', Mean_tmp1_4, MeanAbs_tmp1_4, MeanAbsThr_tmp1_4, CorrThr_Diff));
            case 4
                subplot(subplot_n_rows, subplot_n_cols, 3+i_state-1);
                pcolor(Current_MeanCorrMatrixDiff2_4);
                axis square
                title('\Delta(NonREM-REM)', 'FontSize', Title_FontSize);
                xlabel(sprintf('Non-Significant Values Were Put to 0.\nMean Difference = %.3g\nMean Absolute Difference = %.3g\nMean Absolute Significant Difference = %.3g (Thr = %.2g)', Mean_tmp2_4, MeanAbs_tmp2_4, MeanAbsThr_tmp2_4, CorrThr_Diff));
        end
        caxis([MinDiff MaxDiff]);
        colorbar
        ylabel('Neuron ID');
    end
    h_suptitle = suptitle(Suptitle_Str);
    h_suptitle.FontSize = SupTitle_FontSize;
    
%     FileName = sprintf('Correlation MeanOfStates - Mouse %s', MouseName);
%     FilePath = sprintf('%s\\%s', Dir_Figures, FileName);
%     print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
%     saveas(gcf, strcat(FilePath, '.jpg'))
%     saveas(gcf, strcat(FilePath, '.fig'))
%     close gcf

end


%% Figure 2 ---- Mean between states across various mice.
figure;
set(gcf,'position', get(0,'screensize'));
n_rows = 2;
n_cols = 3;
i_subplot = 1;
BoxPlot_Groups = [1*ones(1, n_mice), 2*ones(1, n_mice), 3*ones(1, n_mice)];

% Boxplot MeanCorr
MeanCorr_tmp = MeanCorr;
MeanCorr_tmp(MeanCorr_tmp == 0) = [];
MeanCorr_BoxPlot = reshape (MeanCorr_tmp, 1, n_mice*(4-1));
subplot(n_rows, n_cols, i_subplot);
h_boxplot_1 = boxplot(MeanCorr_BoxPlot, BoxPlot_Groups); 
set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
i_subplot = i_subplot + 1;
ylabel('Mean Correlation');
title('Mean Correlation')

% Boxplot Mean AbsCorr
MeanCorr_tmp = MeanAbsCorr;
MeanCorr_tmp(MeanCorr_tmp == 0) = [];
MeanCorrAbs_BoxPlot = reshape (MeanCorr_tmp, 1, n_mice*(4-1));
subplot(n_rows, n_cols, i_subplot);
h_boxplot_2 = boxplot(MeanCorrAbs_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
i_subplot = i_subplot + 1;
ylabel('Mean Correlation');
title('Mean Abs Correlation')

% Boxplot Mean AbsCorrThr
MeanCorr_tmp = MeanAbsCorrThr;
MeanCorr_tmp(MeanCorr_tmp == 0) = [];
MeanAbsCorrThr_BoxPlot = reshape (MeanCorr_tmp, 1, n_mice*(4-1));
subplot(n_rows, n_cols, i_subplot);
h_boxplot_3 = boxplot(MeanAbsCorrThr_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
ylabel('Mean Correlation');
title('Mean Abs Significant Correlation (Corr > 0.1)')
i_subplot = i_subplot + 1;

% Boxplot Mean N of Significant Correlations
MeanNPosCorrThr_tmp = MeanNPosCorrThrHard;
MeanNPosCorrThr_tmp(:, 3) = [];
MeanNPosCorrThr_BoxPlot = reshape (MeanNPosCorrThr_tmp, 1, n_mice*(4-1));
subplot(n_rows, n_cols, i_subplot);
h_boxplot_3 = boxplot(MeanNPosCorrThr_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
ylabel('# Significant Positive Correlations');
title('Mean # of Significant Correlation (Corr > 0.2)')
i_subplot = i_subplot + 1;

% Boxplot Mean N of Significant Correlations
MeanNNegCorrThr_tmp = MeanNNegCorrThrHard;
MeanNNegCorrThr_tmp(:, 3) = [];
MeanNNegCorrThr_BoxPlot = reshape (MeanNNegCorrThr_tmp, 1, n_mice*(4-1));
subplot(n_rows, n_cols, i_subplot);
h_boxplot_3 = boxplot(MeanNNegCorrThr_BoxPlot, BoxPlot_Groups);
set(gca,'XTickLabel',{'Awake', 'NoN-REM', 'REM'});
ylabel('# Significant Negative Correlations');
title('Mean # of Significant Correlation (Corr < -0.2)')
i_subplot = i_subplot + 1;

% Pie-chart "Stable Correlations"




%% Figure 3 ---- Bar Plots of single correlation changes.
figure();
Groups_Bars = [1, 2, 4, 5, 7, 8];
y = [N_PosChangingCorrNorm1_2; -N_NegChangingCorrNorm1_2; N_PosChangingCorrNorm2_4; -N_NegChangingCorrNorm2_4; N_PosChangingCorrNorm1_4; -N_NegChangingCorrNorm1_4;].*100;
subplot(2, 2, 1);

bar(Groups_Bars, y, 'stacked')
set(gca,'XTick', [1.5, 4.5, 7.5]);
set(gca,'XTickLabel',{'Awake->NoN-REM', 'NoN-REM->REM', 'Awake->REM'});
ylabel(sprintf('%% Significantly different Correlations\nbetween states'));
h_legend = legend;
tmp = h_legend.String;
h_legend.Interpreter = 'none';
for i_mouse = 1:numel(N_PosChangingCorr1_2)
    tmp{i_mouse} = sprintf('Mouse #%s', Mouse_Names{i_mouse});
end
h_legend.String = tmp;
h_legend.FontSize = 7;
grid on;

h_axis = get(gca);
tmp = h_axis.Children;
Color_Increment = [0, 0, 1/n_mice];
Color = [(1/n_mice)*2, (1/n_mice)*2, 0];
for i_plot = 1:numel(tmp)
   tmp(i_plot).FaceColor = Color + Color_Increment*i_plot;
end

keyboard
% Pie-charts (ratio of significantly changing vs stable)
subplot(2, 2, 2);
pie()



% hold on
% er = errorbar(Groups_Bars,data,errlow,errhigh);    
% er.Color = [0 0 0];                            
% er.LineStyle = 'none';  
% hold off
