function Sync2StateChange (Events_AllMice, Mouse_Names, Opts)
% This function runs the main analysis for the events lag time to the
% previous state change, and plots the results.
% The actual lags are computed in the main analysis function and are saved
% in the struct variable "Events_AllMice".


% Options.
if nargin < 3
    Opts = set_options;
end
if isempty(Opts)
    Opts = set_options;
end

Opts.General.MinStableStateDuration = 20*Opts.General.FrameRate;
n_max_states = 1000; % Maximum numeber of hypothesised states in the whole recordings (for array initialization purpose: keep this number higher than actual number of states)
n_events = numel(Events_AllMice); % Maximum number of events in a state (for array initialization: ok vastly overestimated)

minimum_state_length = Opts.General.MinStableStateDuration;
TagAWAKE = Opts.General.TagAWAKE;
TagNoNREM = Opts.General.TagNoNREM;
TagREM = Opts.General.TagREM;


%% Initialize variables.
% Remove 1st State of recordings (as its duration is unknown, together with the state that comes before it)
Events_AllMice(isnan([Events_AllMice.NextStateTag])) = [];

% Isolate Events per State
tmp_StateChangeLags_All = [Events_AllMice.Dist_PreState];
Events_Awake = Events_AllMice([Events_AllMice.StateTag] == TagAWAKE);
Events_NoNREM = Events_AllMice([Events_AllMice.StateTag] == TagNoNREM);
Events_REM = Events_AllMice([Events_AllMice.StateTag] == TagREM);

tmp_StateChangeLag_Awake = [Events_Awake.Dist_PreState];
tmp_StateChangeLag_NoNREM = [Events_NoNREM.Dist_PreState];
tmp_StateChangeLag_REM = [Events_REM.Dist_PreState];

% Transition States.
Events_Unstable_Awake = Events_Awake([Events_Awake.StateLength] < minimum_state_length);
Events_Unstable_NoNREM = Events_NoNREM([Events_NoNREM.StateLength] < minimum_state_length);
Events_Unstable_REM = Events_REM([Events_REM.StateLength] < minimum_state_length);
Events_Stable_Awake = Events_Awake([Events_Awake.StateLength] > minimum_state_length);
Events_Stable_NoNREM = Events_NoNREM([Events_NoNREM.StateLength] > minimum_state_length);
Events_Stable_REM = Events_REM([Events_REM.StateLength] > minimum_state_length);
StateLength_min_Awake = nanmin([Events_Stable_Awake.StateLength]);
StateLength_min_NoNREM = nanmin([Events_Stable_NoNREM.StateLength]);
StateLength_min_REM = nanmin([Events_Stable_REM.StateLength]);
StateLength_min = nanmin([StateLength_min_Awake, StateLength_min_NoNREM, StateLength_min_REM]);

% For a fair comparison, do not take events with too much lag, as some states are shorter than that.
Events_Stable_Cut2Compare_Awake = Events_Stable_Awake([Events_Stable_Awake.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_NoNREM = Events_Stable_NoNREM([Events_Stable_NoNREM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);
Events_Stable_Cut2Compare_REM = Events_Stable_REM([Events_Stable_REM.Dist_PreState] < StateLength_min/Opts.General.FrameRate);


%% Comparisons
StateChangeLag_Unstable_Awake = [Events_Unstable_Awake.Dist_PreState];
StateChangeLag_Unstable_NoNREM = [Events_Unstable_NoNREM.Dist_PreState];
StateChangeLag_Stable_Awake = [Events_Stable_Awake.Dist_PreState];
StateChangeLag_Stable_NoNREM = [Events_Stable_NoNREM.Dist_PreState];
StateChangeLag_Stable_REM = [Events_Stable_REM.Dist_PreState];

StateChangeLag_Stable_Awake_Cut2Compare = [Events_Stable_Cut2Compare_Awake.Dist_PreState];
StateChangeLag_Stable_NoNREM_Cut2Compare = [Events_Stable_Cut2Compare_NoNREM.Dist_PreState];
StateChangeLag_Stable_REM_Cut2Compare = [Events_Stable_Cut2Compare_REM.Dist_PreState];

% Separate the Events and Events Lags per State for each mouse.
n_mice = numel(Mouse_Names);
tmp_Lag_per_State_Awake = NaN(n_max_states, n_events);
tmp_Lag_per_State_NoNREM = NaN(n_max_states, n_events);
tmp_Lag_per_State_REM = NaN(n_max_states, n_events);
tmp_dim1_pre_Awake = 0;
tmp_dim1_pre_NoNREM = 0;
tmp_dim1_pre_REM = 0;
keyboard
for i_mouse = 1:n_mice
    MouseName = Mouse_Names{i_mouse};
    Current_Mouse_Events = separate_events_per_mouse (Events_AllMice, MouseName);
    n_states = nanmax([Current_Mouse_Events.StateNumber]);
    fprintf('Getting Event Lags for Mouse %s: %d Sleep States detected.\n', MouseName, n_states);
    
    [tmp_Lag_per_State_Awake, tmp_Events_per_State_Awake, tmp_dim1_pre_Awake] = Sync2StateChange_Sub_1 (Events_Stable_Cut2Compare_Awake, tmp_Lag_per_State_Awake, MouseName, n_states, tmp_dim1_pre_Awake);
    [tmp_Lag_per_State_NoNREM, tmp_Events_per_State_NoNREM, tmp_dim1_pre_NoNREM] = Sync2StateChange_Sub_1 (Events_Stable_Cut2Compare_NoNREM, tmp_Lag_per_State_NoNREM, MouseName, n_states, tmp_dim1_pre_NoNREM);
    [tmp_Lag_per_State_REM, tmp_Events_per_State_REM, tmp_dim1_pre_REM] = Sync2StateChange_Sub_1 (Events_Stable_Cut2Compare_REM, tmp_Lag_per_State_REM, MouseName, n_states, tmp_dim1_pre_REM);
    
%     [tmp1_Lag_per_State_Awake, tmp_Events_per_State_Awake] = get_EventsLags_per_State (Events_Stable_Cut2Compare_Awake, MouseName, n_states);
%     [tmp1_Lag_per_State_NoNREM, tmp_Events_per_State_NoNREM] = get_EventsLags_per_State (Events_Stable_Cut2Compare_NoNREM, MouseName, n_states);
%     [tmp1_Lag_per_State_REM, tmp_Events_per_State_REM] = get_EventsLags_per_State (Events_Stable_Cut2Compare_REM, MouseName, n_states);
%     
%     [tmp_dim1_Awake, tmp_dim2_Awake] = size(tmp1_Lag_per_State_Awake);
%     [tmp_dim1_NoNREM, tmp_dim2_NoNREM] = size(tmp1_Lag_per_State_NoNREM);
%     [tmp_dim1_REM, tmp_dim2_REM] = size(tmp1_Lag_per_State_REM);
%     
%     tmp_Lag_per_State_Awake((tmp_dim1_Awake_pre+1):(tmp_dim1_Awake_pre+tmp_dim1_Awake), 1:tmp_dim2_Awake) = tmp1_Lag_per_State_Awake;
%     tmp_Lag_per_State_NoNREM((tmp_dim1_NoNREM_pre+1):(tmp_dim1_NoNREM_pre+tmp_dim1_NoNREM), 1:tmp_dim2_NoNREM) = tmp1_Lag_per_State_NoNREM;
%     tmp_Lag_per_State_REM((tmp_dim1_REM_pre+1):(tmp_dim1_REM_pre+tmp_dim1_REM), 1:tmp_dim2_REM) = tmp1_Lag_per_State_REM;
%     
%     tmp_dim1_Awake_pre = tmp_dim1_Awake_pre + tmp_dim1_Awake;
%     tmp_dim1_NoNREM_pre = tmp_dim1_NoNREM_pre + tmp_dim1_NoNREM;
%     tmp_dim1_REM_pre = tmp_dim1_REM_pre + tmp_dim1_REM;
%     
%     clear tmp_Events; clear tmp1_Lag_per_State_Awake; clear tmp1_Lag_per_State_NoNREM; clear tmp1_Lag_per_State_REM;
end

% Remove extra columns (columns of NaNs only).
tmp_Lag_per_State_Awake(~any(~isnan(tmp_Lag_per_State_Awake), 2),:) = [];
tmp_Lag_per_State_NoNREM(~any(~isnan(tmp_Lag_per_State_NoNREM), 2),:) = [];
tmp_Lag_per_State_REM(~any(~isnan(tmp_Lag_per_State_REM), 2),:) = [];
% Remove extra raws (raws of NaNs only).
tmp_Lag_per_State_Awake(:, ~any(~isnan(tmp_Lag_per_State_Awake), 1)) = [];
tmp_Lag_per_State_NoNREM(:, ~any(~isnan(tmp_Lag_per_State_NoNREM), 1)) = [];
tmp_Lag_per_State_REM(:, ~any(~isnan(tmp_Lag_per_State_REM), 1)) = [];

[LagsDim1_Awake, LagsDim2_Awake] = size(tmp_Lag_per_State_Awake);
[LagsDim1_NoNREM, LagsDim2_NoNREM] = size(tmp_Lag_per_State_NoNREM);
[LagsDim1_REM, LagsDim2_REM] = size(tmp_Lag_per_State_REM);

% Divide the Lags in bins of fixed duration for each state.
bins_max = StateLength_min/Opts.General.FrameRate; % [s]
bins_duration = bins_max/Opts.Sync.NLagBins; % [s]

% Remove States with less than N events, as they confund the analysis in the Means/StE (especially Normalization 2).
[~, tmp_N_Events_perBinStats_Awake, tmp_Event_N_perState_Awake, tmp_Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (tmp_Lag_per_State_Awake, StateLength_min, Opts);
Lag_per_State_Awake = tmp_Lag_per_State_Awake;
Lag_per_State_Awake(~(tmp_Event_N_perState_Awake > tmp_Event_N_perStateStats_Awake.Thr), :) = [];
[~, tmp_N_Events_perBinStats_NoNREM, tmp_Event_N_perState_NoNREM, tmp_Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_NoNREM, StateLength_min, Opts);
Lag_per_State_NoNREM = tmp_Lag_per_State_NoNREM;
Lag_per_State_NoNREM(~(tmp_Event_N_perState_NoNREM > tmp_Event_N_perStateStats_NoNREM.Thr), :) = [];
[~, tmp_N_Events_perBinStats_REM, tmp_Event_N_perState_REM, tmp_Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (tmp_Lag_per_State_REM, StateLength_min, Opts);
Lag_per_State_REM = tmp_Lag_per_State_REM;
Lag_per_State_REM(~(tmp_Event_N_perState_REM > tmp_Event_N_perStateStats_REM.Thr), :) = [];

% Get States and Bins separation, means, StEs.
[N_Events_perBin_Awake, N_Events_perBinStats_Awake, Event_N_perState_Awake, Event_N_perStateStats_Awake] = get_NEvents_PerTimeBin (Lag_per_State_Awake, StateLength_min, Opts);
[N_Events_perBin_NoNREM, N_Events_perBinStats_NoNREM, Event_N_perState_NoNREM, Event_N_perStateStats_NoNREM] = get_NEvents_PerTimeBin (Lag_per_State_NoNREM, StateLength_min, Opts);
[N_Events_perBin_REM, N_Events_perBinStats_REM, Event_N_perState_REM, Event_N_perStateStats_REM] = get_NEvents_PerTimeBin (Lag_per_State_REM, StateLength_min, Opts);

% Compare differences between time bins, for different states.
N_Events_Diff_perBin_Awake = diff(N_Events_perBin_Awake, 1, 2);
N_Events_Diff_perBin_NoNREM = diff(N_Events_perBin_NoNREM, 1, 2);
N_Events_Diff_perBin_REM = diff(N_Events_perBin_REM, 1, 2);

% Compute Statistics: Differences between states across the bins)
for i_bin = 1:Opts.Sync.NLagBins
    Stats.Bins(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.Bins(i_bin).NEvents_Mean_Awake = N_Events_perBinStats_Awake.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_NoNREM = N_Events_perBinStats_NoNREM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_Mean_REM = N_Events_perBinStats_REM.Mean(i_bin);
    Stats.Bins(i_bin).NEvents_StE_Awake = N_Events_perBinStats_Awake.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_NoNREM = N_Events_perBinStats_NoNREM.StE(i_bin);
    Stats.Bins(i_bin).NEvents_StE_REM = N_Events_perBinStats_REM.StE(i_bin);
    [Stats.Bins(i_bin).AwakeVSNoNREM.h, Stats.Bins(i_bin).AwakeVSNoNREM.P_Value, Stats.Bins(i_bin).AwakeVSNoNREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSNoNREM.Stats] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).AwakeVSREM.h, Stats.Bins(i_bin).AwakeVSREM.P_Value, Stats.Bins(i_bin).AwakeVSREM.Confidence_Interval, Stats.Bins(i_bin).AwakeVSREM.Stats] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.Bins(i_bin).NoNREMVSREM.h, Stats.Bins(i_bin).NoNREMVSREM.P_Value, Stats.Bins(i_bin).NoNREMVSREM.Confidence_Interval, Stats.Bins(i_bin).NoNREMVSREM.Stats] = ttest2(N_Events_perBin_NoNREM(:, i_bin), N_Events_perBin_REM(:, i_bin), 'Vartype', 'unequal');
end

% Compute Statistics: Differences between bins of the same states
for i_bin = 1:Opts.Sync.NLagBins
    for j_bin = 1:Opts.Sync.NLagBins
        [Stats.BinsComparison.Awake.h(i_bin, j_bin), Stats.BinsComparison.Awake.P_Value(i_bin, j_bin), Stats.BinsComparison.Awake.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.Awake.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_Awake(:, i_bin), N_Events_perBin_Awake(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.NoNREM.h(i_bin, j_bin), Stats.BinsComparison.NoNREM.P_Value(i_bin, j_bin), Stats.BinsComparison.NoNREM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.NoNREM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_NoNREM(:, i_bin), N_Events_perBin_NoNREM(:, j_bin), 'Vartype', 'unequal');
        [Stats.BinsComparison.REM.h(i_bin, j_bin), Stats.BinsComparison.REM.P_Value(i_bin, j_bin), Stats.BinsComparison.REM.Confidence_Interval{i_bin, j_bin}, Stats.BinsComparison.REM.Stats{i_bin, j_bin}] = ttest2(N_Events_perBin_REM(:, i_bin), N_Events_perBin_REM(:, j_bin), 'Vartype', 'unequal');
    end
end

% Compute Statistics: Differences between derivative(#N Events per bin)
for i_bin = 1:(Opts.Sync.NLagBins - 1)
    Stats.BinsDiff(i_bin).Bin = [(i_bin - 1)*bins_duration, (i_bin)*bins_duration];
    Stats.BinsDiff(i_bin).NEvents_DiffMean_Awake = nanmean(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_NoNREM = nanmean(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffMean_REM = nanmean(N_Events_Diff_perBin_REM(:, i_bin));
    tmp = size(N_Events_Diff_perBin_Awake(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_Awake = nanstd(N_Events_Diff_perBin_Awake(:, i_bin))/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_NoNREM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_NoNREM = N_Events_Diff_perBin_NoNREM(:, i_bin)/sqrt(tmp(1));
    tmp = size(N_Events_Diff_perBin_REM(:, i_bin));
    Stats.BinsDiff(i_bin).NEvents_DiffStE_REM = N_Events_Diff_perBin_REM(:, i_bin)/sqrt(tmp(1));
    [Stats.BinsDiff(i_bin).AwakeVSNoNREM.h, Stats.BinsDiff(i_bin).AwakeVSNoNREM.P_Value, Stats.BinsDiff(i_bin).AwakeVSNoNREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeVSNoNREM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_NoNREM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).AwakeVSREM.h, Stats.BinsDiff(i_bin).AwakeVSREM.P_Value, Stats.BinsDiff(i_bin).AwakeVSREM.Confidence_Interval, Stats.BinsDiff(i_bin).AwakeVSREM.Stats] = ttest2(N_Events_Diff_perBin_Awake(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
    [Stats.BinsDiff(i_bin).NoNREMVSREM.h, Stats.BinsDiff(i_bin).NoNREMVSREM.P_Value, Stats.BinsDiff(i_bin).NoNREMVSREM.Confidence_Interval, Stats.BinsDiff(i_bin).NoNREMVSREM.Stats] = ttest2(N_Events_Diff_perBin_NoNREM(:, i_bin), N_Events_Diff_perBin_REM(:, i_bin), 'Vartype', 'unequal');
end

clear tmp*


%% Transition Types.
Events_REM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagREM);
Events_NoNREM2Awake = Events_Awake([Events_Awake.PreStateTag] == TagNoNREM);
tmp_StateChangeLag_REM2Awake = [Events_REM2Awake.Dist_PreState];
tmp_StateChangeLag_NoNREM2Awake = [Events_NoNREM2Awake.Dist_PreState];

N_Events_StableCut_Awake = numel(StateChangeLag_Stable_Awake_Cut2Compare);
N_Events_StableCut_NoNREM = numel(StateChangeLag_Stable_NoNREM_Cut2Compare);
N_Events_StableCut_REM = numel(StateChangeLag_Stable_REM_Cut2Compare);

keyboard
%% Plot - Distribution of events between lag intervals.
Sync2StateChange_DistributionPlot (N_Events_perBinStats_Awake, N_Events_perBinStats_NoNREM, N_Events_perBinStats_REM, bins_duration, Opts)


%% Scatter Histograms
str_suptitle = 'Events Lag after State Change';
str_xlabel = 'Lag to State Change [s]';

% Awake vs Non-REM vs REM (All)
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [tmp_StateChangeLag_Awake, tmp_StateChangeLag_NoNREM, tmp_StateChangeLag_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake'; str_legend{2} = 'Non-REM'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 1';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% Awake post REM vs Awake post Non-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM2Awake)), 2*ones(1, numel(tmp_StateChangeLag_NoNREM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM2Awake, tmp_StateChangeLag_NoNREM2Awake];
Opts.Sync.Plot.Color = [0, 0, 1; 0, 0, 0.5];
str_legend{1} = 'Awake post REM'; str_legend{2} = 'Awake post Non-REM';
FileName = 'Figure Lag2StateChange 2';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% Awake vs Non-REM vs REM (Stable States)
Data_Conditions = [1*ones(1, numel(StateChangeLag_Stable_Awake)), 2*ones(1, numel(StateChangeLag_Stable_NoNREM)), 3*ones(1, numel(tmp_StateChangeLag_REM))];
Data_tmp = [StateChangeLag_Stable_Awake, StateChangeLag_Stable_NoNREM, StateChangeLag_Stable_REM];
Opts.Sync.Plot.Color = [0, 0, 1; 1, 0, 0; 0, 1, 0];
str_legend{1} = 'Awake (Stable)'; str_legend{2} = 'Non-REM (Stable)'; str_legend{3} = 'REM';
FileName = 'Figure Lag2StateChange 3';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);

% REM vs Awake Post-REM
Data_Conditions = [1*ones(1, numel(tmp_StateChangeLag_REM)), 2*ones(1, numel(tmp_StateChangeLag_REM2Awake))];
Data_tmp = [tmp_StateChangeLag_REM, tmp_StateChangeLag_REM2Awake];
Opts.Sync.Plot.Color = [0, 1, 0; 0, 0, 1];
str_legend{1} = 'REM'; str_legend{2} = 'Awake (after REM)';
FileName = 'Figure Lag2StateChange 4';
FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);

plot_ScatterHist_StateChangeLags(Data_tmp, Data_Conditions, str_legend, str_suptitle, str_xlabel, FilePath, Opts);



%% Sub-Functions
    function [tmp_Lag_per_State, tmp_Events_per_State, tmp_dim1_pre] = Sync2StateChange_Sub_1 (Events_Stable_Cut2Compare, tmp_Lag_per_State, MouseName, n_states, tmp_dim1_pre)
        % This function is used in a loop to increase readibility, and to
        % make it easier to repeat operations for different states.
        % It gets the Event Lags for each State.
        
        [tmp1_Lag_per_State, tmp_Events_per_State] = get_EventsLags_per_State (Events_Stable_Cut2Compare, MouseName, n_states);
        [tmp_dim1, tmp_dim2] = size(tmp1_Lag_per_State);
        tmp_Lag_per_State((tmp_dim1_pre + 1):(tmp_dim1_pre + tmp_dim1), 1:tmp_dim2) = tmp1_Lag_per_State;
        
        tmp_dim1_pre = tmp_dim1_pre + tmp_dim1;        
    end

end
