function Sync_Stats = sync_analysis (Events_AllMice, Hypnogram_AllMice, calTime, Hist_Results)
% This function performs the temporal analysis of the calcium events
% (synchronization).

% Computes the synchrony per single state (interval between 2 state
% changes).
% Sync is the mean number of events in sync / #events, basically, it is
% equivalent to the SPIKE-synchronization measure presented here:
% http://www.scholarpedia.org/article/Measures_of_spike_train_synchrony


Opts.Max_EventsDistance = 10; % [frames, seconds = frames/3]


%% Preliminary operations.
n_mouse = numel(Hypnogram_AllMice);
n_Events_Tot = numel(Events_AllMice);

% Make Binary Traces for Synchro Analysis.
Opts.MakeBinary.EventIdentifier = 'RiseSlope'; % Can be 'StartComposite', 'PeakComposite', 'MidPointComposite', 'PeakSingle'
Binary_Traces_AllMice = make_binary_traces (Events_AllMice, Hypnogram_AllMice, calTime, Opts.MakeBinary);

% Max number of states in mouse.
states_n_max = 0;
for i_mouse = 1:n_mouse
    states_n_max = max(numel(Hypnogram_AllMice(i_mouse).StateChanges), states_n_max);
end


%% Synchrony analysis.
sync_matrix = NaN(n_mouse, states_n_max);
state_matrix = NaN(n_mouse, states_n_max);
n_events_matrix = NaN(n_mouse, states_n_max);
n_events_overlap_avg_matrix = NaN(n_mouse, states_n_max);
n_events_singlets_matrix = NaN(n_mouse, states_n_max);
state_length = NaN(n_mouse, states_n_max);
n_cells = NaN(1, n_mouse);
for i_mouse = 1:n_mouse
    % Get quantities for the current mouse.
    current_mouse_traces = (Binary_Traces_AllMice{i_mouse})';
    current_Hypnogram = Hypnogram_AllMice(i_mouse).Hypnogram;
    current_StateChanges = Hypnogram_AllMice(i_mouse).StateChanges;
    current_traces_matrix = cell2mat(current_mouse_traces);
    
    n_cells(i_mouse) = numel(current_mouse_traces);
    current_n_states = numel(current_StateChanges);
    [current_n_cells, current_n_frames] = size(current_traces_matrix);
    
    % Separate each Mouse binary traces by State.
    synchron = NaN(1, current_n_states);
    state_vector = NaN(1, current_n_states);
    for i_state = 1:current_n_states-1
        if current_StateChanges(i_state) > 1
            state_vector(i_state) = current_Hypnogram(current_StateChanges(i_state));
        elseif current_StateChanges(i_state) == 1
            state_vector(i_state) = current_Hypnogram(1);
        end
        current_state_array = current_StateChanges(i_state):current_StateChanges(i_state + 1);
        
        current_traces_state = current_traces_matrix(:, current_state_array(1):current_state_array(end));
        tmp_sync = nansum(current_traces_state, 1);
        tmp_sync(tmp_sync == 0) = NaN;
        n_events_singlets = numel(tmp_sync(tmp_sync == 1));
        n_events = nansum(tmp_sync);
        tmp_sync(tmp_sync == 1) = 0;
        n_events_overlap = nansum(tmp_sync);
        n_events_overlap_avg = nanmean(tmp_sync);
        tmp_sync = tmp_sync./current_n_cells;
        
        synchron(i_state) = nanmean(tmp_sync);
        if numel(synchron) ~= numel(state_vector)
            warning('Number of states ~= number of Syncs')
        end
        
        state_length(i_mouse, i_state) = numel(current_state_array);
        n_events_matrix(i_mouse, i_state) = n_events;
        n_events_overlap_avg_matrix(i_mouse, i_state) = n_events_overlap_avg;
        n_events_singlets_matrix(i_mouse, i_state) = n_events_singlets;
    end
    
    sync_matrix(i_mouse, 1:numel(synchron)) = synchron;
    state_matrix(i_mouse, 1:numel(synchron)) = state_vector;
    
    clear current*
    clear next*
    clear tmp*
end


%% Get statistics per state.
% Separate Sync measure by state.
Sync_Awake = sync_matrix(state_matrix == 1);
Sync_Awake(isnan(Sync_Awake)) = [];
Sync_NoNREM = sync_matrix(state_matrix == 2);
Sync_NoNREM(isnan(Sync_NoNREM)) = [];
Sync_REM = sync_matrix(state_matrix == 4);
Sync_REM(isnan(Sync_REM)) = [];

state_length_avg_Awake = nanmean(state_length(state_matrix == 1));
state_length_std_Awake = nanstd(state_length(state_matrix == 1));
state_length_avg_NoNREM = nanmean(state_length(state_matrix == 2));
state_length_std_NoNREM = nanstd(state_length(state_matrix == 2));
state_length_avg_REM = nanmean(state_length(state_matrix == 4));
state_length_std_REM = nanstd(state_length(state_matrix == 4));


% Separate n_events by state.
% Awake
n_events_Awake = n_events_matrix(state_matrix == 1);
n_events_Awake(isnan(n_events_Awake)) = [];
n_cells_avg_Awake = mean(n_cells(any(state_matrix == 1, 2)));
n_events_overlap_avg_Awake = n_events_overlap_avg_matrix(state_matrix == 1);
n_events_overlap_avg_Awake(isnan(n_events_overlap_avg_Awake)) = [];
n_events_singlets_Awake = n_events_singlets_matrix(state_matrix == 1);
n_events_singlets_Awake(isnan(n_events_singlets_Awake)) = [];
% NoN-REM
n_events_NoNREM = n_events_matrix(state_matrix == 2);
n_events_NoNREM(isnan(n_events_NoNREM)) = [];
n_cells_avg_NoNREM = mean(n_cells(any(state_matrix == 2, 2)));
n_events_overlap_avg_NoNREM = n_events_overlap_avg_matrix(state_matrix == 2);
n_events_overlap_avg_NoNREM(isnan(n_events_overlap_avg_NoNREM)) = [];
n_events_singlets_NoNREM = n_events_singlets_matrix(state_matrix == 2);
n_events_singlets_NoNREM(isnan(n_events_singlets_NoNREM)) = [];
% REM
n_events_REM = n_events_matrix(state_matrix == 4);
n_events_REM(isnan(n_events_REM)) = [];
n_cells_avg_REM = mean(n_cells(any(state_matrix == 4, 2)));
n_events_overlap_avg_REM = n_events_overlap_avg_matrix(state_matrix == 4);
n_events_overlap_avg_REM(isnan(n_events_overlap_avg_REM)) = [];
n_events_singlets_REM = n_events_singlets_matrix(state_matrix == 4);
n_events_singlets_REM(isnan(n_events_singlets_REM)) = [];

Sync_Stats.Awake.n_states = numel(Sync_Awake);
Sync_Stats.Awake.state_length_avg = state_length_avg_Awake;
Sync_Stats.Awake.state_length_std = state_length_std_Awake;
Sync_Stats.Awake.n_cells_avg = n_cells_avg_Awake;
Sync_Stats.Awake.n_events = nansum(n_events_Awake);
Sync_Stats.Awake.n_events_overlap_avg = nanmean(n_events_overlap_avg_Awake);
Sync_Stats.Awake.n_events_singlets = nansum(n_events_singlets_Awake);
Sync_Stats.Awake.Sync_Mean = nanmean(Sync_Awake);
Sync_Stats.Awake.Sync_Std = nanstd(Sync_Awake);

Sync_Stats.NoNREM.n_states = numel(Sync_NoNREM);
Sync_Stats.NoNREM.state_length_avg = state_length_avg_NoNREM;
Sync_Stats.NoNREM.state_length_std = state_length_std_NoNREM;
Sync_Stats.NoNREM.n_cells_avg = n_cells_avg_NoNREM;
Sync_Stats.NoNREM.n_events = nansum(n_events_NoNREM);
Sync_Stats.NoNREM.n_events_overlap_avg = nanmean(n_events_overlap_avg_NoNREM);
Sync_Stats.NoNREM.n_events_singlets = nansum(n_events_singlets_NoNREM);
Sync_Stats.NoNREM.Sync_Mean = nanmean(Sync_NoNREM);
Sync_Stats.NoNREM.Sync_Std = nanstd(Sync_NoNREM);

Sync_Stats.REM.n_states = numel(Sync_REM);
Sync_Stats.REM.state_length_avg = state_length_avg_REM;
Sync_Stats.REM.state_length_std = state_length_std_REM;
Sync_Stats.REM.n_cells_avg = n_cells_avg_REM;
Sync_Stats.REM.n_events = nansum(n_events_REM);
Sync_Stats.REM.n_events_overlap_avg = nanmean(n_events_overlap_avg_REM);
Sync_Stats.REM.n_events_singlets = nansum(n_events_singlets_REM);
Sync_Stats.REM.Sync_Mean = nanmean(Sync_REM);
Sync_Stats.REM.Sync_Std = nanstd(Sync_REM);


% Compute covariance, information, G.Causality matricex between traces,
% both in the case of the whole trace, and for long.

