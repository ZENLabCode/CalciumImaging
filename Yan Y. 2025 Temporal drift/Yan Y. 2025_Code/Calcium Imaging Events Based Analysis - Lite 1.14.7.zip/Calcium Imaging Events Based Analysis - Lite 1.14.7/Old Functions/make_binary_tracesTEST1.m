function Binary_Traces_AllMice = make_binary_traces (Events_AllMice, Hypnogram_AllMice, calTime, Opts)
% This function gives in output a binary matrix, where values of 1
% correspond to the events peaks (or start, depending on the option) in the
% signal traces.
% This function is intented for use in the syncro_analysis.

% Do not get sub-events.
Events_Complex = get_composite_info(Events_AllMice);
Events = Events_Complex;

keyboard

n_mouse = numel(Hypnogram_AllMice);
n_Events_Tot = numel(Events);

% Get Mouse Tag.
Current_Mouse = Events(1).MouseTag;
Binary_Traces_AllMice = cell(1, n_mouse);
i2_event = 1;
i_event = 1;
if exist('Current_Mouse_Events' , 'var') ~= 0
   clear Current_Mouse_Events
end

for i_mouse = 1:n_mouse
    counter_event_binarized = 0;
    % Get Hypnogram
    Current_Hypnogram = Hypnogram_AllMice(i_mouse).Hypnogram;
    
    n_DataPoints = numel(Current_Hypnogram);
    
    % Get events from a single mouse
    while i_event <= n_Events_Tot && strcmpi(Events(i_event).MouseTag, Current_Mouse) == 1
        Current_Mouse_Events(i2_event) = Events(i_event);
        i2_event = i2_event + 1;
        i_event = i_event + 1;
    end
    
    fprintf('Current Mouse: "%s" (# Events = %d)\n', Current_Mouse, numel(Current_Mouse_Events))

    % Get Events from a single trace.
    n_current_traces = nanmax([Current_Mouse_Events.TraceNumber]);
    Binary_Traces = cell(1, n_current_traces);
    for i_trace = 1:n_current_traces
        % Get current trace.
        current_trace_Events = Current_Mouse_Events([Current_Mouse_Events.TraceNumber] == i_trace);
        
        % Make a binary trace, Event = 1 / NoN-Event = 0.
        current_trace_Binary = zeros(1, n_DataPoints);
        for j_event = 1:numel(current_trace_Events)
            if strcmpi(Opts.EventIdentifier, 'PeakComposite') % Takes only the main peak of a composite as 1
                tmp_event_loc = current_trace_Events(j_event).PeakLoc;
                if isnan(tmp_event_loc) || current_trace_Events(j_event).CompositeTag == 0
                    tmp_event_loc = current_trace_Events(j_event).PeakLoc;
                    current_trace_Binary(tmp_event_loc) = 1;
                end
            elseif strcmpi(Opts.EventIdentifier, 'StartComposite') % Takes the start of a composite event as 1
                tmp_event_loc = current_trace_Events(j_event).Start;
                if isnan(tmp_event_loc) || current_trace_Events(j_event).CompositeTag == 0
                    tmp_event_loc = current_trace_Events(j_event).Start;
                    try
                        current_trace_Binary(tmp_event_loc) = 1;
                        counter_event_binarized = counter_event_binarized + 1;
                    catch
                        keyboard
                    end
                end
            elseif strcmpi(Opts.EventIdentifier, 'MidPointComposite')
                tmp_event_loc = double(int32(abs(current_trace_Events(j_event).Start + current_trace_Events(j_event).End)/2));
                if isnan(tmp_event_loc) || current_trace_Events(j_event).CompositeTag == 0
                tmp_event_loc = double(int32(abs(current_trace_Events(j_event).Start + current_trace_Events(j_event).End)/2));
                    current_trace_Binary(tmp_event_loc) = 1;
                end
            elseif strcmpi(Opts.EventIdentifier, 'PeakSingle')
                error('Opts.EventIdentifier = PeakSingle not implemented yet.')
            end
        end
        
        Binary_Traces{i_trace} = current_trace_Binary; 
    end
    
    % Save all traces for a mouse.
    Binary_Traces_AllMice{i_mouse} = Binary_Traces;

    fprintf('Events correctly represented in the binary traces for mouse "%s": %d.\n', Current_Mouse, counter_event_binarized);
    
    % Get to next mouse
    if i_event >= n_Events_Tot
        break
    end
    
    clear Current_Mouse
    Current_Mouse = Events(i_event).MouseTag;
    i2_event = 1;
    
    % Empty tmp variable
    if i_mouse ~= 7
        clear Current_Mouse_Events
        clear Binary_Traces
        clear current_trace_Binary
    end
end

