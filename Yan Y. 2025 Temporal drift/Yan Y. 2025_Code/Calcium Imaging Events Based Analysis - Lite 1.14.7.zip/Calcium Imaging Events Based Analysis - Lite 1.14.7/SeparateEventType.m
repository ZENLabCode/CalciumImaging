function [EventsSinglets, EventsComposite, EventsSubComposite] = SeparateEventType (Events)
% This function separates the Events in their sub-types, that is singlets
% (or "tonic"), and composite/complex events.
% OUTPUT: 
% - EventsSinglets is a structure containing only Singlets events
% - EventsComposite is a structure containing only Composite events
% - EventsSubComposite is a structure containing all the Composite sub-events

% Get Composite Tag Array
tmpComposite = [Events.Composite];
CompositeTagArray = [tmpComposite.CompositeTag];
clear tmp*

n_EventsTot = numel(Events);

% Separate Singlets from Composite events.
i_Composite = 1;
i_Singlet = 1;
EventsSubComposite = Events(1); EventsSubComposite(1) = [];
EventsSinglets = Events(1); EventsSinglets(1) = [];
for i = 1:n_EventsTot
    if CompositeTagArray(i) == 1
        EventsSubComposite(i_Composite) = Events(i);
        i_Composite = i_Composite + 1;
    end
    if CompositeTagArray(i) == 0
        EventsSinglets(i_Singlet) = Events(i);
        i_Singlet = i_Singlet + 1;
    end
end

% Add Singlets IEI
for i_Singlet = 1:numel(EventsSinglets)
    EventsSinglets(i_Singlet).InterEventInterval = EventsSinglets(i_Singlet).Composite.InterEventInterval;
end

% Number of Events per Type
n_Singlets = numel(EventsSinglets);
n_CompositeSubEvents = numel(EventsSubComposite);

% Get Composite sub-structure
tmpCmpEvents = [EventsSubComposite.Composite];
if ~isfield(tmpCmpEvents, 'StateLength') % Check if this property is present, if not, copy it from the suprastructure
    for i = 1:numel(tmpCmpEvents)
        tmpCmpEvents(i).StateLength = [EventsSubComposite(i).StateLength];
    end
end

% Get Cell Tags CellArray
CellTags = cell(1);
for i_cEvent = 1:n_CompositeSubEvents
    try
        CellTags{i_cEvent} = tmpCmpEvents(i_cEvent).CellTag;
    catch
        keyboard
    end
end

i_cEvent = 1;
EventsComposite = tmpCmpEvents(1); EventsComposite(1) = [];
while i_cEvent < n_CompositeSubEvents
    % Get current event
    CurrentEvent = tmpCmpEvents(i_cEvent);
    % Get all events from the same CellTag
    CurrentEvent_CellTag = CurrentEvent.CellTag;
    CurrentIndexes = find(contains(CellTags, CurrentEvent_CellTag));
    tmpEvents = tmpCmpEvents(CurrentIndexes);
    % Get all composite events with the same EventTag
    tmpTags = [tmpEvents.EventTag];
    % Exclude the repeated tags
    [tmpTagsUnique, tmpIndexes] = unique(tmpTags);
    tmpComposites = tmpEvents(tmpIndexes);
    
    % Get Composite Events
    EventsComposite = [EventsComposite, tmpComposites];
    
    % Update counter
    clear tmpComposites
    i_cEvent = i_cEvent + numel(CurrentIndexes);
end

n_CompositeEvents = numel(EventsComposite);


