function state_change_parcellation (Hypnogram_AllSessions, Mouse_Names, Opts)
% This function returns a division of all the traces into several bins.
% Each bin is computed with a start point and an end point N frames later.
% The start point is always one of the following: 
% - The start of a stable state
% - The start of a stable state + N, unless the bin finishes after the
% state itself
% - The start of a stable state - N
% - The end of a stable state
% - The end of a stable state - N
% - The start of an unstable state and the same + N, unless the bin
% finishes after the start of a stable state

% Option
BinLength = 20; % [Frames]

keyboard
n_sessionsTot = numel(Hypnogram_AllSessions);
FrameRate = Opts.General.FrameRate;
MinStableDuration = Opts.General.MinStableStateDuration;

for i_session = 1:n_sessionsTot
    Hypnogram = Hypnogram_AllSessions(i_session).Hypnogram;
    StateChanges = Hypnogram_AllSessions(i_session).StateChanges; % [Frames]
    StateDurations = Hypnogram_AllSessions(i_session).StateDuration; % [Frames]
    
    
    for i_state = 1:numel(StateChanges)
        StateStart = StateChanges(i_state); % [Frame]
        if i_state == numel(StateChanges)
            StateEnd = numel(Hypnogram); % [Frame]
        else
            StateEnd = StateChanges(i_state + 1) - 1; % [Frame]
        end
        CurrentState_Duration = StateDurations(i_state);
        
        % Case of a stable state
        if  CurrentState_Duration > MinStableDuration/FrameRate 
            % Start Bin
            tmp_BinStart_start = StateStart;
            % End Bin
            tmp_BinStart_end = StateEnd - BinLength;
            % Estimate how many bins can be fitted inside the state (not
            % counting the start and end ones.
            tmp_Nbins = fix(CurrentState_Duration / BinLength);
            tmp_Nbins = tmp_Nbins - 2;
            % Insert the bins, with the best possible spacing between them
            tmp_BinCentralLocs = fix((CurrentState_Duration - (2*BinLength)) / tmp_Nbins);
            tmp_BinSep = rem(CurrentState_Duration - (2*BinLength), tmp_Nbins);
            tmp_BinCentralLocs = (tmp_BinCentralLocs + BinLength/2):tmp_BinCentralLocs-1:(CurrentState_Duration - BinLength);
            tmp_BinCentralLocs = [(BinLength/2 + 1), tmp_BinCentralLocs, (CurrentState_Duration - BinLength/2)];
            
            % Add the spacing
            
%             tmp_BinStartArray = StateStart:BinLength:StateEnd;
%             tmp_Parc_1 = 
%             tmp_Parc_2 = 
            
        % Case of an unstable state
        else
            
            
            
        end
    end
end

