function [EventsRate_TimeArray_perMouse, EventsRateNormalized_TimeArray_perMouse, ...
    EventsRateVariation_Mean_TimeArray_perMouse, EventsRateVariation_StE_TimeArray_perMouse, ...
    EventsRateVariationNormalized_Mean_TimeArray_perMouse, EventsRateVariationNormalized_StE_TimeArray_perMouse] = cmp_EventsRate_perCell_overTime(Events_AllSessions, Mouse_Names, HypnoState, Opts)
% The output is a cell that contains an element per mouse.
% Each element is a matrix with 3 dimensions.
% The first dimension is the state (Awake, -, NREM, REM)
% The second dimension is the number of cells, which varies per mouse
% The third dimension is the session
% The values in the Matrix are the rate of the Calcium Events in each
% state, in the current session [Hz]



n_mice = numel(Mouse_Names);
mouse_sessions = Opts.Mouse_Sessions;
mouse_cell_n = Opts.Mouse_N_Cells;
n_sessions_total = sum(mouse_sessions);

fprintf('\n---Computing EventRates per state over time---\n');
EventsRate_TimeArray_perMouse = cell(1, n_mice);
EventsRateNormalized_TimeArray_perMouse = cell(1, n_mice);
EventsRateVariation_Mean_TimeArray_perMouse = cell(1, n_mice);
EventsRateVariation_StE_TimeArray_perMouse = cell(1, n_mice);
EventsRateVariationNormalized_Mean_TimeArray_perMouse = cell(1, n_mice);
EventsRateVariationNormalized_StE_TimeArray_perMouse = cell(1, n_mice);
for i_mouse = 1:n_mice % Run per mouse
    
    CurrentMouse_Name = Mouse_Names{i_mouse};
    fprintf(' Analyzing Mouse %s\n', CurrentMouse_Name);
    n_currentsessions = mouse_sessions(i_mouse);
    n_currentcells =  mouse_cell_n(i_mouse);
    [Events_CurrentMouse] = separate_events_per_mouse (Events_AllSessions, CurrentMouse_Name);
    CurrentMouse_HypnoState = HypnoState;
    toRemove = [];
    for i_session = 1:n_sessions_total
        if ~strcmpi(HypnoState(i_session).MouseName, CurrentMouse_Name)
            toRemove = [toRemove, i_session];
        end
    end
    CurrentMouse_HypnoState(toRemove) = [];
    
    
    CurrentMouse_EventsRate_TimeArray = NaN(4, n_currentcells, n_currentsessions);
    CurrentMouse_EventsRateNormalized_TimeArray = NaN(4, n_currentcells, n_currentsessions);
    for i_session = 1:n_currentsessions % Run per session
        fprintf('  Analyzing Session %d\n', i_session);
        CurrentSession_EventsRate = NaN(4, n_currentcells);
        CurrentSession_EventsRateNormalized = NaN(4, n_currentcells);
        CurrentSession_EventsCount = NaN(4, n_currentcells);
        [Events_CurrentSession] = separate_events_per_session (Events_CurrentMouse, i_session);
        % Get the total duration of each state
        CurrentSession_HypnoState = CurrentMouse_HypnoState(i_session).Duration;
        StateDuration(1) = CurrentSession_HypnoState.Awake;
        StateDuration(2) = CurrentSession_HypnoState.NoNREM;
        StateDuration(3) = NaN;
        StateDuration(4) = CurrentSession_HypnoState.REM;
        Average_Rate = NaN(4, 1);
        
        for i_state = 1:4 % Run per state
            if i_state == 3
                continue
            end
            Events_CurrentState = separate_events_per_state (Events_CurrentSession, i_state);
            
            for i_cell = 1:n_currentcells
                [Events_CurrentCell] = separate_events_per_cell (Events_CurrentState, i_cell);
                CurrentSession_EventsCount(i_state, i_cell) = numel(Events_CurrentCell);
                CurrentSession_EventsRate(i_state, i_cell) = CurrentSession_EventsCount(i_state, i_cell)./StateDuration(i_state);
                
            end
            Average_Rate(i_state) = mean(CurrentSession_EventsRate(i_state, :), 'omitnan');
            CurrentSession_EventsRateNormalized(i_state, :) = CurrentSession_EventsRate(i_state, :)./Average_Rate(i_state);
            
        end
        
        CurrentMouse_EventsRate_TimeArray(:, :, i_session) = CurrentSession_EventsRate;
        CurrentMouse_EventsRateNormalized_TimeArray(:, :, i_session) = CurrentSession_EventsRateNormalized;

    end
    
    % Compute the EventsRate Variation over sessions
    EventsRate_Variation = abs(diff(CurrentMouse_EventsRate_TimeArray, 1, 3));
    EventsRate_Variation_Mean = squeeze(mean(EventsRate_Variation, 2, 'omitnan'));
    EventsRate_Variation_StE = squeeze(std(EventsRate_Variation, 0, 2, 'omitnan')./sqrt(n_currentcells));
    
    EventsRateNormalized_Variation = abs(diff(CurrentMouse_EventsRateNormalized_TimeArray, 1, 3));
    EventsRateNormalized_Variation_Mean = squeeze(mean(EventsRateNormalized_Variation, 2, 'omitnan'));
    EventsRateNormalized_Variation_StE = squeeze(std(EventsRateNormalized_Variation, 0, 2, 'omitnan')./sqrt(n_currentcells));
    
    % Save stuff for each mouse
    EventsRate_TimeArray_perMouse{1, i_mouse} = CurrentMouse_EventsRate_TimeArray;
    EventsRateNormalized_TimeArray_perMouse{1, i_mouse} = CurrentMouse_EventsRateNormalized_TimeArray;
    EventsRateVariation_Mean_TimeArray_perMouse{1, i_mouse} = EventsRate_Variation_Mean;
    EventsRateVariation_StE_TimeArray_perMouse{1, i_mouse} = EventsRate_Variation_StE;
    EventsRateVariationNormalized_Mean_TimeArray_perMouse{1, i_mouse} = EventsRateNormalized_Variation_Mean;
    EventsRateVariationNormalized_StE_TimeArray_perMouse{1, i_mouse} = EventsRateNormalized_Variation_StE;
    
    
end