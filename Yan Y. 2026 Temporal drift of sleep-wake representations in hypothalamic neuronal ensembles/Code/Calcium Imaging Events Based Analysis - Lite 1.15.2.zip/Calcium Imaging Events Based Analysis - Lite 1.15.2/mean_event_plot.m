function MeanEvent = mean_event_plot (Events, Opts)
% This funtion computes the mean event shape of all the events given as
% input in the "Events" structure, and plots the mean shape.

n_EventsPlotted = Opts.MeanEvent.n_EventsPlotted;
n_events = numel(Events);
Interp_step = Opts.SingleTraceAnalysis.Interp_step;
LightGrey = [0.66, 0.66, 0.66];

% Align all the shapes to zero, and set all to the same length filling with NaNs.
Events_Shapes = [Events.Event];
E_Length = NaN(1, n_events);
for i_event = 1:n_events
    E_Length(i_event) = numel(Events_Shapes{i_event});
end
MaxEventLength = nanmax(E_Length);

for i_event = 1:n_events
    tmp_Shape = (Events_Shapes{i_event} - nanmin(Events_Shapes{i_event}))';
    Events_Shapes{i_event} = ([tmp_Shape, NaN(1, MaxEventLength - numel(tmp_Shape))]);
end
Events_Shapes = Events_Shapes';

% Compute mean event shape.
Events_Shapes_Mat = cell2mat(Events_Shapes);
NaNCount = NaN(1, MaxEventLength);
for i_timepoint = 1:MaxEventLength
    NaNCount(i_timepoint) = numel(find(~isnan(Events_Shapes_Mat(:, i_timepoint))));
end
MeanEvent.MeanEvent = nanmean(Events_Shapes_Mat, 1);
MeanEvent.MedianEvent = nanmedian(Events_Shapes_Mat, 1);
MeanEvent.StdEvent = nanstd(Events_Shapes_Mat, 1, 1);
MeanEvent.SteEvent = MeanEvent.StdEvent./sqrt(NaNCount);

% Get Samples to plot.
if n_events == 0
    return
end

Events_Indexes_Sampled = randi(n_events, 1, n_EventsPlotted);
Events_Sampled_Shapes = Events_Shapes(Events_Indexes_Sampled);


%% Plot
figure();
timepoints = (1:1:MaxEventLength).*Interp_step;
subplots_raws = 2;
subplots_columns = 2;

% --- SubPlot 1 --- %
subplot(subplots_raws, subplots_columns, 1);
hold on;
for i_sample = 1:n_EventsPlotted
   plot(timepoints, Events_Sampled_Shapes{i_sample}, 'LineWidth', 0.5, 'Color', LightGrey) 
end
plot(timepoints, MeanEvent.MeanEvent, 'LineWidth', 2, 'Color', [0, 0, 0])
grid on; box on; axis square;
title_str = sprintf('Mean & Samples (%d events)', n_EventsPlotted);
title(title_str);
xlabel('Frames');
ylabel('\DeltaF/F');

% --- SubPlot 2 --- %
subplot(subplots_raws, subplots_columns, 2);
hold on;
% Plot StE curves
plot(timepoints, (MeanEvent.MeanEvent + MeanEvent.SteEvent), 'LineWidth', 1, 'Color', [0, 0, 0])
plot(timepoints, (MeanEvent.MeanEvent - MeanEvent.SteEvent), 'LineWidth', 1, 'Color', [0, 0, 0])
% Plot shaded area
timepoints_flp = [timepoints, fliplr(timepoints)];
AreaBetweenCurves = [(MeanEvent.MeanEvent + MeanEvent.SteEvent), fliplr((MeanEvent.MeanEvent - MeanEvent.SteEvent))];
fill(timepoints_flp, AreaBetweenCurves, LightGrey);
% Plot Mean
plot(timepoints, MeanEvent.MeanEvent, 'LineWidth', 2, 'Color', [0, 0, 0])
grid on; box on; axis square;
title_str = sprintf('Mean +- StE');
title(title_str);
xlabel('Frames');
ylabel('\DeltaF/F');

% --- SubPlot 3 --- %
subplot(subplots_raws, subplots_columns, 3);
hold on;
for i_sample = 1:n_EventsPlotted
   plot(timepoints, Events_Sampled_Shapes{i_sample}, 'LineWidth', 0.5, 'Color', LightGrey) 
end
plot(timepoints, MeanEvent.MedianEvent, 'LineWidth', 2, 'Color', [0, 0, 0])
grid on; box on; axis square;
title_str = sprintf('Median & Samples (%d events)', n_EventsPlotted);
title(title_str);
xlabel('Frames');
ylabel('\DeltaF/F');

% --- SubPlot 4 --- %
subplot(subplots_raws, subplots_columns, 4);
hold on;
% Plot StE curves
plot(timepoints, (MeanEvent.MedianEvent + MeanEvent.SteEvent), 'LineWidth', 1, 'Color', [0, 0, 0])
plot(timepoints, (MeanEvent.MedianEvent - MeanEvent.SteEvent), 'LineWidth', 1, 'Color', [0, 0, 0])
% Plot shaded area
timepoints_flp = [timepoints, fliplr(timepoints)];
AreaBetweenCurves = [(MeanEvent.MedianEvent + MeanEvent.SteEvent), fliplr((MeanEvent.MedianEvent - MeanEvent.SteEvent))];
fill(timepoints_flp, AreaBetweenCurves, LightGrey);
% Plot Mean
plot(timepoints, MeanEvent.MedianEvent, 'LineWidth', 2, 'Color', [0, 0, 0])
grid on; box on; axis square;
title_str = sprintf('Median +- StE');
title(title_str);
xlabel('Frames');
ylabel('\DeltaF/F');

h_suptitle = suptitle(Opts.MeanEvent.SupTitle);
h_suptitle.FontSize = Opts.MeanEvent.SupTitleFontSize;
h_suptitle.FontWeight = 'bold';

% Save
PlotsOutputPath = Opts.MeanEvent.PlotsOutputPath;
FileName = Opts.MeanEvent.FileName;
FilePath = sprintf('%s\\%s', PlotsOutputPath, FileName);
if Opts.MeanEvent.FLAG_Save == 1
    fprintf('Saving "%s" in %s.\n\n', FileName, PlotsOutputPath);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end