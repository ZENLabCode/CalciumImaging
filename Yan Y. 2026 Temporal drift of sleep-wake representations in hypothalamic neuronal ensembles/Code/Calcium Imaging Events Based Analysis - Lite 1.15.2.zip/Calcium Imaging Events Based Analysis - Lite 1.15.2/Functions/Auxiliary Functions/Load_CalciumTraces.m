function CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session, Opts)
% This function loads the calcium traces of a single mouse recordings, as
% present in the Data Directory "Dir_Data" and subdirectories "MouseName"
% and "session".

% Possible FileName1
FileName1 = 'dFFnormalized.mat';
FileName2 = 'dFF_normalized.mat';

% Reconstruct the recordings folder name
if Opts.General.Suite2p_Format == 1
    mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
    tmp_sessions = dir(mouse_folder);
    for i = 1:numel(tmp_sessions)
        tmp2_sessions = tmp_sessions(i).name;
        if strcmpi(tmp2_sessions, '.') || strcmpi(tmp2_sessions, '..')
            continue
        end
        
        try
            tmp3_sessions = strsplit(tmp2_sessions, Opts.General.FolderNameDelimiter);
            tmp3_sessions = tmp3_sessions{2};
        catch
            warning_message = sprintf('\n=====\nThe session folder "%s" does not have the correct format required for the analysis.\nThis session will be skipped in the analysis.\n=====\n', tmp2_sessions);
            error(warning_message)
        end
        try
            tmp4_sessions = strsplit(tmp3_sessions, '_');
        catch
            warning_message = sprintf('\n=====\nThe session folder "%s" does not have the correct format required for the analysis.\nThis session will be skipped in the analysis.\n=====\n', tmp2_sessions);
            error(warning_message)
        end
        
        
        if numel(tmp4_sessions) > 1
            session_num = tmp4_sessions{2};
        else
            warning_message = sprintf('\n=====\nThe session folder "%s" does not have the correct format required for the analysis.\nThis session will be skipped in the analysis.\n=====\n', tmp2_sessions);
            error(warning_message)
        end
        
        if ~strcmpi(tmp4_sessions{1}, 'Session')
            warning(sprintf('Only folders with syntax like year.month.day-Session_SessionNumber\nExample: 2021.08.14-Session_1\n'))
        end
        
        if str2num(session_num) == i_session
            recordings_folder = sprintf('%s\\%s\\%s', Dir_Data, MouseName, tmp2_sessions);
        end
    end
    
    
else
    recordings_folder = sprintf('%s\\%s\\session_%d', Dir_Data, MouseName, i_session);
end

% Check folder existence.
if exist(recordings_folder, 'dir') ~= 0
    file_dFF_FullPath = sprintf('%s\\%s', recordings_folder, FileName1);
    if exist(file_dFF_FullPath, 'file') == 0
        file_dFF_FullPath = sprintf('%s\\%s', recordings_folder, FileName1);
        if exist(file_dFF_FullPath, 'file') ~= 0
            warning('Please remove the space in %s into "%s"', file_dFF_FullPath, FileName1)
        end
    end
else
    warning('Folder "%s" does not exist.', recordings_folder)
end

% Check folder existence 2.
if exist(recordings_folder, 'dir') ~= 0
    file_dFF_FullPath2 = sprintf('%s\\%s', recordings_folder, FileName2);
    if exist(file_dFF_FullPath2, 'file') == 0
        file_dFF_FullPath2 = sprintf('%s\\%s', recordings_folder, FileName2);
        if exist(file_dFF_FullPath2, 'file') ~= 0
            warning('Please remove the space in %s into "%s"', file_dFF_FullPath2, FileName2)
        end
    end
else
    warning('Folder "%s" does not exist.', recordings_folder)
end

% If file exists, load it.
if exist(file_dFF_FullPath, 'file') == 2
    tmp_data_struct = load(file_dFF_FullPath);
    % Convert into standard name.
    tmp_var_1 = struct2cell(tmp_data_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    CalciumTraces = tmp_var_2;
elseif exist(file_dFF_FullPath2, 'file') == 2
    tmp_data_struct = load(file_dFF_FullPath2);
    % Convert into standard name.
    tmp_var_1 = struct2cell(tmp_data_struct);
    tmp_var_2 = tmp_var_1{1, 1};
    CalciumTraces = tmp_var_2;
else
    error('Missing "%s" file in folder: %s', FileName1, recordings_folder)
end

% Convert into correct format
if ~isa(CalciumTraces, 'double')
    CalciumTraces = double(CalciumTraces);
end
