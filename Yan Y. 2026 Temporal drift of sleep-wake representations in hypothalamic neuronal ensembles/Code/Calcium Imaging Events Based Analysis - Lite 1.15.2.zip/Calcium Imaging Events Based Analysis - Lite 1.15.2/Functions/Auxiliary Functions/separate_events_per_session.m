function [Events] = separate_events_per_session (Events, i_session)
% This function returns only the events which belong to a session with the
% number i_session


n_events = numel(Events);
i_remove = 0;
for i_event = 1:n_events
    current_event = Events(i_event);
    if current_event.Session ~= i_session
        i_remove = i_remove + 1;
        Events_to_remove(i_remove) = i_event;
    end
    clear current_event
end

if i_remove > 0 % This should be true everytime there is more than one mouse recorded
    Events(Events_to_remove) = [];
end