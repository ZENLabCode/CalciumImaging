function out = fill_gap(array, inner_block_length, outer_blocks_length)
% FILL_GAP  Fill zero-runs between two sufficiently long 1-runs.
%
%   out = FILL_GAP(array, inner_block_length, outer_blocks_length)
%
%   Turns all 0s to 1s in any zero-run that:
%     (1) Is sandwiched between two 1-runs,
%     (2) Each neighboring 1-run has length >= outer_blocks_length,
%     (3) The zero-run length is strictly < inner_block_length.
%
%   Parameters
%   ----------
%   array : vector of 0/1 (numeric or logical)
%   inner_block_length : integer > 0
%       Maximum zero-run length (< this) to fill.
%   outer_blocks_length : integer > 0
%       Minimum length required for each neighboring 1-run.

    was_row = isrow(array);
    S = double(array(:) ~= 0);   % force column vector of 0/1
    n = numel(S);
    if n == 0
        out = array;
        return;
    end

    % Pad to simplify boundary handling
    Spad = [0; S; 0];

    % Identify zero-runs
    isZero = (Spad == 0);
    d = diff([0; isZero; 0]);       % +1 at start, -1 at end+1
    zStarts = find(d == 1);
    zEnds   = find(d == -1) - 1;

    % Process each zero-run
    for k = 1:numel(zStarts)
        a = zStarts(k);
        b = zEnds(k);
        len0 = b - a + 1;

        leftIdx  = a - 1;    % index just before the zero-run
        rightIdx = b + 1;    % index just after the zero-run

        % Check if sandwiched between 1s
        if leftIdx >= 1 && rightIdx <= numel(Spad) && Spad(leftIdx) == 1 && Spad(rightIdx) == 1
            % --- Measure contiguous 1-runs on both sides ---
            % Count ones to the left
            Llen = 0;
            j = leftIdx;
            while j >= 1 && Spad(j) == 1
                Llen = Llen + 1;
                j = j - 1;
            end

            % Count ones to the right
            Rlen = 0;
            j = rightIdx;
            while j <= numel(Spad) && Spad(j) == 1
                Rlen = Rlen + 1;
                j = j + 1;
            end

            % Apply criteria
            if (len0 < inner_block_length) && ...
               (Llen >= outer_blocks_length) && ...
               (Rlen >= outer_blocks_length)
                Spad(a:b) = 1;  % fill this zero-run
            end
        end
    end

    % Remove padding and restore shape
    outVec = Spad(2:end-1);
    if was_row
        out = outVec.';
    else
        out = outVec;
    end
end
