function [Events_perSession_QuietWake, HypnoState_QuietWake, n_ActiveWake, n_QuietWake, n_TotalWake] = IsolateWake (Hypnogram_AllSessions, HypnoState, Events_perSession, Mouse_Names, Opts)


% Adjust the Hypnogram

n_sessions_overall = numel(Hypnogram_AllSessions);
n_sessions = numel(Events_perSession);
n_mice = numel(Mouse_Names);
FrameRate = Opts.General.FrameRate;

% Resample the WakeScoring, and save it separately for all sessions.
HypnoState_QuietWake = HypnoState;
WakeScoring = cell(n_sessions_overall, 1);
for i_session = 1:n_sessions_overall
    current_Hypno = Hypnogram_AllSessions(i_session).Hypnogram;
    current_WakeScoring = Hypnogram_AllSessions(i_session).WakeScoring;
    
    N = numel(current_WakeScoring);
    M = numel(current_Hypno);
    
    edges = round(linspace(1, N+1, M+1));
    
    x_ds = zeros(M,1);
    for i = 1:M
        idx = edges(i):edges(i+1)-1;
        if ~isempty(idx)
            x_ds(i) = mean(current_WakeScoring(idx)) >= 0.5;
        end
    end
    WakeScoring{i_session} = x_ds;
    current_Hypno(x_ds == 1) = [];
    
    
    state_duration = analyze_hypnogram (current_Hypno, FrameRate);
    HypnoState_QuietWake(i_session).Duration = state_duration;
    clear x_ds; clear idx; clear edges;
end

% Separate Hypnogram by session
Hypnogram_bySession = cell(n_sessions, 1);
for i_session = 1:n_sessions
    mask = ([Hypnogram_AllSessions.Session] == i_session);
    Hypnogram_bySession{i_session} = Hypnogram_AllSessions(mask);
end


% Separate Hypnogram by mouse
Hypnogram_byMouse = cell(numel(Mouse_Names), 1);
for i_Mouse = 1:numel(Mouse_Names)
    currentMouseName = Mouse_Names{i_Mouse};
    mask = strcmp({Hypnogram_AllSessions.MouseName}, currentMouseName);
    % Extract sub-struct array for current mouse
    Hypnogram_byMouse{i_Mouse} = Hypnogram_AllSessions(mask);
end


% Remove every Event that starts during either Active (1) or Quiet (0)
% wake (default is Active)

Events_perSession_QuietWake = cell(n_sessions, 1);
n_ActiveWake = NaN(n_mice, n_sessions);
n_QuietWake = NaN(n_mice, n_sessions);
for i_session = 1:n_sessions
    Events_CurrentSession = Events_perSession{i_session};
    [Events_perMouse] = get_EventsPerMouse (Events_CurrentSession, Mouse_Names);
    CurrentMouseHypnograms = Hypnogram_bySession{i_session};
    
    Events_CurrentSession_QuietWake = [];
    for i_mouse = 1:n_mice
        Events_CurrentMouse = Events_perMouse{i_mouse};
        CurrentMouseName = Mouse_Names{i_mouse};
        idx = strcmp({CurrentMouseHypnograms.MouseName}, CurrentMouseName);
        tmp = CurrentMouseHypnograms(idx);
        CurrentHypnogram = tmp.Hypnogram;
        clear tmp
        n_events = numel(Events_CurrentMouse);
        
        tmp = Events_CurrentMouse;
        
        idx = find( strcmp({HypnoState.MouseName}, CurrentMouseName) & [HypnoState.Session] == i_session );
        fprintf('Cleaning Wake State - mouse %s Session %d (%d/%d).\n', CurrentMouseName, i_session, idx, n_sessions_overall)
        current_WakeScoring = WakeScoring{idx};
        clear idx
        
        % Count the Active vs Quiet Wake
        try
            idx = (current_WakeScoring == 1);
            WakeScoring_WakeOnly = CurrentHypnogram(idx);
        catch
            idx = (CurrentHypnogram == 1);
            WakeScoring_WakeOnly = current_WakeScoring(idx);
        end
        clear idx
        n_TotalWake(i_mouse, i_session) = numel(CurrentHypnogram == 1);
        n_ActiveWake(i_mouse, i_session) = sum(WakeScoring_WakeOnly == 1);
        n_QuietWake(i_mouse, i_session) = sum(WakeScoring_WakeOnly == 0);
        
        
        ToDelete = false(1, n_events);
        for i_event = 1:n_events
            CurrentEvent_Start = Events_CurrentMouse(i_event).Start;
            ToDelete(i_event) = current_WakeScoring(CurrentEvent_Start) == 1;
        end
        tmp(ToDelete) = [];
        Events_CurrentSession_QuietWake = [Events_CurrentSession_QuietWake, tmp];
        clear tmp
    end
    Events_perSession_QuietWake{i_session} = Events_CurrentSession_QuietWake;
    clear Events_CurrentSession_QuietWake
end

n_QuietWake = n_TotalWake - n_ActiveWake;