function WakeScoring = EMG_Scoring(resampled_data_mV, Hypnogram, SampRate)




fprintf('Computing EMG-based Wake scoring...\n')

EMG = resampled_data_mV;
EMG = EMG - mean(EMG);
EMG_Noise = EMG;
FLAG_debugging_figures = 0;


% Check that the format of the Hypnogram is Double
FLAG_CastBack = 0;
if ~isfloat(Hypnogram)
    fprintf('Hypnogram temporarily converted to Double format.\n')
    FLAG_CastBack = 1;
    Hypnogram = double(Hypnogram);
end
% Check that the Hypnogram does not have NaNs. Since we are only interested
% in Wake state here, convert the NaNs to 0 (the Hypnogram won't be
% returned)
FLAG_NaNs = 0;
if any(isnan(Hypnogram))
    fprintf('Hypnogram still had NaNs, these are being temporarily considered as 0s, for the Wake scoring (they are ignored).\n')
    FLAG_NaNs = 1;
    NaN_Indexes = isnan(Hypnogram);
    Hypnogram(NaN_Indexes) = 0;
end


%% Resize Hypnogam to match
dim1 = length(Hypnogram);
dim2 = length(EMG);  

% Index grids
x_old = linspace(1, dim1, dim1);
x_new = linspace(1, dim1, dim2);

% Nearest-neighbor rounded interpolation

Hypnogram_upsampled = interp1(x_old, Hypnogram, x_new, 'nearest');
Hypnogram = Hypnogram_upsampled;

if FLAG_CastBack == 1
    fprintf('Hypnogram converted back to Integer\n')
    try
        Hypnogram = int32(round(Hypnogram));
    catch
        Hypnogram = uint8(round(Hypnogram));
    end
end
if FLAG_NaNs == 1
    Hypnogram(NaN_Indexes) = NaN;
end

%% Estimate noise and Score
EMG_Noise(Hypnogram == 1) = NaN;
EMG_Noise(Hypnogram == 6) = NaN;

[noise_estimate, ~, ~] = estimate_noise (EMG_Noise, 1);
% threshold = median(EMG) + noise_estimate*1.5;
threshold = noise_estimate*4;
Score = abs(EMG) > threshold;
Score = double(Score);
Score(Hypnogram == 2) = 0;
Score(Hypnogram == 3) = 0;

%% Remove Isolated peaks 
N = SampRate/7.5;   % minimum required neighboring ones
X = SampRate*10;   % window radius

% Count neighbors using convolution
window = ones(2*X + 1, 1);
neighbor_count = conv(Score, window, 'same') - Score;  % exclude self

% Remove isolated 1s
Score_filtered = Score;
Score_filtered(Score == 1 & neighbor_count < N) = 0;

%% Fill micro gaps
N = 1;   % minimum required neighboring ones
X = SampRate*4;   % window radius

% Count neighbors in the ±X window, excluding the center
window = ones(2*X + 1, 1);
neighbor_count = conv(Score_filtered, window, 'same') - Score_filtered;  % subtract center

% Flip zeros that have at least N neighbors = 1
Score_promoted = Score_filtered;
Score_promoted((Score_filtered == 0) & (neighbor_count >= N)) = 1;

%% Erode the blocks of ones
% The previous method adds extra ones at the edges of each block

K = X/2;  % erosion size (number of samples removed from each edge)

Score_eroded = Score_promoted;  % initialize
in_block = false;
count = 0;

for i = 1:length(Score_promoted)
    if Score_promoted(i) == 1 && ~in_block
        in_block = true;
        start_idx = i;
    elseif Score_promoted(i) == 0 && in_block
        end_idx = i - 1;
        block_len = end_idx - start_idx + 1;
        if block_len <= 2*K
            % Remove the whole block if it's too small
            Score_eroded(start_idx:end_idx) = 0;
        else
            Score_eroded(start_idx:start_idx+K-1) = 0;
            Score_eroded(end_idx-K+1:end_idx) = 0;
        end
        in_block = false;
    end
end

if in_block
    end_idx = length(Score_promoted);
    block_len = end_idx - start_idx + 1;
    if block_len <= 2*K
        Score_eroded(start_idx:end_idx) = 0;
    else
        Score_eroded(start_idx:start_idx+K-1) = 0;
        Score_eroded(end_idx-K+1:end_idx) = 0;
    end
end


% inner_block_length = SampRate*20;
% outer_blocks_length = SampRate*5;
% Score_Final = fill_gap(Score_eroded, inner_block_length, outer_blocks_length);

WakeScoring = Score_eroded;


fprintf('Done!! \n')

if FLAG_debugging_figures == 1
    figure
    xdim = numel(EMG);
    raws = 4;
    subplot(raws,1,1)
    plot (EMG)
    xlim([0 xdim])
    hold on
    yline(threshold, 'r--', 'LineWidth', 2);  % add horizontal line
    
    subplot(raws,1,2)
    plot (Hypnogram)
    ylim([-1, 7])
    xlim([0 numel(Hypnogram)])
    
    subplot(raws,1,3)
    plot (Score)
    ylim([-1, 2])
    xlim([0 xdim])
    
    subplot(raws,1,4)
    plot (Score_Final)
    ylim([-1, 2])
    xlim([0 xdim])
end