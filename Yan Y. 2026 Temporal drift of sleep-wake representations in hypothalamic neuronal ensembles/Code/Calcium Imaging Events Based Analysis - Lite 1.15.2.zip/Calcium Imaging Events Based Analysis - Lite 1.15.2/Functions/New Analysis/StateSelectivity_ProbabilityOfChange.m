function [ProbabilityOfTransition_Mean, ProbabilityOfTransition_StE, ProbabilityOfTransition_Permuted_Mean, ProbabilityOfTransition_Permuted_StE, Statistics_ProbabilityOfSelectivityChange] = StateSelectivity_ProbabilityOfChange (CellTags_EvolutionMatrix_Ordered, CellTags_EvolutionMatrix_RandomAssignment, Opts)
% This function computes the probability of a certain cell to change their
% state selectivity to a different state over multiple sessions, and
% compares with a random state selectivity assignment.


[n_cells, n_sessions] = size(CellTags_EvolutionMatrix_Ordered);
CellTags_EvolutionMatrix = CellTags_EvolutionMatrix_Ordered;

if Opts.ClusteringMethod == 2
    States = [0 5 6 7];
elseif Opts.ClusteringMethod == 3
    States = [0 1 2 3 4 5 6 7];
end
n_states = numel(States);

% Compute the probability of each transition per cell
for i_cell = 1:n_cells
    
    CurrentCell_TagEvolution  = CellTags_EvolutionMatrix(i_cell,:); 
    
    curr = CurrentCell_TagEvolution(1:end-1);
    next = CurrentCell_TagEvolution(2:end);
    
    % Map states to indices 1..4 (only valid if row contains only vals)
    [~, i_current] = ismember(curr, States);
    [~, i_next] = ismember(next, States);
    
    % Count transitions
    CurrentTransitions = accumarray([i_current(:) i_next(:)], 1, [numel(States) numel(States)]);
    
    % Convert counts to probabilities P(next | current)
    Probability_Transition(i_cell, :, :) = CurrentTransitions ./ sum(CurrentTransitions,2);
end
clear CurrentCell_TagEvolution

% Mean over cells
ProbabilityOfTransition_Mean = squeeze(mean(Probability_Transition, 1, 'omitnan'));
ProbabilityOfTransition_StE = squeeze(std(Probability_Transition, 0, 1, 'omitnan') ./ sqrt(n_cells));


%% Do the same, for the permuted version

% Compute permuted matrix
CellTags_EvolutionMatrix_Permuted = zeros(size(CellTags_EvolutionMatrix));
for i = 1:size(CellTags_EvolutionMatrix,1)
    CellTags_EvolutionMatrix_Permuted(i,:) = CellTags_EvolutionMatrix(i, randperm(size(CellTags_EvolutionMatrix,2)));
end

CellTags_EvolutionMatrix = CellTags_EvolutionMatrix_Permuted;
% Compute the probability of each transition per cell
for i_cell = 1:n_cells
    
    CurrentCell_TagEvolution  = CellTags_EvolutionMatrix(i_cell,:); 
    
    curr = CurrentCell_TagEvolution(1:end-1);
    next = CurrentCell_TagEvolution(2:end);
    
    % Map states to indices 1..4 (only valid if row contains only vals)
    [~, i_current] = ismember(curr, States);
    [~, i_next] = ismember(next, States);
    
    % Count transitions
    CurrentTransitions = accumarray([i_current(:) i_next(:)], 1, [numel(States) numel(States)]);
    
    % Convert counts to probabilities P(next | current)
    Probability_Transition_Permuted(i_cell, :, :) = CurrentTransitions ./ sum(CurrentTransitions,2);
end
clear CurrentCell_TagEvolution

% Mean over cells
ProbabilityOfTransition_Permuted_Mean = squeeze(mean(Probability_Transition_Permuted, 1, 'omitnan'));
ProbabilityOfTransition_Permuted_StE = squeeze(std(Probability_Transition_Permuted, 0, 1, 'omitnan') ./ sqrt(n_cells));


%% Do the same, for the fully randomized version
CellTags_EvolutionMatrix = CellTags_EvolutionMatrix_RandomAssignment;
% Compute the probability of each transition per cell
for i_cell = 1:n_cells
    
    CurrentCell_TagEvolution  = CellTags_EvolutionMatrix(i_cell,:); 
    
    curr = CurrentCell_TagEvolution(1:end-1);
    next = CurrentCell_TagEvolution(2:end);
    
    % Map states to indices 1..4 (only valid if row contains only vals)
    [~, i_current] = ismember(curr, States);
    [~, i_next] = ismember(next, States);
    
    % Count transitions
    CurrentTransitions = accumarray([i_current(:) i_next(:)], 1, [numel(States) numel(States)]);
    
    % Convert counts to probabilities P(next | current)
    Probability_Transition_FullRandom(i_cell, :, :) = CurrentTransitions ./ sum(CurrentTransitions,2);
end

% Mean over cells
ProbabilityOfTransition_FullRandom_Mean = squeeze(mean(Probability_Transition_FullRandom, 1, 'omitnan'));
ProbabilityOfTransition_FullRandom_StE = squeeze(std(Probability_Transition_FullRandom, 0, 1, 'omitnan') ./ sqrt(n_cells));



%% Statistics

pvals_Wilcoxon = NaN(4,4);
pvals_TTest = NaN(4,4);
pvals_Perm = NaN(4,4);
nperm = 10000;
perm = zeros(nperm,1);
for i = 1:n_states
    for j = 1:n_states
        x = squeeze(Probability_Transition(:,i,j));
        y = squeeze(Probability_Transition_Permuted(:,i,j));

        % Ignore NaNs
        Non_NaN_Elements = ~isnan(x) & ~isnan(y);

        if sum(Non_NaN_Elements) > 0
            pvals_Wilcoxon(i,j) = signrank(x(Non_NaN_Elements), y(Non_NaN_Elements));
            [~, pvals_TTest(i,j)] = ttest(x(Non_NaN_Elements), y(Non_NaN_Elements));
            
            % Permutations
            d = x(Non_NaN_Elements) - y(Non_NaN_Elements);
            obs = mean(d);
            
            for k = 1:nperm
                s = sign(rand(size(d)) - 0.5);
                perm(k) = mean(d .* s);
            end
            
            pvals_Perm(i,j) = mean(abs(perm) >= abs(obs));
        end
    end
end
Statistics_ProbabilityOfSelectivityChange.pvals_Perm = pvals_Perm;
Statistics_ProbabilityOfSelectivityChange.pvals_TTest = pvals_TTest;
Statistics_ProbabilityOfSelectivityChange.pvals_Wilcoxon = pvals_Wilcoxon;

%% Plot
a = max(ProbabilityOfTransition_FullRandom_Mean(:), [], 'omitnan');
b = max(ProbabilityOfTransition_Permuted_Mean(:), [], 'omitnan');
c = max(ProbabilityOfTransition_Mean(:), [], 'omitnan');
max_colorscale = max([a, b, c]);
x = [0.32 0.45 0.54];
y = ceil(max(x)*10) / 10;


figure('units','normalized','outerposition',[0 0 1 1]);

% Probability of transition
subplot(1, 3, 1)
Matrix2Plot_Mean = ProbabilityOfTransition_Mean;
Matrix2Plot_StE = ProbabilityOfTransition_StE;

imagesc(Matrix2Plot_Mean)
axis equal tight
colormap(parula)
colorbar
hold on

cmap = colormap;
clim = caxis;
caxis([0 max_colorscale])
for i = 1:size(Matrix2Plot_Mean,1)
    for j = 1:size(Matrix2Plot_Mean,2)

        % Background color from mean
        t = (Matrix2Plot_Mean(i,j) - clim(1)) / diff(clim);
        idx = max(1, min(size(cmap,1), round(t*(size(cmap,1)-1)+1)));
        bg = cmap(idx, :);

        % Perceived luminance → choose text color
        luminance = 0.299*bg(1) + 0.587*bg(2) + 0.114*bg(3);
        if luminance < 0.5
            txtColor = 'w';
        else
            txtColor = 'k';
        end

        % Text: mean ± StE
        label = sprintf('%.2f \\pm %.2f', ...
            Matrix2Plot_Mean(i,j), Matrix2Plot_StE(i,j));

        text(j, i, label, ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'Color', txtColor, ...
            'FontWeight','bold', ...
            'Interpreter','tex');
    end
end

xticks(1:n_states)
yticks(1:n_states)
if Opts.ClusteringMethod == 2
    xticklabels({'None/Low Activity','Awake','NREM','REM'})
    yticklabels({'None/Low Activity','Awake','NREM','REM'})
elseif Opts.ClusteringMethod == 3
    xticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
    yticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
end
title('Probability of State Transition')


% Probability of transition (Permutation)
subplot(1, 3, 2)
Matrix2Plot_Mean = ProbabilityOfTransition_Permuted_Mean;
Matrix2Plot_StE = ProbabilityOfTransition_Permuted_StE;


imagesc(Matrix2Plot_Mean)
axis equal tight
colormap(parula)
colorbar
hold on

cmap = colormap;
clim = caxis;
caxis([0 max_colorscale])
for i = 1:size(Matrix2Plot_Mean,1)
    for j = 1:size(Matrix2Plot_Mean,2)

        % Background color from mean
        t = (Matrix2Plot_Mean(i,j) - clim(1)) / diff(clim);
        idx = max(1, min(size(cmap,1), round(t*(size(cmap,1)-1)+1)));
        bg = cmap(idx, :);

        % Perceived luminance → choose text color
        luminance = 0.299*bg(1) + 0.587*bg(2) + 0.114*bg(3);
        if luminance < 0.5
            txtColor = 'w';
        else
            txtColor = 'k';
        end

        % Text: mean ± StE
        label = sprintf('%.2f \\pm %.2f', ...
            Matrix2Plot_Mean(i,j), Matrix2Plot_StE(i,j));

        text(j, i, label, ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'Color', txtColor, ...
            'FontWeight','bold', ...
            'Interpreter','tex');
    end
end

xticks(1:n_states)
yticks(1:n_states)
if Opts.ClusteringMethod == 2
    xticklabels({'None/Low Activity','Awake','NREM','REM'})
    yticklabels({'None/Low Activity','Awake','NREM','REM'})
elseif Opts.ClusteringMethod == 3
    xticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
    yticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
end
title('Probability of State Transition (Permuted States)')

% Probability of transition (Random State Values)
subplot(1, 3, 3)
Matrix2Plot_Mean = ProbabilityOfTransition_FullRandom_Mean;
Matrix2Plot_StE = ProbabilityOfTransition_FullRandom_StE;


imagesc(Matrix2Plot_Mean)
axis equal tight
colormap(parula)
colorbar
hold on

cmap = colormap;
clim = caxis;
caxis([0 max_colorscale])
for i = 1:size(Matrix2Plot_Mean,1)
    for j = 1:size(Matrix2Plot_Mean,2)

        % Background color from mean
        t = (Matrix2Plot_Mean(i,j) - clim(1)) / diff(clim);
        idx = max(1, min(size(cmap,1), round(t*(size(cmap,1)-1)+1)));
        bg = cmap(idx, :);

        % Perceived luminance → choose text color
        luminance = 0.299*bg(1) + 0.587*bg(2) + 0.114*bg(3);
        if luminance < 0.5
            txtColor = 'w';
        else
            txtColor = 'k';
        end

        % Text: mean ± StE
        label = sprintf('%.2f \\pm %.2f', ...
            Matrix2Plot_Mean(i,j), Matrix2Plot_StE(i,j));

        text(j, i, label, ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'Color', txtColor, ...
            'FontWeight','bold', ...
            'Interpreter','tex');
    end
end

xticks(1:n_states)
yticks(1:n_states)
if Opts.ClusteringMethod == 2
    xticklabels({'None/Low Activity','Awake','NREM','REM'})
    yticklabels({'None/Low Activity','Awake','NREM','REM'})
elseif Opts.ClusteringMethod == 3
    xticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
    yticklabels({'None/Low Activity', 'Not State Selective', 'Awake', 'Awake & REM', 'REM', 'NREM & REM', 'NREM', 'Awake & NREM'})
end
title('Probability of State Transition (Random States Values)')


%% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Probability of State Selectivity Change - Clustering Type %d - Events Rate based', Opts.CellType, Opts.ClusteringMethod);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Probability of State Selectivity Change - Clustering Type %d - Integrals Frequency based', Opts.CellType, Opts.ClusteringMethod);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
%     close gcf
end

