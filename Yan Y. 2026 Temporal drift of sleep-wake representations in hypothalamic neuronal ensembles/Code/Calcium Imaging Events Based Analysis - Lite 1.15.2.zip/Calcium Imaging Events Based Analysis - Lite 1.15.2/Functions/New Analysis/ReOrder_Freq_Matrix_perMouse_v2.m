function [Freq_Matrix_AllCells_Sorted, Freq_Matrix_AllCells] = ReOrder_Freq_Matrix_perMouse_v2 (CellTags_EvolutionMatrix_Ordered, Freq_Matrix_perMouse, OrderID)


[n_cells, n_sessions] = size(CellTags_EvolutionMatrix_Ordered);

Freq_Matrix_AllCells = NaN(n_cells, 3, n_sessions);
for i_session = 1:n_sessions
    tmp = Freq_Matrix_perMouse{i_session};
    n_mice = numel(tmp);
    
    if n_mice > 1
        current_session_array_unsorted = [];
        for i_mouse = 1:n_mice-1
            tmp1 = [tmp{i_mouse}];
            tmp2 = [tmp{i_mouse + 1}];
            current_session_array_unsorted = cell2mat(tmp(:));  % stacks all mice
            current_session_array_sorted   = current_session_array_unsorted(OrderID,:);
%             catch
%                 keyboard
%             end
        end
    else
        current_session_array_unsorted = tmp{1};
        current_session_array_sorted = current_session_array_unsorted(OrderID,:);
    end
    
    Freq_Matrix_AllCells(:, :, i_session) = current_session_array_unsorted;
    Freq_Matrix_AllCells_Sorted(:, :, i_session) = current_session_array_sorted;
end
