function plotWakeComposition(n_ActiveWake, n_QuietWake, n_TotalWake, Opts)
% This function computes the % of Quiet vs Active wake.

ActiveWake_Fraction = n_ActiveWake./n_TotalWake;
QuietWake_Fraction = n_QuietWake./n_TotalWake;
[n_mice, n_sessions] = size(n_TotalWake);

ActiveWake_Fraction_Avg = mean(ActiveWake_Fraction, 1);
ActiveWake_Fraction_StE = std(ActiveWake_Fraction,0,1)./sqrt(n_mice);
QuietWake_Fraction_Avg = mean(QuietWake_Fraction, 1);
QuietWake_Fraction_StE = std(QuietWake_Fraction,0,1)./sqrt(n_mice);

Color_Max_ActiveWake = [1,0.25,1];
ColorFraction_ActiveWake = Color_Max_ActiveWake./n_mice;
Color_Max_QuietWake = [0.25,0.25,1];
ColorFraction_QuietWake = Color_Max_QuietWake./n_mice;

%% Plot
figure('units','normalized','outerposition',[0 0 1 1]);
hold on

x = 1:n_sessions;

% Individual mice
for i_mouse = 1:n_mice
    plot(x, ActiveWake_Fraction(i_mouse,:), ...
        'LineWidth', 1.25, ...
        'Color', ColorFraction_ActiveWake * i_mouse)

    plot(x, QuietWake_Fraction(i_mouse,:), ...
        'LineWidth', 1.25, ...
        'Color', ColorFraction_QuietWake * i_mouse)
end

% Shaded error: Active Wake
upper = ActiveWake_Fraction_Avg + ActiveWake_Fraction_StE;
lower = ActiveWake_Fraction_Avg - ActiveWake_Fraction_StE;

fill([x fliplr(x)], ...
     [upper fliplr(lower)], ...
     [1 0 1], ...
     'FaceAlpha', 0.25, ...
     'EdgeColor', 'none');

plot(x, ActiveWake_Fraction_Avg, ...
     'LineWidth', 4, ...
     'Color', [1 0 1]);

% Shaded error: Quiet Wake
upper = QuietWake_Fraction_Avg + QuietWake_Fraction_StE;
lower = QuietWake_Fraction_Avg - QuietWake_Fraction_StE;

fill([x fliplr(x)], ...
     [upper fliplr(lower)], ...
     [0 0 1], ...
     'FaceAlpha', 0.25, ...
     'EdgeColor', 'none');

plot(x, QuietWake_Fraction_Avg, ...
     'LineWidth', 4, ...
     'Color', [0 0 1]);

% Axes and labels
ylim([0 1])
xlim([1 n_sessions])
xticks(1:n_sessions)

title('Wake Composition')
xlabel('Sessions')
ylabel('Fraction of Quiet vs Active Wake')

set(gca,'Layer','top')
box off


% figure('units','normalized','outerposition',[0 0 1 1]);
% hold on
% for i_mouse = 1:n_mice
%     CurrentMouseActiveWakePercentage = ActiveWake_Fraction(i_mouse, :);
%     plot(CurrentMouseActiveWakePercentage, 'LineWidth', 1.25, 'Color', ColorFraction_ActiveWake*i_mouse)
%     CurrentMouseQuietWakePercentage = QuietWake_Fraction(i_mouse, :);
%     plot(CurrentMouseQuietWakePercentage, 'LineWidth', 1.25, 'Color', ColorFraction_QuietWake*i_mouse)
% end
% 
% errorbar(ActiveWake_Fraction_Avg, ActiveWake_Fraction_StE, 'LineWidth', 4, 'Color', [1, 0, 1])
% errorbar(QuietWake_Fraction_Avg, QuietWake_Fraction_StE, 'LineWidth', 4, 'Color', [0, 0, 1])
% 
% ylim([0, 1])
% xlim([1, n_sessions])
% xticks(1:21)
% title ('Wake Composition')
% xlabel('Sessions')
% ylabel('Fraction of Quiet vs Active Wake')
% 

%% Save
if Opts.SaveFiguresAutomatically == 1
    FileName = sprintf('%s - Wake Composition', CellType);
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end


