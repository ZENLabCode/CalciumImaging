function Events_Frequency_RGB_Tracking_v2 (Events_Freq_Matrix_AllCells, Opts)
% Plot the evolution matrix for each cell, based solely on the Events
% Frequency per state, translated into RGB.
% Works also for Integrals Frequency



%% Normalize and prepare the values
[n_cells, n_states, n_sessions] = size(Events_Freq_Matrix_AllCells);
    

% Get max frequency per state and normalize all cells.
E_Freq_Max_perSession = NaN(n_sessions, n_states);
E_Freq_Min_perSession = NaN(n_sessions, n_states);
all_cells_per_session = cell(n_sessions, 1);
all_cells_sessions_matrix = NaN(n_sessions, n_cells, n_states);
for i_session = 1:n_sessions
    current_session = Events_Freq_Matrix_AllCells(:, :, i_session);
    E_Freq_Max_perSession(i_session, :) = max(current_session, [], 1, 'omitnan');
    E_Freq_Min_perSession(i_session, :) = min(current_session, [], 1, 'omitnan');
    all_cells_per_session{i_session} = current_session;
end
Max_tmp = nanmedian(E_Freq_Max_perSession);
Max = nanmax(E_Freq_Max_perSession);
Min = nanmin(E_Freq_Min_perSession);
GrandMax = nanmax(Max);
GrandMax_tmp = nanmax(Max_tmp);
GrandMin = nanmin(Min);



% Max frequency for each cell over every session, per state
Max_Freq_perCell_perState = max(Events_Freq_Matrix_AllCells, [], 3, 'omitnan');
Max_Freq_perCell = max(Max_Freq_perCell_perState, [], 2, 'omitnan');

all_cells_per_session_normalized_GrandMax = cell(n_sessions, 1);
all_cells_per_session_normalized_per_cell = cell(n_sessions, 1);
for i_session = 1:n_sessions
    all_cells = all_cells_per_session{i_session};
    all_cells_normalized_GrandMax = all_cells./GrandMax;
    all_cells_normalized_per_cell = all_cells./Max_Freq_perCell;
    all_cells_per_session_normalized_per_cell{i_session} = all_cells_normalized_per_cell;
    all_cells_per_session_normalized_GrandMax{i_session} = all_cells_normalized_GrandMax;
    clear all_cells
end


%% Plot
AxisFontSize = 14;
Ticks_Array = (1:n_sessions);

% Initialize Figure
tmp = (1:(n_cells*(n_sessions+1)));
tmp = reshape(tmp, n_cells, n_sessions+1);
cmap = jet(256);

figure('units','normalized','outerposition',[0 0 1 1]);
h_pcolor = pcolor(tmp);

% Convert to RGB
colormap(gca, cmap);
Cdata = h_pcolor.CData;
cmin = min(Cdata(:));
cmax = max(Cdata(:));
tmp_nrows = length(cmap);
indexes = fix((Cdata-cmin)/(cmax-cmin)*tmp_nrows)+1;
% Then to RGB
RGB_Scale = ind2rgb(indexes, cmap);
h_pcolor.CData = RGB_Scale;

% Assign a specific color to each dot
all_cells_per_session_normalized_per_cell{end+1} = [];
for i_session = 1:n_sessions+1
    all_cells = all_cells_per_session_normalized_per_cell{i_session};
    if isempty(all_cells)
        continue
    end
    all_cells = all_cells./GrandMax_tmp;
    % Reorder from Wake-NREM-REM (B-R-G) into NREM-REM-Wake (R-G-B)
    tmp_wake = all_cells(:, 1);
    tmp_NREM = all_cells(:, 2);
    tmp_REM = all_cells(:, 3);
    tmp_colorscale = [tmp_NREM, tmp_REM, tmp_wake];
    
    h_pcolor.CData(:, i_session, :) = tmp_colorscale; % Color Assignment
end
ylabel('Cell ID');
xlabel('Session');
ax = gca;
ax.FontSize = AxisFontSize; 
xticks(Ticks_Array+0.5)
xticklabels(Ticks_Array)

colorbar


%% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Evolution of Cells Events Rate Specificity (RGB)', Opts.CellType);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Evolution of Cells Integrals Frequency Specificity (RGB)', Opts.CellType);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end



