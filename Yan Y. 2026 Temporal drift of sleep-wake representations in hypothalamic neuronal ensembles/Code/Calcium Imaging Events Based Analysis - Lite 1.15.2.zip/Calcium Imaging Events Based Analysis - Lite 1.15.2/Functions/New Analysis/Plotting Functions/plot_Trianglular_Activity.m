function plot_Trianglular_Activity(Activity_Normalized, Selectivity_Normalized, Opts)

n_sessions = numel(Activity_Normalized);
n_cells = sum(Opts.Mouse_N_Cells);
n_states = 3;

Selectivity_Normalized_Cell = cell(n_sessions, 1);
for i = 1:n_sessions
    Selectivity_Normalized_Cell{i} = Selectivity_Normalized(i).State_Selectivity_Matrix;
end
Selectivity_Normalized = Selectivity_Normalized_Cell';
clear Selectivity_Normalized_Cell

% Randomly select n neurons
n_Interpolated_Frames = 3; % add N extra linearly interpolated frames between each frame
n_RandomNeurons = 5; % Do not select more than 5, unless you want to increase the number of colors
neuronsIDs = randperm(n_cells, n_RandomNeurons);
% Random Neurons Colors
RandomNeuronsColors = {[1, 0, 0], [1, 1, 0], [0, 1, 0], [1, 0, 1], [0, 1, 1]}; % Red; Yellow; Green; Purple; Cyan

% Figure options
FontSize = 18;
MarkersSize = 6; % Matlab's default is 6
MarkersSize_RandomNeurons = 10;
FLAG_NormalizedPlots = 1; % Use manually normalized plots?

% Interpolate positions
if n_Interpolated_Frames > 0
    n_total_Frames_Interp = 4*n_sessions-n_Interpolated_Frames;
    n_total_Frames = 4*n_sessions;
    sessions_array = 1:n_sessions;
    sessions_array_ID = repelem(sessions_array, n_Interpolated_Frames+1);
    Activity_Normalized_Matrix_Interpolated = NaN(n_cells, n_states, n_total_Frames_Interp);
    
    t_interp = linspace(1, n_sessions, n_total_Frames_Interp);
    Activity_Normalized_Matrix = cat(3, Activity_Normalized{:});
    Selectivity_Normalized_Matrix = cat(3, Selectivity_Normalized{:});
    for i = 1:n_cells
        for j = 1:n_states
            Activity_Normalized_Matrix_Interpolated(i, j, :) = interp1(sessions_array, squeeze(Activity_Normalized_Matrix(i, j, :)), t_interp, 'linear');
            Selectivity_Normalized_Matrix_Interpolated(i, j, :) = interp1(sessions_array, squeeze(Selectivity_Normalized_Matrix(i, j, :)), t_interp, 'linear');
        end
    end
    last_frame = Activity_Normalized_Matrix_Interpolated(:, :, end);
    last_frames_repeated = repmat(last_frame, [1, 1, n_Interpolated_Frames]); % Create n_Interpolated_Frames copies
    Activity_Normalized_Matrix_Interpolated = cat(3, Activity_Normalized_Matrix_Interpolated, last_frames_repeated);
    Activity_Normalized = Activity_Normalized_Matrix_Interpolated;
    Activity_Normalized = squeeze(mat2cell(Activity_Normalized, n_cells, n_states, ones(1, n_total_Frames)));
    clear last_frame; clear last_frames_repeated
    last_frame = Selectivity_Normalized_Matrix_Interpolated(:, :, end);
    last_frames_repeated = repmat(last_frame, [1, 1, n_Interpolated_Frames]); % Create n_Interpolated_Frames copies
    Selectivity_Normalized_Matrix_Interpolated = cat(3, Selectivity_Normalized_Matrix_Interpolated, last_frames_repeated);
    Selectivity_Normalized = Selectivity_Normalized_Matrix_Interpolated;
    Selectivity_Normalized = squeeze(mat2cell(Selectivity_Normalized, n_cells, n_states, ones(1, n_total_Frames)));
else
    n_total_Frames_Interp = n_sessions;
    n_total_Frames = n_sessions;
end


%% Write Activity Triangulation Film
fprintf('\nWriting Film\n\n')

% Prepare .avi 
video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'
video_name = sprintf('%s - Activity Film', Opts.CellType);

% Initialize and open video object.
video_obj = VideoWriter(video_name, video_profile);
video_obj.FrameRate = 3; % Change to speed up or slow down the framerate

open(video_obj);
for i_frame = 1:n_total_Frames
    fig_tmp = figure('Renderer', 'painters', 'Position', [500 500 800 600]);
    Current_Session = sessions_array_ID(i_frame);
    Current_Activity = Activity_Normalized{i_frame};
    % Fix out of bounds objects
    Current_Activity(Current_Activity>=1) = 1;
    Current_Activity(Current_Activity<=0) = 0;
    
    % Manually normalize
    if FLAG_NormalizedPlots == 1
        Current_Activity = Current_Activity./sum(Current_Activity, 2);
    end
    
    % Get the activity of the random neurons to plot in a different color
    RandomNeuronActivity = Current_Activity(neuronsIDs, :);
    % Remove these neurons from the rest of the plot
    Current_Activity(neuronsIDs, :) = [];
    
    terplot(1);
    pause(0.05)
    h = ternaryc(Current_Activity(:, 1), Current_Activity(:, 2), Current_Activity(:, 3));
    set(h, 'MarkerSize', MarkersSize)
    hold on
    for i_neuron = 1:n_RandomNeurons
       CurrentRandomNeuron = RandomNeuronActivity(i_neuron, :);
       h = ternaryc(CurrentRandomNeuron(1), CurrentRandomNeuron(2), CurrentRandomNeuron(3)); 
       set(h, 'MarkerFaceColor', RandomNeuronsColors{i_neuron}, 'MarkerEdgeColor', RandomNeuronsColors{i_neuron}, 'MarkerSize', MarkersSize_RandomNeurons)
    end
    hold off
    pause(0.05)

    allTextHandles = findall(gca, 'Type', 'Text');
    delete(allTextHandles);
    text(-0.125, -0.05, 'Wake', 'FontSize', FontSize)
    text(1.025, -0.05, 'NREM', 'FontSize', FontSize)
    text(0.45, 0.915, 'REM', 'FontSize', FontSize)
    text(0.85, 0.85, sprintf('Session %d', Current_Session), 'FontSize', FontSize)
    current_frame = getframe(fig_tmp);
    writeVideo(video_obj, current_frame);
    pause(0.025)
    close
end

close(video_obj);
close % Close the figure used to produce the film.
fprintf('\nFilm saved successfully in .avi format.\n\n')




%% Write Activity Triangulation Film
fprintf('\nWriting Film\n\n')

% Prepare .avi 
video_profile = 'Uncompressed AVI'; % 'Uncompressed AVI' or 'Indexed AVI'
filenametxt_tmp = sprintf('Clustering %s Based', Opts.ClusteringVariable);
video_name = sprintf('%s - %s - Selectivity Film', Opts.CellType, filenametxt_tmp);

% Initialize and open video object.
video_obj = VideoWriter(video_name, video_profile);
video_obj.FrameRate = 3; % Change to speed up or slow down the framerate

open(video_obj);
for i_frame = 1:n_total_Frames
    fig_tmp = figure('Renderer', 'painters', 'Position', [500 500 800 600]);
    Current_Session = sessions_array_ID(i_frame);
    Current_Selectivity = Selectivity_Normalized{i_frame};
    
    % Fix out of bounds objects
    Current_Selectivity(Current_Selectivity>=1) = 1;
    Current_Selectivity(Current_Selectivity<=0) = 0;
    
    % Manually normalize
    if FLAG_NormalizedPlots == 1
        Current_Selectivity = Current_Selectivity./sum(Current_Selectivity, 2);
    end
    
    % Get the activity of the random neurons to plot in a different color
    RandomNeuronSelectivity = Current_Selectivity(neuronsIDs, :);
    % Remove these neurons from the rest of the plot
    Current_Selectivity(neuronsIDs, :) = [];
    
    terplot(1);
    pause(0.05)
    h = ternaryc(Current_Selectivity(:, 1), Current_Selectivity(:, 2), Current_Selectivity(:, 3));
    set(h, 'MarkerSize', MarkersSize)
    
    hold on
    for i_neuron = 1:n_RandomNeurons
        CurrentRandomNeuron = RandomNeuronSelectivity(i_neuron, :);
        h = ternaryc(CurrentRandomNeuron(1), CurrentRandomNeuron(2), CurrentRandomNeuron(3));
        set(h, 'MarkerFaceColor', RandomNeuronsColors{i_neuron}, 'MarkerEdgeColor', RandomNeuronsColors{i_neuron}, 'MarkerSize', MarkersSize_RandomNeurons)
    end
    hold off
    pause(0.05)
    
    allTextHandles = findall(gca, 'Type', 'Text');
    delete(allTextHandles);
    text(-0.125, -0.05, 'Wake', 'FontSize', FontSize)
    text(1.025, -0.05, 'NREM', 'FontSize', FontSize)
    text(0.45, 0.915, 'REM', 'FontSize', FontSize)
    text(0.85, 0.85, sprintf('Session %d', Current_Session), 'FontSize', FontSize)
    current_frame = getframe(fig_tmp);
    writeVideo(video_obj, current_frame);
    pause(0.025)
    close
end

close(video_obj);
close % Close the figure used to produce the film.
fprintf('\nFilm saved successfully in .avi format.\n\n')
