function plot_Triangular_Distance (Activity_Normalized)
% This function computes the euclidean distance of each cell
% (average cell activity) respect to the 3 points Awake = [1,0,0]; 
% NREM = [0,1,0]; REM = [0,0,1]. The distance is computed for each
% recording session.

% As a control and baseline, we assign a random position to each cell in the
% Awake/NREM/REM space for each recording session and repeat the analysis.

% The probability for a cell to change state in a different 
% recording session is therefore computed.

Awake = [1,0,0];
NREM = [0,1,0];
REM = [0,0,1];
[ncells, nstates] = size (Activity_Normalized{1, 1});
n_sessions = numel(Activity_Normalized);

Distance_Cell_Awake = NaN(ncells, n_sessions);
Distance_Cell_NREM = NaN(ncells, n_sessions);
Distance_Cell_REM = NaN(ncells, n_sessions);
for i_session = 1:n_sessions
    Activity_CurrentSession = Activity_Normalized{1, i_session};
    
    [ncells, ~] = size (Activity_CurrentSession);
    
    for i_cell = 1:ncells
        Distance_Cell_Awake(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - Awake);
        Distance_Cell_NREM(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - NREM);
        Distance_Cell_REM(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - REM);
    end
end
clear Activity_CurrentSession
% Compute the variability profile per cell over all sessions
CellAverageDistance_Awake = mean(Distance_Cell_Awake, 2, 'omitnan');
CellDistanceVariability_Awake = std(Distance_Cell_Awake, 0, 2, 'omitnan')./ sqrt(n_sessions);
CellAverageDistance_NREM = mean(Distance_Cell_NREM, 2, 'omitnan');
CellDistanceVariability_NREM = std(Distance_Cell_NREM, 0, 2, 'omitnan')./ sqrt(n_sessions);
CellAverageDistance_REM = mean(Distance_Cell_REM, 2, 'omitnan');
CellDistanceVariability_REM = std(Distance_Cell_REM, 0, 2, 'omitnan')./ sqrt(n_sessions);

% Baseline - Random position in the A-NR-R plane
Random_Activity_Normalized = rand(ncells, nstates, n_sessions);
Distance_Cell_Awake_Random = NaN(ncells, n_sessions);
Distance_Cell_NREM_Random = NaN(ncells, n_sessions);
Distance_Cell_REM_Random = NaN(ncells, n_sessions);
for i_session = 1:n_sessions
    Activity_CurrentSession = Random_Activity_Normalized(:, :, i_session);
    
    [ncells, ~] = size (Activity_CurrentSession);
    
    for i_cell = 1:ncells
        Distance_Cell_Awake_Random(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - Awake);
        Distance_Cell_NREM_Random(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - NREM);
        Distance_Cell_REM_Random(i_cell,i_session) = norm(Activity_CurrentSession(i_cell, :) - REM);
    end
end
clear Activity_CurrentSession
% Compute the variability profile per cell over all sessions
CellAverageDistance_Awake_Random = mean(Distance_Cell_Awake_Random, 2, 'omitnan');
CellDistanceVariability_Awake_Random = std(Distance_Cell_Awake_Random, 0, 2, 'omitnan')./ sqrt(n_sessions);
CellAverageDistance_NREM_Random = mean(Distance_Cell_NREM_Random, 2, 'omitnan');
CellDistanceVariability_NREM_Random = std(Distance_Cell_NREM_Random, 0, 2, 'omitnan')./ sqrt(n_sessions);
CellAverageDistance_REM_Random = mean(Distance_Cell_REM_Random, 2, 'omitnan');
CellDistanceVariability_REM_Random = std(Distance_Cell_REM_Random, 0, 2, 'omitnan')./ sqrt(n_sessions);

tmp = [CellAverageDistance_Awake_Random; CellAverageDistance_NREM_Random; CellAverageDistance_REM_Random];
CellAverageDistance_Random_Mean = mean(tmp, 'omitnan');
CellAverageDistance_Random_StE = std(tmp, 0, 'omitnan')./ sqrt(ncells);

tmp = [CellDistanceVariability_Awake_Random; CellDistanceVariability_NREM_Random; CellDistanceVariability_REM_Random];
CellDistanceVariability_Random_Mean = mean(tmp, 'omitnan');
CellDistanceVariability_Random_StE = std(tmp, 0, 'omitnan')./ sqrt(ncells);

Max_Distance = sqrt(2);
StateSelectivity_Awake = ones(size(CellAverageDistance_Awake));
StateSelectivity_Awake = 1 - (CellAverageDistance_Awake./Max_Distance);
StateSelectivity_NREM = ones(size(CellAverageDistance_NREM));
StateSelectivity_NREM = 1 - (CellAverageDistance_NREM./Max_Distance);
StateSelectivity_REM = ones(size(CellAverageDistance_REM));
StateSelectivity_REM = 1 - (CellAverageDistance_REM./Max_Distance);

StateSelectivity_Random = ones(size(tmp));
StateSelectivity_Random = 1 - (tmp./Max_Distance);
StateSelectivity_Random_Mean = mean(StateSelectivity_Random, 'omitnan');
StateSelectivity_Random_StE = std(StateSelectivity_Random, 0, 'omitnan')./ sqrt(ncells);


% StateSelectivity = StateSelectivity./max(StateSelectivity(:));



figure('units','normalized','outerposition',[0 0 1 1]);
%% Plot the average cells distance from each extreme
subplot(1, 3, 1);
hold on;
box on;
plot(CellAverageDistance_Awake, 'b', 'LineWidth', 2)
plot(CellAverageDistance_NREM, 'r', 'LineWidth', 2)
plot(CellAverageDistance_REM, 'g', 'LineWidth', 2)


yline(CellAverageDistance_Random_Mean, ':', 'LineWidth', 2);
x = [0 ncells];
y1 = CellAverageDistance_Random_Mean + CellAverageDistance_Random_StE;
y2 = CellAverageDistance_Random_Mean - CellAverageDistance_Random_StE;
yline(y1, ':', 'LineWidth', 1);
yline(y2, ':', 'LineWidth', 1);

fill([x fliplr(x)], ...
     [y1 y1 y2 y2], ...
     [0.6 0.6 0.6], ...
     'FaceAlpha', 0.3, ...
     'EdgeColor', 'none');

xlim(x);
axis square
title('Average Cell Distance from State extreme')


%% Plot the average cells state selectivity
subplot(1, 3, 2);
hold on;
box on;
plot(StateSelectivity_Awake, 'b', 'LineWidth', 2)
plot(StateSelectivity_NREM, 'r', 'LineWidth', 2)
plot(StateSelectivity_REM, 'g', 'LineWidth', 2)


yline(StateSelectivity_Random_Mean, ':', 'LineWidth', 2);
x = [0 ncells];
y1 = StateSelectivity_Random_Mean + StateSelectivity_Random_StE;
y2 = StateSelectivity_Random_Mean - StateSelectivity_Random_StE;
yline(y1, ':', 'LineWidth', 1);
yline(y2, ':', 'LineWidth', 1);

fill([x fliplr(x)], ...
     [y1 y1 y2 y2], ...
     [0.6 0.6 0.6], ...
     'FaceAlpha', 0.3, ...
     'EdgeColor', 'none');

xlim(x);
axis square
title('Average Cell State Selectivity')


%% Plot the average cells variability
subplot(1, 3, 3);
hold on;
box on;
plot(CellDistanceVariability_Awake, 'b', 'LineWidth', 2)
plot(CellDistanceVariability_NREM, 'r', 'LineWidth', 2)
plot(CellDistanceVariability_REM, 'g', 'LineWidth', 2)


yline(CellDistanceVariability_Random_Mean, ':', 'LineWidth', 2);
x = [0 ncells];
y1 = CellDistanceVariability_Random_Mean + CellDistanceVariability_Random_StE;
y2 = CellDistanceVariability_Random_Mean - CellDistanceVariability_Random_StE;
yline(y1, ':', 'LineWidth', 1);
yline(y2, ':', 'LineWidth', 1);

fill([x fliplr(x)], ...
     [y1 y1 y2 y2], ...
     [0.6 0.6 0.6], ...
     'FaceAlpha', 0.3, ...
     'EdgeColor', 'none');

xlim(x);
axis square
title('Average Cell Variability')

%% Save
if Opts.SaveFiguresAutomatically == 1
    if strcmpi(Opts.ClusteringVariable, 'Events_Rate')
        FileName = sprintf('%s - Triangular Plots - Single Cells State Selectivity', Opts.CellType, Opts.ClusteringMethod);
    elseif strcmpi(Opts.ClusteringVariable, 'Integrals_Frequency')
        FileName = sprintf('%s - Triangular Plots - Single Cells State Selectivity %d - Integrals Frequency based', Opts.CellType, Opts.ClusteringMethod);
    end
    FilePath = sprintf('%s\\%s', Opts.Dir_Figures, FileName);
    print(gcf, '-depsc', '-painters', strcat(FilePath, '.eps'))
    saveas(gcf, strcat(FilePath, '.jpg'))
    saveas(gcf, strcat(FilePath, '.fig'))
    close gcf
end

