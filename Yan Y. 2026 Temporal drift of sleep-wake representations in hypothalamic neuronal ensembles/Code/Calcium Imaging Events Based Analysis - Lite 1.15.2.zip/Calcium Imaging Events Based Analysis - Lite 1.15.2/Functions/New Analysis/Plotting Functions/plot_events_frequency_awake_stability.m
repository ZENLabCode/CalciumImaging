function plot_events_frequency_awake_stability (Events_Freq_Matrix_allMice_Baseline_1, Events_Freq_Matrix_allMice_Baseline_2, Events_Freq_Matrix_allMice_Baseline_3, Events_Freq_Matrix_allMice_Baseline_4, Events_Freq_Matrix_allMice_Baseline_5, Events_Freq_Matrix_allMice_Baseline_6, Events_Freq_Matrix_allMice_Baseline_7, Events_Freq_Matrix_allMice_Baseline_8, Events_Freq_Matrix_allMice_Baseline_9, Events_Freq_Matrix_allMice_SD_10, Events_Freq_Matrix_allMice_SD_11, Events_Freq_Matrix_allMice_SD_12, Events_Freq_Matrix_allMice_Recovery_13, Events_Freq_Matrix_allMice_Recovery_14, Events_Freq_Matrix_allMice_Recovery_15, Events_Freq_Matrix_allMice_Recovery_16, Events_Freq_Matrix_allMice_Recovery_17, Events_Freq_Matrix_allMice_Recovery_18, Events_Freq_Matrix_allMice_Recovery_19, Events_Freq_Matrix_allMice_Recovery_20, Events_Freq_Matrix_allMice_Recovery_21)


%% WIP

keyboard


% Control for missing cell (WIP patchwork)
[n_cells, ~] = size (Events_Freq_Matrix_allMice_SD_11);
if n_cells ~= 257
    Events_Freq_Matrix_allMice_SD_11(end+1, :) = NaN(1, 3);
end
[n_cells, ~] = size (Events_Freq_Matrix_allMice_Recovery_14);
if n_cells ~= 257
    Events_Freq_Matrix_allMice_Recovery_14(end+1, :) = NaN(1, 3);
end
[n_cells, ~] = size (Events_Freq_Matrix_allMice_Recovery_21);
if n_cells ~= 257
    warning ('Session 21 is missing from a mouse')
end

n_rows = 3;
n_columns = 3;

tmp_bigmatrix = ...
    [Events_Freq_Matrix_allMice_Baseline_1(:, 1), Events_Freq_Matrix_allMice_Baseline_2(:, 1), Events_Freq_Matrix_allMice_Baseline_3(:, 1),...
    Events_Freq_Matrix_allMice_Baseline_4(:, 1), Events_Freq_Matrix_allMice_Baseline_5(:, 1), Events_Freq_Matrix_allMice_Baseline_6(:, 1),...
    Events_Freq_Matrix_allMice_Baseline_7(:, 1), Events_Freq_Matrix_allMice_Baseline_8(:, 1), Events_Freq_Matrix_allMice_Baseline_9(:, 1),...
    Events_Freq_Matrix_allMice_SD_10(:, 1), Events_Freq_Matrix_allMice_SD_11(:, 1), Events_Freq_Matrix_allMice_SD_12(:, 1),...
    Events_Freq_Matrix_allMice_Recovery_13(:, 1), Events_Freq_Matrix_allMice_Recovery_14(:, 1), Events_Freq_Matrix_allMice_Recovery_15(:, 1),...
    Events_Freq_Matrix_allMice_Recovery_16(:, 1), Events_Freq_Matrix_allMice_Recovery_17(:, 1), Events_Freq_Matrix_allMice_Recovery_18(:, 1),...
    Events_Freq_Matrix_allMice_Recovery_19(:, 1), Events_Freq_Matrix_allMice_Recovery_20(:, 1)];

tmp_bigmatrix = ...
    [Events_Freq_Matrix_allMice_Baseline_1(:, 3), Events_Freq_Matrix_allMice_Baseline_2(:, 3), Events_Freq_Matrix_allMice_Baseline_3(:, 3),...
    Events_Freq_Matrix_allMice_Baseline_4(:, 3), Events_Freq_Matrix_allMice_Baseline_5(:, 3), Events_Freq_Matrix_allMice_Baseline_6(:, 3),...
    Events_Freq_Matrix_allMice_Baseline_7(:, 3), Events_Freq_Matrix_allMice_Baseline_8(:, 3), Events_Freq_Matrix_allMice_Baseline_9(:, 3),...
    Events_Freq_Matrix_allMice_SD_10(:, 3), Events_Freq_Matrix_allMice_SD_11(:, 3), Events_Freq_Matrix_allMice_SD_12(:, 3),...
    Events_Freq_Matrix_allMice_Recovery_13(:, 3), Events_Freq_Matrix_allMice_Recovery_14(:, 3), Events_Freq_Matrix_allMice_Recovery_15(:, 3),...
    Events_Freq_Matrix_allMice_Recovery_16(:, 3), Events_Freq_Matrix_allMice_Recovery_17(:, 3), Events_Freq_Matrix_allMice_Recovery_18(:, 3),...
    Events_Freq_Matrix_allMice_Recovery_19(:, 3), Events_Freq_Matrix_allMice_Recovery_20(:, 3)];

colormax = nanmax(tmp_bigmatrix);
freq_globalmax = nanmax(colormax);
freq_globalmin = 0;
ColorLimits = [freq_globalmin, freq_globalmax];



figure
D = pdist([Awake_AllRows(:, 1), Awake_AllRows(:, 2)]);
Dmatrix = squareform(D);
TEST = nanmean(D);
imagesc(Dmatrix)
figure
D = pdist([Awake_AllRows(:, 1), Awake_AllRows(:, 13)]);
Dmatrix = squareform(D);
TEST = nanmean(D);
imagesc(Dmatrix)


figure('units','normalized','outerposition',[0 0 1 1]);
FontSizeTitles = 18;
AxisFontSize = 14;
ColorBar_FontSize = 14;

% First Awake
tmp_bigmatrix = [Events_Freq_Matrix_allMice_Baseline_1(:, 1), Events_Freq_Matrix_allMice_Baseline_4(:, 1), Events_Freq_Matrix_allMice_Baseline_7(:, 1)];
Awake_AllRows = sortrows(tmp_bigmatrix, 1, 'descend');
% Euclidian Distance
for i = 1:20
    D(i)  = sqrt(nansum((Awake_AllRows(:, 1) - Awake_AllRows(:, i)) .^ 2));
end
subplot(n_rows, n_columns, 1)
% imagesc(Awake_AllRows(:, [1, 4, 7, 10, 13, 16, 19]))
imagesc(Awake_AllRows)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - Morning', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

tmp_bigmatrix = [Events_Freq_Matrix_allMice_Baseline_2(:, 1), Events_Freq_Matrix_allMice_Baseline_5(:, 1), Events_Freq_Matrix_allMice_Baseline_8(:, 1)];
Awake_AllRows = sortrows(tmp_bigmatrix, 1, 'descend');

subplot(n_rows, n_columns, 2)
imagesc(Awake_AllRows)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

tmp_bigmatrix = [Events_Freq_Matrix_allMice_Baseline_3(:, 1), Events_Freq_Matrix_allMice_Baseline_6(:, 1), Events_Freq_Matrix_allMice_Baseline_9(:, 1)];
Awake_AllRows = sortrows(tmp_bigmatrix, 1, 'descend');

subplot(n_rows, n_columns, 3)
imagesc(Awake_AllRows)
ax = gca;
ax.FontSize = AxisFontSize; 
title('Awake - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_1 = colorbar;
h_colorbar_1.Label.String = 'Events Frequency (Hz)';
h_colorbar_1.Label.FontSize = ColorBar_FontSize;


% Second NREM
subplot(n_rows, n_columns, 4)
imagesc(NREM_morning)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 5)
imagesc(NREM_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square

subplot(n_rows, n_columns, 6)
imagesc(NREM_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('NREM - 3pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_2 = colorbar;
h_colorbar_2.Label.String = 'Events Frequency (Hz)';
h_colorbar_2.Label.FontSize = ColorBar_FontSize;


% Third Raw - 5pm
subplot(n_rows, n_columns, 7)
imagesc(REM_morning)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
ylabel('Cell ID', 'FontSize', 18)
xticks([1, 2, 3])
xticklabels({'Baseline Day 1','Baseline Day 2','Baseline Day 3'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 8)
imagesc(REM_3pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline Day 1','Baseline Day 2','Baseline Day 3'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square


subplot(n_rows, n_columns, 9)
imagesc(REM_5pm)
ax = gca;
ax.FontSize = AxisFontSize; 
title('REM - 5pm', 'FontSize', FontSizeTitles)
xticks([1, 2, 3])
xticklabels({'Baseline Day 1','Baseline Day 2','Baseline Day 3'})
set(get(gca, 'XAxis'), 'FontWeight', 'bold');
caxis(ColorLimits)
axis square
h_colorbar_3 = colorbar;
h_colorbar_3.Label.String = 'Events Frequency (Hz)';
h_colorbar_3.Label.FontSize = ColorBar_FontSize;


h_suptitle = suptitle('Calcium Events rate per cell over days');
h_suptitle.FontSize = 28;
h_suptitle.FontWeight = 'bold';