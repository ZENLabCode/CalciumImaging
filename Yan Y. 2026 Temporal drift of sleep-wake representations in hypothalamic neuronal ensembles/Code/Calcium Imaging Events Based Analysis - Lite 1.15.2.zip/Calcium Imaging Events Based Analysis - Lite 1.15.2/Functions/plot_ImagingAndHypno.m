function plot_ImagingAndHypno(ExampleTrace, Hypnogram, calTime, ExampleSession2Plot,ExampleTrace2Plot)

%% ==============================
% Parameters
% ==============================
dsFactor = 1;          % downsampling factor (bin size)
spacingFactor = 1.2;   % spacing = spacingFactor * max peak-to-peak (raw units)

FontSize_ylabel = 16;
FontSize_xlabel = 16;
FontSize_title  = 28;

% ---- amplitude scale bar (dF/F)
scaleBar_dff = 20;    % <-- set the dF/F amplitude bar you want (raw units)

nTraces = size(ExampleTrace, 2);

%% ==============================
% Downsample data (bin-mean)
% ==============================
nSamples = length(calTime);
nBins    = floor(nSamples / dsFactor);

trace_trim = ExampleTrace(1:nBins*dsFactor, :);
time_trim  = calTime(1:nBins*dsFactor);
hypno_trim = Hypnogram(1:nBins*dsFactor);

trace_ds   = squeeze(mean(reshape(trace_trim, dsFactor, nBins, nTraces), 1));
calTime_ds = mean(reshape(time_trim, dsFactor, nBins), 1)';

% Hypnogram: take FIRST sample of each bin
Hypno_ds = hypno_trim(1:dsFactor:end);

%% ==============================
% Use RAW values (no normalization)
% ==============================
trace_raw = trace_ds;  % dF/F stays in original units

%% ==============================
% Vertical offsets for stacking (auto spacing)
% ==============================
ptp_each = max(trace_raw, [], 1) - min(trace_raw, [], 1);   % peak-to-peak per trace
max_ptp  = max(ptp_each);

if max_ptp == 0
    max_ptp = 1; % fallback if everything is flat
end

spacing = spacingFactor * max_ptp;
offsets = (nTraces:-1:1) * spacing;

%% ==============================
% Figure
% ==============================
figure('Units','normalized','OuterPosition',[0 0 1 1], 'Color','w');
hold on;

%% ==============================
% Determine y-limits based on raw traces + offsets
% ==============================
y_min = min(trace_raw, [], 'all') + offsets(end);
y_max = max(trace_raw, [], 'all') + offsets(1);
yPad  = 0.05 * (y_max - y_min);

y_low  = y_min - yPad;
y_high = y_max + yPad;

%% ==============================
% Hypnogram background blocks
% ==============================
col_awake = [0.70 0.85 1.00];   % light blue
col_nrem  = [0.75 0.90 0.75];   % light green
col_rem   = [1.00 0.95 0.70];   % light yellow

for i = 1:length(Hypno_ds)-1
    x = [calTime_ds(i) calTime_ds(i+1) calTime_ds(i+1) calTime_ds(i)];
    y = [y_low y_low y_high y_high];

    switch Hypno_ds(i)
        case 1, c = col_awake;
        case 2, c = col_nrem;
        case 4, c = col_rem;
        otherwise, continue
    end

    patch(x, y, c, 'EdgeColor','none');
end

%% ==============================
% Plot stacked traces (RAW)
% ==============================
for t = 1:nTraces
    yy = trace_raw(:, t) + offsets(t);
    plot(calTime_ds, yy, 'k', 'LineWidth', 1);

    % Cell number labels (left)
    text(calTime_ds(1) - 0.02*(calTime_ds(end)-calTime_ds(1)), offsets(t), ...
        sprintf('Cell# %d', ExampleTrace2Plot(t)), ...
        'HorizontalAlignment','right', ...
        'FontWeight','bold', ...
        'FontSize', FontSize_ylabel);
end

%% ==============================
% Axes formatting
% ==============================
set(gca, ...
    'FontSize', 14, ...
    'Color', 'none', ...
    'Box', 'off', ...
    'XGrid', 'off', ...
    'YGrid', 'off', ...
    'YTick', [], ...
    'XTick', [], ...          % remove x tick marks + numbers
    'XColor', 'none');        % hide x axis line completely

xlabel('');                  % remove x label
title(sprintf('Session %d',ExampleSession2Plot), 'FontWeight','bold', 'FontSize', FontSize_title)

xlim([calTime_ds(1) calTime_ds(end)]);
ylim([y_low y_high]);

%% ==============================
% Time scale bar (300 s)
% ==============================
scaleBar_s = 300;

xRange = calTime_ds(end) - calTime_ds(1);
yRange = y_high - y_low;

x0 = calTime_ds(end) - 0.1 * xRange - scaleBar_s;
y0 = y_low + 0.07 * yRange;

plot([x0 x0 + scaleBar_s], [y0 y0], 'k', 'LineWidth', 3)

text(x0 + scaleBar_s/2, y0 - 0.03*yRange, '300 s', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','top', ...
    'FontSize', 14, ...
    'FontWeight','bold');

%% ==============================
% dF/F amplitude scale bar (vertical)
% ==============================
% Place it near the same region as the time bar, but a bit to the right
x1 = x0 + 0.85*scaleBar_s;  % adjust if you want it elsewhere
y1 = y0;                    % bottom of the amplitude bar

plot([x1 x1], [y1 y1 + scaleBar_dff], 'k', 'LineWidth', 3)

text(x1 + 0.01*xRange, y1 + scaleBar_dff/2, sprintf('%.3g \dF/F0', scaleBar_dff), ...
    'HorizontalAlignment','left', ...
    'VerticalAlignment','middle', ...
    'FontSize', 14, ...
    'FontWeight','bold');

end

% function plot_ImagingAndHypno(ExampleTrace, Hypnogram, calTime, ExampleTrace2Plot)
% 
% %% ==============================
% % Parameters
% % ==============================
% dsFactor = 30;        % downsampling factor
% spacing  = 1.5;       % vertical spacing between stacked traces
% 
% FontSize_ylabel = 16;
% FontSize_xlabel = 16;
% FontSize_title  = 28;
% 
% nTraces = size(ExampleTrace, 2);
% 
% %% ==============================
% % Downsample data
% % ==============================
% nSamples = length(calTime);
% nBins    = floor(nSamples / dsFactor);
% 
% % Trim data to full bins
% trace_trim = ExampleTrace(1:nBins*dsFactor, :);
% time_trim  = calTime(1:nBins*dsFactor);
% hypno_trim = Hypnogram(1:nBins*dsFactor);
% 
% % Average traces within bins
% trace_ds = squeeze(mean(reshape(trace_trim, dsFactor, nBins, nTraces), 1));
% 
% % Average time within bins
% calTime_ds = mean(reshape(time_trim, dsFactor, nBins), 1)';
% 
% % Hypnogram: take FIRST sample of each bin
% Hypno_ds = hypno_trim(1:dsFactor:end);
% 
% %% ==============================
% % Normalize traces to same scale
% % ==============================
% trace_min  = min(trace_ds, [], 1);
% trace_max  = max(trace_ds, [], 1);
% trace_norm = (trace_ds - trace_min) ./ (trace_max - trace_min);
% 
% %% ==============================
% % Vertical offsets for stacking
% % ==============================
% offsets = (nTraces:-1:1) * spacing;
% 
% %% ==============================
% % Figure
% % ==============================
% figure('Units','normalized','OuterPosition',[0 0 1 1], 'Color','w');
% hold on;
% 
% %% ==============================
% % Hypnogram background blocks
% % ==============================
% col_awake = [0.70 0.85 1.00];   % light blue
% col_nrem  = [0.75 0.90 0.75];   % light green
% col_rem   = [1.00 0.95 0.70];   % light yellow
% 
% for i = 1:length(Hypno_ds)-1
%     x = [calTime_ds(i) calTime_ds(i+1) calTime_ds(i+1) calTime_ds(i)];
%     y = [0 0 offsets(1)+spacing offsets(1)+spacing];
% 
%     switch Hypno_ds(i)
%         case 1, c = col_awake;
%         case 2, c = col_nrem;
%         case 4, c = col_rem;
%         otherwise, continue
%     end
% 
%     patch(x, y, c, 'EdgeColor','none');
% end
% 
% %% ==============================
% % Plot stacked traces
% % ==============================
% for t = 1:nTraces
%     yy = trace_norm(:, t) + offsets(t);
%     plot(calTime_ds, yy, 'k', 'LineWidth', 1);
% 
%     % Cell number labels (left)
%     text(calTime_ds(1) - 0.02*(calTime_ds(end)-calTime_ds(1)), offsets(t), ...
%         sprintf('Cell# %d', ExampleTrace2Plot(t)), ...
%         'HorizontalAlignment','right', ...
%         'FontWeight','bold', ...
%         'FontSize', FontSize_ylabel);
% end
% 
% %% ==============================
% % Axes formatting
% % ==============================
% set(gca, ...
%     'FontSize', 14, ...
%     'Color', 'none', ...
%     'Box', 'off', ...
%     'XGrid', 'off', ...
%     'YGrid', 'off', ...
%     'YTick', []);
% 
% xlabel('Time [s]', 'FontWeight','bold', 'FontSize', FontSize_xlabel)
% title('Stacked Traces (Aligned)', 'FontWeight','bold', 'FontSize', FontSize_title)
% 
% xlim([calTime_ds(1) calTime_ds(end)]);
% ylim([0 offsets(1)+spacing]);
% 
% %% ==============================
% % Time scale bar (300 s)
% % ==============================
% scaleBar_s = 300;
% 
% xRange = calTime_ds(end) - calTime_ds(1);
% yRange = offsets(1) + spacing;
% 
% x0 = calTime_ds(end) - 0.1 * xRange - scaleBar_s;
% y0 = 0.05 * yRange;
% 
% plot([x0 x0 + scaleBar_s], [y0 y0], 'k', 'LineWidth', 3)
% 
% text(x0 + scaleBar_s/2, y0 - 0.03*yRange, '300 s', ...
%     'HorizontalAlignment','center', ...
%     'VerticalAlignment','top', ...
%     'FontSize', 14, ...
%     'FontWeight','bold');
% 
% 
% 
% 
% 
% 
% 
% end