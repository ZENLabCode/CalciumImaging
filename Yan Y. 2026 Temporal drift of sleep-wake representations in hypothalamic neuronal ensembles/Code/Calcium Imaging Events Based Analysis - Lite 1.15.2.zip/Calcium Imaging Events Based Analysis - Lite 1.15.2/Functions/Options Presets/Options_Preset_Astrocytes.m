function Opts = Options_Preset_Astrocytes (Opts)
% This function sets the options presets to treat Astrocytes.



% Sanity Check.
if strcmpi(Opts.FLAG_Cell_PreSet, 'Astrocytes') == 0
    warning ('The options are being set as Astrocytes, but they were requested to be set as something else.')
end

Opts.General.CellType = 'Astro';
% Find Peaks (with trace interpolation)
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Dist = 3*Opts.General.FrameRate;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinHeight = 4; % 4 Default. Controls the multiplier to the noise, for the minimum peak height.
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.NoiseMultiplier_MinProm = 3; % 1 Default. Controls the multiplier to the noise, for the minimum peak prominence.
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MinPeak_Width = 5*Opts.General.FrameRate;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.MaxPeak_Width = (32/Opts.SingleTraceAnalysis.Interp_step).*Opts.General.FrameRate;
% Get Peaks function
Opts.SingleTraceAnalysis.GetPeaks.event_end_thr_multiplier = 1;
Opts.SingleTraceAnalysis.GetPeaks.prePeak_interval_length = (6/Opts.SingleTraceAnalysis.Interp_step)*Opts.General.FrameRate; % Raise duration should be 200~300
Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff = 1; % In place of the first derivative, take its moving average. (note: 2nd derivative is in any case computed on the raw 1st derivative!)
Opts.SingleTraceAnalysis.GetPeaks.FLAG_SmoothDiff2 = 1; % In place of the second derivative, take its moving average.
Opts.SingleTraceAnalysis.GetPeaks.MovingAverageWinLength = 400; % Moving average - window length (note that the moving average is on the 2nd derivative of the interpolated trace)
% Get Peaks function - Integrity checks
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationComposite = (3); % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinDurationSingle = (1.3); % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxDurationComposite = 30; % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDuration = 2; % [s]
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MaxRiseDecayRatio = 0.4;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinBaseWidth = 10;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth = 5;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeNoiseMultiplier = 3; % 2 by default for DFoF
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude = 3; % 3 by default for DFoF, 0.5*(10^3) for raw. Value is changed in function of MinAmplitudeNoiseMultiplier*Noise.
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinPeakHeight = Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude./2; 
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeSingle = (0.5)*Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitude;
Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinIntegralSingle = (1/5)*Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinAmplitudeSingle*Opts.SingleTraceAnalysis.GetPeaks.IntCheck.MinHalfWidth; 

% Get Peaks function - Find Peaks in 2nd Derivative
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Dist = 5;
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_HeigthMultiplier = 0.75; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_PromMultiplier = 0.75; % Multiplier of the noise estimate of the 2nd derivative, to determine the threshold.
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MinPeak_Width = 0.5/Opts.SingleTraceAnalysis.Interp_step; % Was 1
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.MaxPeak_Width = 10/Opts.SingleTraceAnalysis.Interp_step;
Opts.SingleTraceAnalysis.GetPeaks.FindPeaksDiff2.Display = 0;
% Negative Peaks
Opts.SingleTraceAnalysis.NegativePeaks.Smoothing_Steps = 3; % 3 default
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinBaseWidth = 10;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinHalfWidth = 5;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinAmplitude = 1*10^3;
Opts.SingleTraceAnalysis.NegativePeaks.IntCheck.MinIntegral = 5;
Opts.SingleTraceAnalysis.NegativePeaks.FLAG_Display = 0;