function [Total_Transitions, Total_Transitions_Artifacts] = artifacts_check_allSessions (CalciumTraces_Clean_AllSessions, Hypnogram_AllSessions, Mouse_Names, Opts)
% This function gets the results for the artifacts check/analysis and the
% plot for each session.

transition_duration_in_seconds = 4;
Opts.transition_duration = transition_duration_in_seconds.*Opts.General.FrameRate; % [Seconds].*FrameRate

n_mice = numel(Mouse_Names);
n_sessions = numel(CalciumTraces_Clean_AllSessions);

Transition_Artifacts = cell(n_sessions, 1);
for i_session = 1:n_sessions
    current_mouse = Hypnogram_AllSessions(i_session).MouseName;
    current_session = Hypnogram_AllSessions(i_session).Session;
    tmp_FileName = sprintf('Artifact Plots - %s - Session %d', current_mouse, current_session);
    fprintf('\nAnalyzing Artifacts for - %s - Session %d\n', current_mouse, current_session);
    Transition_Artifacts{i_session} = artifacts_analysis(CalciumTraces_Clean_AllSessions{i_session}, Hypnogram_AllSessions(i_session), tmp_FileName, Opts);
end

% Count total artifacts per state transition
Total_Transitions.A2N = 0;
Total_Transitions.N2A = 0;
Total_Transitions.N2R = 0;
Total_Transitions.R2A = 0;
Total_Transitions.R2N = 0;
Total_Transitions_Artifacts.A2N = 0;
Total_Transitions_Artifacts.N2A = 0;
Total_Transitions_Artifacts.N2R = 0;
Total_Transitions_Artifacts.R2A = 0;
Total_Transitions_Artifacts.R2N = 0;
for i_session = 1:n_sessions
    Total_Transitions.A2N = Total_Transitions.A2N + Transition_Artifacts{i_session, 1}.A2N.N;
    Total_Transitions.N2A = Total_Transitions.N2A + Transition_Artifacts{i_session, 1}.N2A.N;
    Total_Transitions.N2R = Total_Transitions.N2R + Transition_Artifacts{i_session, 1}.N2R.N;
    Total_Transitions.R2A = Total_Transitions.R2A + Transition_Artifacts{i_session, 1}.R2A.N;
    Total_Transitions.R2N = Total_Transitions.R2N + Transition_Artifacts{i_session, 1}.R2N.N;
    
    Total_Transitions_Artifacts.A2N = Total_Transitions_Artifacts.A2N + Transition_Artifacts{i_session, 1}.A2N.N_Artifact;
    Total_Transitions_Artifacts.N2A = Total_Transitions_Artifacts.N2A + Transition_Artifacts{i_session, 1}.N2A.N_Artifact;
    Total_Transitions_Artifacts.N2R = Total_Transitions_Artifacts.N2R + Transition_Artifacts{i_session, 1}.N2R.N_Artifact;
    Total_Transitions_Artifacts.R2A = Total_Transitions_Artifacts.R2A + Transition_Artifacts{i_session, 1}.R2A.N_Artifact;
    Total_Transitions_Artifacts.R2N = Total_Transitions_Artifacts.R2N + Transition_Artifacts{i_session, 1}.R2N.N_Artifact;
end

% Plot total fraction of artifacts per state transition.
figure('units','normalized','outerposition', [0 0 1 1]);
FontSize_ylabel = 16;
FontSize_xlabel = 16;
FontSize_title = 28;

x_Location_Array = 1:2:8;
Data = [Total_Transitions.A2N - Total_Transitions_Artifacts.A2N, Total_Transitions_Artifacts.A2N; ...
    Total_Transitions.N2A - Total_Transitions_Artifacts.N2A, Total_Transitions_Artifacts.N2A; ...
    Total_Transitions.N2R - Total_Transitions_Artifacts.N2R, Total_Transitions_Artifacts.N2R; ...
    Total_Transitions.R2A - Total_Transitions_Artifacts.R2A, Total_Transitions_Artifacts.R2A];

bar (x_Location_Array, Data, 'stacked')
xlim([0, 8]);
xticks(x_Location_Array);
xtickangle(0)
xticklabels({'Wake2NREM', 'NREM2Wake', 'NREM2REM', 'REM2Wake'})
set(gca,'FontSize',14)
ylabel('Number or Transitions')
legend('Transitions without artifact', 'Transitions with artifact')
title(sprintf('Artifacts during transitions\nTotal of %d Mice\n Counting %d Seconds after Transition', n_mice, transition_duration_in_seconds))

grid on; axis square;
box on;