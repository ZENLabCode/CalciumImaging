function plot_ImagingAllAndHypno(CalciumTraces, Hypnogram, calTime)

figure('units','normalized','outerposition',[0 0 1 1]);

FontSize_ylabel = 16;
FontSize_xlabel = 16;
FontSize_title = 28;

[dim1, dim2] = size(CalciumTraces);

yyaxis left
plot(calTime, Hypnogram, 'b', 'LineWidth', 2);
axis([-inf, inf, 0.5, 4.5]);
ylabel('State', 'FontWeight', 'bold', 'FontSize', FontSize_ylabel)
yticks([1, 2, 4])
yticklabels({'Awake', 'NREM', 'REM'})
hold on;
yyaxis right
for i_trace = 1:dim2
    plot(calTime, CalciumTraces(:, i_trace) + i_trace*10, '-k');
end
set(gca,'FontSize',14)

yticks([])
% ylabel('Traces', 'FontSize', FontSize_ylabel)
xlabel('Time [s]', 'FontWeight', 'bold', 'FontSize', FontSize_xlabel)
title('Example Recording Session', 'FontWeight', 'bold', 'FontSize', FontSize_title)

grid on;

