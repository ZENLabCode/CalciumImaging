function [Opts, Events_AllSessions, Hypnogram_AllSessions, HypnoState, CalciumTraces_Clean_AllSessions, Mouse_Names, MouseCellsRecorded] = analyze_all_mouse_GUIversion(Opts)
% Main Analysis function. 
% To be started from the GUI.
% To change the options pre-sets, or change the options manually, visit the
% relative functions.

Dir_Main = pwd;
addpath(genpath(Dir_Main));

%% Set Options

% Unselectable options ========= WIP
PLACEHOLDEROPTION = 1;

Opts = Advanced_PeakDetection_Options (Opts);

Opts = Other_Options (Opts);

Opts.SingleTraceAnalysis.FrameRate = Opts.General.FrameRate;
Opts.SingleTraceAnalysis.CheckEveryTrace = 0;
Opts.SingleTraceAnalysis.FindPeaks_Opt.trace_interp.Display = 0;

Opts.SingleTraceAnalysis.GetPeaks.Save_EventShape = 1; % Save events shapes? Set to 0 to save lots of RAM

FLAG_Split_MiniscopeData = 0; % Split Christina Data in different folders+files


% Automatic options selection from the GUI
if Opts.General.Suite2p_Format == 1
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Pyramidal')
        fprintf('== Cell Type set to be Pyramidal ==\n\n');
        Opts = Options_Preset_Pyramidal_Suite2p (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (SOM)')
        fprintf('== Cell Type set to be Fast Spiking - SOM ==\n\n');
        Opts = Options_Preset_SOM_Suite2p (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (VIP)')
        fprintf('== Cell Type set to be Fast Spiking - VIP ==\n\n');
        Opts = Options_Preset_VIP_Suite2p (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (PV)')
        fprintf('== Cell Type set to be Fast Spiking - PV ==\n\n');
        Opts = Options_Preset_PV_Suite2p (Opts);
    end
    
    Opts.General.FolderNameDelimiter = '-';
    fprintf('Session Folders must be formatted as <Date>-Session_<SessionNumber>\nExample: 2021.08.14-Session_1\n\n');
else
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Pyramidal')
        fprintf('== Cell Type set to be Pyramidal ==\n\n');
        Opts = Options_Preset_Pyramidal (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (PV)')
        fprintf('== Cell Type set to be Fast Spiking - PV ==\n\n');
        Opts = Options_Preset_PV (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (SOM)')
        fprintf('== Cell Type set to be Fast Spiking - SOM ==\n\n');
        Opts = Options_Preset_SOM (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Fast Spiking (VIP)')
        fprintf('== Cell Type set to be Fast Spiking - VIP ==\n\n');
        Opts = Options_Preset_VIP (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Astrocytes')
        fprintf('== Cell Type set to be Astrocytes ==\n\n');
        Opts = Options_Preset_Astrocytes (Opts);
    end
    
    if strcmpi(Opts.FLAG_Cell_PreSet, 'Dendrites')
        fprintf('== Cell Type set to be Dendrites ==\n\n');
        Opts = Options_Preset_Dendrites (Opts);
    end
    
end



%% Initialize
warning('off', 'MATLAB:chckxy:IgnoreNaN'); % Ignore spline interpolation warning messages.

% Add Default Directories
try
    addpath(genpath('Z:\Lab_resources\calcium_imaging_toolbox'));
catch
    warning (sprintf('\nCould not find %s directory. Proceeding without it.\n\n', '"Z:\Lab_resources\calcium_imaging_toolbox"'))
end
if isempty (Dir_Main)
    Dir_Main = pwd;
end
Opts.Dir_Main = Dir_Main;

% Add Data Directories.
DUMMY = 1;
while DUMMY == 1
    fprintf('Please Specify the Data Folder.\n\n')
    Dir_Data = uigetdir(Dir_Main, 'Choose Data Folder');
    % fprintf('Please Specify the EEG Data Folder.')
    % Dir_EEGData = uigetdir(Dir_Main, 'Choose EEG Data Folder');
    
    if isempty (Dir_Data) || isscalar(Dir_Data)
        warning ('You did not select any Data Folder.')
    else
        DUMMY = 0; % Folder selected
    end
end
Opts.Dir_Data = Dir_Data;

% Figures Folder
Opts.Dir_Figures = sprintf('%s\\Figures', Dir_Main);
if exist(Opts.Dir_Figures, 'dir') == 0
    Opts.Dir_Figures = uigetdir(Dir_Main, 'Choose Output Figures Folder');
end

fprintf('\n---\nMain Folder Set as "%s".\n', Opts.Dir_Main);
fprintf('Data Folder Set as "%s".\n', Opts.Dir_Data);
fprintf('Figures Folder Set as "%s".\n---\n', Opts.Dir_Figures);


% Get Mice Names (from folder structure)
cd(Dir_Data); tmp_list = dir; cd(Dir_Main);
tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
Mouse_Folders = tmp_list;
clear tmp*

Mouse_Names = cell(numel(Mouse_Folders), 1);
Mouse_Sessions = zeros(numel(Mouse_Folders), 1);
i_mouse_name = 1;
for i_mouse = 1:numel(Mouse_Folders)
    Mouse_Names{i_mouse_name} = Mouse_Folders(i_mouse).name;
    tmp_folder = sprintf('%s\\%s', Dir_Data, Mouse_Names{i_mouse_name});
    cd(tmp_folder); tmp_list = dir; cd(Dir_Main);
    tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
    if ~isempty(tmp_list)
        Mouse_Sessions(i_mouse) = numel(tmp_list);
        i_mouse_name = i_mouse_name + 1;
    else
        error('Mouse "%s" contains no sessions.\n\n', Mouse_Names{i_mouse_name});
    end
end
n_mice = numel(Mouse_Names);
n_sessions = nansum(Mouse_Sessions);

% Split Miniscope data if needed, and get new Mouse Names + Sessions
if FLAG_Split_MiniscopeData == 1
    fprintf('\nSplitting Concatenated Miniscope Sessions into separate folders+files...\n...\n');
    for i_mouse = 1:n_mice
        MouseName = Mouse_Names{i_mouse};
        CurrentMouseFolder = sprintf('%s\\%s', Opts.Dir_Data, MouseName);
        cd(CurrentMouseFolder)
        SubFoldersList = dir;
        cd(Opts.Dir_Main)
        
        SubFoldersList(1:2) = []; % Remove "." and ".." elements
        SubFilesList = SubFoldersList;
        SubFoldersList([SubFoldersList.isdir] == 0) = []; % Remove non-folder elements
        SubFilesList([SubFilesList.isdir] == 1) = []; % Remove folder elements
        n_files = numel(SubFilesList);
        n_sessionfolders = numel(SubFoldersList);
        if n_files > 0 % If more than 1 file is detected in the main folder
            error('The mouse folder %s must not contain any files. Put the file for splitting in the subfolder "session_1"\n', MouseName)
        end
        if n_sessionfolders > 1 % If more than 1 folders are detected
            fprintf('More than one session folders for mouse %s.\n', MouseName)
            fprintf('Data was considered as already split.\n')
            continue
        end

        i_session = 1;
        [CalciumTraces, Hypnogram, ~, ~, ~, SessionStarts] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
        n_sessions = numel(SessionStarts - 1);
        SplitConcatMiniscopeData (CalciumTraces, Hypnogram, SessionStarts, n_sessions, MouseName, Opts);
    end
    clear CalciumTraces; clear Hypnogram; clear SessionStarts;
    clear SubFoldersList; clear n_sessionfolders; clear CurrentMouseFolder
    % Get again the sessions structure
    Mouse_Names = cell(numel(Mouse_Folders), 1);
    Mouse_Sessions = zeros(numel(Mouse_Folders), 1);
    i_mouse_name = 1;
    for i_mouse = 1:numel(Mouse_Folders)
        Mouse_Names{i_mouse_name} = Mouse_Folders(i_mouse).name;
        tmp_folder = sprintf('%s\\%s', Dir_Data, Mouse_Names{i_mouse_name});
        cd(tmp_folder); tmp_list = dir; cd(Dir_Main);
        tmp_list(~[tmp_list.isdir]) = []; tmp_list([1, 2]) = [];
        if ~isempty(tmp_list)
            Mouse_Sessions(i_mouse) = numel(tmp_list);
            i_mouse_name = i_mouse_name + 1;
        else
            error('Mouse "%s" contains no sessions.\n\n', Mouse_Names{i_mouse_name});
        end
    end
    n_mice = numel(Mouse_Names);
    n_sessions = nansum(Mouse_Sessions);
end



%% Analyze All Mice.
Removed_Candidate_Events = NaN(1, n_mice);
CalciumTraces_Clean_AllSessions = cell(1, n_sessions);
MouseCellsRecorded = NaN(1, n_mice);
Hypnogram_AllSessions = struct;

% Initializing waitbar.
prog_bar = waitbar(0, 'Cylon virus detected!', 'Name', 'Detecting events...',...
    'CreateCancelBtn',...
    'setappdata(gcbf,''canceling'',1)');

% 1st mouse separated to define "Events_AllMice" struct
i_mouse_ses = 1;
for i_mouse = 1:1
    % Get Mouse Name
    MouseName = Mouse_Names{i_mouse};
    Opts.SingleTraceAnalysis.MouseName = MouseName;
    n_current_sessions = Mouse_Sessions(i_mouse);
    fprintf('\n~~~~~~ Getting Calcium Events for Mouse "%s" ~~~~~~\n\n', MouseName);
    for i_session = 1:1
        % Update waitbar
        waitbar(0/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', 0, n_sessions));
        if getappdata(prog_bar, 'canceling')
            delete(prog_bar);
            warning('Operation cancelled by user.');
            return
        end
        % Load Calcium Data & EEG Classification (Hypnogram)
        CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session, Opts);
        Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
        
        % Make sure the Hypnogram is in the correct format
        [tmpdim1, tmpdim2] = size(Hypnogram);
        if tmpdim1 > tmpdim2
            Hypnogram = Hypnogram';
        end
        if Opts.Hypnogram.Set_Hypnogram_NaN == 1
            fprintf('The Hypnogram NaN values were cut.\n')
            Hypnogram(isnan(Hypnogram)) = [];
        end
        if Opts.Hypnogram.Cut_Hypnogram_0s == 1
            if numel(Hypnogram(Hypnogram == 0)) > 0
                fprintf('The Hypnogram 0 values were cut.\n')
                Hypnogram(Hypnogram == 0) = [];
            end
        end
        if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
            Hypnogram(Hypnogram == 3) = 4;
        end
        if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
            Hypnogram(Hypnogram == 5) = 4;
        end

        if Opts.Hypnogram.Resample_Hypno == 1
            [tmp_dim1, ~] = size(CalciumTraces);
            nnn = numel(Hypnogram)/tmp_dim1;
            yyy = downsample(Hypnogram, 100);
            Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
            Hypnogram(Hypnogram < 0) = 0;
            Hypnogram(Hypnogram == 0) = 1;
            if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
                Hypnogram(Hypnogram == 3) = 4;
            end
            if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
                Hypnogram(Hypnogram == 5) = 4;
            end
        end
        
        % Get the EEG classification time.
        calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
        
        % Set the Calcium Traces to NaN according to EMG artifacts
        if Opts.General.EMG_Artifact_Filter == 1 
            mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
            EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
            if exist (EMG_FileName, 'file') ~= 0
                load(EMG_FileName);
            else
                error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
            end
            [CalciumTraces, EMG, Artifacts_Trace] = EMG_filtering (CalciumTraces, Hypnogram, resampled_data_mV, SampRate, Opts);
            
            clear resampled_data_mV; clear SampRate
        end
        
        
        if PLACEHOLDEROPTION == 1
            mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
            EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
            if exist (EMG_FileName, 'file') ~= 0
                load(EMG_FileName);
            else
                error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
            end
            WakeScoring = EMG_Scoring(resampled_data_mV, Hypnogram, SampRate);
            
            clear resampled_data_mV; clear SampRate
        end
        
        % Analyze!
        fprintf('\n    Analyzing Session #%d\n', i_session);
        [Events_AllSessions, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, 1}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
        Removed_Candidate_Events(1) = n_removed;
        HypnoState(1).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
        HypnoState(1).MouseName = MouseName;
        HypnoState(1).Session = i_session;
            
        % Add Mouse Tag & Cell Tag
        for i_tmp = 1:numel(Events_AllSessions)
            Events_AllSessions(i_tmp).MouseTag = MouseName;
            Events_AllSessions(i_tmp).Session = i_session;
            Events_AllSessions(i_tmp).Composite.MouseTag = MouseName;
            Events_AllSessions(i_tmp).Composite.Session = i_session;
        end
        
        StateIsStable = StateLength(StateChanges);
        StateIsStable(StateIsStable < Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 0;
        StateIsStable(StateIsStable >= Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 1;
        
        Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
        if Opts.General.EMG_Artifact_Filter == 1
            Hypnogram_AllSessions(i_mouse_ses).EMG = EMG;
            Hypnogram_AllSessions(i_mouse_ses).Artifacts_Trace = Artifacts_Trace;
        end
        Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
        Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
        Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
        Hypnogram_AllSessions(i_mouse_ses).StateIsStable = StateIsStable;
        Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
        Hypnogram_AllSessions(i_mouse_ses).WakeScoring = WakeScoring;
        Hypnogram_AllSessions(i_mouse_ses).Session = 1;
    end

    
    if n_current_sessions > 1
        for i_session = 2:n_current_sessions
            % Update waitbar
            waitbar(i_mouse_ses/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', i_mouse_ses, n_sessions));
            if getappdata(prog_bar, 'canceling')
                delete(prog_bar);
                warning('Operation cancelled by user.');
                return
            end
            i_mouse_ses = i_mouse_ses + 1;
            % Load Calcium Data & EEG Classification (Hypnogram)
%             if strcmpi (Opts.General.CellType, 'Pyr')
%                 CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session);
%                 Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session);
%             elseif strcmpi (Opts.General.CellType, 'Astro')
%                 [CalciumTraces, Hypnogram, EEG1, EMG, TTL] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
%             end
            CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session, Opts);
            Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
            % Make sure the Hypnogram is in the correct format
            [tmpdim1, tmpdim2] = size(Hypnogram);
            if tmpdim1 > tmpdim2
                Hypnogram = Hypnogram';
            end
            if Opts.Hypnogram.Set_Hypnogram_NaN == 1
                fprintf('The Hypnogram NaN values were cut.\n')
                Hypnogram(isnan(Hypnogram)) = [];
            end
            if Opts.Hypnogram.Cut_Hypnogram_0s == 1
                if numel(Hypnogram(Hypnogram == 0)) > 0
                    fprintf('The Hypnogram 0 values were cut.\n')
                    Hypnogram(Hypnogram == 0) = [];
                end
            end
            if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
                Hypnogram(Hypnogram == 3) = 4;
            end
            if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
                Hypnogram(Hypnogram == 5) = 4;
            end
            if Opts.Hypnogram.Resample_Hypno == 1
                [tmp_dim1, ~] = size(CalciumTraces);
                nnn = numel(Hypnogram)/tmp_dim1;
                yyy = downsample(Hypnogram, 100);
                Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
                Hypnogram(Hypnogram < 0) = 0;
                Hypnogram(Hypnogram == 0) = 1;
                if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
                    Hypnogram(Hypnogram == 3) = 4;
                end
                if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
                    Hypnogram(Hypnogram == 5) = 4;
                end
            end
            
            % Get the EEG classification time.
            calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
            
            % Set the Calcium Traces to NaN according to EMG artifacts
            if Opts.General.EMG_Artifact_Filter == 1
                mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
                EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
                if exist (EMG_FileName, 'file') ~= 0
                    load(EMG_FileName);
                else
                    error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
                end
                [CalciumTraces, EMG, Artifacts_Trace] = EMG_filtering (CalciumTraces, Hypnogram, resampled_data_mV, SampRate, Opts);
                clear resampled_data_mV; clear SampRate
            end
            
            if PLACEHOLDEROPTION == 1
                mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
                EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
                if exist (EMG_FileName, 'file') ~= 0
                    load(EMG_FileName);
                else
                    error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
                end
                WakeScoring = EMG_Scoring(resampled_data_mV, Hypnogram, SampRate);
                
                clear resampled_data_mV; clear SampRate
            end
            
            % Analyze!
            fprintf('\n    Analyzing Session #%d\n\n', i_session);
            [Events_MouseAllTraces, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, i_mouse_ses}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
            Removed_Candidate_Events(1) = n_removed;
            HypnoState(i_mouse_ses).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
            HypnoState(i_mouse_ses).MouseName = MouseName;
            HypnoState(i_mouse_ses).Session = i_session;
            
            % Add Mouse Tag & Cell Tag
            for i_tmp = 1:numel(Events_MouseAllTraces)
                Events_MouseAllTraces(i_tmp).MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Session = i_session;
                Events_MouseAllTraces(i_tmp).Composite.MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Composite.Session = i_session;
            end
            Events_AllSessions = [Events_AllSessions, Events_MouseAllTraces];
            
            StateIsStable = StateLength(StateChanges);
            StateIsStable(StateIsStable < Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 0;
            StateIsStable(StateIsStable >= Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 1;

            Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
            if Opts.General.EMG_Artifact_Filter == 1
                Hypnogram_AllSessions(i_mouse_ses).EMG = EMG;
                Hypnogram_AllSessions(i_mouse_ses).Artifacts_Trace = Artifacts_Trace;
            end
            Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
            Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
            Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
            Hypnogram_AllSessions(i_mouse_ses).StateIsStable = StateIsStable;
            Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
            Hypnogram_AllSessions(i_mouse_ses).WakeScoring = WakeScoring;
            Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
            
            fprintf('\n    Completed Analysis for Session %d\n\n', i_session);
        end
    end
    [~, MouseCellsRecorded(i_mouse)] = size(CalciumTraces);
    fprintf('\n--- Completed Analysis for Mouse "%s" ---\n\n', MouseName);
end 

% All other mice
if n_mice > 1
    for i_mouse = 2:n_mice
        % Get Mouse Name
        MouseName = Mouse_Names{i_mouse};
        Opts.SingleTraceAnalysis.MouseName = MouseName;
        n_current_sessions = Mouse_Sessions(i_mouse);
        fprintf('\n~~~~~~ Getting Calcium Events for Mouse "%s" ~~~~~~\n\n', MouseName);
        for i_session = 1:n_current_sessions
            % Update waitbar
            waitbar(i_mouse_ses/n_sessions, prog_bar, sprintf('Detecting events from session: %d / %d', i_mouse_ses, n_sessions));
            if getappdata(prog_bar, 'canceling')
                delete(prog_bar);
                warning('Operation cancelled by user.');
                return
            end
        
            i_mouse_ses = i_mouse_ses + 1;
            Opts.SingleTraceAnalysis.CurrentSession = i_session;
            % Load Calcium Data & EEG Classification (Hypnogram)
%             if strcmpi (Opts.General.CellType, 'Pyr')
%                 CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session);
%                 Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session);
%             elseif strcmpi (Opts.General.CellType, 'Astro')
%                 [CalciumTraces, Hypnogram, EEG1, EMG, TTL] = Load_AstrocyteData (MouseName, Dir_Data, Dir_Main, i_session);
%             end
            CalciumTraces = Load_CalciumTraces (MouseName, Dir_Data, i_session, Opts);
            Hypnogram = Load_Hypnogram (MouseName, Dir_Data, i_session, Opts);
            % Make sure the Hypnogram is in the correct format
            [tmpdim1, tmpdim2] = size(Hypnogram);
            if tmpdim1 > tmpdim2
                Hypnogram = Hypnogram';
            end
            if Opts.Hypnogram.Set_Hypnogram_NaN == 1
                fprintf('The Hypnogram NaN values were cut.\n')
                Hypnogram(isnan(Hypnogram)) = [];
            end
            if Opts.Hypnogram.Cut_Hypnogram_0s == 1
                if numel(Hypnogram(Hypnogram == 0)) > 0
                    fprintf('The Hypnogram 0 values were cut.\n')
                    Hypnogram(Hypnogram == 0) = [];
                end
            end
            if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
                Hypnogram(Hypnogram == 3) = 4;
            end
            if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
                Hypnogram(Hypnogram == 5) = 4;
            end
            if Opts.Hypnogram.Resample_Hypno == 1
                [tmp_dim1, ~] = size(CalciumTraces);
                nnn = numel(Hypnogram)/tmp_dim1;
                yyy = downsample(Hypnogram, 100);
                Hypnogram = int32(resample(yyy, tmp_dim1, numel(yyy)));
                Hypnogram(Hypnogram < 0) = 0;
                Hypnogram(Hypnogram == 0) = 1;
                if Opts.Hypnogram.Set_Hypnogram_3to4 == 1
                    Hypnogram(Hypnogram == 3) = 4;
                end
                if Opts.Hypnogram.Set_Hypnogram_5to4 == 1
                    Hypnogram(Hypnogram == 5) = 4;
                end
            end
            
            % Get the EEG classification time.
            calTime = (1/Opts.General.FrameRate):(1/Opts.General.FrameRate):numel(Hypnogram)*(1/Opts.General.FrameRate);
            
            % Set the Calcium Traces to NaN according to EMG artifacts
            if Opts.General.EMG_Artifact_Filter == 1
                mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
                EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
                if exist (EMG_FileName, 'file') ~= 0
                    load(EMG_FileName);
                else
                    error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
                end
                [CalciumTraces, EMG, Artifacts_Trace] = EMG_filtering (CalciumTraces, Hypnogram, resampled_data_mV, SampRate, Opts);
                clear resampled_data_mV; clear SampRate
            end
            
            if PLACEHOLDEROPTION == 1
                mouse_folder = sprintf('%s\\%s', Dir_Data, MouseName);
                EMG_FileName = sprintf ('%s\\Session_%d\\EMG.mat', mouse_folder, i_session);
                if exist (EMG_FileName, 'file') ~= 0
                    load(EMG_FileName);
                else
                    error ('Could not find the EMG file %s. Make sure it exists in the correct folder structure and it is named "EMG.mat".', EMG_FileName)
                end
                WakeScoring = EMG_Scoring(resampled_data_mV, Hypnogram, SampRate);
                
                clear resampled_data_mV; clear SampRate
            end
            
            % Analyze!
            fprintf('\n    Analyzing Session #%d\n\n', i_session);
            [Events_MouseAllTraces, StateChanges, StateLength, n_removed, CalciumTraces_Clean_AllSessions{1, i_mouse_ses}] = analyze_single_mouse (CalciumTraces, Hypnogram, calTime, Opts);
            HypnoState(i_mouse_ses).Duration = analyze_hypnogram (Hypnogram, Opts.General.FrameRate);
            HypnoState(i_mouse_ses).MouseName = MouseName;
            HypnoState(i_mouse_ses).Session = i_session;
            Removed_Candidate_Events(i_mouse_ses) = n_removed;
            
            % Add Mouse Tag
            for i_tmp = 1:numel(Events_MouseAllTraces)
                Events_MouseAllTraces(i_tmp).MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Session = i_session;
                Events_MouseAllTraces(i_tmp).Composite.MouseTag = MouseName;
                Events_MouseAllTraces(i_tmp).Composite.Session = i_session;
            end
            fprintf('\n    Completed Analysis for Session %d\n\n', i_session);
            
            % Get results together
            Events_AllSessions = [Events_AllSessions, Events_MouseAllTraces];
            
            StateIsStable = StateLength(StateChanges);
            StateIsStable(StateIsStable < Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 0;
            StateIsStable(StateIsStable >= Opts.General.MinStableStateDuration.*Opts.General.FrameRate) = 1;
            
            Hypnogram_AllSessions(i_mouse_ses).Hypnogram = Hypnogram;
            if Opts.General.EMG_Artifact_Filter == 1
                Hypnogram_AllSessions(i_mouse_ses).EMG = EMG;
                Hypnogram_AllSessions(i_mouse_ses).Artifacts_Trace = Artifacts_Trace;
            end
            Hypnogram_AllSessions(i_mouse_ses).calTime = calTime;
            Hypnogram_AllSessions(i_mouse_ses).StateDuration_Array = StateLength;
            Hypnogram_AllSessions(i_mouse_ses).StateChanges = StateChanges;
            Hypnogram_AllSessions(i_mouse_ses).StateIsStable = StateIsStable;
            Hypnogram_AllSessions(i_mouse_ses).MouseName = MouseName;
            Hypnogram_AllSessions(i_mouse_ses).WakeScoring = WakeScoring;
            Hypnogram_AllSessions(i_mouse_ses).Session = i_session;
        end
        [~, MouseCellsRecorded(i_mouse)] = size(CalciumTraces);
        fprintf('\n--- Completed Analysis for Mouse "%s" ---\n\n', MouseName);
    end
end
n_sessions = numel(Hypnogram_AllSessions);
delete(prog_bar);
clear CalciumTraces



for i_tmp = 1:numel(Events_AllSessions)
    Events_AllSessions(i_tmp).CellTag = sprintf('%s_%d_%d', Events_AllSessions(i_tmp).MouseTag, Events_AllSessions(i_tmp).Session, Events_AllSessions(i_tmp).TraceNumber);
    Events_AllSessions(i_tmp).Composite.CellTag = Events_AllSessions(i_tmp).CellTag;
end
% Check which recordings have a specific state.
SessionHasState = SessionsCheckStates (Hypnogram_AllSessions, Opts);
Opts.n_mice = n_mice;
Opts.n_sessions = n_sessions;
Opts.Mouse_Sessions = Mouse_Sessions;
Opts.Mouse_N_Cells = MouseCellsRecorded;
Opts.SessionHasState = SessionHasState;

% Add info about duration of each state.
for i_session = 1:n_sessions
    n_states = numel(Hypnogram_AllSessions(i_session).StateChanges);
    for i_state = 1:n_states
        tmp_state_start = Hypnogram_AllSessions(i_session).StateChanges(i_state);
        if i_state ~= n_states
            tmp_state_end = Hypnogram_AllSessions(i_session).StateChanges(i_state+1) - 1;
        else
            tmp_state_end = numel(Hypnogram_AllSessions(i_session).Hypnogram);
        end
        Hypnogram_AllSessions(i_session).StateDuration(i_state) = tmp_state_end - tmp_state_start + 1;
        Current_State = Hypnogram_AllSessions(i_session).Hypnogram(Hypnogram_AllSessions(i_session).StateChanges(i_state));
        Hypnogram_AllSessions(i_session).StateType(i_state) = Current_State;
    end
end

clear tmp*
clear i_*

% Print Results Summary.
fprintf('Events detected = %d.\n', numel(Events_AllSessions));
fprintf('Events filtered = %d.\n', nansum(Removed_Candidate_Events));


if Opts.General.Save_Automatically
    
    if strcmpi(Opts.General.AutomaticSaveFileName, 'Automatic')
        AutomaticSave_FileName = datestr(datetime, 'yyyy-mm-dd');
        AutomaticSave_FileName_tmp = AutomaticSave_FileName;
        AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
        % Check for unique name
        DUMMY = 1;
        counter_FileName = 1;
        while DUMMY == 1
            
            if exist(AutomaticSave_FileName_tmp_2, 'file') ~= 0
                tmp_nametag = sprintf('_%d', counter_FileName);
                AutomaticSave_FileName = [AutomaticSave_FileName_tmp, tmp_nametag];
                AutomaticSave_FileName_tmp_2 = [AutomaticSave_FileName, '.mat'];
            else
                DUMMY = 0;
            end
            counter_FileName = counter_FileName + 1;
        end
        AutomaticSave_FileName = [AutomaticSave_FileName, '.mat'];
    else
        AutomaticSave_FileName = Opts.General.AutomaticSaveFileName;
    end
    
    if ~strcmpi(Opts.General.AutomaticSaveFolder, 'Automatic')
        Analysis_OutputFolder = Opts.General.AutomaticSaveFolder;
        if exist(Analysis_OutputFolder, 'dir') == 0
            Analysis_OutputFolder = uigetdir(Dir_Main, 'Select Analysis Output Folder');            
        end
        AutomaticSave_FileName = [Analysis_OutputFolder, '\', AutomaticSave_FileName];
    end
    
    fprintf('The Analysis results are being saved in %s.\n\n', AutomaticSave_FileName)
    
    save(AutomaticSave_FileName, 'Opts', 'Events_AllSessions', 'Hypnogram_AllSessions', ...
        'HypnoState', 'CalciumTraces_Clean_AllSessions', ...
        'Mouse_Names', 'MouseCellsRecorded', '-v7.3');
    
end


